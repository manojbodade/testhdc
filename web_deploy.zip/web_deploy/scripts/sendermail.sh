export in_title_mail=$1
export in_from_mail_id=$2
export in_mail_id=$3
export in_html_file_body=$4
export in_cc_mail_id=$5
export in_bcc_mail_id=$6
		
(echo "From: $in_from_mail_id"  ; echo "To: $in_mail_id"  ; echo "Cc: $in_cc_mail_id"  ; echo "Bcc: $in_bcc_mail_id"  ; echo "MIME-Version: 1.0"  ; echo "Subject: $in_title_mail  @`date`"   ; echo "Content-Type: text/html"   ; cat ${in_html_file_body}  ; ) | ${SEND_MAIL_HOME}/sendmail  -t
