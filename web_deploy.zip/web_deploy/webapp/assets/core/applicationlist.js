var al = {};
al.server = ko.observable('')
al.appName = ko.observable('')
al.sourceDatastore = ko.observable('')
al.targetDatastore = ko.observable('')
al.newApplication = ko.observable('')

al.getApplicationList = function(){
    var payload = {}

    $("#applicationlist").html('')
    $("#applicationlist").kendoGrid({
        dataSource: {
            transport: {
               read:function(option){
                    payload.filter = option.data.filter
                    payload.page = option.data.page
                    payload.pageSize = option.data.pageSize
                    payload.skip = option.data.skip
                    payload.sort = option.data.sort
                    payload.take = option.data.take
                    ajaxPost("/applicationlist/getapplicationlist", payload, function (res) {
                        option.success(res);
                    })
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
            },
            pageSize: 10,
            serverPaging: true,
            serverSorting: true,
            serverFiltering: true,
            sort: [{field:"Server",dir:"asc"},
                    {field:"AppName",dir:"asc"},
                    {field:"SourceDatastore",dir:"asc"},
                    {field:"TargetDatastore",dir:"asc"},
            ],
            schema: {
                data: function(res){
                    var data = (res.data.data ==  []) ? [] : res.data.data
                    return data
                },
                total:"data.totaldata",
                model: {
                    fields: {
                        Server: { type: "string" },
                        AppName: { type: "string" },
                        SourceDatastore: { type: "string" },
                        TargetDatastore: { type: "string" },
                    }
                }
            }
        },
        resizable: true,
        columns: [
            { field: "Server", title: "Server",},
            { field: "AppName", title: "Application",},
            { field: "SourceDatastore", title: "Source Datastore",},
            { field: "TargetDatastore", title: "Target Datastore",},
            { field: "Action", title: "Action", width:80, template:'<button type="button" class="btn btn-sm change-btn glyphicon glyphicon-pencil" onclick=\'al.popupApp(\"#=Server#\",\"#=AppName#\",\"#=SourceDatastore#\",\"#=TargetDatastore#\")\'></button>',},
        ],
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        sortable: true,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 1,
            pageSize: 20,
             pageSizes: [5, 10, 20],
        },
    });
}

al.popupApp = function(server, appname, sourcedatastore, targetdatastore){
    al.server(server)
    al.appName(appname)
    al.sourceDatastore(sourcedatastore)
    al.targetDatastore(targetdatastore)
    al.newApplication('')
    $('#appupdate').modal('show');
}

al.saveApp = function(){
    var payload = {
        ServerName      : al.server(),
        AppName         : al.appName(),
        SourceDatastore : al.sourceDatastore(),
        TargetDatastore : al.targetDatastore(),
        NewAppName      : al.newApplication(),
    }
    ajaxPost("/applicationlist/updateapplicationname", payload, function (res) {
    })
    $('#appupdate').modal('hide');
    swal("Success!", "", "success")
    al.getApplicationList()
}

$(function(){
    al.getApplicationList()
})