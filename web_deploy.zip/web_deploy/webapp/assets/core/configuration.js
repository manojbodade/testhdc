var ac = {};
ac.dbserver = ko.observable('')
ac.dbport = ko.observable('')
ac.dbname = ko.observable('')
ac.dbusername = ko.observable('')
ac.dbpassword = ko.observable('')

ac.sourcefile = ko.observable('')
ac.dumpfile = ko.observable('')
ac.timer = ko.observable('')

ac.emailrecipient = ko.observable([])
ac.emailsender = ko.observable('')
ac.smtpport = ko.observable('')
ac.emailusername = ko.observable('')
ac.emailpassword = ko.observable('')
ac.emailtitle = ko.observable('')
ac.emailtemplate = ko.observable('')
ac.emailperioddaily = ko.observable('')
ac.emailperioddailyList = ko.observable([{value:0,text:"0"},{value:1,text:"1"},{value:2,text:"2"},{value:3,text:"3"},
                                         {value:4,text:"4"},{value:5,text:"5"},{value:6,text:"6"},{value:7,text:"7"},
                                         {value:8,text:"8"},{value:9,text:"9"},{value:10,text:"10"},{value:11,text:"11"},
                                         {value:12,text:"12"},{value:13,text:"13"},{value:14,text:"14"},{value:15,text:"15"},
                                         {value:16,text:"16"},{value:17,text:"17"},{value:18,text:"18"},{value:19,text:"19"},
                                         {value:20,text:"20"},{value:21,text:"21"},{value:22,text:"22"},{value:23,text:"23"},])
ac.emailperiodmonthly = ko.observable('')
ac.index = ko.observable([])

ac.getData = function(){
    var payload = {}
    ajaxPost("/configuration/getconfigdata", payload, function (res) {
        var config = res.data;
        ac.dbserver(config.DBHost)
        ac.dbport(config.DBPort)
        ac.dbname(config.DatabaseName)
        ac.dbusername(config.DBUsername)
        ac.dbpassword(config.DBPassword)

        ac.sourcefile(config.ConsoleSourcePath)
        ac.dumpfile(config.ConsoleDumpPath)
        ac.timer(config.ConsoleTimer)
        
        var email = config.EmailRecipient.split(',')
        ac.emailrecipient(email)
        ac.emailsender(config.EmailSender)
        ac.smtpport(config.EmailSMTPPort)
        ac.emailusername(config.EmailUsername)
        ac.emailpassword(config.EmailPassword)
        ac.emailtitle(config.EmailHeader)
        ac.emailtemplate(config.EmailMessage)
        ac.emailperioddaily(config.EmailPeriodHour)
        ac.emailperiodmonthly(config.EmailPeriodDate)

        $.each(ac.emailrecipient(), function(i,v){
            if (i == 0) {
                $('#firstdata input[type=text]').val(v)
            }else{
                ac.addField(v)
            }
        });
    })
}

ac.addField = function(value){
    var index = []
    var num = Math.random().toString(36).substring(7)
    index.push(num)
    var $template = $('#optionTemplate'),
    $clone    = $template
                    .clone()
                    .removeClass('hide')
                    .attr('id', index)
                    .insertBefore($template),
    $option   = $clone.find('.option');
    $('#'+index+' input[type=text]').val(value)

    // $('#tabform').formValidation('addField', $option);
}

ac.removeField = function(el){
    var $row = $(el).parents('.form-group'),
    $option = $row.find('[name="option[]"]');
    $row.remove();
    // $('#surveyForm').formValidation('removeField', $option);
}

ac.cancelForm = function(){
    ac.dbserver('')
    ac.dbport('')
    ac.dbname('')
    ac.dbusername('')
    ac.dbpassword('')
    ac.sourcefile('')
    ac.dumpfile('')
    ac.timer('')
    ac.emailrecipient([])
    ac.emailsender('')
    ac.smtpport('')
    ac.emailusername('')
    ac.emailpassword('')
    ac.emailtitle('')
    ac.emailtemplate('')
    ac.emailperioddaily('')
    ac.emailperiodmonthly('')
    
    $(".option").map(function() {
        return $(this).val('');
    }).get();
}
ac.saveForm = function(){
    var texts= $(".option").map(function() {
        if ($(this).val() !== ""){
           return $(this).val();
        }
    }).get();
    ac.emailrecipient(texts)

    console.log(ac.dbserver(),ac.dbport(),ac.dbname(),ac.dbusername(),ac.dbpassword(),ac.sourcefile(),ac.dumpfile(),ac.timer(),ac.emailrecipient(),ac.emailsender(),ac.smtpport(),ac.emailusername(),ac.emailpassword(),ac.emailtitle(),ac.emailtemplate(),ac.emailperioddaily(),ac.emailperiodmonthly())
}

$(function(){
    // $("#sourcefile").kendoUpload();
    // $("#dumpfile").kendoUpload();
    $("#emailperiodmonthly").kendoDatePicker({
        format: "yyyy-MM-dd",
    })
    ac.getData()
})