var ac = {};
ac.btns = ko.observable(true)
ac.dbserver = ko.observable('')
ac.dbport = ko.observable('')
ac.dbname = ko.observable('')
ac.dbusername = ko.observable('')
ac.dbpassword = ko.observable('')
ac.appport = ko.observable('')
ac.excelgen = ko.observable('')
ac.exceldownload = ko.observable('')

ac.sourcefile = ko.observable('')
ac.dumpfile = ko.observable('')
ac.timer = ko.observable('')

ac.latency = ko.observable('')

ac.emailrecipient = ko.observable([])
ac.emailsender = ko.observable('')
ac.smtpport = ko.observable('')
ac.smtpserver = ko.observable('')
ac.emailusername = ko.observable('')
ac.emailpassword = ko.observable('')
ac.emailtitle = ko.observable('')
ac.emailtemplate = ko.observable('')
ac.emailperioddaily = ko.observable('')
ac.emailperioddailyList = ko.observable([{value:0,text:"0"},{value:1,text:"1"},{value:2,text:"2"},{value:3,text:"3"},
                                         {value:4,text:"4"},{value:5,text:"5"},{value:6,text:"6"},{value:7,text:"7"},
                                         {value:8,text:"8"},{value:9,text:"9"},{value:10,text:"10"},{value:11,text:"11"},
                                         {value:12,text:"12"},{value:13,text:"13"},{value:14,text:"14"},{value:15,text:"15"},
                                         {value:16,text:"16"},{value:17,text:"17"},{value:18,text:"18"},{value:19,text:"19"},
                                         {value:20,text:"20"},{value:21,text:"21"},{value:22,text:"22"},{value:23,text:"23"},])
ac.emailperiodmonthly = ko.observable('')


ac.ldapisenabled = ko.observable(false)
ac.ldaptype = ko.observable('')
ac.ldapservername = ko.observable('')
ac.ldaphost = ko.observable('')
ac.ldapbasedn = ko.observable('')
ac.ldapuserdn = ko.observable('')
ac.ldapuserauth = ko.observable('')
ac.ldapcertificate = ko.observable('')
ac.ldapbindusername = ko.observable('')
ac.ldapbindpassword = ko.observable('')
ac.ldapbindfilter = ko.observable('')
ac.ldapissecureskip = ko.observable(false)
ac.ldapdatafullname = ko.observable('')
ac.ldapdatafirstname = ko.observable('')
ac.ldapdatalastname = ko.observable('')
ac.ldapdatausercountry = ko.observable('')

ac.index = ko.observable([])

ac.purgetables = ko.observable([])
ac.purgetablesList = ko.observable([])
ac.purgedays = ko.observable(0)



ac.getData = function(){
    var payload = {}
    ajaxPost("/configuration/getconfigdata", payload, function (res) {
        var config = res.data;
        ac.dbserver(config.DBHost)
        ac.dbport(config.DBPort)
        ac.dbname(config.DatabaseName)
        ac.dbusername(config.DBUsername)
        ac.dbpassword(config.DBPassword)
        ac.appport(config.ApplicationPort)
        ac.excelgen(config.ExcelGenPath)
        ac.exceldownload(config.ExcelDonwloadPath)

        ac.sourcefile(config.ConsoleSourcePath)
        ac.dumpfile(config.ConsoleDumpPath)
        ac.timer(config.ConsoleTimer)

        ac.latency(config.LatencyThreshold)
        
        var email = config.EmailRecipient.split(',')
        ac.emailrecipient(email)
        ac.emailsender(config.EmailSender)
        ac.smtpport(config.EmailSMTPPort)
        ac.smtpserver(config.EmailSMTPServer)
        ac.emailusername(config.EmailUsername)
        ac.emailpassword(config.EmailPassword)
        ac.emailtitle(config.EmailHeader)
        ac.emailtemplate(config.EmailMessage)
        ac.emailperioddaily(config.EmailPeriodHour)
        ac.emailperiodmonthly(config.EmailPeriodDate)

        ac.ldapisenabled(config.LDAPIsEnabled)
        ac.ldaptype(config.LDAPType)
        ac.ldapservername(config.LDAPServerName)
        ac.ldaphost(config.LDAPHost)
        ac.ldapbasedn(config.LDAPBaseDN)
        ac.ldapuserdn(config.LDAPUserDN)
        ac.ldapuserauth(config.LDAPUserAuthAttr)
        var certificate = config.LDAPCertificate.split(',')
        ac.ldapcertificate(certificate)
        ac.ldapbindusername(config.LDAPBindUsername)
        ac.ldapbindpassword(config.LDAPBindPassword)
        ac.ldapbindfilter(config.LDAPBindFilter)
        ac.ldapissecureskip(config.LDAPIsInsecureSkipVerify)
        ac.ldapdatafullname(config.LDAPDataFullName)
        ac.ldapdatafirstname(config.LDAPDataFirstName)
        ac.ldapdatalastname(config.LDAPDataLastName)
        ac.ldapdatausercountry(config.LDAPDataUserCountry)

        $.each(ac.emailrecipient(), function(i,v){
            if (i == 0) {
                $('#firstdata input[type=text]').val(v)
            }else{
                ac.addField(v)
            }
        });
        $.each(ac.ldapcertificate(), function(i,v){
            if (i == 0) {
                $('#firstcertificate input[type=text]').val(v)
            }else{
                ac.addCertificate(v)
            }
        });
    })
}

ac.addField = function(value){
    var index = []
    var num = Math.random().toString(36).substring(7)
    index.push(num)
    var $template = $('#optionTemplate'),
    $clone    = $template
                    .clone()
                    .removeClass('hide')
                    .attr('id', index)
                    .insertBefore($template),
    $option   = $clone.find('.option');
    $('#'+index+' input[type=text]').val(value)

    // $('#tabform').formValidation('addField', $option);
}

ac.removeField = function(el){
    var $row = $(el).parents('.form-group'),
    $option = $row.find('[name="option[]"]');
    $row.remove();
    // $('#surveyForm').formValidation('removeField', $option);
}

ac.addCertificate = function(value){
    var index = []
    var num = Math.random().toString(36).substring(7)
    index.push(num)
    var $template = $('#certificateTemplate'),
    $clone    = $template
                    .clone()
                    .removeClass('hide')
                    .attr('id', index)
                    .insertBefore($template),
    $option   = $clone.find('.option');
    $('#'+index+' input[type=text]').val(value)

    // $('#tabform').formValidation('addField', $option);
}

ac.removeCertificate = function(el){
    var $row = $(el).parents('.form-group'),
    $option = $row.find('[name="option[]"]');
    $row.remove();
    // $('#surveyForm').formValidation('removeField', $option);
}

ac.cancelForm = function(){
    redirectUrl("/dashboard/default");
    // ac.dbserver('')
    // ac.dbport('')
    // ac.dbname('')
    // ac.dbusername('')
    // ac.dbpassword('')
    // ac.appport('')
    // ac.excelgen('')
    // ac.exceldownload('')
    // ac.sourcefile('')
    // ac.dumpfile('')
    // ac.timer('')
    // ac.emailrecipient([])
    // ac.emailsender('')
    // ac.smtpport('')
    // ac.smtpserver('')
    // ac.emailusername('')
    // ac.emailpassword('')
    // ac.emailtitle('')
    // ac.emailtemplate('')
    // ac.emailperioddaily('')
    // ac.emailperiodmonthly('')
    // ac.ldapisenabled(false)
    // ac.ldaptype('')
    // ac.ldapservername('')
    // ac.ldaphost('')
    // ac.ldapbasedn('')
    // ac.ldapuserdn('')
    // ac.ldapuserauth('')
    // ac.ldapcertificate('')
    // ac.ldapbindusername('')
    // ac.ldapbindpassword('')
    // ac.ldapbindfilter('')
    // ac.ldapissecureskip(false)
    // ac.ldapdatafullname('')
    // ac.ldapdatafirstname('')
    // ac.ldapdatalastname('')
    // ac.ldapdatausercountry('')
    
    // $(".option").map(function() {
    //     return $(this).val('');
    // }).get();
}

ac.saveForm = function(){
    var texts = $(".option").map(function() {
        if ($(this).val() !== ""){
           return $(this).val();
        }
    }).get();
    ac.emailrecipient(texts)

    var param = {
        DBHost : ac.dbserver(),
        DBPort : ac.dbport(),
        DatabaseName : ac.dbname(),
        DBUsername : ac.dbusername(),
        DBPassword : ac.dbpassword(),
        ApplicationPort: ac.appport(),
        ExcelGenPath : ac.excelgen(),
        ExcelDonwloadPath : ac.exceldownload(),
        ConsoleSourcePath : ac.sourcefile(),
        ConsoleDumpPath : ac.dumpfile(),
        ConsoleTimer : ac.timer(),
        LatencyThreshold : ac.latency(),
        EmailRecipient : ac.emailrecipient(),
        EmailSender : ac.emailsender(),
        EmailSMTPPort : ac.smtpport(),
        EmailSMTPServer: ac.smtpserver(),
        EmailUsername : ac.emailusername(),
        EmailPassword : ac.emailpassword(),
        EmailHeader : ac.emailtitle(),
        EmailMessage : ac.emailtemplate(),
        EmailPeriodHour : ac.emailperioddaily(),
        EmailPeriodDate : ac.emailperiodmonthly(),
        LDAPIsEnabled : ac.ldapisenabled(),
        LDAPType : ac.ldaptype(),
        LDAPServerName : ac.ldapservername(),
        LDAPHost : ac.ldaphost(),
        LDAPBaseDN : ac.ldapbasedn(),
        LDAPUserDN : ac.ldapuserdn(),
        LDAPUserAuthAttr : ac.ldapuserauth(),
        LDAPCertificate : ac.ldapcertificate(),
        LDAPBindUsername : ac.ldapbindusername(),
        LDAPBindPassword : ac.ldapbindpassword(),
        LDAPBindFilter : ac.ldapbindfilter(),
        LDAPIsInsecureSkipVerify : ac.ldapissecureskip(),
        LDAPDataFullName : ac.ldapdatafullname(),
        LDAPDataFirstName : ac.ldapdatafirstname(),
        LDAPDataLastName : ac.ldapdatalastname(),
        LDAPDataUserCountry : ac.ldapdatausercountry(),
    }
    ajaxPost("/configuration/saveconfigdata", param, function (res) {
    })
}

function isenabled(check){
    check(!check());
}

function issecureskip(check){
    check(!check());
}

ac.runConsole = function(){
    var payload = {

    }
    ajaxPost("/configuration/runconsoleadhoc", payload, function (res) {
    })
}

ac.getTables = function(){
    var payload = {

    }
    ajaxPost("/configuration/gettablenames", payload, function (res) {
        var tables = [];
        $.each(res.data.data, function(i,v){
            tables.push({text:v, value:v})
        });
        ac.purgetablesList(tables);
    })
}

ac.purge = function(){
    var payload = {
        Days: parseInt(ac.purgedays()),
        Tables: ac.purgetables(),
    }
    
    swal({
      title: "Are you sure to proceed?",
      text: "This process will delete all data recursively.",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      closeOnConfirm: false
    },
    function(){
        ajaxPost("/configuration/rundatapurging", payload, function (res) {
        })
      swal("Deleted!", "", "success");
    });
}

$(function(){
    // $("#sourcefile").kendoUpload();
    // $("#dumpfile").kendoUpload();
    $("#emailperiodmonthly").kendoDatePicker({
        format: "yyyy-MM-dd",
    })
    ac.getData()
    ac.getTables()
})