var adm = {}

adm.searchGrid = ko.observable(false);
adm.addUser = ko.observable(false);
adm.listUser = ko.observableArray([]);
adm.listGroup = ko.observableArray([]);
adm.logintype = ko.observable(0);
adm.logintypeList = ko.observableArray([{value:0,text:"Basic"},{value:1,text:"LDAP"}]);
adm.listSession = ko.observableArray([]);
adm.dataChangePassword = ko.observable({oldPassword: '', newPassword: '', reNewPassword: ''});
adm.addNewUser =  ko.observable({bankid:'', fullname: '', email: '', groups: '', enable:true, userid: '', logintype:0});
adm.valueGroup = ko.observable();
adm.valueGetUserSingle = ko.observable();
adm.editUserText = ko.observable(false);
adm.valueEnable = ko.observable('');
adm.loadingProcess = ko.observable(false);
adm.listTab = ko.observableArray([]);

adm.logintype.subscribe(function(v){
  return parseInt(v);
});

function changeInputtype(id){
  $input = $("#input-"+id);
  $addon = $("#addon-"+id);
  if($input.attr("type").toLowerCase() == 'password'){
    $input.attr("type", "text")
    $addon.find("i").addClass('fa-eye-slash').removeClass('fa-eye');
  }else{
    $input.attr("type", "password")
    $addon.find("i").addClass('fa-eye').removeClass('fa-eye-slash');
  }
}

adm.createGridUserAdministration = function(){

  var url = "/aclsysadmin/getdatauser";   

  ajaxPost(url, {}, function (datas){
    console.log(datas)
    adm.listUser(datas.Data)
    $("#gridUserAdministrator").html("");
    $("#gridUserAdministrator").kendoGrid({
      dataSource: {
        data: adm.listUser(),
        pageSize : 15,
        schema: {
          model: {
            fields: {
              // loginid: { type: "number" }
            }
          }
        }
      },
      columns: [{
        field:"loginid",
        title:'Login ID',
        template: '<a href="javascript:adm.EditNewUserLogin(\'#:_id#\')"> #:loginid #</a>',
        headerAttributes: {
          "class": "align-left"
        }
      },{
        field:"fullname",
        title:'Full Name',
        headerAttributes: {
          "class": "align-left"
        }
      },{
        field:"email",
        title:'Email ID',
        headerAttributes: {
          "class": "align-left"
        }
      },{
        field:"logintype",
        title:'Login Type',
        // template: '#if(logintype == 0) { # Basic # } else { # LDAP # }#',
        template: function(e){
          console.log(e.logintype)
          if (e.logintype == 0) {
            return 'Basic'
          }else{
            return 'LDAP'
          }
        },
        headerAttributes: {
          "class": "align-left"
        }
      },{
        field:"enable",
        title:'Status',
        template: '#if(enable == true) { # Active # } else { # In-Active # }#',
        headerAttributes: {
          "class": "align-left"
        }
      }],
      sortable: true,
      filterable: {
        extra:false, 
        operators: {
          string: {
            contains: "Contains",
            startswith: "Starts with",
            eq: "Is equal to",
            neq: "Is not equal to",
            doesnotcontain: "Does not contain",
            endswith: "Ends with"
          },
        }
      },
      pageable: {
          refresh: true,
          pageSizes: true,
          buttonCount: 5
      },
      excel: {
        fileName: "User List Name.xlsx",
        allPages: true
      },
    });
  }) 
}

adm.createGridGroupAdministrator = function(){
  var url = "/aclsysadmin/getdatagroup"; 
  ajaxPost(url, {}, function (datas){
    adm.listGroup(datas.Data)
    $("#gridGroupAdministrator").html("");
    $("#gridGroupAdministrator").kendoGrid({
      dataSource: {
        data: adm.listGroup(),
        pageSize : 10 
      },
      columns: [{
        field:"title",
        title:'Title'
      },{
        field:"enable",
        title:'Enable'
      },{
        field:"grouptype",
        title:'Group type'
      }],
      sortable: true,
      pageable: {
        refresh: true,
        pageSizes: true,
        buttonCount: 5
      },
      excel: {
        fileName: "Group List Name.xlsx",
        allPages: true
      },
      height: 380,
    });
  });

  setTimeout(function() {
    $("#gridGroupAdministrator").html("");
    $("#gridGroupAdministrator").kendoGrid({
      dataSource: {
        data: adm.listGroup(),
        pageSize : 10 
        },
        columns: [{
          field:"title",
          title:'Title'
        },{
          field:"enable",
          title:'Enable'
        },{
          field:"grouptype",
          title:'Group type'
        }],
      sortable: true,
      pageable: {
        refresh: true,
        pageSizes: true,
        buttonCount: 5
      },
      excel: {
        fileName: "Group List Name.xlsx",
        allPages: true
      },
      height: 380,
    });
  }, 1000);
}

adm.createGridSessionAdministrator = function(){
  var url = "/aclsysadmin/getdatasession"; 

  ajaxPost(url, {}, function (datas){
    adm.listSession(datas.Data)
    $("#gridSessionAdministrator").html("");
    $("#gridSessionAdministrator").kendoGrid({
      dataSource: {
       data: adm.listSession(),
       pageSize : 20,
       sort:{field: "created", dir: "desc"}  
      },
      columns: [{
        field:"loginid",
        title:'Login ID'
      },{
        field:"created",
        title:'Created',
        template: "#= kendo.toString(kendo.parseDate(created, 'yyyy-MM-ddTHH:mm:ss'), 'yyyy-MM-dd HH:mm:ss') #"
      },{
        field:"expired",
        title:'Expired',
        template: "#= kendo.toString(kendo.parseDate(expired, 'yyyy-MM-ddTHH:mm:ss'), 'yyyy-MM-dd HH:mm:ss') #"
      }],
      sortable: true,
      pageable: {
          refresh: true,
          pageSizes: true,
          buttonCount: 5
      },
      excel: {
        fileName: "Session List Name.xlsx",
        allPages: true
      },
      height: 450,
    });
  });
}

adm.currentChangePassword = function(){
  var validator = $("#formCurrentResetPassword").data("kendoValidator");
  
  if(validator ==  undefined){
    validator = $("#formCurrentResetPassword").kendoValidator().data("kendoValidator");
  }

  var url = "/acluser/savenewpassword"
  var sessionid = localStorage.getItem("sessionid")  

  if (validator.validate()){
    if ( adm.dataChangePassword().newPassword !==  adm.dataChangePassword().reNewPassword ){
      swal("Error!", "New Password not match with re New Password", "error")
      return;
    }  
    var param = {
      newpassword: adm.dataChangePassword().newPassword,
      sessionid: sessionid,
      oldpassword:adm.dataChangePassword().oldPassword  
    }
    ajaxPost(url, param, function (datas){ 
      if (datas.IsError == false){
         swal("Success","Change Passsword Success", "success");
         $("#newPassword").val('');
         $("#reNewPassword").val('');
         $("#oldPassword").val('');
      }else {
        swal("Error!", datas.Message.replace("Acl.ChangePassword: ",""))
        $("#newPassword").val('');
        $("#reNewPassword").val('');
        $("#oldPassword").val('');
      }
    }); 
  }else {
    swal("Error!","Unable to validate process", "error"); 
  }
}

adm.resetFormUser = function(){
  $("#loginid").val('');
  $("#fullname").val('');
  $("#email").val('');
  $("#password").val('');
  $("#repassword").val('');
  $("#group").data("kendoMultiSelect").value([]);
  $("#titleCreateUser").text("Create New User");
  $("#bank-id").prop("disabled", false)
  adm.addNewUser({loginid: '', fullname: '', email: '', password: '', rePassword:'', groups: '', enable:true, userid: '', logintype:0});
}

adm.EditNewUserLogin = function(id){
  var url = "/aclsysadmin/getdatauser";   

  var param = {
    userid : id
  };

  ajaxPost(url, param, function (datas){
    adm.valueGetUserSingle(datas.Data[0])
    adm.addUser(true);
    $("#titleCreateUser").text("Edit User");
    if ($("#titleCreateUser").text() == "Edit User"){
      $("#bank-id").prop("disabled", true)
    } 
    setTimeout(function() {
      $("#bank-id").val(adm.valueGetUserSingle().loginid);  
    }, 100);    
    adm.logintype(parseInt(adm.valueGetUserSingle().logintype) );

    $("#fullname").val(adm.valueGetUserSingle().fullname);
    $("#email").val(adm.valueGetUserSingle().email);
    $("#password").val(adm.valueGetUserSingle().password);
    $("#repassword").val(adm.valueGetUserSingle().password);
    $("#group").data("kendoMultiSelect").value(adm.valueGetUserSingle().groups);
    adm.valueGroup(adm.valueGetUserSingle().groups);

    $('#status').bootstrapSwitch('state',adm.valueGetUserSingle().enable);

    adm.addNewUser({loginid: adm.valueGetUserSingle().loginid, fullname: adm.valueGetUserSingle().fullname, email: adm.valueGetUserSingle().email, password: adm.valueGetUserSingle().password, rePassword:adm.valueGetUserSingle().password, groups: adm.valueGetUserSingle().groups, enable:adm.valueGetUserSingle().enable, userid: adm.valueGetUserSingle()._id, logintype:adm.valueGetUserSingle().logintype });
  })
}

adm.DeleteUserLogin = function(id, name){
  adm.loadingProcess(true);
  var url = '/aclsysadmin/savedatauser';
  var param = {
    userid: id,
    enable: false
  }

  swal({
    title: "Are you sure?",   
    text: "You will deleted user "+name,   
    type: "warning",   
    showCancelButton: true,   
    confirmButtonColor: "#DD6B55",   
    confirmButtonText: "Yes, delete it!",   
    cancelButtonText: "No, cancel!",   
    closeOnConfirm: false,   
    closeOnCancel: false }, 
    function(isConfirm){   
      if (isConfirm) {     
          ajaxPost(url, param, function (res){
          if (!res.IsError){
            adm.loadingProcess(false);
            swal("Deleted!", "user "+name+" has been deleted.", "success"); 
            adm.createGridUserAdministration(); 
          }else {
            adm.loadingProcess(false);
            swal("Error!",res.Message, "error"); 
          }
        }); 
      } else {
        adm.loadingProcess(false);     
        swal("Cancelled",'', "error");   
      } 
    });
}

adm.AddNewUserLogin = function(){
  var url = '/aclsysadmin/savedatauser';
  adm.addNewUser().groups = adm.valueGroup();
  
  var validator = $("#formAddUser").data("kendoValidator");
  if ( validator == undefined){
    validator = $("#formAddUser").kendoValidator().data("kendoValidator");
  }

  if (validator.validate()){
    if (adm.addNewUser().password !== adm.addNewUser().rePassword ){
      swal("Error!", 'Password did not match', "error");
      return;
    }
    var statusValue = $("#status").prop("checked");
    if (statusValue){
      adm.addNewUser().enable = statusValue   
    }else {
      adm.addNewUser().enable = false   
    
    }
    adm.addNewUser().logintype = parseInt( adm.logintype() ); 
     // parseInt( adm.addNewUser().logintype );
     console.log('aaaa',adm.logintype())
    adm.loadingProcess(true) 
    ajaxPost(url, adm.addNewUser(), function (res){
      if (!res.IsError){
        adm.loadingProcess(false)
        swal("Success","New User Profile Created", "success"); 
        adm.resetFormUser();
        adm.createGridUserAdministration();
        adm.addUser(false);  
        adm.resetFormUser();
      }else {
        adm.loadingProcess(false)
        swal("Error!",res.Message, "error"); 
      }
    });
  }else {
    swal("Error!","Unable to validate process", "error"); 
  }
}

adm.resetPasswordByAdmin = function(){
  adm.loadingProcess(true);
  var url = '/aclsysadmin/resetpasswordbyadmin';
  var param = {
    email: adm.addNewUser().email,
    baseurl: window.location.origin,
    loginid: adm.addNewUser().loginid
  };
  
  ajaxPost(url, param, function (res){
    if (!res.IsError){
      adm.loadingProcess(false);
      swal("Success","Please check your email", "success");  
    }else {
      adm.loadingProcess(false);
      swal("Error",res.Message, "error");  
    }
  }); 
}

adm.getListTab = function(){
  ajaxPost("/aclsysadmin/getlisttab",{} , function (res){
    var data = res.Data;
    $.each(data,function(index,value){
     for(var i=0; i<(data.length-1); i++){
        if(data[i].index > data[i+1].index){
          var old = data[i+1];
          data[i+1] = data[i]
          data[i] = old
        }
      }
    })
    adm.listTab(data)
  })
}

adm.export = function(){
  return function(){
    var grid = $("#gridUserAdministrator").data("kendoGrid");
    grid.saveAsExcel();
    var payload = {
      Type : "Aclsysadmin User Grid"
    }
    ajaxPost("/analyticuser/downloadlog", payload, function (res){
    })
    }
}

adm.exportsession = function(){
  return function(){
    var grid = $("#gridSessionAdministrator").data("kendoGrid");
    grid.saveAsExcel();
    var payload = {
      Type : "Aclsysadmin Session Grid"
    }
    ajaxPost("/analyticuser/downloadlog", payload, function (res){
    })
  }
}

$(function(){
  adm.createGridUserAdministration();
  adm.createGridGroupAdministrator();
  adm.createGridSessionAdministrator();
  adm.getListTab();
  // model.bootstrapSwitchSelector('#filter')  
})