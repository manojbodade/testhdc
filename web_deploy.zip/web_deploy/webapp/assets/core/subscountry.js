var sc = {};

sc.getSubscriptionCountry = function(){
    var payload = {}

    $("#gridsubscountry").html('')
    $("#gridsubscountry").kendoGrid({
        dataSource: {
            transport: {
               read:function(option){
                    ajaxPost("/subscountry/getsubscriptioncountry", payload, function (res) {
                        var datas = res.data.data
                        option.success(datas);
                    })
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
            },
            pageSize: 10,
            schema: {
                model: {
                    fields: {
                    Host: {
                        type: "string",
                        editable: false
                    },
                    Subscription: {
                        type: "string",
                        editable: false
                    },
                    Source_Datastore: {
                        type: "string",
                        editable: false
                    },
                    Target_Datastore: {
                        type: "string",
                        editable: false
                    },
                    Country: {
                        type: "string",
                    },
                    }
                }
            },
            change: function(e) {
                if (e.action == 'itemchange') {
                    payload = {
                        // subsCountryParam:{
                            //_id            : e.items[0]._id,
                            Host            : e.items[0].Host,
                            Subscription    : e.items[0].Subscription,
                            SourceDatastore : e.items[0].Source_Datastore,
                            TargetDatastore : e.items[0].Target_Datastore,
                            Country         : e.items[0].Country,
                        // },
                        // configParam:{
                        //     DBHost            :  sc.dbserver(),
                        //     DBPort            :  sc.dbport(),
                        //     DatabaseName      :  sc.dbname(),
                        //     DBUsername        :  sc.dbusername(),
                        //     DBPassword        :  sc.dbpassword(),
                        //     // ApplicationPort   :
                        //     ConsoleSourcePath : sc.sourcefile(),
                        //     ConsoleDumpPath   : sc.dumpfile(),
                        //     ConsoleTimer      : sc.timer(),
                        //     EmailRecipient    : sc.emailrecipient(),
                        //     EmailSender       : sc.emailsender(),
                        //     // EmailSMTPServer   : 
                        //     EmailSMTPPort     : sc.smtpport(),
                        //     EmailUsername     : sc.emailusername(),
                        //     EmailPassword     : sc.emailpassword(),
                        //     EmailHeader       : sc.emailtitle(),
                        //     EmailMessage      : sc.emailtemplate(),
                        //     // EmailPeriodDate   : 
                        //     EmailPeriodHour   : sc.emailperioddaily(),
                        //     LatencyThreshold  : sc.latency(),
                        // }
                    }
                    ajaxPost("/subscountry/savesubscriptioncountry", payload, function (res) {
                    })
                }
            },
        },
        columns: [
            { field: "Host", title: "Host",},
            { field: "Subscription", title: "Subscription",},
            { field: "Source_Datastore", title: "Src Datastore",},
            { field: "Target_Datastore", title: "Tgt Datastore",},
            { field: "Country", title: "Country",
              attributes: {
                class: "field-ellipsis",
              },
              template: function(e){
                return e.Country
              }
            },
        ],
        sortable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        pageable: {
          refresh: true,
          pageSizes: true,
          buttonCount: 5
        },
        editable: true
    });
}

$(function(){
    sc.getSubscriptionCountry()
})