var sc = {};
sc.host = ko.observable('')
sc.subscription = ko.observable('')
sc.sourceDatastore = ko.observable('')
sc.targetDatastore = ko.observable('')
sc.country = ko.observable('')
sc.newCountry = ko.observable('')
sc.getSubscriptionCountry = function(){
    var payload = {}

    $("#gridsubscountry").html('')
    $("#gridsubscountry").kendoGrid({
        dataSource: {
            transport: {
               read:function(option){
                    payload.filter = option.data.filter
                    payload.page = option.data.page
                    payload.pageSize = option.data.pageSize
                    payload.skip = option.data.skip
                    payload.sort = option.data.sort
                    payload.take = option.data.take
                    ajaxPost("/subscountry/getsubscriptioncountry", payload, function (res) {
                        option.success(res);
                    })
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
            },
            pageSize: 10,
            serverPaging: true,
            serverSorting: true,
            serverFiltering: true,
            sort: [{field:"Host",dir:"asc"},
                    {field:"Subscription",dir:"asc"},
                    {field:"Source_Datastore",dir:"asc"},
                    {field:"Target_Datastore",dir:"asc"},
                    {field:"Country",dir:"asc"},
            ],
            schema: {
                data: function(res){
                    var data = (res.data.data ==  []) ? [] : res.data.data
                    return data
                },
                total:"data.totaldata",
                model: {
                    fields: {
                        Host: { type: "string" },
                        Subscription: { type: "string" },
                        Source_Datastore: { type: "string" },
                        Target_Datastore: { type: "string" },
                        Country: { type: "string" },
                    }
                }
            }
        },
        resizable: true,
        columns: [
            { field: "Host", title: "Host",},
            { field: "Subscription", title: "Subscription",},
            { field: "Source_Datastore", title: "Src Datastore",},
            { field: "Target_Datastore", title: "Tgt Datastore",},
            { field: "Country", title: "Country",},
            { field: "Action", title: "Action", width:80, template:'<button type="button" class="btn btn-sm change-btn glyphicon glyphicon-pencil" onclick=\'sc.popupCountry(\"#=Host#\",\"#=Subscription#\",\"#=Source_Datastore#\",\"#=Target_Datastore#\")\'></button>',},
        ],
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        sortable: true,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 1,
            pageSize: 20,
             pageSizes: [5, 10, 20],
        },
    });
}

sc.popupCountry = function(host, subscription, sourcedatastore, targetdatastore){
    sc.host(host)
    sc.subscription(subscription)
    sc.sourceDatastore(sourcedatastore)
    sc.targetDatastore(targetdatastore)
    sc.newCountry('')
    $('#countryupdate').modal('show');
}

sc.saveCountry = function(){
    var payload = {
        Host            : sc.host(),
        Subscription    : sc.subscription(),
        SourceDatastore : sc.sourceDatastore(),
        TargetDatastore : sc.targetDatastore(),
        Country         : sc.country(),
        NewCountry      : sc.newCountry(),
    }
    ajaxPost("/subscountry/savesubscriptioncountry", payload, function (res) {
    })
    $('#countryupdate').modal('hide');
    swal("Success!", "", "success")
    sc.getSubscriptionCountry()
}

$(function(){
    sc.getSubscriptionCountry()
})