package main

import (
	//"bufio"
	now "eaciit/scb-cdc/webapp/webext"
	// v2016 "eaciit/scb-cdc/webapp/webext"
	. "eaciit/scb-cdc/webapp/helper"
	"fmt"
	"github.com/eaciit/knot/knot.v1"
	//"log"
	"net/http"
	"os"
	//"path/filepath"
	"strings"
)

var (
	wd = func() string {
		d, _ := os.Getwd()
		return d + "/"
	}()
)

func main() {
	fmt.Println("Starting Application")

	routes := map[string]knot.FnContent{
		"/": func(k *knot.WebContext) interface{} {
			// rURL := k.Request.URL.String()
			prefix := now.Version

			// if strings.Contains(rURL, v2016.Version) {
			// prefix = v2016.Version
			// }

			if k.Session("username") == nil && k.Session("sessionid") == nil {
				if !strings.Contains(k.Request.Header.Get("referer"), "/acluser/default") {
					http.Redirect(k.Writer, k.Request, fmt.Sprintf("/%s/acluser/default", prefix), 301)
				}
			} else {
				http.Redirect(k.Writer, k.Request, fmt.Sprintf("/%s/dashboard/default", prefix), 301)
			}
			return true
		},
	}

	config := ReadConfig()
	runPort := config["runport"] + ":" + config["port"]
	appConf := knot.AppContainerConfig{Address: runPort}
	knot.DefaultOutputType = knot.OutputTemplate
	knot.StartContainerWithFn(&appConf, routes)
}

// func ReadConfig() map[string]string {
// 	ret := make(map[string]string)
// 	fileph := filepath.Join(wd, "conf", "app.conf")
// 	file, err := os.Open(fileph)
// 	if err == nil {
// 		defer file.Close()

// 		reader := bufio.NewReader(file)
// 		for {
// 			line, _, e := reader.ReadLine()
// 			if e != nil {
// 				break
// 			}
// 			sval := strings.Split(string(line), "=")
// 			ret[sval[0]] = sval[1]

// 		}
// 	} else {
// 		log.Println(err.Error())
// 	}

// 	return ret
// }
