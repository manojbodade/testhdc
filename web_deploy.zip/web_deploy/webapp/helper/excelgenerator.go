package helper

import (
	tk "github.com/eaciit/toolkit"
	xlsx "github.com/tealeg/xlsx"
	//"io/ioutil"
	//"strings"
	"time"
)

func GenerateExcel(header []string, data []tk.M) (filepath string, e error) {
	//wdpath, _ := os.Getwd()
	//path := strings.Replace(wdpath+"/conf/app.conf", "consoleapps", "webapp", -1)
	cfg := ReadConfig()

	var file *xlsx.File
	var sheet *xlsx.Sheet
	var row *xlsx.Row
	var cell *xlsx.Cell

	file = xlsx.NewFile()
	sheet, e = file.AddSheet("Sheet1")
	ErrorHandling(e, false)

	//header
	if len(header) > 0 {
		row = sheet.AddRow()
		for _, field := range header {
			cell = row.AddCell()
			cell.Value = field
		}
	}

	//data row
	if len(data) > 0 {
		for _, datarow := range data {
			row = sheet.AddRow()
			for _, title := range header {
				cell = row.AddCell()
				cell.SetValue(datarow.Get(title))
			}
		}
	}
	filename := time.Now().Format("20060102_150405") + ".xlsx"
	filepath = cfg["excelgenpath"] + "/" + filename
	e = file.Save(filepath)
	ErrorHandling(e, false)
	filepath = cfg["exceldownloadpath"] + "/" + filename

	return
}
