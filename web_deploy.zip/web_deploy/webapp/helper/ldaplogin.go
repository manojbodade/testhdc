package helper

import (
	"crypto/tls"
	"crypto/x509"
	"errors"
	"fmt"
	"io/ioutil"
	"strings"
	"time"

	"github.com/eaciit/ldap"
	"github.com/eaciit/toolkit"
	tk "github.com/eaciit/toolkit"
)

type LDAPDataList struct {
	LDAPDataFullName    string
	LDAPDataFirstName   string
	LDAPDataLastName    string
	LDAPDataUserCountry string
}

func TryToLoginUsingLDAP(username, password string) (bool, LDAPDataList, error) {
	type ForgetMe struct{}
	cfg := ReadConfig()

	configLDAPHost := strings.TrimSpace(cfg["LDAPHost"])
	configLDAPServerName := strings.TrimSpace(cfg["LDAPServerName"])
	configLDAPType := strings.TrimSpace(cfg["LDAPType"])
	configLDAPUserAuthAttr := strings.TrimSpace(cfg["LDAPUserAuthAttr"])
	configLDAPUserDN := strings.TrimSpace(cfg["LDAPUserDN"])
	configLDAPBaseDN := strings.TrimSpace(cfg["LDAPBaseDN"])
	configLDAPBindUsername := strings.TrimSpace(cfg["LDAPBindUsername"])
	configLDAPBindPassword := strings.TrimSpace(cfg["LDAPBindPassword"])
	configLDAPBindFilter := strings.TrimSpace(cfg["LDAPBindFilter"])
	configLDAPIsInsecureSkipVerify := strings.ToLower(strings.TrimSpace(cfg["LDAPIsInsecureSkipVerify"])) == "true"
	configLDAPCertificate := cfg["LDAPCertificate"]

	// if configLDAPBindPassword != "" {
	// 	decoded, _ := Decode(configLDAPBindPassword)
	// 	configLDAPBindPassword = decoded
	// }

	ldapData := LDAPDataList{}
	ldapData.LDAPDataFullName = cfg["LDAPDataFullName"]
	ldapData.LDAPDataFirstName = cfg["LDAPDataFirstName"]
	ldapData.LDAPDataLastName = cfg["LDAPDataLastName"]
	ldapData.LDAPDataUserCountry = cfg["LDAPDataUserCountry"]

	ldapConfig := tk.M{}
	ldapConfig.Set("host", configLDAPHost)
	ldapConfig.Set("basedn", configLDAPBaseDN)

	loginConf := tk.M{}
	loginConf.Set("address", configLDAPHost)
	loginConf.Set("basedn", configLDAPBaseDN)
	if configLDAPType != "" {
		tk.Println("#Type :", configLDAPType)
		tk.Println("#ServerName : ", configLDAPServerName)
		tk.Println("#Address : ", configLDAPHost)
		tk.Println("#BaseDN : ", configLDAPBaseDN)
		if configLDAPUserAuthAttr != "" {
			tk.Println("#UserAuthAttrLDAP : ", configLDAPUserAuthAttr)
		}
		if configLDAPUserDN != "" {
			tk.Println("#UserDNLDAP : ", configLDAPUserDN)
		}
		tk.Println("#Username : ", username)
		loginConf.Set("type", configLDAPType)
		tlsconfig := tls.Config{}
		if configLDAPServerName != "" {
			tlsconfig.ServerName = configLDAPServerName
		}
		tlsconfig.InsecureSkipVerify = configLDAPIsInsecureSkipVerify
		tlsconfig.Certificates = []tls.Certificate{}
		caCertPool := x509.NewCertPool()
		for x, c := range strings.Split(configLDAPCertificate, ",") {
			if c == "," {
				continue
			}

			file, err := ioutil.ReadFile(c)
			if err != nil {
				err = errors.New(fmt.Sprintf("Found error : %v", err.Error()))
			}

			s := caCertPool.AppendCertsFromPEM(file)
			tk.Println("Certificate ", (x + 1), " # Added : ", s)
		}
		tlsconfig.RootCAs = caCertPool
		loginConf.Set("tlsconfig", &tlsconfig)
	}
	rawUsername := username
	UserAuthAttr := "CN"
	if configLDAPUserAuthAttr != "" {
		UserAuthAttr = configLDAPUserAuthAttr
		username = UserAuthAttr + "=" + username
	}
	if configLDAPUserDN != "" {
		if configLDAPUserAuthAttr == "" {
			username = UserAuthAttr + "=" + username
		}
		username = username + "," + configLDAPUserDN
	}

	ldapUserDNComponent := strings.Split(configLDAPUserDN, ",")
	if len(ldapUserDNComponent) > 0 {
		if ldapUserDNComponent[0] == rawUsername {
			//username = configLDAPUserDN
			username = UserAuthAttr + "=" + ldapUserDNComponent[0]
		}
	}

	// if IsAdminLogin {
	// 	username = BaseDNLDAP
	// }

	isSuccess, information, err := checkloginldap(username, password, loginConf, configLDAPBindUsername, configLDAPBindPassword, configLDAPUserAuthAttr, configLDAPUserDN, configLDAPBindFilter, ldapData)
	return isSuccess, information, err
}

func getldapconn(address string, config toolkit.M) *ldap.Connection {
	l := new(ldap.Connection)

	switch config.GetString("type") {
	case "ssl":
		l = ldap.NewSSLConnection(address, config.Get("tlsconfig", nil).(*tls.Config))
	case "tls":
		l = ldap.NewTLSConnection(address, config.Get("tlsconfig", nil).(*tls.Config))
	default:
		l = ldap.NewConnection(address)
	}

	return l
}

func checkloginldap(username string, password string, loginconf toolkit.M, BindUsernameLDAP string, BindPasswordLDAP string, UserAuthAttrLDAP string, UserDNLDAP string, BindFilterLDAP string, LDAPData LDAPDataList) (cond bool, information LDAPDataList, err error) {
	toolkit.Println("# Connecting to LDAP")
	cond = false
	connectTime := time.Now()
	address := loginconf.GetString("address")
	l := getldapconn(address, loginconf)
	defer l.Close()
	err = l.Connect()
	if err != nil {
		toolkit.Println("#ERROR Connecting to LDAP", err.Error())
		return
	}
	if strings.Trim(BindUsernameLDAP, " ") != "" {
		// Bind Through Config
		// defer l.Unbind(BindUsernameLDAP, BindPasswordLDAP)
		err = l.Bind(BindUsernameLDAP, BindPasswordLDAP)
	} else {
		// defer l.Unbind(username, password)
		err = l.Bind(username, password)
	}
	if strings.Trim(BindUsernameLDAP, " ") != "" && err == nil {
		// from Login FORM
		// defer l.Unbind(username, password)
		err = l.Bind(username, password)
		if err == nil {
			cond = true
		} else {
			toolkit.Println("#ERROR Binding to LDAP with username : ", username, " - ", err.Error())
		}
	} else {
		if err == nil {
			cond = true
		} else {
			toolkit.Println("#ERROR Binding to LDAP  with username : ", username, " - ", err.Error())
		}
	}

	toolkit.Println("# Closing LDAP Connection")
	toolkit.Println("# Connection Time : ", time.Since(connectTime).Seconds(), "s")

	return

	if cond {
		toolkit.Println("# Getting some Information from LDAP ")
		filter := ""
		if strings.Trim(UserAuthAttrLDAP, " ") == "" {
			filter = "(CN=" + username + ")"
		} else {
			filter = "(dn=" + username + ")"
		}
		attributes := []string{}
		if LDAPData.LDAPDataFullName != "" {
			attributes = append(attributes, LDAPData.LDAPDataFullName)
		}
		if LDAPData.LDAPDataFirstName != "" {
			attributes = append(attributes, LDAPData.LDAPDataFirstName)
		}
		if LDAPData.LDAPDataLastName != "" {
			attributes = append(attributes, LDAPData.LDAPDataLastName)
		}
		// if LDAPData.LDAPDataLastName != "" {
		// 	attributes = append(attributes, LDAPData.LDAPDataLastName)
		// }

		// attributes := []string{"cn", "givenName"}
		toolkit.Println("BaseDN : ", loginconf.GetString("basedn"))
		toolkit.Println("Filter : ", filter)
		toolkit.Println("Attributes : ", strings.Join(attributes, ", "))
		search := ldap.NewSearchRequest(loginconf.GetString("basedn"),
			ldap.ScopeWholeSubtree,
			ldap.DerefAlways,
			0,
			0,
			false,
			filter,
			attributes,
			nil)

		sr, err := l.Search(search)
		if err != nil {
			toolkit.Println("#ERROR Getting information from LDAP : ", err.Error())
		}
		for _, v := range sr.Entries {
			for _, str := range attributes {
				val := ""
				if len(v.GetAttributeValues(str)) > 1 {
					val = strings.Join(v.GetAttributeValues(str), "|")
				} else {
					val = v.GetAttributeValue(str)
				}
				if val != "" {
					switch str {
					case LDAPData.LDAPDataFullName:
						information.LDAPDataFullName = val
						break
					case LDAPData.LDAPDataFirstName:
						information.LDAPDataFirstName = val
						break
					case LDAPData.LDAPDataLastName:
						information.LDAPDataLastName = val
						break
					// case LDAPData.LDAPDataLastName:
					// 	information.LDAPDataLastName = val
					// 	break
					default:
						break
					}
				}
			}
		}
		toolkit.Println("# Information Achieved : ")
		toolkit.Println("# - LDAPDataFullName : ", information.LDAPDataFullName)
		toolkit.Println("# - LDAPDataFirstName : ", information.LDAPDataFirstName)
		toolkit.Println("# - LDAPDataLastName : ", information.LDAPDataLastName)
		toolkit.Println("# - LDAPDataLastName : ", information.LDAPDataLastName)

	}

	return

}
func FindDataLdap(addr, basedn, filter string, param toolkit.M) (arrtkm []toolkit.M, err error) {
	arrtkm = make([]toolkit.M, 0, 0)

	l := getldapconn(addr, param)
	err = l.Connect()
	if err != nil {
		return
	}
	defer l.Close()

	if param.Has("username") {
		// defer l.Unbind(toolkit.ToString(param["username"]), toolkit.ToString(param["password"]))
		err = l.Bind(toolkit.ToString(param["username"]), toolkit.ToString(param["password"]))
		if err != nil {
			return
		}
	}

	attributes := make([]string, 0, 0)
	if param.Has("attributes") {
		attributes = param["attributes"].([]string)
	}
	// filter = "(*" + filter + "*)"
	search := ldap.NewSearchRequest(basedn,
		ldap.ScopeWholeSubtree,
		ldap.DerefAlways,
		0,
		0,
		false,
		filter,
		attributes,
		nil)

	sr, err := l.Search(search)

	for _, v := range sr.Entries {
		tkm := toolkit.M{}

		for _, str := range attributes {
			if len(v.GetAttributeValues(str)) > 1 {
				tkm.Set(str, v.GetAttributeValues(str))
			} else {
				tkm.Set(str, v.GetAttributeValue(str))
			}
		}

		if len(tkm) > 0 {
			arrtkm = append(arrtkm, tkm)
		}
	}

	return
}

// func GetLdapMemberOfGroup(groupid string, conf toolkit.M) (members []*User, err error) {

// 	members = make([]*User, 0, 0)

// 	arrtkm, err := FindDataLdap(toolkit.ToString(conf["address"]), toolkit.ToString(conf["basedn"]), toolkit.ToString(conf["filter"]), conf)
// 	if err != nil {
// 		err = errors.New(fmt.Sprintf("Find Data, found : %v", err.Error()))
// 		return
// 	}

// 	maptkm, err := toolkit.ToM(conf["mapattributes"])
// 	if err != nil {
// 		return
// 	}

// 	for _, val := range arrtkm {
// 		member := new(User)
// 		member.ID = toolkit.RandomString(32)
// 		member.LoginID = toolkit.ToString(val.Get(toolkit.ToString(maptkm.Get("LoginID", "")), ""))
// 		member.FullName = toolkit.ToString(val.Get(toolkit.ToString(maptkm.Get("FullName", "")), ""))
// 		member.Email = toolkit.ToString(val.Get(toolkit.ToString(maptkm.Get("Email", "")), ""))
// 		// member.Enable = true
// 		// member.LoginType = LogTypeLdap
// 		// member.LoginConf = toolkit.M{}.Set("address", toolkit.ToString(conf["address"])).
// 		// 	Set("basedn", toolkit.ToString(conf["basedn"])).
// 		// 	Set("filter", toolkit.ToString(conf["filter"]))
// 		// member.AddToGroup(groupid)

// 		if member.LoginID != "" {
// 			members = append(members, member)
// 		}
// 	}

// 	return
// }

// //Check existing user, if any add group. and set enable
// func AddUserLdapByGroup(groupid string, conf toolkit.M) (err error) {

// 	if !conf.Has("address") || !conf.Has("basedn") || !conf.Has("filter") || !conf.Has("attributes") || !conf.Has("mapattributes") {
// 		err = errors.New("The config is not completed")
// 		return
// 	}

// 	members, err := GetLdapMemberOfGroup(groupid, conf)

// 	if err != nil {
// 		err = errors.New(fmt.Sprintf("Add By Group found error when get member : %v", err.Error()))
// 		return
// 	}

// 	if len(members) == 0 {
// 		return
// 	}

// 	for _, val := range members {

// 		tUser := new(User)
// 		err = FindUserByLoginID(tUser, val.LoginID)

// 		if err != nil && !(strings.Contains(err.Error(), ".Cursor.Fetch] Not found")) {
// 			return
// 		}

// 		if tUser.LoginID == val.LoginID {
// 			tUser.AddToGroup(groupid)
// 			err = Save(tUser)
// 		} else {
// 			err = Save(val)
// 		}

// 		if err != nil {
// 			return
// 		}

// 	}

// 	return
// }

// //if group len == 0, delete user
// func RefreshUserLdapByGroup(groupid string, conf toolkit.M) (err error) {
// 	if !conf.Has("address") || !conf.Has("basedn") || !conf.Has("filter") || !conf.Has("attributes") || !conf.Has("mapattributes") {
// 		err = errors.New("The config is not completed")
// 		return
// 	}

// 	if toolkit.TypeName(conf["attributes"]) == "[]interface {}" {
// 		arrstr := make([]string, 0, 0)
// 		for _, v := range conf["attributes"].([]interface{}) {
// 			arrstr = append(arrstr, toolkit.ToString(v))
// 		}
// 		conf.Set("attributes", arrstr)
// 	}

// 	members, err := GetLdapMemberOfGroup(groupid, conf)

// 	if err != nil {
// 		err = errors.New(fmt.Sprintf("Add By Group found error where get member : %v", err.Error()))
// 		return
// 	}

// 	arrUsers, err := GetUserByGroup(groupid)
// 	if err != nil {
// 		err = errors.New(fmt.Sprintf("Add By Group found error when get user by group : %v", err.Error()))

// 		return
// 	}

// 	if len(arrUsers) == 0 && len(members) == 0 {
// 		return
// 	}

// 	for _, val := range arrUsers {
// 		in := 0
// 		flag := false

// 		for i, tval := range members {
// 			if val.LoginID == tval.LoginID {
// 				flag = true
// 				in = i + 1
// 				break
// 			}
// 		}

// 		if flag {
// 			if in < len(members) {
// 				members = append(members[:in], members[in+1:]...)
// 			} else {
// 				members = members[:in]
// 			}
// 		} else {
// 			if len(val.Groups) == 1 {
// 				err = Delete(val)
// 			} else {
// 				val.RemoveFromGroup(groupid)
// 				err = Save(val)
// 			}

// 			if err != nil {
// 				return
// 			}
// 		}
// 	}

// 	for _, val := range members {
// 		tUser := new(User)
// 		err = FindUserByLoginID(tUser, val.LoginID)
// 		if err != nil && !(strings.Contains(err.Error(), ".Cursor.Fetch] Not found")) {
// 			return
// 		}

// 		if tUser.LoginID == val.LoginID {
// 			tUser.AddToGroup(groupid)
// 			err = Save(tUser)
// 		} else {
// 			err = Save(val)
// 		}

// 		if err != nil {
// 			return
// 		}

// 	}

// 	return
// }

// //Refresh user based on enable and disable
