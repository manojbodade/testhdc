package helper

import (
	"bufio"
	"crypto/aes"
	"crypto/cipher"
	"encoding/hex"
	"encoding/json"
	tk "github.com/eaciit/toolkit"
	"os"
	"strings"
	"time"
)

var (
	DebugMode bool
	keys      string = "KU4tD1L@k0N1G@Ku@tD1tingg@lNgOp1"
)

func wd() string {
	d, _ := os.Getwd()
	return d + "/"
}

func readconfigfile(file *os.File) map[string]string {
	reader := bufio.NewReader(file)
	ret := make(map[string]string)
	for {
		line, _, e := reader.ReadLine()
		if e != nil {
			break
		}

		sval := strings.Split(string(line), "=")
		if len(sval) > 2 {
			if strings.Contains(strings.ToLower(sval[0]), "password") && sval[0] != "LDAPIsUsingEncryptedPassword" {
				content, e := Decrypt(strings.Replace(string(line), sval[0]+"=", "", -1))
				ErrorHandling(e, false)
				ret[sval[0]] = content
			} else {
				ret[sval[0]] = strings.Replace(string(line), sval[0]+"=", "", -1)
			}
		} else {
			if strings.Contains(strings.ToLower(sval[0]), "password") && sval[0] != "LDAPIsUsingEncryptedPassword" {
				content, e := Decrypt(sval[1])
				ErrorHandling(e, false)
				ret[sval[0]] = content
			} else {
				ret[sval[0]] = sval[1]
			}
			// ret[sval[0]] = sval[1]
		}

	}
	return ret
}

func ReadConfig() map[string]string {
	ret := make(map[string]string)
	file, err := os.Open(wd() + "conf/app.conf")
	if err == nil {
		defer file.Close()
		ret = readconfigfile(file)
	} else {
		tk.Println(err.Error())
	}

	return ret
}

func ReadConfigWithPath(filepath string) map[string]string {
	ret := make(map[string]string)
	file, err := os.Open(filepath)
	if err == nil {
		defer file.Close()
		ret = readconfigfile(file)
	} else {
		tk.Println(err.Error())
	}

	return ret
}

func ErrorHandling(err error, isPanic bool) bool {
	if err != nil {
		if strings.Contains(err.Error(), "No more data to fetched!") || strings.Contains(err.Error(), "not found") {
			return false
		} else {
			if isPanic {
				panic(err)
			} else {
				tk.Println(err.Error())
			}

			return true
		}
	} else {
		return false
	}
}

func checkSpaceOnDate(value string) (retval string) {
	retval = value
	if strings.Contains(value, " ") {
		retval = strings.Split(value, " ")[0]
	}
	return
}

func GetDate(value string) (retval time.Time) {
	if strings.Contains(value, "/") {
		retval = tk.String2Date(checkSpaceOnDate(value), "dd/MM/yyyy")
		if retval.Year() == 1 {
			retval = tk.String2Date(checkSpaceOnDate(value), "MMM/dd/yyyy")
		}
		if retval.Year() == 1 {
			retval = tk.String2Date(checkSpaceOnDate(value), "MM/dd/yyyy")
		}
		if retval.Year() == 1 {
			retval = tk.String2Date(checkSpaceOnDate(value), "M/dd/yyyy")
		}
		if retval.Year() == 1 {
			retval = tk.String2Date(checkSpaceOnDate(value), "MM/d/yyyy")
		}
		if retval.Year() == 1 {
			retval = tk.String2Date(checkSpaceOnDate(value), "M/d/yyyy")
		}
		if retval.Year() == 1 {
			retval = tk.String2Date(checkSpaceOnDate(value), "dd/MMM/yyyy")
		}
		if retval.Year() == 1 {
			retval = tk.String2Date(checkSpaceOnDate(value), "dd/MM/yyyy")
		}
		if retval.Year() == 1 {
			retval = tk.String2Date(checkSpaceOnDate(value), "dd/M/yyyy")
		}
		if retval.Year() == 1 {
			retval = tk.String2Date(checkSpaceOnDate(value), "d/MM/yyyy")
		}
		if retval.Year() == 1 {
			retval = tk.String2Date(checkSpaceOnDate(value), "d/M/yyyy")
		}
	} else if strings.Contains(value, "_") {
		retval = tk.String2Date(checkSpaceOnDate(value), "MMM_yy")
	} else if strings.Contains(value, " ") && strings.Contains(value, ",") {
		retval = tk.String2Date(value, "MMMM dd, yyyy")
		if retval.Year() == 1 {
			//Sep 5, 2017 12:47:32 PM

			retval = tk.String2Date(value, "MMM d, yyyy H:mm:ss A")
		}
	} else if strings.Contains(value, "-") {
		retval = tk.String2Date(value, "yyyy-MM-dd HH:mm:ss")
		if retval.Year() == 1 {
			retval = tk.String2Date(value, "yyyy-MM-dd-HH:mm:ss")
		}
		if retval.Year() == 1 {
			retval = tk.String2Date(checkSpaceOnDate(value), "yyyy-MM-dd")
		}
	} else {
		basedate := time.Date(1899, 12, 30, 0, 0, 0, 0, time.UTC)
		duration := time.Duration(tk.ToInt(value, "RoundingAuto")) * time.Hour * 24
		retval = basedate.Add(duration)
	}

	return retval
}

func Deserialize(str string, res interface{}) error {
	err := json.Unmarshal([]byte(str), &res)
	return err
}

func CreateResult(success bool, data interface{}, message string) map[string]interface{} {
	if !success {
		tk.Println("ERROR! ", message)
		if DebugMode {
			panic(message)
		}
	}

	return map[string]interface{}{
		"data":    data,
		"success": success,
		"message": message,
	}
}

func GetSyncTime(synctime string, mode string) interface{} {

	var retval interface{}
	if len(synctime) == 14 {
		if mode == "datetime" {
			retval = time.Date(tk.ToInt(synctime[:4], "ROUNDINGAUTO"), time.Month(tk.ToInt(synctime[4:6], "ROUNDINGAUTO")), tk.ToInt(synctime[6:8], "ROUNDINGAUTO"), tk.ToInt(synctime[8:10], "ROUNDINGAUTO"), tk.ToInt(synctime[10:12], "ROUNDINGAUTO"), tk.ToInt(synctime[12:14], "ROUNDINGAUTO"), 0, time.UTC)
		}
		if mode == "string" {
			retval = synctime[:4] + "-" + synctime[4:6] + "-" + synctime[6:8] + " " + synctime[8:10] + ":" + synctime[10:12] + ":" + synctime[12:14]
		}

	}
	return retval
}

func Decode(text string) (string, error) {
	ciphertext, err := hex.DecodeString(text)
	if err != nil {
		return "", err
	}
	key := []byte("*eaciit-standard-chartered-apps*")
	c, err := aes.NewCipher(key)
	if err != nil {
		return "", err
	}

	gcm, err := cipher.NewGCM(c)
	if err != nil {
		return "", err
	}

	nonceSize := gcm.NonceSize()
	if len(ciphertext) < nonceSize {
		return "", err
	}

	nonce, ciphertext := ciphertext[:nonceSize], ciphertext[nonceSize:]
	res, err := gcm.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return "", err
	}

	result := tk.Sprintf("%s", res)
	return result, nil
}

func GetStartAndEndDateOfTheWeek(dates time.Time) (startdate time.Time, enddate time.Time) {
	weekday := time.Duration(dates.Weekday())
	if weekday == 0 {
		weekday = 7
	}
	year, month, day := dates.Date()
	currentZeroDay := time.Date(year, month, day, 0, 0, 0, 0, time.UTC).UTC()
	startdate = currentZeroDay.Add(-1 * (weekday - 1) * 24 * time.Hour).UTC()
	enddate = currentZeroDay.Add((7 - weekday) * 24 * time.Hour).UTC()
	return
}

func RemoveSpace(text string) string {
	return strings.Replace(text, " ", "", -1)
}

func SetPercentage(text string) float64 {
	return tk.ToFloat64(strings.Replace(RemoveSpace(text), "%", "", -1), 2, "ROUNDINGAUTO") / 100
}

func SetSizeNumberToMB(size string) (retval float64) {
	multiplier := 0.0
	nominator := 0.0
	retval = 0
	if strings.Contains(strings.ToLower(size), "gb") {
		multiplier = 1000.0
		nominator = tk.ToFloat64(strings.Replace(strings.ToLower(RemoveSpace(size)), "gb", "", -1), 2, "ROUNDINGAUTO")
		retval = nominator * multiplier
	} else if strings.Contains(strings.ToLower(size), "g") {
		multiplier = 1000.0
		nominator = tk.ToFloat64(strings.Replace(strings.ToLower(RemoveSpace(size)), "g", "", -1), 2, "ROUNDINGAUTO")
		retval = nominator * multiplier
	} else if strings.Contains(strings.ToLower(size), "tb") {
		multiplier = 1000000.0
		nominator = tk.ToFloat64(strings.Replace(strings.ToLower(RemoveSpace(size)), "tb", "", -1), 2, "ROUNDINGAUTO")
		retval = nominator * multiplier
	} else if strings.Contains(strings.ToLower(size), "t") {
		multiplier = 1000000.0
		nominator = tk.ToFloat64(strings.Replace(strings.ToLower(RemoveSpace(size)), "t", "", -1), 2, "ROUNDINGAUTO")
		retval = nominator * multiplier
	} else if strings.Contains(strings.ToLower(size), "kb") {
		multiplier = 1000.0
		nominator = tk.ToFloat64(strings.Replace(strings.ToLower(RemoveSpace(size)), "kb", "", -1), 2, "ROUNDINGAUTO")
		retval = nominator / multiplier
	} else if strings.Contains(strings.ToLower(size), "k") {
		multiplier = 1000.0
		nominator = tk.ToFloat64(strings.Replace(strings.ToLower(RemoveSpace(size)), "k", "", -1), 2, "ROUNDINGAUTO")
		retval = nominator / multiplier
	}

	return
}

func SetTwoDecimalNumber(f float64) string {
	return tk.Sprintf("%.2f", f)
}

func Encrypt(text string) (string, error) {
	return tk.EncryptAES(text, keys)
}

func Decrypt(text string) (string, error) {
	return tk.DecryptAES(text, keys)
}

func GetTwoNumber(number int) string {
	retval := tk.ToString(number)
	if number < 10 && number >= 0 {
		retval = "0" + tk.ToString(number)
	}
	return retval
}

func RemoveQuestionMark(text string) string {
	temp := strings.Replace(text, "?", "", -1)
	if temp == "" {
		temp = "UNDEFINED"
	}
	return temp
}
