package helper

import (
	tk "github.com/eaciit/toolkit"
	mail "gopkg.in/gomail.v2"
	"os"
	"os/exec"
	"strings"
)

func SendEmail(recipient string, sender string, title string, message string) (err error) {
	wdpath, _ := os.Getwd()
	path := strings.Replace(wdpath+"/conf/app.conf", "consoleapps", "webapp", -1)
	cfg := ReadConfigWithPath(path)

	recipients := strings.Split(cfg["emailrecipient"], ",")
	if recipient != "" {
		recipients = strings.Split(recipient, ",")
	}

	m := mail.NewMessage()

	m.SetHeader("From", cfg["emailsender"])
	if sender != "" {
		m.SetHeader("From", sender)
	}

	m.SetHeader("To", recipients...)

	m.SetHeader("Subject", cfg["emailheader"])
	if title != "" {
		m.SetHeader("Subject", title)
	}

	m.SetBody("text/html", cfg["emailmessage"])
	if message != "" {
		m.SetBody("text/html", message)
	}

	d := mail.NewDialer(cfg["emailserver"], tk.ToInt(cfg["emailport"], "ROUNDINGAUTO"), cfg["emailusername"], cfg["emailpassword"])

	err = d.DialAndSend(m)
	ErrorHandling(err, false)

	return
}

func SendEmailMailx(recipient string, sender string, title string, message string) (err error) {
	// command := "mailx -s " + title + " " + recipient

	// cmd := exec.Command("sh", "-c", "echo "+message+" | "+command)
	cmd := exec.Command("sh", "-c", `
		(echo "From: `+sender+`"; 
		echo "To: `+recipient+`"; 
		echo "MIME-Version:1.0"; 
		echo "Subject: `+title+`"; 
		echo "Content-Type:text/html"; 
		echo `+message+`;) | 
		${SEND_MAIL_HOME}/sendmail -t`)
	printCommand(cmd)
	output, err := cmd.Output()
	printError(err)
	printOutput(output)
	return err
}

func printCommand(cmd *exec.Cmd) {
	tk.Printf("==> Executing: %s\n", strings.Join(cmd.Args, " "))
}

func printError(err error) {
	if err != nil {
		os.Stderr.WriteString(tk.Sprintf("==> Sending Email Error: %s\n", err.Error()))
	}
}

func printOutput(outs []byte) {
	if len(outs) > 0 {
		tk.Printf("==> Sending Email Output: %s\n", string(outs))
	}
}
