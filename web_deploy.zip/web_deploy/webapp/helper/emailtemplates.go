package helper

import (
	"strconv"

	tk "github.com/eaciit/toolkit"
)

func DefaultTemplateStyle() string {
	return `
	<style>
  table {
    text-align: center;
    border-collapse: collapse;
    border: 1px solid #2C3F51;
    padding: 3px 10px;
  }

  table thead tr:first-child th {
    background: #eee;
  }

  table thead tr th {
    color: #2C3F51;
    border: 1px solid #2C3F51;
    padding: 3px 10px;
  }

  table tbody tr td {
    text-align: left;
    color: #428bca;
    border: 1px solid #2C3F51;
    padding: 3px 10px;
  }

  .dark, .darker {
    background: #eee;
  }

  .center {
    text-align: center;
  }
	</style>
	`
}

func CreateEODHTMLTemplate(datasubs []tk.M, dataddl []tk.M) string {
	retval := ""
	retval += `
	<html>
	
	` + DefaultTemplateStyle() + `
	
	<body>
  <table>
    <thead>
      <tr>
        <th colspan='10'>EOD Report</th>
      </tr>
      <tr>
        <th rowspan='2'>Hostname</th>
        <th rowspan='2'>Application</th>
        <th rowspan='2'>Country</th>
        <th colspan='4'>As Of Today</th>
        <th colspan='4'>As Of Now</th>
      </tr>
      <tr>
        <th># of Subs</th>
        <th>Subs Failed</th>
        <th>Subs Inactive</th>
        <th>Subs Unknown</th>
        <th>Subs Latency</th>
        <th>Subs Failed</th>
        <th>Subs Latency</th>
      </tr>
    </thead>
    <tbody>
	`

	class := "light"
	currentHost := ""
	for idx := range datasubs {
		mapdata, e := tk.ToM(datasubs[idx])
		ErrorHandling(e, false)

		if currentHost != "" && currentHost != mapdata.GetString("host") {
			if class == "light" {
				class = "dark"
			} else {
				class = "light"
			}
		}

		retval += "<tr class='" + class + "'>"
		retval += "<td>" + mapdata.GetString("host") + "</td>"
		retval += "<td>" + mapdata.GetString("application") + "</td>"
		retval += "<td>" + mapdata.GetString("country") + "</td>"
		retval += "<td>" + tk.ToString(mapdata.GetInt("num_subs")) + "</td>"
		retval += "<td>" + tk.ToString(mapdata.GetInt("num_subs_failed")) + "</td>"
		retval += "<td>" + tk.ToString(mapdata.GetInt("num_subs_inactive")) + "</td>"
		retval += "<td>" + tk.ToString(mapdata.GetInt("num_subs_unknown")) + "</td>"
		retval += "<td>" + tk.ToString(mapdata.GetInt("num_subs_latency")) + "</td>"
		retval += "<td>" + tk.ToString(mapdata.GetInt("now_failed")) + "</td>"
		retval += "<td>" + tk.ToString(mapdata.GetInt("now_latency")) + "</td>"
		retval += "</tr>"
	}

	retval += `
		</tbody>
	</table>

	<br>

  <table>
    <thead>
      <tr>
        <th colspan='9'>DDL Changes</th>
      </tr>
      <tr>
        <th>Hostname</th>
        <th>Application</th>
        <th>Country</th>
        <th># of Column Add</th>
        <th># of Column Modify</th>
        <th># of Column Drop</th>
        <th>Impacted Table</th>
      </tr>
    </thead>
    <tbody>
	`

	class = "light"
	currentHost = ""
	for idx := range dataddl {
		mapdata, e := tk.ToM(dataddl[idx])
		ErrorHandling(e, false)

		if currentHost != "" && currentHost != mapdata.GetString("host") {
			if class == "light" {
				class = "dark"
			} else {
				class = "light"
			}
		}

		retval += "<tr class='" + class + "'>"
		retval += "<td>" + mapdata.GetString("server") + "</td>"
		retval += "<td>" + mapdata.GetString("application") + "</td>"
		retval += "<td>" + mapdata.GetString("country") + "</td>"
		retval += "<td>" + tk.ToString(mapdata.GetInt("num_add")) + "</td>"
		retval += "<td>" + tk.ToString(mapdata.GetInt("num_mod")) + "</td>"
		retval += "<td>" + tk.ToString(mapdata.GetInt("num_drop")) + "</td>"
		retval += "<td>" + mapdata.GetString("tables") + "</td>"
		retval += "</tr>"
	}

	retval += `
		</tbody>
	</table>
	</body>

	</html>
	`

	return retval
}

func CreateHAHTMLTemplate(dataServerStatus []tk.M, dataDSFailure []tk.M, dataSubsFailure []tk.M) string {
	retval := ""
	retval += `
	<html>
	
	` + DefaultTemplateStyle() + `
	
	<body>
		<table>
			<thead>
				<tr>
					<th colspan='9'>Access Server Connection Status</th>
				</tr>
				<tr>
					<th>Hostname</th>
					<th>Connection Status</th>
				</tr>
			</thead>
			<tbody>
	`

	class := "light"
	currentHost := ""
	for idx := range dataServerStatus {
		mapdata, e := tk.ToM(dataServerStatus[idx])
		ErrorHandling(e, false)

		if currentHost != "" && currentHost != mapdata.GetString("server") {
			if class == "light" {
				class = "dark"
			} else {
				class = "light"
			}
		}

		retval += "<tr class='" + class + "'>"
		retval += "<td>" + mapdata.GetString("server") + "</td>"
		retval += "<td>" + mapdata.GetString("status") + "</td>"
		retval += "</tr>"
	}

	retval += `
			<tbody>
		</table>

		<br>

		<table>
			<thead>
				<tr>
					<th colspan='5'>DataStore Connection Failures</th>
				</tr>
				<tr>
					<th>Hostname</th>
					<th>Application</th>
					<th>Country</th>
					<th>Source / Target</th>
					<th>Connection Status</th>
				</tr>
			</thead>
			<tbody>
	`

	class = "light"
	currentHost = ""
	for idx := range dataDSFailure {
		mapdata, e := tk.ToM(dataDSFailure[idx])
		ErrorHandling(e, false)

		if currentHost != "" && currentHost != mapdata.GetString("host") {
			if class == "light" {
				class = "dark"
			} else {
				class = "light"
			}
		}

		retval += "<tr class='" + class + "'>"
		retval += "<td>" + mapdata.GetString("host") + "</td>"
		retval += "<td>" + mapdata.GetString("apps") + "</td>"
		retval += "<td>" + mapdata.GetString("country") + "</td>"
		retval += "<td>" + mapdata.GetString("datastoretype") + "</td>"
		retval += "<td>" + mapdata.GetString("status") + "</td>"
		retval += "</tr>"
	}

	retval += `
			<tbody>
		</table>

		<br>

		<table>
			<thead>
				<tr>
					<th colspan='7'>Subscription Failures</th>
				</tr>
				<tr>
					<th>Hostname</th>
					<th>Application</th>
					<th>Country</th>
					<th>Source Instance Name</th>
					<th>Target Instance Name</th>
					<th>Subscription Name</th>
					<th>Status</th>
				</tr>
			</thead>
			<tbody>
	`

	class = "light"
	currentHost = ""
	for idx := range dataSubsFailure {
		mapdata, e := tk.ToM(dataSubsFailure[idx])
		ErrorHandling(e, false)

		if currentHost != "" && currentHost != mapdata.GetString("host") {
			if class == "light" {
				class = "dark"
			} else {
				class = "light"
			}
		}

		retval += "<tr class='" + class + "'>"
		retval += "<td>" + mapdata.GetString("host") + "</td>"
		retval += "<td>" + mapdata.GetString("apps") + "</td>"
		retval += "<td>" + mapdata.GetString("country") + "</td>"
		retval += "<td>" + mapdata.GetString("source") + "</td>"
		retval += "<td>" + mapdata.GetString("target") + "</td>"
		retval += "<td>" + mapdata.GetString("subs") + "</td>"
		retval += "<td>" + mapdata.GetString("status") + "</td>"
		retval += "</tr>"
	}

	retval += `
		</tbody>
	</table>
	</body>

	</html>
	`

	return retval
}

func CreateLHAHTMLTemplate(dataSubsLatency []tk.M) string {
	retval := ""
	retval += `
	<html>
	
	` + DefaultTemplateStyle() + `
	
	<body>
		<table>
			<thead>
				<tr>
					<th colspan='9'>Subscription running above threshold</th>
				</tr>
				<tr>
					<th>Hostname</th>
					<th>Application</th>
					<th>Country</th>
					<th>Source Instance</th>
					<th>Target Instance</th>
					<th>Subscription</th>
					<th>Status</th>
					<th>Latency (hh:mm)</th>
				</tr>
			</thead>
			<tbody>
	`

	class := "light"
	currentHost := ""
	for idx := range dataSubsLatency {
		mapdata, e := tk.ToM(dataSubsLatency[idx])
		ErrorHandling(e, false)

		if currentHost != "" && currentHost != mapdata.GetString("host") {
			if class == "light" {
				class = "dark"
			} else {
				class = "light"
			}
		}

		retval += "<tr class='" + class + "'>"
		retval += "<td>" + mapdata.GetString("host") + "</td>"
		retval += "<td>" + mapdata.GetString("apps") + "</td>"
		retval += "<td>" + mapdata.GetString("country") + "</td>"
		retval += "<td>" + mapdata.GetString("source") + "</td>"
		retval += "<td>" + mapdata.GetString("target") + "</td>"
		retval += "<td>" + mapdata.GetString("subs") + "</td>"
		retval += "<td>" + mapdata.GetString("status") + "</td>"
		// retval += "<td class='center'>" + tk.ToString(strconv.FormatFloat(mapdata["latency"].(float64), 'f', -1, 64)) + "</td>"
		// retval += "<td class='center'>" + tk.ToString(strconv.FormatFloat(mapdata["threshold"].(float64), 'f', -1, 64)) + "</td>"
		retval += "<td class='center'>" + mapdata.GetString("latency") + "</td>"
		//retval += "<td class='center'>" + mapdata.GetString("threshold") + "</td>"
		retval += "</tr>"
	}

	retval += `
		</tbody>
	</table>
	</body>

	</html>
	`

	return retval
}

func CreateDAHTMLTemplate(dataSubsStatLatency []tk.M, dataUnplannedDDL []tk.M) string {
	retval := ""
	retval += `
	<html>
	
	` + DefaultTemplateStyle() + `
	
	<body>
		<table>
			<thead>
				<tr>
					<th colspan='9'>Subscription with High CDC Latency</th>
				</tr>
				<tr>
					<th rowspan='2'>Application</th>
					<th rowspan='2'>Country</th>
					<th rowspan='2'>Total Subscription</th>
					<th colspan='3'># of Subscription (As of today)</th>
					<th colspan='3'># of Subscription (As of now)</th>
				</tr>
				<tr>
					<th>Failed</th>
					<th>Inactive</th>
					<th>Unknown</th>
					<th>Latency Observed (<2 Hrs)</th>
					<th>Failed</th>
					<th>Latency Observer (>2 Hrs)</th>
				</tr>
			</thead>
			<tbody>
	`

	for idx := range dataSubsStatLatency {
		mapdata, e := tk.ToM(dataSubsStatLatency[idx])
		ErrorHandling(e, false)

		retval += "<tr>"
		retval += "<td>" + mapdata.GetString("application") + "</td>"
		retval += "<td>" + mapdata.GetString("country") + "</td>"
		retval += "<td class='center'>" + tk.ToString(strconv.FormatFloat(mapdata["num_subs"].(float64), 'f', -1, 64)) + "</td>"
		retval += "<td>" + mapdata.GetString("num_subs_failed") + "</td>"
		retval += "<td>" + mapdata.GetString("num_subs_inactive") + "</td>"
		retval += "<td>" + mapdata.GetString("num_subs_unknown") + "</td>"
		retval += "<td>" + mapdata.GetString("num_subs_latency") + "</td>"
		retval += "<td>" + mapdata.GetString("now_failed") + "</td>"
		retval += "<td>" + mapdata.GetString("now_latency") + "</td>"
		retval += "</tr>"
	}

	retval += `
			<tbody>
		</table>

		<br>

		<table>
			<thead>
				<tr>
					<th colspan='6'>Un-Planned DDL Status</th>
				</tr>
				<tr>
					<th rowspan='2'>Application</th>
					<th rowspan='2'>Country</th>
					<th colspan='3'># of DDL Changes</th>
					<th rowspan='2'>Impacted Table List</th>
				</tr>
				<tr>
					<th>Application</th>
					<th>Country</th>
					<th>Impacted Table List</th>
				</tr>
			</thead>
			<tbody>
	`

	for idx := range dataUnplannedDDL {
		mapdata, e := tk.ToM(dataUnplannedDDL[idx])
		ErrorHandling(e, false)

		retval += "<tr>"
		retval += "<td>" + mapdata.GetString("application") + "</td>"
		retval += "<td>" + mapdata.GetString("country") + "</td>"
		retval += "<td>" + mapdata.GetString("num_add") + "</td>"
		retval += "<td>" + mapdata.GetString("num_mod") + "</td>"
		retval += "<td>" + mapdata.GetString("num_drop") + "</td>"
		retval += "<td>" + mapdata.GetString("tables") + "</td>"
		retval += "</tr>"
	}

	retval += `
		</tbody>
	</table>
	</body>

	</html>
	`

	return retval
}
