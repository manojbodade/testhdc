var cpass = {
	oldPassword:ko.observable(""),
	newPassword:ko.observable(""),
	confirmPassword:ko.observable(""),
}
cpass.Change =  function(){

	cpass.initValidator()
	var validator = $("#formChangePass").data("kendoValidator");

    if(validator==undefined){
		cpass.initValidator()
	    validator= $("#formChangePass").kendoValidator().data("kendoValidator");
 	}
 
 
 	if(validator.validate()) {
		var payload = {
			newpassword : cpass.newPassword(),
			oldpassword : cpass.oldPassword()
		}
		ajaxPost("/changepassword/savenewpassword", payload, function (res){
		 	if(res.IsError != true) {
            	cpass.Reset();
            	return swal("Success!", res.Message, "success");
		 	
			}else{
				return swal("Error!", res.Message, "error");
			}
		})
	}
}
cpass.initValidator = function(){
	var container = $("#formChangePass");
	kendo.init(container);
	    container.kendoValidator({
	        rules:{
	        	custom1: function(input){
	                if(input.is("[name=newPassword]")){
	                    var newPassword = input.val();
	                    if(newPassword === ''){
	                    	 
	                        return false;
	                    }
	                }
	                return true;
	            },
	        	custom2: function(input){
	                if(input.is("[name=confirmPassword]")){
	                    var confirmPass = input.val();
	                    if(confirmPass === ''){
	                    	 
	                        return false;
	                    }
	                }
	                return true;
	            },
	            custom3: function(input){
	                if(input.is("[name=confirmPassword]")){
	                    var confirmPass = input.val(),
	                    newPass = cpass.newPassword();
	                    if(confirmPass !== newPass){
	             
	                        return false;
	                    }
	                }
	                return true;
	            },
	            custom4: function(input){
	                if(input.is("[name=newPassword]")){
	                    var newPass = input.val();
	                   	re = /(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d.$@$!%*?&]{8,}/
	                    if(!re.test(newPass)){
	             
	                        return false;
	                    }
	                }
	                return true;
	            },
	            custom5: function(input){
	                if(input.is("[name=confirmPassword]")){
	                    var confirmPass = input.val();
	                   	re = /(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d.$@$!%*?&]{8,}/
	                    if(!re.test(confirmPass)){
	             
	                        return false;
	                    }
	                }
	                return true;
	            }

	        },
	        messages: {
	        	custom1:"New Password is required",
	        	custom2:"Confirm Password is required",
	            custom3:"Confirm Password must has same value with Password",
	            custom4:"Password Policy is min 8 characters, with uppercase and number",
	            custom5:"Password Policy is min 8 characters, with uppercase and number",
	        }
	});

}
cpass.Reset = function(){
	cpass.oldPassword("");
	cpass.newPassword("");
	cpass.confirmPassword("");
}
 
