var dg = {
    PullRequest:ko.observable(0),
    Processing:ko.observable(true),
    MapMajorRegion:ko.observableArray(),
    MapSource:ko.observableArray([]),
    GChart1All:ko.observableArray([]),
    GChart1RM:ko.observableArray([]),
    GChart3:ko.observableArray([]),
    GChart4:ko.observableArray([]),
    GChart5:ko.observableArray([]),
    GChart6Call:ko.observableArray([]),
    GChart6RM:ko.observableArray([]),
    GChartTop1:ko.observableArray([]),
    GChartTop2:ko.observableArray([]),
    GChartTop3:ko.observableArray([]),
    GChartTop4:ko.observableArray([]),
    TopCountry : ko.observableArray([]),
    ProspectTotal:ko.observable(),
	callReportView:ko.observable("call"),
	activeUserView:ko.observable("all"),
    paramTopDeal : ko.observableArray([]),
    paramTopAvgCreate : ko.observableArray([]),
    paramTopCalls : ko.observableArray([]),
    showRenderDela : ko.observable(false),
    showRenderAvgCreate : ko.observable(false),
    showRenderCalls: ko.observable(false),
};
dg.PullRequest.subscribe(function(newval){
    if(newval==0){
        dg.Processing(false);
		dg.gen1();
        //dg.generategrid1(dg.GChart1());
        dg.generategrid3(dg.GChart3());
        dg.generategrid4(dg.GChart4());
        dg.generategrid5(dg.GChart5()); 
        dg.generategrid6();
        dg.renderMap(dg.MapSource());

        dg.chartTop5(dg.GChartTop1(), "gcharttop1", dg.GChartTop1().globalAverage, dg.GChartTop1().regionalAverage, false);
        dg.chartTop5(dg.GChartTop2().series, "gcharttop2", dg.GChartTop2().globalAverage, dg.GChartTop2().regionalAverage, true);
        dg.chartTop5(dg.GChartTop3(), "gcharttop3", dg.GChartTop3().globalaverage, dg.GChartTop3().regionalaverage, true);
        dg.top5Country(dg.GChartTop4())

        //dg.GChartTop4(res.data)
        //dg.chartTop5("","gcharttop1");
        //dg.chartTop5("","gcharttop2");
        // dg.chartTop5(dg.GChartTop3(),"gcharttop3");
        // dg.chartTop5("","gcharttop4");
        // dg.top5Country(dg.TopCountry());
    }
})

dg.callReportView.subscribe(function(xx){
	dg.generategrid6();
})

dg.activeUserView.subscribe(function(xx){
	dg.gen1();
})

function GetData(){
    if(ds.fromAnalytic()){
        resetDate();
        ds.fromAnalytic(false);
    }
    dg.PullRequest(13);
    dg.Processing(true);
    ajaxPost("/mastermap/getdata", {}, 
        function (res) {
            if(res.IsError){
                swal("",res.Message,"error");
                return;   
            }
            model.MapDataSource(res.Data);
            pullRequestComplete(dg.PullRequest);
        }
    )
    ajaxPost("/masterregion/getdata",{},function(res){
        if(res.IsError){
            alert(res.Message);
            return;   
        }
        dg.MapSource(res.Data)
        pullRequestComplete(dg.PullRequest);
    });
    
	var param = ko.mapping.toJS(filter);
	param.AllorRM = "all";
	ajaxPost("/dashboard/getdataloginusers",param,function(res){
        if(res.IsError){
            alert(res.Message);
            return;  
        }
		dg.GChart1All(res.Data);
        //dg.gen1(res.Data);
		pullRequestComplete(dg.PullRequest);
    });

    var param = ko.mapping.toJS(filter);
	param.AllorRM = "rm";
	ajaxPost("/dashboard/getdataloginusers",param,function(res){
        if(res.IsError){
            alert(res.Message);
            return;  
        }
		dg.GChart1RM(res.Data);
        //dg.gen1(res.Data);
		pullRequestComplete(dg.PullRequest);
    });
	
	ajaxPost("/dashboard/getdataaccountplan", param, //globalaccountplan
		function (res) {
			if(res.IsError){
				swal("",res.message,"error");
                return;   
			}
            dg.GChart3(res.Data);
            pullRequestComplete(dg.PullRequest);
		}, 
		function () {}
	)
	
	ajaxPost("/dashboard/globalprospect", param, 
		function (res) {
			if(!res.success){
				swal("",res.message,"error");
				return;
			}
            dg.GChart4(res.data);
            pullRequestComplete(dg.PullRequest);
		}, 
		function () {}
	)
	
	ajaxPost("/dashboard/dealcomercialbank", param, 
		function (res) {
			if(!res.success){
				swal("",res.message,"error");
				return;
			}
            dg.GChart5(res.data);
            pullRequestComplete(dg.PullRequest);
		}, 
		function () {}
	)
	
	
	
	var urlCallReport = "";
		urlCallReport = "/dashboard/callreportclient"
	
	ajaxPost(urlCallReport, param, 
		function (res) {
			if(!res.success){
				swal("",res.message,"error");
                return;   
			}
			dg.GChart6Call(res.data);
            pullRequestComplete(dg.PullRequest);
		}, 
		function () {}
	)

    var urlCallReport = "";
		urlCallReport = "/dashboard/chart6"
	
	ajaxPost(urlCallReport, param, 
		function (res) {
			if(!res.success){
				swal("",res.message,"error");
                return;   
			}
			dg.GChart6RM(res.data);
            pullRequestComplete(dg.PullRequest);
		}, 
		function () {}
	)

    ajaxPost("/dashboard/top5callreport", param, 
        function (res) {
            if(!res.success){
                swal("",res.message,"error");
                return;   
            }
            //dg.paramTopCalls(filter);
            dg.GChartTop3(res.data)
            // dg.GChartTop3(res.data);
            pullRequestComplete(dg.PullRequest);
            // setTimeout(function() {
            //     dg.chartTop5(res.data, "gcharttop3", res.data.globalaverage, res.data.regionalaverage)
            // }, 300);
        }, 
        function () {}
    )
    
    ajaxPost("/dashboard/top5dealbycountry", filter, 
		function (res) {
			     
            if(!res.success){
                alert(res.message);
                return;
            }
            // dg.paramTopDeal(param);
            var countryOrder = ["HONG KONG", "INDIA", "UNITED ARAB EMIRATES", "SINGAPORE", "CHINA"];
            if(filter.MajorRegion() == "AME")
                countryOrder = ["UNITED ARAB EMIRATES", "NIGERIA", "KENYA", "PAKISTAN", "UGANDA", "GHANA"];
            else if(filter.MajorRegion() == "ASA")
                countryOrder = ["INDIA", "SINGAPORE", "MALAYSIA", "BANGLADESH", "INDONESIA"];
            else if(filter.MajorRegion() == "GCNA")
                countryOrder = ["HONG KONG", "KOREA, REPUBLIC OF", "CHINA", "TAIWAN"];

            newData = [];
            countryOrder.forEach(function(xx){
                var tt = Enumerable.From(res.data.DataRevenue).FirstOrDefault(undefined, "$.Country == '" + xx + "'");
                if(tt != undefined){
                    newData.push(tt);
                }
            })

            var take5 = Enumerable.From(newData).Take(5).ToArray()
            if(filter.MajorRegion() == "AME")
                take5 = Enumerable.From(newData).Take(6).ToArray()
            var cat = Enumerable.From(take5).Select("$.Country").ToArray()
            var ser = Enumerable.From(take5).Select("$.Average").ToArray()
            var globalAverage = Enumerable.From(res.data.DataRevenue).Select("$.Average").Average()
            var rtt = {
                series : [
                    {data: ser, type: "bar", name: "" }
                ],
                categories: cat,
                globalAverage: globalAverage
            }
             
            dg.GChartTop1(rtt)
            // setTimeout(function() {
            //     dg.chartTop5(rtt, "gcharttop1", globalAverage, regionalAverage)
            // }, 300);
            // dg.GChart6(res.data);
             pullRequestComplete(dg.PullRequest);
		}, 
		function () {}
	)

    ajaxPost("/dashboard/top5prospectbycountry", filter, 
		function (res) {
			if(res.IsError){
				alert(res.Message);
				return;
			}
            dg.paramTopAvgCreate(filter);
            var countryOrder = ["HONG KONG", "INDIA", "UNITED ARAB EMIRATES", "SINGAPORE", "CHINA"];
            if(filter.MajorRegion() == "AME"){
                countryOrder = ["UNITED ARAB EMIRATES", "NIGERIA", "KENYA", "PAKISTAN", "UGANDA", "GHANA"];
            }else if(filter.MajorRegion() == "ASA"){
                countryOrder = ["INDIA", "SINGAPORE", "MALAYSIA", "BANGLADESH", "INDONESIA"];
            }else if(filter.MajorRegion() == "GCNA"){
                countryOrder = ["HONG KONG", "KOREA, REPUBLIC OF", "CHINA", "TAIWAN"];
            }
            newData = [];
            countryOrder.forEach(function(xx){
                var tt = Enumerable.From(res.Data.Datas).FirstOrDefault(undefined, "$._id.country == '" + xx + "'");
                if(tt != undefined){
                    newData.push(tt);
                }
            })
            // var ordering = Enumerable.From(newData).OrderByDescending("$.created").ToArray();
            var take5 = Enumerable.From(newData).Take(5).ToArray()
            if(filter.MajorRegion() == "AME")
                take5 = Enumerable.From(newData).Take(6).ToArray()
            var cat = Enumerable.From(take5).Select("$._id.country").ToArray()
            var ser = Enumerable.From(take5).Select("$.created").ToArray()
            var globalAverage = Enumerable.From(res.Data.Datas).Select("$.created").Average()
            var series = {
                series : [
                    {data: ser, type: "bar", name: "" }
                ],
                categories: cat
            }
            var Data = {
                series,
                globalAverage: globalAverage
            }
            dg.GChartTop2(Data)
             pullRequestComplete(dg.PullRequest);
            // setTimeout(function() {
            //     dg.chartTop5(rtt, "gcharttop2", 0)
            // }, 300);
            // dg.GChart6(res.data);
		}, 
		function () {}
	)
    

    ajaxPost("/dashboard/globaltop5contry", param, function (res) {
        if(res.IsError == true){
            return swal("",res.message,"error");
        }
        // dg.TopCountry(res.data);
        // gcharttop4
        dg.GChartTop4(res.data)
        pullRequestComplete(dg.PullRequest);
    })

}

dg.generategrid1 = function(dataSource){
    var userSources = [];
    var SelectedPeriod = Enumerable.From(dataSource.ActiveUserData).GroupBy("$._id.period").OrderBy("$.Key()").ToArray();
    for(var p in SelectedPeriod){
        var period = SelectedPeriod[p].Key();
        var d = {
            periodstr:period,
            period:new Date(period),
        }
        var SelectedMajorRegion = SelectedPeriod[p].source;
        for(var i in SelectedMajorRegion){
            d["activeuser"+SelectedMajorRegion[i]._id.major_region] = SelectedMajorRegion[i].activeuser;
        }
        userSources.push(d);
    }
    var MajorRegionList = Enumerable.From(dataSource.ActiveUserData).GroupBy("$._id.major_region").OrderBy("$.Key()").ToArray();

    var ActiveUsersSeries = [];
    for(var i in MajorRegionList){
        ActiveUsersSeries.push({field:"activeuser"+MajorRegionList[i].Key(),name:MajorRegionList[i].Key()});
    }
    $("#gchart1").html("");
    $("#gchart1").kendoChart({
        dataSource: {
            data: userSources
        },
        title: {
            visible:false,
        },
        chartArea:{
            height:200
        },
        legend: {
            visible: true,
            position:"bottom",
            labels:{
                font:chartFont
            }
        },
        seriesDefaults: {
            type: "column",
            labels: {
                visible: chartLabelDisplay,
                font:chartFont,
                color:chartLabelColor,
                background:"transparent",
                template:"#:numbformat(value)#",
                padding:0,
                margin:0,
            },
            overlay: {
              gradient: "none"
            },
        },
        series: ActiveUsersSeries,
        valueAxis:{
            majorGridLines: {
                    visible: true
            },
            line:{
                visible:false,
            },
            labels:{
                font:chartFont,
                template:"#:numbformat(value)#",
            },

            visible: true
        },
        categoryAxis: {
            field: "period",
            majorGridLines: {
                visible: false
            },
            labels:{
                font:chartFont,
                rotation: {
                    angle: 45,
                    align: "center"
                }
            }
        },
        tooltip: {
            visible: true,
            font:chartFont,
            template: "#:kendo.toString(value, 'N0')#"
        },
        seriesColors:chartColors,
    });

};

var scale = chroma.scale(["white", "green"]).domain([1, 1000]);

function onShapeCreated(e) {
    var shape = e.shape;
    var users = shape.dataItem.properties.users;
    if (users) {
        var color = scale(users).hex();
        shape.options.fill.set("color", color);
    }
}

function onShapeFeatureCreated(e) {
    e.group.options.tooltip = {
        font:chartFont,
        content: e.properties.country,
        position: "cursor",
        offset: 10,
        width: 80
    };
}

var popup = $("<div></div>")
          .appendTo(document.body)
          .kendoPopup()
          .data("kendoPopup");

function onShapeMouseEnter(e) {
    if(e.shape.dataItem.major_region != undefined){
        var oe = e.originalEvent;
        var x = oe.pageX || oe.clientX;
        var y = oe.pageY || oe.clientY;
        var country = e.shape.dataItem.country;
        var majorRegion = e.shape.dataItem.major_region;
        popup.element.html("<center>"+ majorRegion + " <br /> " + country + "</center>");
        popup.open(x, y);
        e.shape.options.set("fill.opacity", 1);
    }
}

function onShapeMouseLeave(e) {
    if (!$(e.originalEvent.relatedTarget).is(".k-popup, .k-animation-container")) {
        popup.close();

        // Necessary to stop the animations,
        // will be fixed in future versions
        popup.element.kendoStop(true, true);
    }
    e.shape.options.set("fill.opacity", 0.7);
}

function onClickMap(e){
    if (model.Role.EnaReg() == "false"){
        return
    } 
	var major_region = e.shape.dataItem.major_region;
    if(major_region!==undefined){
        filter.MajorRegion(major_region);
        GetData();   
    }
}


dg.renderMap = function(dataSource){
    var sources = ko.mapping.toJS(model.MapDataSource());
    var mapColor = {};
    var idx = 0;
    for(var i in sources){
        var country = sources[i].country.toUpperCase();
        var c = Enumerable.From(dataSource).Where("$.Country == '"+country+"'").FirstOrDefault();
        if(c!==undefined){
			sources[i].Region = c.Region;
            sources[i].major_region = c.Major_Region;
            if(mapColor[c.Major_Region]===undefined){
                mapColor[c.Major_Region] = chartColors[idx];
                idx++;
            }else{
                mapColor[c.Major_Region] = mapColor[c.Major_Region];
            }
            sources[i].color = mapColor[c.Major_Region];
        }else{
            sources[i].color = "#f3f3f3";
        }
    }
    sources = Enumerable.From(sources).OrderBy("$.major_region").ToArray();
    var MapMajorRegion = [];
    for(var i in mapColor){
        MapMajorRegion.push({name:i,color:mapColor[i]});
    }
    dg.MapMajorRegion(MapMajorRegion)
    //console.log(sources)

    $("#gmap").attr("style","height:237px;border:1px solid #0075B2;");
    $("#gmap").html("");
    $("#gmap").kendoMap({
        center: [13.58192045054587, 68.73046875],
        zoom: 2,
        layers: [
            {
                type: "shape",
                urlTemplate: "http://#= subdomain #.tile.openstreetmap.org/#= zoom #/#= x #/#= y #.png",
                dataSource: {
                    data:sources 
                },
                // locationField: "latlng",
                // titleField: "country",
                style: {
                    fill: {
                        opacity: 0.8
                    }
                },
                attribution: model.Role.EnaReg() == "true" ?  "Click Map To Refresh Data" : "",
            },
            
        ],
		shapeClick: onClickMap,
        shapeCreated: function(e) {
           // var scale = chroma.scale(["#FFF", "#0075B2"]).domain([1, maxValue]);
           var shape = e.shape;
           var obj = shape.dataItem.value;
           var color = scale(obj).hex();
           shape.options.fill.set("color", shape.dataItem.color);

           // Calculate shape bounding box
           var bbox = e.shape.bbox();
           var center = bbox.center();

           // Create the label
           var labelText = e.shape.dataItem.country;
           var label = new kendo.drawing.Text(labelText,[0,0],{ font: "9px Helvetica Neue, Helvetica, Arial, sans-serif" });
           var labelCenter = label.bbox().center();

            // Position the label
            //    label.position([
            //      center.x - labelCenter.x,
            //      center.y - labelCenter.y
            //    ]);
            //    label.visible(false);
            //    e.shape.dataItem["dataLabel"] = label;
            //    // Render the label on the layer
            //    e.layer.surface.draw(label);
        },
        shapeFeatureCreated: onShapeFeatureCreated,
        shapeMouseEnter: onShapeMouseEnter,
        shapeMouseLeave: onShapeMouseLeave
    });
}

dg.generategrid3 = function(data){
    var periodStart = filter.Start();
    var monthlySource = data.MonthlyData;
    approvedytd = 0;
    for(var i in monthlySource){
        var my = monthlySource[i]._id.toString();
        monthlySource[i].perioddate = new Date(moment(my.substr(0,4)+"-"+my.substr(4,2)));
        monthlySource[i].period = moment(my.substr(0,4)+"-"+my.substr(4,2)).format("MMM")
        if(monthlySource[i].period=="Jan"){
            approvedytd = 0;
        }
        approvedytd += monthlySource[i].approved;
        monthlySource[i].total =  approvedytd+monthlySource[i].initiated;
        var total = 0.1*monthlySource[i].total;
        monthlySource[i].totaldisplay =   total < 50 ? 50 : total;
        monthlySource[i].approvedytd =  approvedytd;
    }
    
    var y = AccountPlan.YTD;
    y.Approved(0);
    // if(data.BCAData.length>0){
    //     y.BCAGroups(data.BCAData[0].count);
    // }else{
    //     y.BCAGroups(data.BCAData.length);
    // }
    y.BCAGroups(data.BCAData[0] == undefined ? 0 : data.BCAData[0].totalbca);
    if(monthlySource.length>0){
        y.Approved(monthlySource[monthlySource.length-1].approvedytd);
    }
    var Completed = y.BCAGroups()==0?0:y.Approved()/y.BCAGroups();
    y.Completed(Completed);
    
    $("#gchart3").html("");
    $("#gchart3").kendoChart({
        dataSource: {
            data: Enumerable.From(monthlySource).Where(function(x){return x.perioddate >= periodStart}).ToArray()
        },
        title: {
            visible:false,
        },
        chartArea:{
            height:200
        },
        legend: {
            visible: true,
            position:"bottom",
            labels:{
                font:chartFont
            }
        },
        seriesDefaults: {
            type: "column",
            stack:true,
            labels:{
                visible: chartLabelDisplay,
                font:chartFont,
                position:"center",
                color:chartLabelColor,
                background:"transparent",
                template:"#:numbformat(value)#",
                padding:0,
                margin:0,
            },
            overlay: {
              gradient: "none"
            },
        },
        series: [
            {field: "approvedytd",name:"Approved", labels: {visible: false}},
            {field: "initiated",name:"Initiated", labels: {visible: false}},
            {field: "totaldisplay",
            name:"",
                visual: function (e) {
                return "";
            },
            labels:{
                visible: chartLabelDisplay,
                position:"insideBase",
                template:"#:kendo.toString(dataItem.total,'N0')#"
            },
            tooltip: {
                visible: false,
            },
            color:"transparent"
        },
        ],
        valueAxis: {
            majorGridLines: {
                visible: true
            },
            line:{
                visible:false
            },
            labels:{
                font:chartFont,
                template:"#:kendo.toString(value,'N0')#"
            },
            visible: true,
        },
        categoryAxis: {
            field: "period",
            majorGridLines: {
                visible: false
            },
            labels:{
                font:chartFont,
                rotation: {
                    angle: 45,
                    align: "center"
                },
            },
        },
        tooltip: {
            visible: true,
            font:chartFont,
            template: "#= series.name #: #= kendo.toString(value, 'N0') #"
        },
        seriesColors:chartColors
    });
};

dg.generategrid4 = function(series){
	series.forEach(function(xx){
		xx.category = xx.Category;
		xx.value = xx.Value;
	});
    var ProspectTotal = Enumerable.From(series).Sum("$.value");
    dg.ProspectTotal(ProspectTotal);
	$("#gchart4").html("");
    $("#gchart4").kendoChart({
        chartArea: {
            background: "transparent",
            height: 200,
        },
        legend: {
            visible: true,
            position:"bottom",
            labels:{
                font:chartFont
            }
        },
        seriesColors:chartColors,
        series: [{
			padding: 0,
            type: "donut",
            data: series,
            //size:40,
            overlay: {
              gradient: "none"
            },
            labels: {
                visible: chartLabelDisplay,
                font:chartFont,
                color:"#FFF",
                background:"transparent",
                template:"#:replaceString(kendo.toString(percentage,'P0'))#",
                padding:0,
                margin:0,
            },
        }],
        tooltip: {
            visible: true,
            font:chartFont,
            template:"#: category # : #:kendo.toString(value,'N0')# (#:kendo.toString(percentage,'P0')#)",
        }
    });
};

dg.generategrid5 = function(data){
    var dataSer = []
    data.series.forEach(function(e){
		e.data = e.Data;
		e.type = e.Type;
		e.name = e.Name;
        if(e.type == "line"){
            e.labels= {
                visible: false
            }
        }
        if(e.WhatData == "allinfo"){
            dataSer.push(e)
        }
	});
    $("#gchart5").kendoChart({
        chartArea: {
            background: "transparent",
            height: 200
        },
        legend: {
            position: "bottom",
            labels:{
            	font:chartFont
            }
        },
		seriesDefaults: {
            overlay: {
              gradient: "none"
            },
            labels: {
                visible: chartLabelDisplay,
                font:chartFont,
                color:chartLabelColor,
                background:"transparent",
                template:"#:kendo.toString(value/1000,'N0')#",
                padding:0,
                margin:0,
            },
        },
        seriesColors: chartColors,
        series: dataSer,
        valueAxis:{
        	labels:{
                font:chartFont,
        		template:"#:kendo.toString(value/1000,'N0')#"
        	},
            majorGridLines: {
                visible: true
            },
            line:{
                visible:false,
            }
        },
        categoryAxis: {
            categories: data.categories,
            labels:{
                font:chartFont,
                rotation: {
                    angle: 45,
                    align: "center"
                }
            }
        },
		axisDefaults: {
			majorGridLines: {
				visible: false,
			},
			labels:{
				font:chartFont,
                template:"#:numbformat(value)#"
			}
		},
		tooltip: {
            visible: true,
            template: "#= series.name #: # if(series.axis == 'avg'){ #  #:kendo.toString(value, 'P1')#  #}else{# #: kendo.toString(value, 'N0') # #}#"
        }
    });
};

dg.generategrid6 = function(data){
	if(dg.callReportView() == "call")
		dg.generategrid6Call(dg.GChart6Call())
	else 
		dg.generategrid6RM(dg.GChart6RM())
}

dg.generategrid6Call = function(data){
	var series = [];
	data.series.forEach(function(x){
		x["name"] = x.Name
		x["field"] = x.Field
		x["data"] = x.Data
		if(x.Name.indexOf("percentage") < 0){
			series.push({field: x.field,name:x.Name, labels: {visible: false}})
		}
	});
	if(dcr.clientbyregionview() == "monthly"){
		series.push({
                field: "totaldisplay",
                name:"(% of Total BCA Client)",
                    visual: function (e) {
                    return "";
                },
                labels:{
                    visible: true,
                    position:"insideBase",
                    // template:"#:kendo.toString(dataItem.totaldisplay,'P0')#"
                    template:"#:replaceString(kendo.toString(dataItem.totaldisplay,'P0'))#"
                },
                tooltip: {
                    visible: false,
                },
                color:"#ffffff"
            })
	}
	
    var arrtotal = [];
    var arr = data.series[0].data;
    for(var i in arr){
        var v = arr[i]+data.series[1].data[i];
        arrtotal.push(v<50?50:v);
    }
    var totalseries = {
        name:"total",
		field:"total",
        data:arrtotal
    }
    var sources = [];
    for(var i in data.categories){
        var d = {
            period:data.categories[i]
        }
        for(var s in data.series){
            d[data.series[s].field] = data.series[s].data[i];    
        }
        var total = 0.1*d[data.series[data.series.length - 1].field];
		if(dcr.clientbyregionview() == "monthly")
        	d["totaldisplay"] = d["percentageofBCAGroup"];
		
        sources.push(d);
    }
    
	$("#gchart6").html("");
    $("#gchart6").kendoChart({
		dataSource: {
            data: sources
        },
        title: {
            visible:false,
        },
        chartArea:{
            height:200
        },
        legend: {
            visible: true,
            position:"bottom",
            labels:{
                font:chartFont
            }
        },
        seriesDefaults: {
            type: "column",
            stack: true,
            labels:{
                visible: chartLabelDisplay,
                font:chartFont,
                position:"center",
                color:chartLabelColor,
                background:"transparent",
                template:"#:numbformat(value)#",
                padding:0,
                margin:0,
            },
            overlay: {
              gradient: "none"
            },
        },
        series: series,
        valueAxis: {
            majorGridLines: {
                visible: true
            },
            line:{
                visible:false
            },
            labels:{
                font:chartFont,
                template:"#:value<=1000?kendo.toString(value,'N0'):kendo.toString(value/1000,'N0')+'k'#"
            },
            visible: true,
        },
        categoryAxis: {
            field: "period",
            majorGridLines: {
                visible: false
            },
            labels:{
                font:chartFont,
                rotation: {
                    angle: 45,
                    align: "center"
                }
            }
        },
        tooltip: {
            visible: true,
            font:chartFont,
            template: "#= series.name #: #= kendo.toString(value, 'N0') #"
        },
        seriesColors:chartColors
    });
};

dg.generategrid6RM = function(data){
	var series = [];
	data.series.forEach(function(x){
		x["name"] = x.Name
		x["field"] = x.Field
		x["data"] = x.Data
		if(x.Name.indexOf("Average") < 0 && x.Name != "Not Call"){
			series.push({field: x.Field,name:x.Name, stack: "Call"})
		}else if(x.Name.indexOf("Average") < 0 && x.Name == "Not Call"){
            series.push({field: x.Field,name:x.Name, stack: "NotCall"})
        }
	});

	//if(dcr.clientbyregionview() == "monthly"){
    series.push({field: "totaldisplay",
        visual: function (e) {
            return "";
        },
        labels:{
            position:"insideBase",
            template:"#:replaceString(kendo.toString(dataItem.totaldisplay,'P0'))#"
        },
        tooltip: {
            visible: false,
        },
        color:"transparent",
        stack: "Call"
    })
	//}

    series.push({field: "totaldisplaynotcall",
            name:"(% of Total RMs)",
                visual: function (e) {
                return "";
            },
            labels:{
                position:"insideBase",
                template:"#:replaceString(kendo.toString(dataItem.totaldisplaynotcall,'P0'))#"
            },
            tooltip: {
                visible: false,
            },
            color:"transparent",
            stack: "NotCall"
        })
	
    var arrtotal = [];
    var arr = data.series[0].data;
    for(var i in arr){
        var v = arr[i]+data.series[1].data[i];
        arrtotal.push(v<50?50:v);
    }
    var totalseries = {
        name:"total",
		field:"total",
        data:arrtotal
    }
    var sources = [];
    for(var i in data.categories){
        var d = {
            period:data.categories[i]
        }
        for(var s in data.series){
            d[data.series[s].Field] = data.series[s].data[i];    
        }
        var total = 0.1*d[data.series[data.series.length - 1].Name];
		//if(dcr.clientbyregionview() == "monthly")
        d["totaldisplay"] = d["Average"];
        d["totaldisplaynotcall"] = d["AverageNotCall"];
        sources.push(d);
    }
    $("#gchart6").kendoChart({
        dataSource: {
            data: sources
        },
        title: {
            visible:false,
        },
        chartArea:{
            height:200
        },
        legend: {
            visible: true,
            position:"bottom",
            labels:{
                font:chartFont
            }
        },
        seriesDefaults: {
            type: "column",
            stack:true,
            labels:{
                visible: chartLabelDisplay,
                font:chartFont,
                position:"center",
                color:chartLabelColor,
                background:"transparent",
                template:"#:numbformat(value)#",
                padding:0,
                margin:0,
            },
            overlay: {
              gradient: "none"
            },
        },
        series: series,
        valueAxis: {
            majorGridLines: {
                visible: true
            },
            line:{
                visible:false
            },
            labels:{
                font:chartFont,
                template:"#:value<=1000?kendo.toString(value,'N0'):kendo.toString(value/1000,'N0')+'k'#"
            },
            visible: true,
        },
        categoryAxis: {
            field: "period",
            majorGridLines: {
                visible: false
            },
            labels:{
                font:chartFont,
                rotation: {
                    angle: 45,
                    align: "center"
                }
            }
        },
        tooltip: {
            visible: true,
            font:chartFont,
            template: "#= series.name #: #= kendo.toString(value, 'N0') #"
        },
        seriesColors:chartColors
    });
};

dg.gen1 = function(){
    var dataSource = [];
    if (dg.activeUserView()=="all") {
        dataSource = dg.GChart1All()
    }else{
        dataSource = dg.GChart1RM()
    }
    // Merge Data
    var userSources = [];
    var SelectedPeriod = Enumerable.From(dataSource.ActiveUserData).GroupBy("$._id.period").OrderBy("$.Key()").ToArray();
    var ActiveUsers = 0;
    var RMUsers = 0;
    var TotalUsers = 0;
    var TotalActiveUsers = 0;
    var RMUsers = 0;

    for(var p in SelectedPeriod){
        var period = SelectedPeriod[p].Key();
        var d = {
            periodstr:period,
            period:new Date(period),
        }
        var SelectedMajorRegion = SelectedPeriod[p].source;
        for(var i in SelectedMajorRegion){
            d["allactiveuser"+SelectedMajorRegion[i]._id.major_region] = SelectedMajorRegion[i].allactiveuser;
            d["activeuser"+SelectedMajorRegion[i]._id.major_region] = SelectedMajorRegion[i].activeuser;
        }
        if(p==(SelectedPeriod.length-1)){
            ActiveUsers = Enumerable.From(SelectedMajorRegion).Sum("$.activeuser");
            TotalActiveUsers = Enumerable.From(SelectedMajorRegion).Sum("$.count");
        }
        userSources.push(d);
    }

    var HeadCountSelectedPeriod = Enumerable.From(dataSource.HeadcountData).GroupBy("$._id.period").OrderBy("$.Key()").ToArray();
    for(var p in HeadCountSelectedPeriod){
        var period = HeadCountSelectedPeriod[p].Key();
        var existingData = Enumerable.From(userSources).Where("$.periodstr == '"+period+"'").FirstOrDefault();
        var isFound = true;
        if(existingData===undefined){
            isFound = false;
            existingData = {
                periodstr:period,
                period:new Date(period),
            }   
        }
        var SelectedMajorRegion = HeadCountSelectedPeriod[p].source;
        existingData["headcounttotal"] = Enumerable.From(SelectedMajorRegion).Sum("$.allactiveuser");
        for(var i in SelectedMajorRegion){
            existingData["headcount"+SelectedMajorRegion[i]._id.major_region] = SelectedMajorRegion[i].activeuser;
            // rm users
            var activeuser = existingData["activeuser"+SelectedMajorRegion[i]._id.major_region];
            var usage = SelectedMajorRegion[i].activeuser == 0 ? 0 : activeuser/SelectedMajorRegion[i].activeuser;
            existingData["usage"+SelectedMajorRegion[i]._id.major_region] = usage;

            // all users
            var allactiveuser = existingData["allactiveuser"+SelectedMajorRegion[i]._id.major_region];
            var usage = SelectedMajorRegion[i].allactiveuser == 0 ? 0 : allactiveuser/SelectedMajorRegion[i].allactiveuser;
            existingData["allusage"+SelectedMajorRegion[i]._id.major_region] = usage;

            if(!isFound){
                userSources.push(existingData);
            }
        }

        if(p==(HeadCountSelectedPeriod.length-1)){
            TotalUsers = Enumerable.From(SelectedMajorRegion).Sum("$.count");
            RMUsers = Enumerable.From(SelectedMajorRegion).Sum("$.activeuser");
        }
        userSources.push(d);
    }
	
    var ytd = LoginUsers.YTD;
    ytd.Users(TotalUsers)
    ytd.ActiveUsers(TotalActiveUsers);
    ytd.ActiveUsage(TotalUsers==0?0:TotalActiveUsers/TotalUsers);
    
    var MajorRegionList = Enumerable.From(dataSource.ActiveUserData).GroupBy("$._id.major_region").OrderBy("$.Key()").ToArray();

    var ActiveUsersSeries = [];
    var ActiveUsageSeries = [];
    var prefix = "";
    if(dg.activeUserView()=="all"){
        prefix = "all";
    }
    for(var i in MajorRegionList){
        ActiveUsersSeries.push({field:prefix+"activeuser"+MajorRegionList[i].Key(),name:MajorRegionList[i].Key(),axis:"users",
            labels:{
                template: "#:kendo.toString(dataItem."+prefix+"usage"+MajorRegionList[i].Key()+",'P0')#",
            }
    	});
    }
	
	// for(var i in dataSource.SalesModuleData){
	// 	if(dg.activeUserView() == "rm")
 //        	dataSource.SalesModuleData[i].headcounttotal = dataSource.HeadcountRM;
	// 	else
	// 		dataSource.SalesModuleData[i].headcounttotal = userSources[i].headcounttotal;
 //    }
    var SalesModulesData = dataSource.SalesModuleData;
    // var maxValue = Enumerable.From(SalesModulesData).Max("$.countMrUser");
    // var maxValue = Enumerable.From(SalesModulesData).Max("$.headcounttotal");
    // maxValue = 60*Math.ceil(maxValue/50);
    // SalesModulesData.push({
    //     _id:"",
    // })
    var seriesList;
    if(dg.activeUserView() == "rm"){
        var seriesList = [
            {field:"apclientmap",name:"Account Plan"},
            {field:"callreports",name:"Call Reports"},
            {field:"dealpipeline",name:"Deal Pipeline"},
            {field:"prospects",name:"Prospects"},
            {field:"countMrUser",name:"Total Headcount",color:'#000'},
        ]
    }else{
        var seriesList = [
            {field:"apclientmap",name:"Account Plan"},
            {field:"callreports",name:"Call Reports"},
            {field:"dealpipeline",name:"Deal Pipeline"},
            {field:"prospects",name:"Prospects"},
        ]
    }
    // Gen ActiveUsersPR Chart 
    $("#gchart1").html("");
    $("#gchart1").kendoChart({
        // transitions: false,
        dataSource: {
            data: SalesModulesData
        },
        title: {
            visible:false,
        },
        chartArea:{
            height:200
        },
        legend: {
            visible: true,
            position:"bottom",
            labels:{
                font:chartFont
            }
        },
        seriesDefaults: {
            type: "line",
            labels: {
                visible: false,//chartLabelDisplay,
                font:chartFont,
                color:chartLabelColor,
                background:"transparent",
                template: "#:kendo.toString(value, 'N0') #",
                padding:0,
                margin:0,
            },
            overlay: {
              gradient: "none"
            },
        },
        series: seriesList,
        valueAxis:{
            // max:maxValue,
            majorGridLines: {
                visible: false
            },
            line:{
                visible:false
            },
            labels:{
                font:chartFont,
                template:"#:kendo.toString(value,'N0')#"
            },
            visible: true
        },
        categoryAxis: {
            field: "_id",
            majorGridLines: {
                visible: false
            },
            labels:{
                font:chartFont,
                rotation: {
                    angle: 45,
                    align: "center"
                },
                template:"#:value!==''?moment(value).format('MMM YY'):''#"
            },

            axisCrossingValues: [0, 10]
        },
        tooltip: {
            visible: true,
            font:chartFont,
            template: "#= series.name #: #= kendo.toString(value, 'N0') #"
        },
        seriesColors:chartColors,
        // render: function(e) {
        //     var draw = kendo.drawing;
        //     var width = $("#gchart1").width();
        //     var height = $("#gchart1").height()-30;
        //     var dataSource = e.sender.dataSource._data;
        //     var totallength = dataSource.length;
        //     var lastData = dataSource[totallength-2];
        //     var legendWidth = (width/totallength); 
        //     var xPosition = width -legendWidth-(0.30*legendWidth);
        //     var maxValue = e.sender.options.valueAxis.max;
        //     for(var i in seriesList){
        //         var value  = lastData[seriesList[i].field];
        //         var yPosition = height-((value/maxValue)*height);
        //         yPosition-=3;
        //         var text = new draw.Text(seriesList[i].name, [xPosition, yPosition], {
        //           font:chartFont,
        //           color:"#58666e"
        //         });
        //         e.sender.surface.draw(text);
        //     }
        // },
    });

}

dg.chartTop5 = function(data, target, globalAverage, regionalAverage, showRender){
    //change united arab emirate to UAE
    var uae = data.categories.indexOf("UNITED ARAB EMIRATES")
    if (uae !== -1) {
        data.categories[uae] = "UAE";
    }

    var kor = data.categories.indexOf("KOREA, REPUBLIC OF")
    if (kor !== -1) {
        data.categories[kor] = "KOREA";
    }

    var finalPlotGlobal = globalAverage;//avgPlot / 5;
    var finalPlotRegional = regionalAverage //regionalAverage;//avgPlot / 5;
    // if (target == "gcharttop1"){
    //     console.log(data.categories);
    // }
    var rotateVal = 0;
    if(target == "gcharttop1") {
        rotateVal = 320;
    }
    
    var max = 0;
    data.series.forEach(function(xx){
        xx.data.forEach(function(yy){
            if (yy > max)
                max = yy
        });
    });

    $("#" + target).html("");
    $("#" + target).kendoChart({
        chartArea: {
            background: "transparent",
            // width: 300,
            height: 183
        },
        legend: {
            position: "bottom",
            visible:true,
            labels:{
                font:chartFont
            }
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            labels:{
                visible: chartLabelDisplay,
                font:chartFont,
                //position:"center",
                color:chartLabelColor,
                background:"transparent",
                template:"#:kendo.toString(value,'N0')#",
                padding:5,
                margin:0,
            }
        },
        seriesColors:chartColors,
        series: data.series,
        valueAxis: {
            name: "axs",
            line: {
                visible: false
            },
            labels:{
                font:chartFont,
                template:"#:kendo.toString(value,'N0')#",
                rotation: {
                    angle: 45,
                    align: "center"
                },
            },
            majorGridLines: {
                visible: true
            },
            max: max * 1.5
        },
        categoryAxis: {
            name: "catAxis",
            categories: data.categories,//["China", "Hong Kong", "India", "Singapore", "UAE"],//data.categories,//
            majorGridLines: {
                visible: false
            },
            labels:{
                font:chartFont,
            },
        },
        tooltip: {
            visible: true,
            template: "#= kendo.toString(value,'n0') #",//#= series.name #:
            font:chartFont,
        },

        render: function(e) {
            if (showRender == true) {
                var valueAxis = e.sender.getAxis("axs");
                var categoryAxis = e.sender.getAxis("catAxis");

                var valueSlot = valueAxis.slot(finalPlotGlobal);
                var valueSlotRegion = valueAxis.slot(finalPlotRegional);

                var lastCategoryIndex = Math.max(1, categoryAxis.range().max);
                var minCategorySlot = categoryAxis.slot(0);
                var maxCategorySlot = categoryAxis.slot(lastCategoryIndex);


                var line = new kendo.drawing.Path({
                    stroke: {
                      color: "#8a8b8d",
                      width: 3
                    },
                });
                line.moveTo(valueSlot.origin).lineTo([valueSlot.origin.x, minCategorySlot.origin.y + 10]);

                var line2 = new kendo.drawing.Path({
                    stroke: {
                      color: "#f0ad4e",
                      width: 3
                    },
                });
                line2.moveTo(valueSlotRegion.origin).lineTo([valueSlotRegion.origin.x, minCategorySlot.origin.y + 10]);

                var labelPos = [valueSlot.origin.x - 10 , 0 ];
                var avgVal = kendo.toString(finalPlotGlobal, "n2")
                var label = new kendo.drawing.Text(avgVal, labelPos, {
                    fill: {
                      color: "#8a8b8d"
                    },
                    font: "11px 'Helvetica Neue'",
                });

                var labelPos2 = [valueSlotRegion.origin.x - 10 , valueSlot.origin.y ];
                var avgVal2 = kendo.toString(finalPlotRegional, "n2")
                var label2 = new kendo.drawing.Text(avgVal2, labelPos2, {
                    fill: {
                      color: "#f0ad4e"
                    },
                    font: "11px 'Helvetica Neue'",
                });

                var group = new kendo.drawing.Group();
                group.append(line, label);

                var group2 = new kendo.drawing.Group();
                group2.append(line2, label2);

                if(target != "gcharttop2"){
                    var Mr = filter.MajorRegion();
                    if (Mr != "") {
                        e.sender.surface.draw(group);
                        e.sender.surface.draw(group2);
                    }else{
                        e.sender.surface.draw(group);
                    }
                    
                }
            }
        }
    });
}

dg.top5Country = function(data){
    var countryOrder = ["HONG KONG", "INDIA", "UNITED ARAB EMIRATES", "SINGAPORE", "CHINA"];
    if(filter.MajorRegion() == "AME")
        countryOrder = ["UNITED ARAB EMIRATES", "NIGERIA", "KENYA", "PAKISTAN", "UGANDA", "GHANA"];
    else if(filter.MajorRegion() == "ASA")
        countryOrder = ["INDIA", "SINGAPORE", "MALAYSIA", "BANGLADESH", "INDONESIA"];
    else if(filter.MajorRegion() == "GCNA")
        countryOrder = ["HONG KONG", "KOREA, REPUBLIC OF", "CHINA", "TAIWAN"];
    var ctg1 = data.categories1;
    var ctg2 = data.categories2;
    var data1 = Enumerable.From(ctg1)
                .OrderByDescending(function (x) { return x._id.Country})
                .ToArray();

    var data2 = Enumerable.From(ctg2)
                .OrderByDescending(function (x) { return x._id.Country})
                .ToArray();
    var datas = [];
    countryOrder.forEach(function(value, idx){
        var f1 = Math.floor(Enumerable.From(ctg1).Where("$._id.PEOPLESOFT_COUNTRY == '" + value + "'").Select("$.Count").Average()) ;
        var f2 = Enumerable.From(ctg2).Where("$._id == '" + value + "'").Select("$.totalRM").Average();
        datas.push({
            country : value,
            field1 :  f1,
            field2 :  (f2 - f1) < 0 ? 0 : f2 - f1 // < 0 ? 0 : f2 - f1,
        });
    });

    var sortData = Enumerable.From(datas)
                //.OrderByDescending(function (x) { return x.total})
                .ToArray();

    
    var val1 = Enumerable.From(sortData).Select("$.field1").ToArray();
    var val2 = Enumerable.From(sortData).Select("$.field2").ToArray();
    var categories = Enumerable.From(sortData).Select("$.country").ToArray();

    //shorting United Arab Emirates
    var uae = categories.indexOf("UNITED ARAB EMIRATES")
    if (uae !== -1) {
        categories[uae] = "UAE";
    }

    var kor = categories.indexOf("KOREA, REPUBLIC OF")
    if (kor !== -1) {
        categories[kor] = "KOREA";
    }

    var series = [];
    series.push({ "name" : "RMs logging in", "data" : val1 });
    series.push({ "name" : "RMs not logging in", "data" : val2 });
    $("#gcharttop4").kendoChart({
        chartArea: {
            background: "transparent",
            height: 193
        },
        legend: {
            position: "bottom",
            visible:true,
            labels:{
                font:chartFont
            }
        },
        seriesDefaults: {
            type: "bar",
            stack: true,
            overlay: {
              gradient: "none"
            },
            labels:{
                visible: chartLabelDisplay,
                font:chartFont,
                color:chartLabelColor,
                position:"center",
                background:"transparent",
                template:"#:kendo.toString(value,'N0')#",
                padding:0,
                margin:0,
            }
        },
        seriesColors:chartColors,
        series: series,
        valueAxis: {
            line: {
                visible: false
            },
            labels:{
                font:chartFont,
                template:"#:kendo.toString(value,'N0')#"
            },
            majorGridLines: {
                visible: true
            },
        },
        categoryAxis: {
            categories: categories,
            majorGridLines: {
                visible: false
            },
            labels:{
                font:chartFont,
            },
        },
        tooltip: {
            visible: true,
            template: "#= kendo.toString(value,'n0') #",
            font:chartFont,
        }
    });
}

function resetGlobalFilter(){
    resetFilter();
    GetData();
}