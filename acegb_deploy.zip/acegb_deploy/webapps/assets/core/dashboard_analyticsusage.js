var au = {
  Processing:ko.observable(false),
  activeUserChart4:ko.observable("all"),
  allData124:ko.observable({}),
  allData356:ko.observable({}),
  allDataAnalyze1:ko.observable({}),
  showRender:ko.observable(true),
  selectUser: ko.observable("ALL"),
  listSelect:ko.observableArray(["ALL", "RM", "NON RM"]),
  dataGlobal1:ko.observable(""),
  dataGlobal2:ko.observable(""),
  dataGlobal3:ko.observable(""),
  totalPerMonth:ko.observableArray([]),
  listYear:ko.observableArray(['201701', '201702', '201703', '201704', '201705', '201706', '201707', '201708', '201709', '201710', '201711']),
  totalYear:ko.observableArray([]),
  dataList:ko.observableArray([])
};

au.temp = {}

au.Init = function() {
    au.Processing(false)
    au.getTop5Analityc()
    
    setTimeout(function(){
        au.generateChart1(au.allData124())
        au.generateChart2(au.allData124())
        au.generateChart3(au.allData356())
        au.generateChart4(au.allData124())
        // au.generateChart5(au.allData356())
        // au.generateChart6(au.allData356())
        // au.RenderAnalys1(au.allDataAnalyze1())
    }, 100)
}

au.GetData = function(){
    if(!ds.fromAnalytic()){
        resetDate(true);
    }
    ds.fromAnalytic(true);
    // filter.Start(new Date(filter.DefaultDate().getFullYear(), filter.DefaultDate().getMonth()+1, filter.DefaultDate().getDate()));
    // filter.Finish(new Date(filter.Start().getFullYear()+1, filter.Start().getMonth()-1, 30));
    var paramTemp = ko.mapping.toJS(filter)

    var param = {
        StartStr :  paramTemp.StartStr,
        FinishStr :  paramTemp.FinishStr,
        MajorRegion : paramTemp.MajorRegion,
        Country : paramTemp.Country
    }

    au.Processing(true)

    Promise.all([au.GetChart1and2and4(param), au.GetChart3and5and6(param)]).then(function(){
        au.Init()
    })
    // au.GetChart1and2and4(param, au.GetChart3and5and6)
}

au.GetChart1and2and4 = function(param){
    return new Promise(function(resolve, reject){
        ajaxPost("/dashboard/chart1and2and4", param, function(res){
            au.allData124(res.Data.data)
            resolve("done")
        })
    })
}

au.GetChart3and5and6 = function(param) {
    return new Promise(function(resolve, reject) {
        ajaxPost("/dashboard/chart3and5and6", param, function(res){
            if(res.Data !== null) {
                au.allData356(res.Data)
                resolve("done")
            }
        })
    })
}

au.GetAnalys1 = function(param, callback) {
    return new Promise(function(resolve, reject){
        param["Category"] =  (au.selectUser() == "NON RM")?"NON-RM":au.selectUser()

        $(".grid-loading").css("height", 100)

        kendo.ui.progress($(".grid-loading"), true);
        $("#gridAnalys1").html("")
        // ajaxPost("/dashboard/analyze1", param, function(res) {
        //     au.allDataAnalyze1(res.Data)

        //     resolve("done")

        //     if(typeof callback === "function") {
        //         callback()
        //     }
        // })
        au.RenderAnalys1(param)
    })
}

au.ChangeAnalyze1 = function(e) {
    var val = e.sender.value();
    au.selectUser(val)

    var paramTemp = ko.mapping.toJS(filter)

    var param = {
        StartStr :  paramTemp.StartStr,
        FinishStr :  paramTemp.FinishStr,
        MajorRegion : paramTemp.MajorRegion,
        Country : paramTemp.Country
    }

    au.GetAnalys1(param, au.RenderAnalys1)
}

au.RenderAnalys1 = function(param) {
    var strFilter = ""
    var strName = ""
    if(au.selectUser() == "ALL") {
        strFilter = "All_User_Ids"
        strName   = "v.All_User_Names"
    } else if(au.selectUser() == "RM") {
        strFilter = "RM_User_Ids"
        strName   = "v.RM_User_Names"
    } else if(au.selectUser() == "NON RM") {
        strFilter = "NON_RM_User_Ids"
        strName = "v.NON_RM_User_Names"
    }

    var usersDistinct = Enumerable.From(au.allDataAnalyze1().monthlyData).GroupBy("$." + strFilter).ToArray()
    var startDateYtd = parseInt(filter.Finish().getFullYear() + "01")
    var data = []
    usersDistinct.forEach(function(e){
        var row = {
            psid : e.Key()
        }

        e.source.forEach(function(v){
            row['Users']  = eval(strName);
            row["Country"] = v.Country
            row['Segment'] = v.segment
            row['Category'] = v.category
            row['lm_id'] = v.lm_id
            row["Manager"] = v.Line_Manager
            var keys = Object.keys(v);
            keys.forEach(function(v1){
                var key = parseInt(v1)
                if(!isNaN(key) && key >= startDateYtd) {
                    var year = (""+key).substring(0,4)
                    var month = (""+key).substring(4,6)
                    var dateFormat = moment(year+"-"+month).format("MMMYY")
                    if(row[dateFormat] === undefined) {
                        row[dateFormat] = 0
                    }

                    if(!isNaN(v[key])){
                        row[dateFormat] += v[key]
                    } else {
                        row[dateFormat] += 0
                    }
                }
            })
        })

        data.push(row)
    })

    au.temp = data
    var columns = []

    if(data.length > 0) {
        columns = Object.keys(data[0])
    }

    var columnsGrid = []
    var aggregates = []

    var count = 0;
    columns.forEach(function(e){
        if(++count > 7) {

            columnsGrid.push({
                field: e,
                title: e,
                aggregates: ["sum"],
                footerTemplate: "#=sum#"
            })

            aggregates.push({
                field: e,
                aggregate: "sum"
            })
        } else {
            if(e == "Manager") {
                columnsGrid.push({
                    field: e,
                    title: e,
                    footerTemplate: "Total",
                    footerAttributes: {
                        style: "text-align: right;"
                    }
                })
            } else {
                columnsGrid.push({
                    field: e,
                    title: e
                })
            }
        }
    })
    
    $("#gridAnalys1").kendoGrid({
        dataSource: {
            transport: {
               read:function(option){
                    // param.filter = option.data.filter
                    // param.page = option.data.page
                    // param.pageSize = option.data.pageSize
                    param.Skip = option.data.skip
                    param.Sort = option.data.sort
                    param.Take = option.data.take
                    // param.title = ds.subscriptionTitleList()[0]
                    ajaxPost("/dashboard/analyze1", param, function (res) {
                        au.totalPerMonth(res.Data.totalpermonth)
                        var data = (res.Data ==  []) ? [] : res.Data
                        option.success(data);
                    })
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
            },
            // data: data,
            // pageSize: 10,
            // aggregate: aggregates,
            serverPaging: true,
            serverSorting: true,
            // serverFiltering: true,

            sort: [{field:"All_User_Ids",dir:"asc"},
                    {field:"All_User_Names",dir:"asc"},
                    {field:"Country",dir:"asc"},
                    {field:"segment",dir:"asc"},
                    {field:"category",dir:"asc"},
                    {field:"lm_id",dir:"asc"},
                    {field:"Line_Manager",dir:"asc"},
                    {field:'["201701"]',dir:"asc"},
                    {field:'["201702"]',dir:"asc"},
                    {field:'["201703"]',dir:"asc"},
                    {field:'["201704"]',dir:"asc"},
                    {field:'["201705"]',dir:"asc"},
                    {field:'["201706"]',dir:"asc"},
                    {field:'["201707"]',dir:"asc"},
                    {field:'["201708"]',dir:"asc"},
                    {field:'["201709"]',dir:"asc"},
                    {field:'["201710"]',dir:"asc"},
                    {field:'["201711"]',dir:"asc"},
            ],
            schema: {
                data: function(data) {
                    if (data.length == 0) {
                        return [];
                    } else {
                        return data.monthlyData;
                    }   
                },
                total: "totaldata",
                model: {
                    fields: {
                        All_User_Ids: { type: "string" },
                        All_User_Names: { type: "string" },
                        Country: { type: "string" },
                        segment: { type: "string" },
                        category: { type: "string" },
                        lm_id: { type: "string" },
                        Line_Manager: { type: "string" },
                        '["201701"]': { type: "number" },
                        '["201702"]': { type: "number" },
                        '["201703"]': { type: "number" },
                        '["201704"]': { type: "number" },
                        '["201705"]': { type: "number" },
                        '["201706"]': { type: "number" },
                        '["201707"]': { type: "number" },
                        '["201708"]': { type: "number" },
                        '["201709"]': { type: "number" },
                        '["201710"]': { type: "number" },
                        '["201711"]': { type: "number" },
                    }
                }
            }
        },
        // excel: {
        //     fileName: "Total Logins Per Month.xlsx",
        //     allPages: true,
        // },
        // toolbar: ["excel"],
        columns: [
            { field: "All_User_Ids", title: "PSID",},
            { field: "All_User_Names", title: "Users",},
            { field: "Country", title: "Country",},
            { field: "segment", title: "Segment",},
            { field: "category", title: "Category",},
            { field: "lm_id", title: "LM ID",},
            { field: "Line_Manager", title: "Manager",},
            { field: '["201701"]', title: "Jan17",
              footerTemplate: "#: au.totalPerMonth()[201701] #",},
            { field: '["201702"]', title: "Feb17",
              footerTemplate: "#: au.totalPerMonth()[201702] #",},
            { field: '["201703"]', title: "Mar17",
              footerTemplate: "#: au.totalPerMonth()[201703] #",},
            { field: '["201704"]', title: "Apr17",
              footerTemplate: "#: au.totalPerMonth()[201704] #",},
            { field: '["201705"]', title: "May17",
              footerTemplate: "#: au.totalPerMonth()[201705] #",},
            { field: '["201706"]', title: "Jun17",
              footerTemplate: "#: au.totalPerMonth()[201706] #",},
            { field: '["201707"]', title: "Jul17",
              footerTemplate: "#: au.totalPerMonth()[201707] #",},
            { field: '["201708"]', title: "Aug17",
              footerTemplate: "#: au.totalPerMonth()[201708] #",},
            { field: '["201709"]', title: "Sep17",
              footerTemplate: "#: au.totalPerMonth()[201709] #",},
            { field: '["201710"]', title: "Oct17",
              footerTemplate: "#: au.totalPerMonth()[201710] #",},
            { field: '["201711"]', title: "Nov17",
              footerTemplate: "#: au.totalPerMonth()[201711] #",},
        ],
        resizable: true,
        scrollable: false,
        sortable: true,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 1,
            pageSize: 10,
            pageSizes: [5, 10, 20],
        },
        // columns: columnsGrid
    });
    // $("#gridAnalys1").kendoGrid({
    //     dataSource: {
    //         data: data,
    //         pageSize: 15,
    //         aggregate: aggregates
    //     },
    //     excel: {
    //         fileName: "Total Logins Per Month.xlsx",
    //         allPages: true,
    //     },
    //     toolbar: ["excel"],
    //     sortable: true,
    //     resizable: true,
    //     scrollable: false,
    //     pageable: true,
    //     columns: columnsGrid
    // });
    var finish = kendo.toString(new Date(param.FinishStr), "yyyyMM")
    _.filter(au.listYear() , function(num){
        if (num > finish) {
            au.totalYear().push(num)
        }
    });
    _.each(au.totalYear(), function(v){
        var grid = $("#gridAnalys1").data("kendoGrid");
        grid.hideColumn('["'+v+'"]');
    });

    kendo.ui.progress($(".grid-loading"), false);
    $(".grid-loading").css("height", 0)
}

au.RenderAnalys2 = function(data) {
    var dataCountry = Enumerable.From(data.dataRegion).GroupBy("$.Country").ToArray()

    startDateYtd = parseInt(filter.Finish().getFullYear() + "01")

    var data = []
    dataCountry.forEach(function(e){
        var row = {
            Country : e.Key()
        }

        var totalLogin = 0
        var totalYtdAvg = 0
        var totalNumberRM = 0
        var totalRMLogin = 0
        var countMonth = 0
        e.source.forEach(function(e){
            if(e.Period >= startDateYtd) {
                totalLogin += e.TotalLogin
                totalYtdAvg += e.LoginDistinct
                countMonth++
            }
        })

        totalYtdAvg = totalYtdAvg / countMonth

        if(e.source.length > 0) {
            totalNumberRM = e.source[e.source.length - 1].TotalLatestRM
        }

        totalRMLogin = totalYtdAvg / totalNumberRM

        row["totalLogin"] = totalLogin
        row["totalYtdAvg"] = totalYtdAvg
        row["totalNumberRM"] = totalNumberRM
        row["totalRMLogin"] = totalRMLogin

        data.push(row)
    })

    data = Enumerable.From(data).OrderByDescending("$.totalRMLogin").ToArray()
    au.temp = data
    var dataSource = {
        Data : data
    }

    dataSource["Column"] = [{
        field: "Country",
        title: "Country"
    },{
        field: "totalLogin",
        title: "TYD Total Logins"
    },{
        field: "totalYtdAvg",
        title: "YTD Avrg # RM logging in/mnt",
        template: function(d){
            return kendo.toString(d.totalYtdAvg, "N2")
        }
    },{
        field: "totalNumberRM",
        title: "Total # of RMs"
    },{
        field: "totalRMLogin",
        title: "% of RM Logins/mth",
        template: function(d) {
            if(!isFinite(d.totalRMLogin)) {
                return "0%"
            } else {
                return kendo.toString(d.totalRMLogin, "P0")
            }
        }
    },]

    $("#gridAnalys2").html();
    $("#gridAnalys2").kendoGrid({
            dataSource: {
                data: dataSource.Data
            },
            excel: {
                fileName: "Avrg Logins per RM.xlsx",
                allPages: true,
            },
            toolbar: ["excel"],
            sortable: true,
            resizable: true,
            scrollable: true,
            height: 300,
            pageable: {
                numeric: false,
                previousNext: false,
                messages: {
                    display: "Showing {2} data items"
                }
            },
            pageable: false,
            columns: dataSource.Column
        });

    // setTimeout(function(){
    //     $("#gridAnalys2").data("kendoGrid").refresh();
    // }, 500)

    au.temp = data
}

au.activeUserView = function(activeUser) {
    au.activeUserChart4(activeUser)
    au.generateChart4(au.allData124())
}

au.showModal = function(id, callback) {
    $("#"+id).modal("show");

    if(id === "modalRMLogin") {
        au.selectUser("ALL");

        var paramTemp = ko.mapping.toJS(filter)

        var param = {
            StartStr :  paramTemp.StartStr,
            FinishStr :  paramTemp.FinishStr,
            MajorRegion : paramTemp.MajorRegion,
            Country : paramTemp.Country
        }

        au.GetAnalys1(param, au.RenderAnalys1)
        }
    if(id === "modalChart6") {
        setTimeout(function(){
            au.RenderAnalys2(au.allData356())
        }, 500)
    }
}

au.generateChart1 = function(data){
    var seriesList = []
    var dataCategories = []
    var fillCategories = true

    var startDateYtd = parseInt(filter.Finish().getFullYear() + "01")
    var max = 0
    var dataGroup = Enumerable.From(data).OrderBy("$.Period").GroupBy("$.Group").ToArray()

    dataGroup.forEach(function(e){
        var dataRow = {
            name : e.Key(),
            data : []
        }

        e.source.forEach(function(e1){
            if(e1.Period >= startDateYtd) {
                dataRow.data.push(e1.TotalLogin)
                if(e1.TotalLogin > max) {
                    max = e1.TotalLogin
                }

                if(fillCategories === true) {
                    var monthStr = ""

                    dataCategories.push(e1.PeriodStr)
                }
            }
        })
        seriesList.push(dataRow)
        fillCategories = false
    })

    seriesList = _.sortBy(seriesList, 'name')

    if(max > 1000) {
        max = max + 300
    } else {
        max += 100
    }
  $("#chartusage1").kendoChart({
    chartArea: {
        background: "transparent",
        height: 200,
        width: 490
    },
    legend: {
        position: "bottom"
    },
    seriesColors:chartColors,
    seriesDefaults: {
        type: "column",
        overlay: {
          gradient: "none"
        },
        labels:{
            visible: true,
            font:chartFont,
            color:chartLabelColor,
            margin: {
                bottom: 0
            },
            padding: {
                bottom: 0
            },
            background:"transparent",
        },
        max: max
    },
    series: seriesList,
    valueAxis: {
        labels:{
            font:chartFont
        },
        majorGridLines: {
            visible: false
        },
        line:{
            visible:false
        },
        max: max,
        visible: false
    },
    categoryAxis: {
        categories: dataCategories,
        line: {
            visible: false
        },
        majorGridLines: {
            visible: false
        },
        labels: {
            font:chartFont,
            rotation: {
                angle: 45,
                align: "center"
            }
        }
    },
    tooltip: {
        visible: true,
        format: "{0}%",
        template: "#= series.name #: #= value #"
    },
    seriesColors:chartColors
  });
}

au.generateChart2 = function(data){
    var seriesList = []
    var dataCategories = []
    var fillCategories = true

    var startDateYtd = parseInt(filter.Finish().getFullYear() + "01")

    var dataGroup = Enumerable.From(data).OrderBy("$.Period").GroupBy("$.Group").ToArray()
    var max = 0

    dataGroup.forEach(function(e){
        var dataRow = {
            name : e.Key(),
            data : []
        }

        e.source.forEach(function(e1){
            if(e1.Period >= startDateYtd) {
                if (e1.LoginDistinct > max) {
                    max = e1.LoginDistinct
                }

                dataRow.data.push(e1.LoginDistinct)

                if(fillCategories === true) {
                    var monthStr = ""

                    dataCategories.push(e1.PeriodStr)
                }
            }
        })

        seriesList.push(dataRow)
        fillCategories = false
    })

    if(max > 1000) {
        max = max + 300
    } else {
        max += 100
    }

  $("#chartusage2").kendoChart({
    chartArea: {
        background: "transparent",
        height: 200
    },
    seriesColors:chartColors,
    legend: {
        position: "bottom"
    },
    seriesDefaults: {
        type: "column",
        overlay: {
          gradient: "none"
        },
        labels:{
            visible: true,
            font:chartFont,
            margin: {
                bottom: 0
            },
            padding: {
                bottom: 0
            },
            color:chartLabelColor,
            background:"transparent",
        }
    },
    series: seriesList,
    valueAxis: {
        labels:{
            font:chartFont
        },
        max: max,
        majorGridLines: {
            visible: false
        },
        line:{
            visible:false
        },
        visible: false
    },
    categoryAxis: {
        categories: dataCategories,
        line: {
            visible: false
        },
        majorGridLines: {
            visible: false
        },
        labels: {
            font:chartFont,
            rotation: {
                angle: 45,
                align: "center"
            }
        }
    },
    tooltip: {
        visible: true,
        format: "{0}%",
        template: "#= series.name #: #= value #"
    },
    seriesColors:chartColors
  });
}

au.generateChart3 = function(data){
    var seriesList = [{
            name : "# of Unique CB RM Logins",
            data : [],
            axis : "cbrm",
            type : "column"
        },
        {
            name : "CB RM login %",
            data : [],
            axis : "totalrm",
            type : "line",
            labels: {
                visible: true,
                template: "#: value #%",
                //position: "below",
                background: "transparent"
            }
        }]

    var startDateYtd = parseInt(filter.Finish().getFullYear() + "01")

    var max1 = 0
    var max2 = 0
    var max3 = 0

    var dataCategories = []
    var fillCategories = true
    
    data.dataGlobal.forEach(function(e){
        if(e.Period >= startDateYtd) {
            if(filter.MajorRegion() == "" && filter.Country() == "") {
                seriesList[0].data.push(e.LoginDistinct)
            }

            if(e.LoginDistinct > max1) {
                max1 = e.LoginDistinct
            }

            var temp = (e.LoginDistinct / e.TotalRM).toFixed(2) * 100
            seriesList[1].data.push(kendo.toString(temp, 'n0'))
            if(kendo.toString(temp, 'n0') > max2) {
                max2 = kendo.toString(temp, 'n0')
            }
            au.dataGlobal3((e.LoginDistinct / e.TotalRM).toFixed(2) * 100)

            dataCategories.push(e.PeriodStr)
        }
    })

    if(filter.MajorRegion() != "" && filter.Country() == ""){
        dataCategories.forEach(function(d){
            var totLogicDistinct = 0
            for(var i = 0; i < data.dataRegion.length; i++){
                var e = data.dataRegion[i];
                if(e.Region == filter.MajorRegion() && e.PeriodStr == d){
                    totLogicDistinct += e.LoginDistinct
                }
            }

            seriesList[0].data.push(totLogicDistinct)
        })

    } else if(filter.MajorRegion() != "" && filter.Country() != ""){
        dataCategories.forEach(function(d){
            var totLogicDistinct = 0
            for(var i = 0; i < data.dataRegion.length; i++){
                var e = data.dataRegion[i];
                if(e.Country == filter.Country() && e.PeriodStr == d){
                    totLogicDistinct += e.LoginDistinct
                }
            }

            seriesList[0].data.push(totLogicDistinct)
        })
    }

    
    if(filter.MajorRegion() != "" && filter.Country() == ""){
        max2 = 0
        datax = []
        dataCategories.forEach(function(d){
            var valueLoginDistinct = 0;
            var valueTotalRM = 0;
            for(var i = 0; i < data.dataRegion.length; i++){
                var e = data.dataRegion[i];
                if(e.Region == filter.MajorRegion() && e.PeriodStr == d){
                    valueLoginDistinct += e.LoginDistinct;
                    valueTotalRM += e.TotalRM
                }
            }

            var temp = (valueLoginDistinct / valueTotalRM).toFixed(2) * 100
            if(kendo.toString(temp, 'n0') > max2) {
                max2 = kendo.toString(temp, 'n0')
            }
            datax.push(temp.toFixed(0))
        });
        seriesList[1].data = datax
        
    }else if(filter.MajorRegion() != "" && filter.Country() != ""){
        max2 = 0
        datax = []
        dataCategories.forEach(function(d){
            var valueLoginDistinct = 0;
            var valueTotalRM = 0;
            for(var i = 0; i < data.dataRegion.length; i++){
                var e = data.dataRegion[i];
                if(e.Country == filter.Country() && e.PeriodStr == d){
                    valueLoginDistinct += e.LoginDistinct;
                    valueTotalRM += e.TotalRM
                }
            }

            // console.log(valueLoginDistinct, valueTotalRM)
            // if (valueTotalRM > 0) {
                var temp = (valueLoginDistinct / valueTotalRM).toFixed(2) * 100
            // }else{
                // var temp = 0
            // }
            if(kendo.toString(temp, 'n0') > max2) {
                max2 = kendo.toString(temp, 'n0')
            }
            datax.push(temp.toFixed(0))
            // var value = 0;
            // for(var i = 0; i < data.dataRegion.length; i++){
            //     var e = data.dataRegion[i];
            //     if(e.Country == filter.Country() && e.PeriodStr == d){
            //         value += (e.LoginDistinct / e.TotalRM).toFixed(2) * 100;
            //     }
            // }
            // data.push(value.toFixed(0))
        });
        seriesList[1].data = datax
    }

    max1 += 100
    // max2  += 20
  $("#chartusage3").kendoChart({
    chartArea: {
        background: "transparent",
        height: 200
    },
    seriesDefaults: {
        overlay: {
          gradient: "none"
        },
    },
    legend: {
        position: "bottom",
        labels: {
            template: function(e){
                console.log(e)
                var text = e.text.replace('CB','GB')
                return text
            }
        }
    },
    series: seriesList,
    valueAxis: [{
        name:"cbrm",
        labels:{
            font:chartFont,
            visible: false
        },
        majorGridLines: {
            visible: false
        },
        line:{
            visible:false
        },
        visible: false
    },{
        name:"totalrm",
        labels:{
            font:chartFont,
            format: "{0}%",
            visible: true
            // template:"#:numbformatToPersen(value)#",
        },
        majorGridLines: {
            visible: false
        },
        majorUnit: 5,
        max:max2 * 1.22,
        line:{
            visible:false
        },
        visible: false
    },{
        name:"totalrm1",
        labels:{
            font:chartFont,
            format: "{0}%",
            visible: true
            // template:"#:numbformatToPersen(value)#",
        },
        majorGridLines: {
            visible: false
        },
        majorUnit: 10,
        max:max2,
        line:{
            visible:false
        },
        visible: false
    }],
    categoryAxis: {
        categories: dataCategories,
        line: {
            visible: false
        },
        majorGridLines: {
            visible: false
        },
        labels: {
            font:chartFont,
            rotation: {
                angle: 45,
                align: "center"
            }
        },
        axisCrossingValues: [0, 10, 10]
    },
    tooltip: {
        visible: true,
        format: "{0}%",
        template: "#= series.name #: # if(series.axis == 'totalrm'){ #  #:value ##:'%'#  #}else{# #: value # #}#"
    },
    seriesColors:chartColors
  });
}

au.generateChart4 = function(data){
    var seriesList = []
    var dataCategories = []
    var fillCategories = true

    var categoriesFilter = {}

    var startDateYtd = parseInt(filter.Finish().getFullYear() + "01")

    var max = 0

    categoriesFilter = Enumerable.From(data).OrderBy("$.Period").Distinct("$.PeriodStr").ToArray()

    categoriesFilter.forEach(function(e){
        if(e.Period >= startDateYtd) {
            dataCategories.push(e.PeriodStr)
        }
    })

    var dataFilter = {}
    if(au.activeUserChart4() === "rm") {
        dataFilter = Enumerable.From(data).Where(function(x){
            return x.Group === "RM"
        }).OrderBy("$.Period").ToArray()


        var dataRow = {
            type : "line",
            name : "Avrg Logins",
            data : [],
            axis : "lineAxis",
            labels: {
                visible: true
            }
        }

        dataFilter.forEach(function(e){
           if(e.Period >= startDateYtd) {
                if ((e.TotalLogin / e.LoginDistinct).toFixed(1) > max) {
                    max = (e.TotalLogin / e.LoginDistinct).toFixed(1)
                }

                dataRow.data.push((e.TotalLogin / e.LoginDistinct).toFixed(1))
            }
        })

        seriesList.push(dataRow)
    } else {
        dataFilter = Enumerable.From(data).OrderBy("$.Period").GroupBy("$.Period").ToArray()
        var dataRow = {
            type : "line",
            name : "Avrg Logins",
            data : [],
            axis : "lineAxis",
            labels: {
                visible: true
            }
        }

        dataFilter.forEach(function(e){
            if(e.Key() >= startDateYtd) {
                var totalLogin = 0
                var totalUniqueLogin = 0

                e.source.forEach(function(e1){
                    totalLogin += e1.TotalLogin
                    totalUniqueLogin += e1.LoginDistinct
                })

                au.dataGlobal2((totalLogin / totalUniqueLogin).toFixed(1))

                if ((totalLogin / totalUniqueLogin).toFixed(1) > max) {
                    max = (totalLogin / totalUniqueLogin).toFixed(1)
                }

                dataRow.data.push((totalLogin / totalUniqueLogin).toFixed(1))
            }
        })

        seriesList.push(dataRow)
    }

  $("#chartusage4").kendoChart({
    chartArea: {
        background: "transparent",
        height: 200
    },
    legend: {
        position: "bottom",
        visible: false
    },
    seriesColors:chartColors,
    series: seriesList,
    valueAxis: [{
        labels:{
            font:chartFont,
            margin:{
                top:50
            }
        },
        majorGridLines: {
            visible: false
        },
        line:{
            visible:false
        },
        majorUnit: 10,
        visible: false,
        name:"lineAxis"
    }],
    categoryAxis: {
        categories: dataCategories,
        line: {
            visible: false
        },
        majorGridLines: {
            visible: false
        },
        labels: {
            font:chartFont,
            rotation: {
                angle: 45,
                align: "center"
            }
        }
    },
    tooltip: {
        visible: true,
        format: "{0}%",
        template: "#= series.name #: #= value #"
    },
    seriesColors:chartColors
  });
}

// au.generateChart5 = function(data){

//     var seriesList = [{
//         name: "Avrg Logins",
//         data: [],
//         labels: {
//             visible: true
//         },
//         axis:"axs"
//     }]

//     var maxPlot = 0

//     var startDateYtd = parseInt(filter.Finish().getFullYear() + "01")

//     var dataCategories = ["GLOBAL", "GCNA", "ASA", "AME", "HONGKONG", "INDIA", "UAE", "SINGAPORE", "CHINA"]

//     var totalGlobal = 0
//     var totalGlobalTemp = 0
//     var totalRMTemp = 0
//     data.dataGlobal.forEach(function(e){
//         if(e.Period >= startDateYtd) {
//             totalGlobalTemp += e.LoginDistinct
//             totalRMTemp = e.TotalLatestRM
//         }
//     })

//     totalGlobal = totalGlobalTemp / totalRMTemp
//     if(maxPlot < kendo.toString(totalGlobal, 'n2')) {
//         maxPlot = kendo.toString(totalGlobal, 'n2')
//     }

//     au.dataGlobal1(kendo.toString(totalGlobal, 'n2'))

//     seriesList[0].data.push(kendo.toString(totalGlobal, 'n2'))

//     var dataGCNA = Enumerable.From(au.allData356().dataRegion).Where(function(x){
//         return x.Region === "GCNA"
//     }).ToArray()

//     var totalGCNA = 0
//     var totalGCNATemp = 0
//     totalRMTemp = 0

//     dataGCNA.forEach(function(e){
//         if(e.Period >= startDateYtd) {
//             totalGCNATemp += e.LoginDistinct
//             totalRMTemp += e.TotalRM
//         }
//     })

//     totalGCNA = totalGCNATemp / totalRMTemp
//     if(maxPlot < kendo.toString(totalGCNA, 'n2') * 100) {
//         maxPlot = kendo.toString(totalGCNA, 'n2') * 100
//     }

//     seriesList[0].data.push(kendo.toString(totalGCNA, 'n2') * 100)

//     var dataASA = Enumerable.From(au.allData356().dataRegion).Where(function(x){
//         return x.Region === "ASA"
//     }).ToArray()

//     var totalASA = 0
//     var totalASATemp = 0
//     totalRMTemp = 0
//     dataASA.forEach(function(e){
//         if(e.Period >= startDateYtd) {
//             totalASATemp += e.LoginDistinct
//             totalRMTemp += e.TotalRM
//         }
//     })

//     totalASA = totalASATemp / totalRMTemp
//     if(maxPlot < kendo.toString(totalASA, 'n2') * 100) {
//         maxPlot = kendo.toString(totalASA, 'n2') * 100
//     }

//     seriesList[0].data.push(kendo.toString(totalASA, 'n2') * 100)

//     var dataAME = Enumerable.From(au.allData356().dataRegion).Where(function(x){
//         return x.Region === "AME"
//     }).ToArray()

//     var totalAME = 0
//     var totalAMETemp = 0
//     totalRMTemp = 0

//     dataAME.forEach(function(e){
//         if(e.Period >= startDateYtd) {
//             totalAMETemp += e.LoginDistinct
//             totalRMTemp += e.TotalRM
//         }
//     })

//     totalAME = totalAMETemp / totalRMTemp
//     if(maxPlot < kendo.toString(totalAME, 'n2') * 100) {
//         maxPlot = kendo.toString(totalAME, 'n2') * 100
//     }

//     seriesList[0].data.push(kendo.toString(totalAME, 'n2') * 100)

//     var dataHONGKONG = Enumerable.From(au.allData356().dataRegion).Where(function(x){
//         return x.Country === "HONG KONG"
//     }).ToArray()

//     var totalHONGKONG = 0
//     var totalHONGKONGTemp = 0
//     totalRMTemp = 0
//     dataHONGKONG.forEach(function(e){
//         if(e.Period >= startDateYtd) {
//             totalHONGKONGTemp += e.LoginDistinct
//             totalRMTemp += e.TotalRM
//         }
//     })

//     totalHONGKONG = totalHONGKONGTemp / totalRMTemp

//     if(maxPlot < kendo.toString(totalHONGKONG, 'n2') * 100) {
//         maxPlot = kendo.toString(totalHONGKONG, 'n2') * 100
//     }

//     seriesList[0].data.push(kendo.toString(totalHONGKONG, 'n2') * 100)

//     var dataINDIA = Enumerable.From(au.allData356().dataRegion).Where(function(x){
//         return x.Country === "INDIA"
//     }).ToArray()

//     var totalINDIA = 0
//     var totalINDIATemp = 0
//     totalRMTemp = 0

//     dataINDIA.forEach(function(e){
//         if(e.Period >= startDateYtd) {
//             totalINDIATemp += e.LoginDistinct
//             totalRMTemp += e.TotalRM
//         }
//     })

//     totalINDIA = totalINDIATemp / totalRMTemp
//     if(maxPlot < kendo.toString(totalINDIA, 'n2') * 100) {
//         maxPlot = kendo.toString(totalINDIA, 'n2') * 100
//     }

//     seriesList[0].data.push(kendo.toString(totalINDIA, 'n2') * 100)

//     var dataUAE = Enumerable.From(au.allData356().dataRegion).Where(function(x){
//         return x.Country === "UNITED ARAB EMIRATES"
//     }).ToArray()

//     var totalUAE = 0
//     var totalUAETemp = 0
//     totalRMTemp = 0

//     dataUAE.forEach(function(e){
//         if(e.Period >= startDateYtd) {
//             totalUAETemp += e.LoginDistinct
//             totalRMTemp += e.TotalRM
//         }
//     })

//     totalUAE = totalUAETemp / totalRMTemp
//     if(maxPlot < kendo.toString(totalUAE, 'n2') * 100) {
//         maxPlot = kendo.toString(totalUAE, 'n2') * 100
//     }

//     seriesList[0].data.push(kendo.toString(totalUAE, 'n2') * 100)

//     var dataSINGAPORE = Enumerable.From(au.allData356().dataRegion).Where(function(x){
//         return x.Country === "SINGAPORE"
//     }).ToArray()

//     var totalSINGAPORE = 0
//     var totalSINGAPORETemp = 0
//     totalRMTemp = 0
//     dataSINGAPORE.forEach(function(e){
//         if(e.Period >= startDateYtd) {
//             totalSINGAPORETemp += e.LoginDistinct
//             totalRMTemp += e.TotalRM
//         }
//     })

//     totalSINGAPORE = totalSINGAPORETemp / totalRMTemp

//     totalSINGAPORE  = kendo.toString(totalSINGAPORE, 'n2') * 100
//     totalSINGAPORE = kendo.toString(totalSINGAPORE, 'n0')

//     if(maxPlot < totalSINGAPORE) {
//         maxPlot = totalSINGAPORE
//     }


//     seriesList[0].data.push(totalSINGAPORE)

//     var dataCHINA = Enumerable.From(au.allData356().dataRegion).Where(function(x){
//         return x.Country === "CHINA"
//     }).ToArray()

//     var totalCHINA = 0
//     var totalCHINATemp = 0
//     totalRMTemp = 0

//     var dataLast = dataCHINA[dataCHINA.length - 1]

//     dataCHINA.forEach(function(e){
//         if(e.Period >= startDateYtd) {
//             totalCHINATemp += e.LoginDistinct
//             totalRMTemp += e.TotalRM
//         }
//     })

//     totalCHINA = totalCHINATemp / totalRMTemp

//     if(maxPlot < kendo.toString(totalCHINA, 'n2') * 100) {
//         maxPlot = kendo.toString(totalCHINA, 'n2') * 100
//     }

//     seriesList[0].data.push(kendo.toString(totalCHINA, 'n2') * 100)

//     au.temp = seriesList

//     $("#chartusage5").kendoChart({
//         chartArea: {
//             background: "transparent",
//             height: 200
//         },
//         legend: {
//             position: "bottom",
//             visible:true,
//             labels:{
//                 font:chartFont
//             }
//         },
//         seriesColors:chartColors,
//         seriesDefaults: {
//             type: "bar",
//             overlay: {
//               gradient: "none"
//             },
//             labels:{
//                 visible: true,
//                 font:chartFont,
//                 //position:"center",
//                 color:chartLabelColor,
//                 background:"transparent",
//                 padding:5,
//                 margin:0,
//             }
//         },
//         seriesColors:chartColors,
//         series: seriesList,
//         valueAxis: {
//             name: "axs",
//             line: {
//                 visible: false
//             },
//             labels:{
//                 font:chartFont,
//                 rotation: {
//                     angle: 45,
//                     align: "center"
//                 }
//             },
//             majorGridLines: {
//                 visible: true
//             }
//         },
//         categoryAxis: {
//             name: "catAxis",
//             categories: dataCategories,//["China", "Hong Kong", "India", "Singapore", "UAE"],//data.categories,//
//             majorGridLines: {
//                 visible: false
//             },
//             labels:{
//                 font:chartFont
//             },
//         },
//         tooltip: {
//             visible: true,
//             font:chartFont
//         },
//         render: function(e) {
//             var valueAxis = e.sender.getAxis("axs");
//             var categoryAxis = e.sender.getAxis("catAxis");
//             var lastCategoryIndex = Math.max(1, categoryAxis.range().max);

//             var valueSlot = valueAxis.slot(maxPlot + 30)
//             var minCategorySlot = categoryAxis.slot(0);
//             var maxCategorySlot = categoryAxis.slot(4);

//             var line = new kendo.drawing.Path({
//                 stroke: {
//                   color: "#0075B2",
//                   width: 3
//                 },
//             });

//             line.moveTo(maxCategorySlot.origin).lineTo([valueSlot.origin.x, maxCategorySlot.origin.y]);

//             e.sender.surface.draw(line);

//         }
//     });
// }

// au.generateChart6 = function(data){

//     var seriesList = [{
//         name: "Avrg Logins",
//         data: [],
//         labels: {
//             visible: true
//         },
//         axis:"axs"
//     }]

//     var maxPlot = 0
//     var startDateYtd = parseInt(filter.Finish().getFullYear() + "01")

//     var dataCategories = ["GLOBAL", "GCNA", "ASA", "AME", "HONGKONG", "INDIA", "UAE", "SINGAPORE", "CHINA"]
//     var listRegion = ["GCNA", "ASA", "AME"];
//     var listCountry = ["HONG KONG", "INDIA", "UNITED ARAB EMIRATES", "SINGAPORE", "CHINA"];
//     var startDateYtd = parseInt(filter.Finish().getFullYear() + "01")
//     var month = 0;
//     var globalTotalLogin = 0;
//     var globalLoginDistinct = 0;
//     var totalGlobalTemp = 0
//     var totalLoginDistinct = 0
//     var monthCount = 0

//     data.dataGlobal.forEach(function(e){
//         if(e.Period >= startDateYtd) {
//             globalTotalLogin += e.TotalLogin;
//             globalLoginDistinct += e.LoginDistinct;
//             month++;
//         }
//     })

//     var totalGlobal = (globalTotalLogin / globalLoginDistinct) / month;

//     if(maxPlot < kendo.toString(totalGlobal, 'n2') * 100) {
//         maxPlot = kendo.toString(totalGlobal, 'n2') * 100
//     }

//     seriesList[0].data.push(kendo.toString(totalGlobal, 'n2') * 100)

//     for(var i = 0; i < listRegion.length; i++){
//         var dataRegion = Enumerable.From(au.allData356().dataRegion).Where(function(x){
//             return x.Region === listRegion[i];
//         }).ToArray()

//         var regionTotalLogin = 0
//         var regionLoginDistinct = 0
//         dataRegion.forEach(function(e){
//             if(e.Period >= startDateYtd) {
//                 regionTotalLogin += e.TotalLogin;
//                 regionLoginDistinct += e.LoginDistinct;
//             }
//         })
//         var totalRegion = (regionTotalLogin / regionLoginDistinct) / month;
//         if(maxPlot < kendo.toString(totalRegion * 100, 'N0')) {
//             maxPlot = kendo.toString(totalRegion * 100, 'N0')
//         }

//         seriesList[0].data.push(kendo.toString(totalRegion * 100, 'N0'))
//     }

//     for(var i = 0; i < listCountry.length; i++){
//         var dataRegion = Enumerable.From(au.allData356().dataRegion).Where(function(x){
//             return x.Country === listCountry[i];
//         }).ToArray()

//         var regionTotalLogin = 0
//         var regionLoginDistinct = 0
//         dataRegion.forEach(function(e){
//             if(e.Period >= startDateYtd) {
//                 regionTotalLogin += e.TotalLogin;
//                 regionLoginDistinct += e.LoginDistinct;
//             }
//         })
//         var totalRegion = (regionTotalLogin / regionLoginDistinct) / month;
//         if(maxPlot < kendo.toString(totalRegion * 100, 'N0')) {
//             maxPlot = kendo.toString(totalRegion * 100, 'N0')
//         }

//         seriesList[0].data.push(kendo.toString(totalRegion * 100, 'N0'))
//     }

//     $("#chartusage6").kendoChart({
//         chartArea: {
//             background: "transparent",
//             height: 200
//         },
//         legend: {
//             position: "bottom",
//             visible:true,
//             labels:{
//                 font:chartFont
//             }
//         },
//         seriesColors:chartColors,
//         seriesDefaults: {
//             type: "bar",
//             overlay: {
//               gradient: "none"
//             },
//             labels:{
//                 visible: true,
//                 font:chartFont,
//                 //position:"center",
//                 color:chartLabelColor,
//                 background:"transparent",
//                 padding:5,
//                 margin:0,
//             }
//         },
//         seriesColors:chartColors,
//         series: seriesList,
//         valueAxis: {
//             name: "axs",
//             line: {
//                 visible: false
//             },
//             labels:{
//                 font:chartFont,
//                 rotation: {
//                     angle: 45,
//                     align: "center"
//                 }
//             },
//             majorGridLines: {
//                 visible: true
//             }
//         },
//         categoryAxis: {
//             name: "catAxis",
//             categories: dataCategories,//["China", "Hong Kong", "India", "Singapore", "UAE"],//data.categories,//
//             majorGridLines: {
//                 visible: false
//             },
//             labels:{
//                 font:chartFont
//             },
//         },
//         tooltip: {
//             visible: true,
//             font:chartFont
//         },
//         render: function(e) {
//             var valueAxis = e.sender.getAxis("axs");
//             var categoryAxis = e.sender.getAxis("catAxis");
//             var lastCategoryIndex = Math.max(1, categoryAxis.range().max);

//             var valueSlot = valueAxis.slot(maxPlot + 30)
//             var minCategorySlot = categoryAxis.slot(0);
//             var maxCategorySlot = categoryAxis.slot(4);

//             var line = new kendo.drawing.Path({
//                 stroke: {
//                   color: "#0075B2",
//                   width: 3
//                 },
//             });

//             line.moveTo(maxCategorySlot.origin).lineTo([valueSlot.origin.x, maxCategorySlot.origin.y]);

//             e.sender.surface.draw(line);

//         }
//     });
// }

au.getAnalyzePDF = function(){
    var paramTemp = ko.mapping.toJS(filter)

    var param = {
        StartStr :  paramTemp.StartStr,
        FinishStr :  paramTemp.FinishStr,
        MajorRegion : paramTemp.MajorRegion,
        Country : paramTemp.Country,
        Category: au.selectUser(),
    }
    ajaxPost("/dashboard/analyticusageexcel", param, function (res) {
        window.location.href = res.Data
    })
}

au.getTop5Analityc = function(){
    ajaxPost("/dashboard/top5analyticusage", {}, function(res){
        console.log(res)
        au.dataList(res.Data);
    })
}