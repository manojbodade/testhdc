var activeLog = {
	loading: ko.observable(true),
	filterUser: ko.observableArray([]),
	filterActivity: ko.observableArray([]),
	from: ko.observable(new Date()),
	to: ko.observable(new Date()),
	listUserName: ko.observableArray([]),
	listActivity: ko.observableArray([]),
	TitelFilter: ko.observable(""),
}

activeLog.toggleFilter = function(){

}

activeLog.Search = function(){
	activeLog.generateGrid();
}

activeLog.Reset = function(){
	activeLog.filterUser([]);
	activeLog.filterActivity([]);
	activeLog.from(new Date());
    activeLog.to(new Date());
	activeLog.generateGrid();
}

activeLog.getAlluser = function(){
	ajaxPost("/usersetting/getalluser", {}, function(res){
		activeLog.listUserName(res.data);
	})
}

activeLog.getAllActivity = function(){
	ajaxPost("/activitylog/getallactivity", {}, function(res){
		activeLog.listActivity(res.Data);
	})
}

activeLog.generateGrid = function(){
	activeLog.loading(true);
	var obj = $("#MasterGridUser");
    obj.html("");
    obj.kendoGrid({
        toolbar:["excel"],
        excel: {
            fileName: "Activity Log Data.xlsx",
        },
        pdf: {
            fileName: "Activity Log Data.pdf",
        },
        excelExport: function(e) {
            e.preventDefault();
            var callData = {};
            var filters = $("#MasterGridUser").data("kendoGrid").dataSource._filter;
            if(filters == undefined){
                filters = {filter: {"filters":[]}}
                callData["filter"] = filters.filter;
            }else{
                callData["filter"] = filters;
            }
            var sort = ""
            if ($("#MasterGridUser").data("kendoGrid").dataSource._sort != undefined){
                sort = $("#MasterGridUser").data("kendoGrid").dataSource._sort[0]["field"];
                sort = $("#MasterGridUser").data("kendoGrid").dataSource._sort[0]["dir"] == "asc"?sort:"-"+sort;
            }
            callData["sort"] = sort;
            callData["Username"] = activeLog.filterUser();
            callData["Activity"] = activeLog.filterActivity();
            callData["From"] = parseInt(moment(activeLog.from()).format("YYYYMMDD"));
            callData["To"] = parseInt(moment(activeLog.to()).format("YYYYMMDD"));

            activeLog.loading(true);
            ajaxPost("/activitylog/exportexcel", callData, function(res){
                setTimeout(function(){
                    location.href = "/activitylog/downloadexcel?filename="+res.Data.filename;
                    activeLog.loading(false);
                }, 1000);
            });
        },
        dataSource:{
            transport:{
                read:function(yo){
                    var callData = {};
                    var sort = "";
                    //build sort parameter
                    if (yo.data["sort"] != undefined){
                      sort = yo.data["sort"][0]["field"];
                      sort = yo.data["sort"][0]["dir"] == "asc"?sort:"-"+sort;
                    }
                    //check filter header kendo
                    if(yo.data["filter"] == undefined){
                      yo.data["filter"] = {filters:[]}
                    }

                    filtsum = yo.data["filter"];
                    //append all kendo parameter (pageize, take, skip, filters, etc)
                    for(var i in yo.data){
                        callData[i] = yo.data[i];
                    }

                    callData["sort"] = sort;
                    callData["Username"] = activeLog.filterUser();
                    callData["Activity"] = activeLog.filterActivity();
                    callData["From"] = parseInt(moment(activeLog.from()).format("YYYYMMDD"));
                    callData["To"] = parseInt(moment(activeLog.to()).format("YYYYMMDD"));
                    ajaxPost("/activitylog/getdata",callData, function(res){
                        activeLog.loading(false)
                        yo.success(res.Data);
                    });
                }
            },
             schema: {
                data: "Records",
                total: "Count",
            },
            serverPaging: true, 
            pageSize:10,
            serverSorting: true,
            serverFiltering:true,
            // data:res.data.data,
            // pageSize: 20
        },
        height: 450,
        scrollable: true,
        sortable: true,
        filterable: true,
        columns: [
        	{
                field: "Username",
                title: "Username"
            },
            {
                field: "IpAddress",
                title: "Ip Address"
            },
            {
                field: "Activity",
                title: "Activity"
            },
            {
                field: "PageUrl",
                title: "Url"
            },
            {
                field: "PageName",
                title: "Page Name"
            },
            {
                field: "AccessTime",
                title: "Access Time",
                template: function(d){
                	return kendo.toString(new Date(d.AccessTime),'dd MMM yyyy HH:MM:ss')
                },
            },
            {
                field: "AccessDate",
                title: "Access Date"
            },
        ],
        pageable:true,
    })
}

$(document).ready(function(){
	activeLog.getAlluser();
	activeLog.getAllActivity();
	activeLog.generateGrid();
    setTimeout(function(){
        $(".panel-nav-button button").css("display", "");
    },100);
});