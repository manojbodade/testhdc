var Prospect = {
    PullRequest:ko.observable(2),
    Processing:ko.observable(false),
    DataMajorRegion : ko.observableArray([]),
    DataPcvc : ko.observableArray([]),
    SelectedMajorRegion:ko.observableArray([]),
    PeriodValue:{
        Period:ko.observable(new Date()),
        Created:ko.observable(0),
        Converted:ko.observable(0),
        Conversion:ko.observable(0),
    },
    YTD:{
        Created:ko.observable(0),
        Converted:ko.observable(0),
        Conversion:ko.observable(0),
    },
    IsFirstLoad:ko.observable(true),
    DataSource:ko.observable(),
    ProspectByRegionSources:ko.observableArray([]),
    ExcludeCategory:ko.observableArray([]),
    IncludeCategory: ko.observableArray([])
}

Prospect.InitComplete = function(){
    Prospect.Processing(false);
}

Prospect.PullRequest.subscribe(function(val){
    if(val==0){
        dl.Processing(false);
        Prospect.CreatePCvC(Prospect.DataPcvc().createconv);
        Prospect.PopulateYTD(Prospect.DataPcvc().ytd);
        var pcvcLastIndex = Prospect.DataPcvc().createconv.length - 1;
        Prospect.PopulatePeriodVal(Prospect.DataPcvc().createconv[pcvcLastIndex]);
        Prospect.CreateRegion(Prospect.DataMajorRegion());
    }
})

Prospect.Open = function(){
    if(!Prospect.IsFirstLoad()){
        Prospect.Processing(true);
        setTimeout(function(){
            Prospect.Processing(false);
            Prospect.Render(Prospect.DataSource());
        }, 500);
    }
}

Prospect.PopulateYTD = function(data){
    Prospect.YTD.Created(data.created);
    Prospect.YTD.Converted(data.converted);
    Prospect.YTD.Conversion(data.conversion);
}

Prospect.PopulatePeriodVal = function(data){
    Prospect.PeriodValue.Period(data.period);
    Prospect.PeriodValue.Created(data.created);
    Prospect.PeriodValue.Converted(data.converted);
    Prospect.PeriodValue.Conversion(data.conversion);
}

Prospect.CreatePCvC = function(data){
    $("#PCvC").html("");
    $("#PCvC").kendoChart({
        dataSource: {
            data: data
        },
        title: {
            visible:false,
        },
        chartArea:{
            height:200
        },
        legend: {
            visible: true,
            position:"bottom",
            labels:{
                font:chartFont
            }
        },
        seriesDefaults: {
            type: "column",
            overlay: {
              gradient: "none"
            },
            labels:{
                visible: chartLabelDisplay,
                font:chartFont,
                color:chartLabelColor,
                background:"transparent",
                template: "#= series.field=='conversion'?kendo.toString(value, 'P2'):kendo.toString(value, 'N0') #",
                padding:0,
                margin:0,
            }
        },
        series: [
            {field: "created",name:"Created",axis:"value"},
            // {field: "open",name:"Open",axis:"value"},
            {field: "converted",name:"Converted",axis:"value"},
            // {field: "disqualified",name:"Disqualified",axis:"value"},
            {field: "conversion",name:"(%) Conversion",axis:"percentage",type:"line"}
        ],
        valueAxis: [
            {
                name:"value",
                majorGridLines: {
                    visible: true
                },
                line:{
                    visible:false
                },
                labels:{
                    font:chartFont,
                    template:"#:value<=1000?kendo.toString(value,'N0'):kendo.toString(value/1000,'N0')+'k'#"
                },
                visible: true
            },
            {
                name:"percentage",
                majorGridLines: {
                    visible: true
                },
                line:{
                    visible:false
                },
                labels:{
                    font:chartFont,
                    template:"#:kendo.toString(value,'P0')#"
                },
                visible: false
            }
        ],
        categoryAxis: {
            field: "period",
            majorGridLines: {
                visible: false
            },
            labels: {
                rotation: {
                    angle: 45,
                    align: "center"
                }
            },
            // axisCrossingValues: [0, 10]
        },
        tooltip: {
            visible: true,
            font:chartFont,
            template: "#= series.name #: #= series.field=='conversion'?kendo.toString(value, 'P2'):kendo.toString(value, 'N0') #"
        },
        seriesColors:chartColors,
    });
}


Prospect.CreateRegion = function(data){
    var width = $("#ProspectByRegionSize").width();
    //console.log(width);
    // if()
    var j = 0;
    var tt = "";
    var width = $("#ProspectByRegionSize").width();
    for(var i in data){
        tt = i;
        var center;
        var radius;
        var valueSum = 0;
        
        data[i].forEach(function(xx, ix){
            xx.color = chartColors[ix];
        });

        var obj = $("#ProspectByRegion"+j);
            obj.kendoChart({
                dataSource: {
                    data: data[i]
                },
                chartArea: {
                    background: "transparent",
                    height: 200,
                    width:width,
                    margin:{
                      top:-33
                    },
                },
                legend: {
                    visible: false,
                },
                transitions: false,
                seriesDefaults: {
                    type: "donut",
                    size:40,
                    tooltip: {
                      visible: true,
                      template: "#:kendo.toString(value,'N0')#"
                    },
                    overlay: {
                      gradient: "none"
                    },
                    labels: {
                      visible: chartLabelDisplay,
                      position: "center",
                      template: "#:kendo.toString(percentage,'P0')#",
                      color: "#FFFFFF",
                      background: "transparent",
                      font:chartFont,
                    },
                    color: "#ec7209",
                },
                //seriesColors:chartColors,
                series: [{
                  field: "Value",
                  categoryField: "Id",
                  visual: function(e) {
                      // Obtain parameters for the segments
                      // Will run many times, but that's not an issue
                      // center = e.center;
                      // radius = e.radius;

                      // Create default visual
                      return e.createVisual();
                    },
                }],

                // seriesColors:chartColors,
                tooltip: {
                    visible: true,
                    font:chartFont,
                    template: "#= dataItem.Id #: #= kendo.toString(value, 'N0') #"
                },
                render: function(e) {
                    var draw = kendo.drawing;
                    var geom = kendo.geometry;
                    var chart = e.sender;

                    var circleGeometry = new geom.Circle(center, radius);
                    var bbox = circleGeometry.bbox();
                    //console.log(valueSum);
                    // var text = new draw.Text(kendo.toString(valueSum,'N0'), [0, 0], {
                    //   font: "12px Helvetica Neue",
                    //   color:"#58666e"
                    // });

                    // draw.align([text], bbox, "center");
                    // draw.vAlign([text], bbox, "center");

                    // e.sender.surface.draw(text);
                }
            })
            j++;
    }

    $("#MajorRegionLegend").html("");
    $("#MajorRegionLegend").attr("style","margin-top:--36px");
    if(Prospect.SelectedMajorRegion().length>0){
        $("#MajorRegionLegend").kendoChart({
            dataSource: {
                data: data[tt]
            },
            chartArea: {
                background: "transparent",
                height: "20px",
                // width: 1319,
                width:$("#PBRLegendSize").width(),
            },
            legend: {
                visible: true,
                position:"bottom",
                labels:{
                    font:chartFont
                }
            },
            transitions: false,
            seriesDefaults: {
                type: "donut",
                size:30,
                tooltip: {
                  visible: false,
                  template: "SGD #:kendo.toString(value,'N0')#"
                },
                overlay: {
                  gradient: "none"
                },
                labels: {
                  visible: true,
                  position: "center",
                  template: "#:kendo.toString(percentage,'P0')#",
                  color: "#FFFFFF",
                  background: "transparent",
                  font:chartFont,
                },
                color: "#ec7209",
            },
            seriesColors:chartColors,
            series: [{
              visible:false,
              field: "Value",
              categoryField: "Name",
            }],
            // seriesColors:chartColors,
            legendItemClick:function(e){
                var arr = data;
                var selectedLegend = e.text;

                if(Prospect.ExcludeCategory().indexOf(selectedLegend) >= 0){
                    Prospect.ExcludeCategory.remove(selectedLegend);
                }else{
                    Prospect.ExcludeCategory.push(selectedLegend);
                }
                var j=0;
                for(var i in arr){
                    //console.log(i);
                    var obj = $("#ProspectByRegion"+j).getKendoChart();
                    var source = ko.mapping.fromJS(arr[i]);
                    for(var x in Prospect.ExcludeCategory()){
                        // console.log(Prospect.ExcludeCategory()[x]);
                        var x = Enumerable.From(source()).Where("$.Id() == '"+Prospect.ExcludeCategory()[x]+"'").FirstOrDefault()
                        // console.log(x);
                        source.remove(x);
                    }
                    obj.setDataSource(ko.mapping.toJS(source()));
                    obj.refresh();
                    j++;
                }
            }
        })
    }
}


Prospect.Conversion = function(data){
   var series = [];
    data.series.forEach(function(x){
        x["name"] = x.name
        x["field"] = x.Field
        x.labels = {
            visible: false,
        };
        if(x.name.indexOf("Total") < 0){
            series.push({field: x.Field,name:x.name})
        }
    });

    series.push({field: "Total",
        name:"",
            visual: function (e) {
            return "";
        },
        labels:{
            visible: chartLabelDisplay,
            position:"insideBase",
            template:"#:kendo.toString(dataItem.Total,'n0')#"
        },
        tooltip: {
            visible: false,
        },
        color:"transparent"
    })

    var arrtotal = [];
    var arr = data.series[0].data;
    for(var i in arr){
        var v = arr[i]+data.series[1].data[i];
        arrtotal.push(v<50?50:v);
    }
    var totalseries = {
        name:"total",
        field:"total",
        data:arrtotal
    }

    var sources = [];

    for(var i in data.category){
        var d = {
            period:data.category[i]
        }
        for(var s in data.series){
            d[data.series[s].Field] = data.series[s].data[i];    
        }
        sources.push(d);
    }
    $("#ConvertedComparison").kendoChart({
        dataSource: {
            data: sources
        },
        title: {
            visible:false,
        },
        chartArea:{
            height:200
        },
        legend: {
            visible: true,
            position:"bottom",
            labels:{
                font:chartFont
            }
        },
        seriesDefaults: {
            type: "column",
            stack: true,
            overlay: {
              gradient: "none"
            },
            labels:{
                visible: false,//chartLabelDisplay,
                font:chartFont,
                position:"center",
                color:chartLabelColor,
                background:"transparent",
                template:"#:numbformat(value)#",
                padding:0,
                margin:0,
            },
        },
        seriesColors:chartColors,
        series: series,
        valueAxis: {
            name: "valueAxis",
            majorGridLines: {
                visible: true
            },
            line:{
                visible:false
            },
            labels:{
                font:chartFont,
            },
            visible: true,
        },
        categoryAxis: {
            field: "period",
            name: "categoryAxis",
            // categories: DataSource.category,
            majorGridLines: {
                visible: false
            },
            labels:{
                font:chartFont,
            },
            visible:true,
        },
        tooltip: {
            visible: true,
            font:chartFont,
            template: "#= series.name #: #= value #"
        }
    });
}

Prospect.Reset = function(){
    resetFilter();
    Prospect.GetData();
}

Prospect.GetData = function(){
    if(ds.fromAnalytic()){
        resetDate();
        ds.fromAnalytic(false);
    }
    var Prospects = moment(new Date(model.arrayLastDate().lastUpdateProspects)).format("MMM YY");
    model.lastDateData(Prospects);

    Prospect.Processing(true);
    var parm = ko.mapping.toJS(filter);
    // parm.Start = new Date(parm.Start.getFullYear(),0,1);
    // parm.StartStr = kendo.toString(parm.Start,'yyyy-MM-dd');

    Prospect.PullRequest(5);

    ajaxPost("/dashboard/getprospectbyregion",parm,function(res){
        var container= [];
        for(var region in res){
            // console.log(region.)
            var valueSum = 0;
            res[region].forEach(function(xx, ix){
                valueSum = valueSum + xx.Value;
            });
            container.push({region:region, sum:valueSum})
        }
        //console.log(res);
        Prospect.SelectedMajorRegion(container);
        Prospect.DataMajorRegion(res);
        pullRequestComplete(Prospect.PullRequest);
        
    });

    ajaxPost("/dashboard/getprospectpermonth",parm,function(res){
        // console.log(res);
        Prospect.DataPcvc(res);
        pullRequestComplete(Prospect.PullRequest);
    });

    ajaxPost("/dashboard/getdataprospect",parm,function(res){

        if(res.IsError){
            swal("","Invalid password!","error");
            Prospect.Processing(false);
            return false;
        }
        Prospect.DataSource(res.Data);
        pullRequestComplete(Prospect.PullRequest);
        // Prospect.Processing(false);
    });


    ajaxPost("/dashboard/getdataprospectconversion",parm,function(res){
        if(res.IsError){
            swal("","Invalid password!","error");
            Prospect.Processing(false);
            return false;
        }
        Prospect.Processing(false);
        Prospect.Conversion(res.Data);
        pullRequestComplete(Prospect.PullRequest);
    });

    ajaxPost("/dashboard/top5prospectbycountry", filter, 
        function (res) {
            if(res.IsError){
                alert(res.Message);
                return;
            }

            var countryOrder = ["HONG KONG", "INDIA", "UNITED ARAB EMIRATES", "SINGAPORE", "CHINA"];
            if(filter.MajorRegion() == "AME"){
                countryOrder = ["UNITED ARAB EMIRATES", "NIGERIA", "KENYA", "PAKISTAN", "UGANDA", "GHANA"];
            }else if(filter.MajorRegion() == "ASA"){
                countryOrder = ["INDIA", "SINGAPORE", "MALAYSIA", "BANGLADESH", "INDONESIA"];
            }else if(filter.MajorRegion() == "GCNA"){
                countryOrder = ["HONG KONG", "KOREA, REPUBLIC OF", "CHINA", "TAIWAN"];
            }
            newData = [];
            countryOrder.forEach(function(xx){
                var tt = Enumerable.From(res.Data.Datas).FirstOrDefault(undefined, "$._id.country == '" + xx + "'");
                if(tt != undefined){
                    newData.push(tt);
                }
            })
            // var ordering = Enumerable.From(newData).OrderByDescending("$.created").ToArray();
            var take5 = Enumerable.From(newData).ToArray()
            var cat = Enumerable.From(take5).Select("$._id.country").ToArray()
            var ser1 = Enumerable.From(take5).Select("$.created").ToArray()
            var ser2 = Enumerable.From(take5).Select("$.converted").ToArray()
            var globalAverage1 = Enumerable.From(res.Data.Datas).Select("$.created").Average()
            var globalAverage2 = Enumerable.From(res.Data.Datas).Select("$.converted").Average()
            var series1 = {
                series : [
                    {data: ser1, type: "bar", name: "" }
                ],
                categories: cat
            }

            var series2 = {
                series : [
                    {data: ser2, type: "bar", name: "" }
                ],
                categories: cat
            }

            Prospect.prospectTop5(series1, "chartProspects1", globalAverage1);
            Prospect.prospectTop5(series2, "chartProspects2", globalAverage2);
            pullRequestComplete(Prospect.PullRequest);
        }
    )
}

Prospect.prospectTop5 = function(data, target){
    //change united arab emirate to UAE
    var uae = data.categories.indexOf("UNITED ARAB EMIRATES")
    if (uae !== -1) {
        data.categories[uae] = "UAE";
    }

    var kor = data.categories.indexOf("KOREA, REPUBLIC OF")
    if (kor !== -1) {
        data.categories[kor] = "KOREA";
    }
    
    $("#" + target).kendoChart({
        chartArea: {
            background: "transparent",
            // width: 300,
            height: 183
        },
        legend: {
            position: "bottom",
            visible:true,
            labels:{
                font:chartFont
            }
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            labels:{
                visible: chartLabelDisplay,
                font:chartFont,
                //position:"center",
                color:chartLabelColor,
                background:"transparent",
                template:" #:kendo.toString(value,'N0')#",
                padding:5,
                margin:0,
            }
        },
        seriesColors:chartColors,
        series: data.series,
        valueAxis: {
            name: "axs",
            line: {
                visible: false
            },
            labels:{
                font:chartFont,
                template:"#:kendo.toString(value,'N0')#"
            },
            majorGridLines: {
                visible: true
            },
        },
        categoryAxis: {
            name: "catAxis",
            categories: data.categories,//["China", "Hong Kong", "India", "Singapore", "UAE"],//data.categories,//
            majorGridLines: {
                visible: false
            },
            labels:{
                font:chartFont,
            },
        },
        tooltip: {
            visible: true,
            template: "#= kendo.toString(value,'n0') #",//#= series.name #:
            font:chartFont,
        }
    });
}

Prospect.Init = function(){
    setTimeout(function(){
        Prospect.GetData();
    }, 2000);
    // Prospect.PullRequest(1);
    // Prospect.Processing(true);
    // ajaxPost("/mastercountry/getdata",{},function(res){
    //     Prospect.Filter.CountryList(res.Data);
    //     pullRequestComplete(Prospect.PullRequest,Prospect.InitComplete());
    // })
}