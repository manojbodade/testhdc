var dl = {};

dl.Processing = ko.observable(false);
dl.PullRequest = ko.observable(0);
dl.Chart1 = ko.observableArray([]);
dl.Chart2 = ko.observableArray([]);
dl.Chart3 = ko.observableArray([]);
dl.Chart4 = ko.observableArray([]);
dl.Chart5 = ko.observableArray([]);
dl.Chart6 = ko.observableArray([]);
dl.ChartTop1 = ko.observable();
dl.ChartTop2 = ko.observable();
dl.map = ko.observableArray([]);
dl.tableSneak = ko.observableArray([]);

dl.newDeal = ko.observable(0);
dl.newDealValue = ko.observable(0);
dl.conversion = ko.observable(0);
dl.liveDeal = ko.observable(0);
dl.liveDealValue = ko.observable(0);
dl.wonYtd = ko.observable(0);

dl.pieSource1 = ko.observableArray([]);
dl.pieSource2 = ko.observableArray([]);
dl.pieShow = ko.observableArray([]);
dl.pieHide = ko.observableArray([]);

dl.majorRegionGrid = "";

dl.Chart1Text = ko.observable("Deal Pipeline <br />(CY Revenue in USD'M)")
dl.Chart1Option = ko.observable("newdeals")
dl.Chart1Option.subscribe(function(vl){
    if(vl == "allinfo")
        dl.Chart1Text("Deal Pipeline <br />(CY Revenue in USD'M)")
    else
        dl.Chart1Text('Deal Pipeline <br />(Count)')
    dl.generategrid1(dl.Chart1())
})

dl.Top = {
	ShowTop: ko.observable(5),
	takeWhat : ko.observable("live"),//live, new, lost, won
    listSelectedCountry: ko.observableArray([]),
    takeWhatCountry: ko.observable(""),
	takeWhatMajorRegion: ko.observable(""),
	dataLive : ko.observableArray([]),
	dataNew : ko.observableArray([]),
	dataLost : ko.observableArray([]),
	dataWon : ko.observableArray([]),
}

function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

function Convert(f, decimal){
	if(decimal == undefined)
		decimal = 0
	if(f > 1000000000000)
		return kendo.toString(Math.round(f/1000000000000, decimal),'N' + decimal) + "T"
	else if(f > 1000000000)
		return kendo.toString(Math.round(f/1000000000, decimal),'N' + decimal) + "B"
	else if(f > 1000000)
		return kendo.toString(Math.round(f/1000000, decimal),'N' + decimal) + "M"
	else if(f > 1000)
		return kendo.toString(Math.round(f/1000, decimal),'N' + decimal) + "K"

	return f
}
dl.Reset = function(){
	resetFilter();
    dl.GetDataDeal();
}

dl.PullRequest.subscribe(function(newval){
    if(newval==0){
        dl.Processing(false);
		dl.generategrid1(dl.Chart1())
		dl.generategrid2(dl.Chart1().RawRevenue, dl.Chart1())
		dl.generategriddet(dl.Chart1().RawCount)
		dl.generategrid3(dl.Chart3())
		dl.generategrid5(dl.Chart4().dataPieRevenue)
		dl.generategrid6(dl.Chart4().dataPie)
		dl.generateChartLegend(dl.Chart4().dataPie)
		dl.pieShow(Enumerable.From(dl.Chart4().dataPieRevenue).Select("$.Category").Distinct().ToArray())
        dl.chartTop5(dl.ChartTop1(), "dlChart8", dl.ChartTop1().globalAverage, dl.ChartTop1().regionalAverage, true)
        dl.chartTop5(dl.ChartTop2(), "dlChart9", dl.ChartTop2().globalAverage)

        if(dl.Top.takeWhatMajorRegion() == ""){
            dl.renderMapDeals(dl.map(), "AME", "dlmap1");
            dl.renderMapDeals(dl.map(), "ASA", "dlmap2");
            dl.renderMapDeals(dl.map(), "GCNA", "dlmap3");
            dl.renderMapDeals(dl.map(), "EUROPE", "dlmap4");
            dl.renderMapDeals(dl.map(), "AMERICAS", "dlmap5");
        }else if(dl.Top.takeWhatMajorRegion() == "AME"){
            dl.renderMapDeals(dl.map(), "AME", "dlmap1");
        }else if(dl.Top.takeWhatMajorRegion() == "ASA"){
            dl.renderMapDeals(dl.map(), "ASA", "dlmap2");
        }else if(dl.Top.takeWhatMajorRegion() == "GCNA"){
            dl.renderMapDeals(dl.map(), "GCNA", "dlmap3");
        }else if(dl.Top.takeWhatMajorRegion() == "GCNA"){
            dl.renderMapDeals(dl.map(), "EUROPE", "dlmap4");
        }else if(dl.Top.takeWhatMajorRegion() == "GCNA"){
            dl.renderMapDeals(dl.map(), "AMERICAS", "dlmap5");
        }
    }
})

dl.GetDataDeal = function(){
    if(ds.fromAnalytic()){
        resetDate();
        ds.fromAnalytic(false);
    }
    var DealPipeline = moment(new Date(model.arrayLastDate().lastUpdateDealPipeline)).format("MMM YY");
    model.lastDateData(DealPipeline);

	dl.PullRequest(8)
	dl.Processing(true)
    dl.Top.takeWhatMajorRegion(filter.MajorRegion())
	ajaxPost("/dashboard/dealtopbox", filter,
		function (res) {
			if(!res.success){
				alert(res.message);
				return;
			}
			dl.newDeal(res.data.newDeals);
			dl.newDealValue(Convert(res.data.newDealsRev));
			dl.conversion(res.data.conversion);
			dl.liveDeal(res.data.liveDealCount);
			dl.liveDealValue(Convert(res.data.liveDealRev));
			dl.wonYtd(res.data.WonYtd);
			pullRequestComplete(dl.PullRequest);
		},
		function () {}
	)

    ajaxPost("/masterregion/getdata",{},function(res){
        if(res.IsError){
            alert(res.message);
            return;
        }
        dl.map(res.Data);
        pullRequestComplete(dl.PullRequest);
    });

	ajaxPost("/dashboard/dealcomercialbank", filter,
		function (res) {
			if(!res.success){
				alert(res.message);
				return;
			}
			dl.Chart1(res.data)
//			dl.generategrid1(res.data)
			pullRequestComplete(dl.PullRequest);
		},
		function () {}
	)

	ajaxPost("/dashboard/dealbusinesssegment", filter,
		function (res) {
			if(!res.success){
				alert(res.message);
				return;
			}
			dl.Chart3(res.data)
			pullRequestComplete(dl.PullRequest);
		},
		function () {}
	)



	ajaxPost("/dashboard/dealproductsplit", filter,
		function (res) {
			if(!res.success){
				alert(res.message);
				return;
			}
			setTimeout(function(){
				dl.Chart4(res.data)
				pullRequestComplete(dl.PullRequest);
			}, 1000)

		},
		function () {}
	)

    ajaxPost("/dashboard/top5dealbycountry", filter,
		function (res) {
			if(!res.success){
				alert(res.message);
				return;
			}
             // dg.paramTopDeal(param);
            var countryOrder = ["HONG KONG", "INDIA", "UNITED ARAB EMIRATES", "SINGAPORE", "CHINA"];
            if(filter.MajorRegion() == "AME")
                countryOrder = ["UNITED ARAB EMIRATES", "NIGERIA", "KENYA", "PAKISTAN", "UGANDA", "GHANA"];
            else if(filter.MajorRegion() == "ASA")
                countryOrder = ["INDIA", "SINGAPORE", "MALAYSIA", "BANGLADESH", "INDONESIA"];
            else if(filter.MajorRegion() == "GCNA")
                countryOrder = ["HONG KONG", "KOREA, REPUBLIC OF", "CHINA", "TAIWAN"];

            newData = [];
            countryOrder.forEach(function(xx){
                var tt = Enumerable.From(res.data.Data).FirstOrDefault(undefined, "$.Country == '" + xx + "'");
                if(tt != undefined){
                    newData.push(tt);
                }
            })
            var take5 = Enumerable.From(newData).Take(5).ToArray()
            if(filter.MajorRegion() == "AME")
                take5 = Enumerable.From(newData).Take(6).ToArray()
            var cat = Enumerable.From(take5).Select("$.Country").ToArray()
            var ser = Enumerable.From(take5).Select("$.Average").ToArray()
            var globalAverage = Enumerable.From(res.data.Data).Select("$.Average").Average()
            var regionalAverage = Enumerable.From(take5).Select("$.Average").Average()
            var rtt = {
                series : [
                    {data: ser, type: "bar", name: "" }
                ],
                categories: cat,
                globalAverage: globalAverage,
                regionalAverage: regionalAverage
            }

            // setTimeout(function() {
            //     dl.chartTop5(rtt, "dlChart8", globalAverage, regionalAverage, true)
            // }, 300);
            dl.ChartTop1(rtt);
            pullRequestComplete(dl.PullRequest);
		},
		function () {}
	)

    ajaxPost("/dashboard/top5dealbycountry", filter,
		function (res) {
			if(!res.success){
				alert(res.message);
				return;
			}
            // dg.paramTopDeal(param);
            var countryOrder = ["HONG KONG", "INDIA", "UNITED ARAB EMIRATES", "SINGAPORE", "CHINA"];
            if(filter.MajorRegion() == "AME")
                countryOrder = ["UNITED ARAB EMIRATES", "NIGERIA", "KENYA", "PAKISTAN", "UGANDA", "GHANA"];
            else if(filter.MajorRegion() == "ASA")
                countryOrder = ["INDIA", "SINGAPORE", "MALAYSIA", "BANGLADESH", "INDONESIA"];
            else if(filter.MajorRegion() == "GCNA")
                countryOrder = ["HONG KONG", "KOREA, REPUBLIC OF", "CHINA", "TAIWAN"];

            newData = [];
            countryOrder.forEach(function(xx){
                var tt = Enumerable.From(res.data.DataRevenue).FirstOrDefault(undefined, "$.Country == '" + xx + "'");
                if(tt != undefined){
                    newData.push(tt);
                }
            })
            var take5 = Enumerable.From(newData).Take(5).ToArray()
            if(filter.MajorRegion() == "AME")
                take5 = Enumerable.From(newData).Take(6).ToArray()
            var cat = Enumerable.From(take5).Select("$.Country").ToArray()
            var ser = Enumerable.From(take5).Select("$.Average").ToArray()
            var globalAverage = Enumerable.From(res.data.DataRevenue).Select("$.Average").Average()
            var rtt = {
                series : [
                    {data: ser, type: "bar", name: "" }
                ],
                categories: cat,
                globalAverage: globalAverage
            }

            // setTimeout(function() {
            //     dl.chartTop5(rtt, "dlChart9", globalAverage)
            // }, 300);
            dl.ChartTop2(rtt);
            pullRequestComplete(dl.PullRequest);
		},
		function () {}
	)

	// setTimeout(function(){
	// 	dl.generatemapDeals();
	// }, 2000)

	ajaxPost("/dashboard/sneakpeak", filter,
        function (res) {
            if(!res.success){
                alert(res.message);
                return;
            }
            setTimeout(function(){
                dl.tableSneak(res.data);
                pullRequestComplete(dl.PullRequest);
            }, 1000)

        },
        function () {}
    )
}


dl.getKindOfDeal = function(){
	if(dl.Top.takeWhat() == "live"){
		return dl.Top.dataLive();
	}else if(dl.Top.takeWhat() == "new"){
		return dl.Top.dataNew();
	}else if(dl.Top.takeWhat() == "lost"){
		return dl.Top.dataLost();
	}else if(dl.Top.takeWhat() == "won"){
		return dl.Top.dataWon();
	}
}

dl.getDetailDeals = function(data, excelName){
	$("#gridDetail").replaceWith("<div id='gridDetail' />")
	$("#gridDetail").kendoGrid({
		toolbar: ["excel"],
		excel:{
            fileName:  excelName + ".xlsx",
            allPages:true,
            filterable:true
        },
		dataSource: {
            data: data,
			schema:{
                    model: {
                        fields: {
                            //Client_Group_Name: { type: "string" },
                            Sub_Product: { type: "string", nullable: true },
                            Annual_Revenue_USD_K: { type: "number", nullable: true },
                            Current_Year_Revenue_USD_K: { type: "number", nullable: true },
							Booking_Location: { type: "string", nullable: true },
							Deal_Country: { type: "string", nullable: true },
							Deal_Owner_Full_Name: { type: "string", nullable: true },
							Sales_Stage: { type: "string", nullable: true },
							Expected_Close_Date: { type: "date", nullable: true },
							Deal_ID: { type: "string", nullable: true },
                        }
                    }
	        },
        },
		//resizeable: true,
        columns: [
            { field: "Deal_Country", title: "Deal Country"},
            { field: "Deal_Owner_Full_Name", title: "Deal Owner"},
            // { field: "Client_Name", title: "Client Name"},
            { field: "Booking_Location", title: "Booking Location"},
			{ field: "Sub_Product", title: "Sub Product"},
			{ field: "Annual_Revenue_USD_K", title: "Expected Annual <br/>Revenue (USD'000)", template: "#:kendo.toString(Annual_Revenue_USD_K, 'N1')#"},
			{ field: "Current_Year_Revenue_USD_K", title: "Current Year <br/>Revenue (USD'000)", template: "#:kendo.toString(Current_Year_Revenue_USD_K, 'N1')#"},
			{ field: "Expected_Close_Date", title: "Expected Close Date", template: "#:moment(Expected_Close_Date).format('DD MMM YYYY')#"},
            { field: "Sales_Stage", title: "Sales Stage"},
			//{ field: "Deal_ID", title: "Deal Id"}
        ]

	})
}

// dl.generatemapDeals = function(){
//     ajaxPost("/masterregion/getdata",{},function(res){
//         if(res.IsError){
//             alert(res.message);
//             return;
//         }
//         if(dl.Top.takeWhatMajorRegion() == ""){
//             dl.renderMapDeals(res.Data, "AME", "dlmap1");
//             dl.renderMapDeals(res.Data, "ASA", "dlmap2");
//             dl.renderMapDeals(res.Data, "GCNA", "dlmap3");
//         }else if(dl.Top.takeWhatMajorRegion() == "AME"){
//             dl.renderMapDeals(res.Data, "AME", "dlmap1");
//         }else if(dl.Top.takeWhatMajorRegion() == "ASA"){
//             dl.renderMapDeals(res.Data, "ASA", "dlmap2");
//         }else if(dl.Top.takeWhatMajorRegion() == "GCNA"){
//             dl.renderMapDeals(res.Data, "GCNA", "dlmap3");
//         }
//     });
// };

dl.renderMapDeals = function(dataSource, majorRegion, target){
    var sources = ko.mapping.toJS(model.MapDataSource());
    var mapColor = {};
    var idx = 0;
    for(var i in sources){
        var country = sources[i].country.toUpperCase();
        var c = Enumerable.From(dataSource).Where("$.Country == '"+country+"'").FirstOrDefault();
		if(c!==undefined){

				sources[i].Region = c.Region;
	            sources[i].major_region = c.Major_Region;
	            if(mapColor[c.Major_Region]===undefined){
	                mapColor[c.Major_Region] = chartColors[idx];
	                idx++;
	            }else{
	                mapColor[c.Major_Region] = mapColor[c.Major_Region];
	            }
			if(c.Major_Region == majorRegion){
	            sources[i].color = mapColor[c.Major_Region];
	        }
			else{
				sources[i].color = "#FFFFFF"//mapColor[c.Major_Region];
			}
		}
    }
    sources = Enumerable.From(sources).OrderBy("$.major_region").ToArray();
    var MapMajorRegion = [];
    for(var i in mapColor){
        MapMajorRegion.push({name:i,color:mapColor[i]});
    }
    dg.MapMajorRegion(MapMajorRegion)
    var ctr = [];
    var zoom = 0;
    if(target == "dlmap1"){
        ctr = [6.315298538330021, 36.035156249999986];
        zoom = 2;
    }else if(target == "dlmap2"){
        ctr = [10.487811882056631, 106.34765625000001];
        zoom = 2;
    }else if(target == "dlmap3"){
        ctr = [35.46066995149528, 108.45703125000003];
        zoom = 2;
    }else if(target == "dlmap4"){
        ctr = [55.378051, -3.435973];
        zoom = 2;
    }else if(target == "dlmap5"){
        ctr = [30.268107, -97.744821];
        zoom = 2;
    }
    $("#"+target).html("");
    $("#"+target).attr("style","height:200px;border:1px solid #0075B2;");
    $("#"+target).kendoMap({
        controls: {
            navigator: false,
            zoom: false
        },
        center: ctr,//[33.526045, 72.505946],
        zoom: zoom,
        // minZoom: 3,
        layers: [
            {
                type: "shape",
                urlTemplate: "http://#= subdomain #.tile.openstreetmap.org/#= zoom #/#= x #/#= y #.png",
                dataSource: {
                    data:sources
                },
                style: {
                    fill: {
                        opacity: 0.8
                    }
                },
                attribution: "Click Map To Refresh Data",
            },

        ],
		shapeClick: function (e){
            var majorRegion = e.shape.dataItem.major_region;
            // takeWhatMajorRegion
            // $("#modalDeal").modal("show");
            //  GenerateDataTop5(majorRegion);
            // if(major_region!==undefined){
            //     filter.MajorRegion(major_region);
            //     GetData();
            // }
        },
		zoomStart: function(e){
			e.preventDefault();
		},
        shapeCreated: function(e) {
            // var scale = chroma.scale(["#FFF", "#0075B2"]).domain([1, maxValue]);
            var shape = e.shape;
            var obj = shape.dataItem.value;
            var color = scale(obj).hex();
            shape.options.fill.set("color", shape.dataItem.color);

            // Calculate shape bounding box
            var bbox = e.shape.bbox();
            var center = bbox.center();

            // Create the label
            var labelText = e.shape.dataItem.country;
            var label = new kendo.drawing.Text(labelText,[0,0],{ font: "9px Helvetica Neue, Helvetica, Arial, sans-serif" });
            var labelCenter = label.bbox().center();

            // Position the label
            label.position([
                center.x - labelCenter.x,
                center.y - labelCenter.y
            ]);
            label.visible(false);
            e.shape.dataItem["dataLabel"] = label;
            // Render the label on the layer
            //shape.options.fill.set("color", shape.dataItem.color);
            // if(shape.dataItem.color == undefined || shape.dataItem.color == "#FFFFFF"){}
            // else{
            //     e.layer.surface.draw(label);
            // }

        },
        shapeFeatureCreated: onShapeFeatureCreated,
        shapeMouseEnter: function (e) {
            // if(e.shape.dataItem.major_region != undefined){
            //     var oe = e.originalEvent;
            //     var x = oe.pageX || oe.clientX;
            //     var y = oe.pageY || oe.clientY;
            //     var country = e.shape.dataItem.country;
            //     var majorRegion = e.shape.dataItem.major_region;
            //     popup.element.html("<center>"+ majorRegion + " <br /> " + country + "</center>");
            //     popup.open(x, y);
            //     e.shape.options.set("fill.opacity", 1);
            // }
            e.shape.options.set("fill.opacity", 1);
        },
        shapeMouseLeave: onShapeMouseLeave
    });
}

dl.generategrid1 = function(data){
    var ser = []

	data.series.forEach(function(e){

        if(e.Name == "New Deals CB"){
            e.data = e.Count;
            e.count = e.Data;
        }else{
            e.data = e.Data;
            e.count = e.Count;
        }
		e.type = e.Type;
		e.name = e.Name;
        if(e.WhatData == "newdeals" && e.Type == "line"){
            e.axis = "avg"
        }else{
            e.axis = "col"
        }

        if(e.WhatData == dl.Chart1Option()){
            if(e.name == "New Deals" && dl.Chart1Option() == "newdeals"){ //ignore new deals.
            }else{
                ser.push(e)
            }
        }
	});

    valAx = {
                visible: true,
                name: "col",
                labels:{
                    font:chartFont,
                    template:"#:kendo.toString(value/1000,'N0')#"//template:"#:Convert(value)#"
                },
                majorGridLines: {
                    visible: true
                },
                line:{
                    visible:false
                }
            }
    if(dl.Chart1Option() == "newdeals"){
        valAx = [
            {
                visible: true,
                name: "col",
                labels:{
                    font:chartFont,
                    template:"#:kendo.toString(value/1000,'N0')#"//template:"#:Convert(value)#"
                },
                majorGridLines: {
                    visible: true
                },
                line:{
                    visible:false
                }
            },
            {
                visible: true,
                name: "avg",
                labels:{
                    font:chartFont,
                    template:"#:kendo.toString(value,'N2')#"
                },
                majorGridLines: {
                    visible: true
                },
                line:{
                    visible:false
                },
                tooltip: {
                    font:chartFont,
                    visible: true,
                    template: "#= series.name #: #= kendo.toString(value,'N2') #",
                }
            }
        ]
    }

    $("#dlchart1").kendoChart({
        chartArea: {
            background: "transparent",
            height: 236
        },
        legend: {
            position: "bottom",
            labels:{
            	font:chartFont
            }
        },
		seriesDefaults: {
            overlay: {
              gradient: "none"
            },
			labels: {
                visible: chartLabelDisplay,
                font:chartFont,
                color:chartLabelColor,
                background:"transparent",
                template: function(xx){
                    if(xx.series.axis == "avg"){
                        return kendo.toString(xx.dataItem,'N2')
                    }else{
                        if(xx.series.Name == "New Deals CB")
                            return kendo.toString(xx.dataItem,'N0')
                        else
                            return kendo.toString(xx.dataItem/1000,'N0')
                    }
                },//"#:kendo.toString(value/1000,'N0')#",
                padding:0,
                margin:0,
            },
        },
        seriesColors: chartColors,
        series: ser,
        valueAxis: valAx,
        categoryAxis: {
            categories: data.categories,
            axisCrossingValues: [0, 12]
        },
		axisDefaults: {
			majorGridLines: {
				visible: false,
			},
			labels:{
				visible: true,
                rotation: {
                    angle: 45,
                    align: "center"
                },
				font:chartFont,
			},
		},
		tooltip: {
            font:chartFont,
            visible: true,
            template: function(xx){
                var ix = data.categories.indexOf(xx.category)
                var cnt = xx.series.count[ix];
                var rev = xx.dataItem
                var nm = xx.series.Name;
                if(xx.series.axis == "avg"){
                    return "Average " + kendo.toString(rev, 'N2')
                }else{
                    if(rev != undefined || nm != undefined || cnt != undefined){
                        if(nm == "New Deals CB"){ //reverse it.
                            return nm + "<br /> Revenue: " + kendo.toString(cnt, 'N0') + "<br /> Count: " + kendo.toString(rev, 'N0')
                        }else{
                            return nm + "<br /> Revenue: " + kendo.toString(rev, 'N0') + "<br /> Count: " + kendo.toString(cnt, 'N0')
                        }
                    }
                }
            }
        }
    });
};

dl.generategriddet = function(data){
	var max = 0;
	var Existing = 0;
	var New = 0;
	var Close = 0;
	var Lost = 0;
	var Dropped = 0;
	var Live = 0;
    var stale = 0;
    var catLength = data.Categories.length;
    var maxYear = data.Categories[catLength-1]
    var countStart = 0;
	data.Categories.forEach(function(e, idx){
        if(maxYear.toString().substring(0, 4) == e.toString().substring(0, 4)){
            if(idx == 0 || e.toString().substring(4, 6)=="01"){
                Existing = data.Existing[idx];
            }

            New = New + data.New[idx];
            Close = Close + data.Won[idx];
            Lost = Lost + data.Lost[idx];
            Dropped = Dropped + data.Drop[idx];
            stale = stale + data.Stale[idx];

            if(idx == data.Categories.length - 1){
                Live = data.Live[idx]
            }
        }
	})
	data = [
		{Name: "Existing", Tooltip: Existing, Value: 400},
		{Name: "New", Tooltip: New, Value: -400},
		{Name: "Closed", Tooltip: Close, Value: 400},
		{Name: "Lost", Tooltip: Lost, Value: -400},
		{Name: "Dropped", Tooltip: Dropped, Value: 400},
		{Name: "Live", Tooltip: Live, Value: -400},
        {Name: "", Tooltip: "", Value: 400},
        {Name: "Stale", Tooltip: stale, Value: -400},
	]
	$("#chartGrid").kendoChart({
		chartArea: {
            background: "transparent",
            height: 50
        },
	    dataSource: {
	        data: data
	    },
	    legend: {
	        visible: false
	    },
		seriesDefaults: {
            overlay: {
              gradient: "none"
            },
        },
	    series: [{
	        type: "waterfall",
	        field: "Value",
			gap: 0,
			spacing: 0,
	        categoryField: "Name",
			line: { visible: false, width: 0 },
	        color: function(point) {
                if(point.index == 6)
                    return "#ffffff"
	            return chartColors[point.index];
	        },
			labels: {
                visible: chartLabelDisplay,
				background: "transparent",
                position: "center",
				color: "white",
				template: "#: kendo.toString(dataItem.Tooltip, 'N0') #",
            },
	    }],
	    axisDefaults: {
			line: {
				visible: false
			},
			majorGridLines: {
				visible: false,
			},
			labels:{
				font:chartFont
			}
		},
		valueAxis: {
			visible: false,
            labels: { format: "N1" },
			template: "#: kendo.toString(dataItem.Tooltip, 'N') #",
            majorGridLines: { visible: false }
        },
		tooltip: {
			visible: false,
			font:chartFont,
			template: function(xx){
                // console.log(xx)
            }//"Revenue #= dataItem.Name # : #: kendo.toString(dataItem.Tooltip, 'N2') #"
		},
	});
}

dl.generategrid2 = function(data, DataSource){
	var max = 0;
	var Existing = 0;
	var New = 0;
	var Close = 0;
	var Lost = 0;
	var Dropped = 0;
	var Live = 0;
    var stale = 0;

    var CountExisting = 0;
	var CountNew = 0;
	var CountClose = 0;
	var CountLost = 0;
	var CountDropped = 0;
	var CountLive = 0;
    var Countstale = 0;

    var catLength = data.Categories.length;
    var maxYear = data.Categories[catLength-1]
    var countStart = 0;
	data.Categories.forEach(function(e, idx){
        if(maxYear.toString().substring(0, 4) == e.toString().substring(0, 4)){
            if(countStart == 0){
			    Existing = (data.Existing[idx]*1000);
                CountExisting = DataSource.RawCount.Existing[idx]
            }

            New = New + (data.New[idx]*1000);
            Close = Close + (data.Won[idx]*1000);
            Lost = Lost + (data.Lost[idx]*1000);
            Dropped = Dropped + (data.Drop[idx]*1000);
            stale = stale + (data.Stale[idx]*1000);
            Live = Live + (data.Live[idx]*1000);

            CountNew = CountNew + DataSource.RawCount.New[idx]
            CountClose = CountClose + DataSource.RawCount.Won[idx]
            CountLost = CountLost + DataSource.RawCount.Lost[idx]
            CountDropped = CountDropped + DataSource.RawCount.Drop[idx]
            Countstale = Countstale + DataSource.RawCount.Stale[idx]
            CountLive = DataSource.RawCount.Live[idx]

            if(idx == data.Categories.length - 1){
                Live = (data.Live[idx]*1000);
            }
            countStart++;
        }
	})
	data = [
		{Name: "Existing", Tooltip: Existing, Value: Existing, Count: CountExisting},
		{Name: "New", Tooltip: New, Value: New, Count: CountNew},
		{Name: "Close", Tooltip: Close, Value: Close * -1, Count: CountClose},
		{Name: "Lost", Tooltip: Lost, Value: Lost * -1, Count: CountLost},
		{Name: "Dropped", Tooltip: Dropped, Value: Dropped * -1, Count: CountDropped},
		{Name: "Live", Tooltip: Live, Value: Live * -1, Count: CountLive},
        {Name: " ", Tooltip: "", Value: 1, Count: 0},
        {Name: "Stale", Tooltip: stale, Value: stale * 1, Count: Countstale},
	]

	$("#dlchart2").kendoChart({
		chartArea: {
            background: "transparent",
            height: 200
        },
	    dataSource: {
	        data: data
	    },
	    legend: {
	        visible: false
	    },
		seriesDefaults: {
            overlay: {
              gradient: "none"
            },
        },
	    series: [{
	        type: "waterfall",
	        field: "Value",
			gap: 0,
			spacing: 0,
	        categoryField: "Name",
			labels: {
                visible: chartLabelDisplay,
				background: "transparent",
                position: "insideEnd",
				template: "#: Convert(dataItem.Tooltip) #",
            },
			line: { visible: false, width: 0 },
	        color: function(point) {
	            return chartColors[point.index];
	        }
	    },
        {
	        field: "Count",
	        visible: false
	    }],
	    axisDefaults: {
			line: {
				visible: false
			},
			majorGridLines: {
				visible: false,
			},
			labels:{
				font:chartFont
			},
			visible: false
		},
		valueAxis: {
			visible: false,
            min: 0,
            labels: { font: chartFont, format: "N1" },
			template: "#: kendo.toString(dataItem.Tooltip, 'N') #",
            majorGridLines: { visible: false }
        },
		tooltip: {
			font:chartFont,
			visible: true,
			template: function(xx){
                var a = Enumerable.From(data).FirstOrDefault(undefined, "$.Name == '" + xx.category +"'")
                if(a != undefined){
                    if (a.Value < 0) {
                        a.Value = a.Value * -1
                    }
                    return a.Name + " <br /> Revenue: " + kendo.toString(a.Value, 'N0') + "<br /> Count: " + a.Count
                }
            }//"Revenue #= dataItem.Name # : #: kendo.toString(dataItem.Tooltip, 'N') #"
		},
	});
}

dl.generategrid3 = function(data){
	var center;
    var radius;
	var valueSum = 0;
	data.series.forEach(function(e){
		valueSum = valueSum + e.Value
	});
	$("#dlchart3").kendoChart({
		chartArea: {
            background: "transparent",
            height: 250
        },
        legend: {
            position: "bottom",
            labels:{
            	font:chartFont
            }
        },
        dataSource: {
            data: data.series
        },
		seriesDefaults: {
            overlay: {
              gradient: "none"
            },
            labels:{
            	font:chartFont
            }
        },
        series: [{
			padding: 0,
            type: "donut",
            field: "Value",
            categoryField: "Title",
			visual: function(e) {
              // Obtain parameters for the segments
              // Will run many times, but that's not an issue
              center = e.center;
              radius = e.radius;

              // Create default visual
              return e.createVisual();
            },
			labels: {
                visible: chartLabelDisplay,
                font:chartFont,
                color:"#FFF",
                background:"transparent",
                template:"#:replaceString(kendo.toString(percentage,'P0'))#",
                padding:0,
                margin:0,
            },
        }],
        seriesColors: chartColors,//["#3F9C35", "#009FDA", "#69BE28", "#005C84"],
        tooltip: {
            visible: true,
            font:chartFont,
            template:"#: category # - #:kendo.toString(value,'N0')#",
        },
		render: function(e) {
            var draw = kendo.drawing;
            var geom = kendo.geometry;
            var chart = e.sender;

            var circleGeometry = new geom.Circle(center, radius);
            var bbox = circleGeometry.bbox();

            var text = new draw.Text(kendo.toString(valueSum,'N0'), [0, 0], {
              font: "12px Helvetica Neue",
              color:"#58666e"
            });

            draw.align([text], bbox, "center");
            draw.vAlign([text], bbox, "center");

            e.sender.surface.draw(text);
        }
    });
};

dl.generategrid5 = function(series){
	var center;
    var radius;
	var valueSum = 0;
	series.forEach(function(xx, idx){
		xx.category = xx.Category;
		xx.value = xx.Value;
		xx.color = chartColors[idx]
		valueSum = valueSum + xx.Value;
	});
	dl.pieSource1(series);
	$("#dlchart5").replaceWith("<div id='dlchart5' />")
    $("#dlchart5").kendoChart({
		title: {
		   text: "Deal Value (Annualised Revenue)",
		   color: "#0075B2",
		   font: chartFont
		},
        chartArea: {
            background: "transparent",
            height: 255,
            margin:0,
        },
		seriesDefaults: {
            overlay: {
              gradient: "none"
            },
        },
		dataSource: {
            data: series
        },
        legend: {
            visible: false,
            position: "bottom",
            labels:{
                font:chartFont
            }
        },
		transitions: false,
        //seriesColors: chartColors,
		series: [{
			padding: 0,
            type: "donut",
            field: "Value",
            categoryField: "Category",
			visual: function(e) {
              // Obtain parameters for the segments
              // Will run many times, but that's not an issue
              center = e.center;
              radius = e.radius;

              // Create default visual
              return e.createVisual();
            },
			labels: {
                visible: chartLabelDisplay,
                font:chartFont,
                color:"#FFF",
                background:"transparent",
				//template:"#:Convert(percentage)#",
                template:"#:replaceString(kendo.toString(percentage,'P0'))#",
                padding:0,
                margin:0,
            },
        }],
        tooltip: {
            visible: true,
            font:chartFont,
            template:"#: dataItem.category # - #:kendo.toString(value,'N0')#",
        },
		HtmlAttributes: { style : "margin:0 auto;border:none; width: 100%;" },
		render: function(e) {
            var draw = kendo.drawing;
            var geom = kendo.geometry;
            var chart = e.sender;

            var circleGeometry = new geom.Circle(center, radius);
            var bbox = circleGeometry.bbox();

            var text = new draw.Text(Convert(valueSum), [0, 0], {
              font: "12px Helvetica Neue",
              color:"#58666e"
            });

            draw.align([text], bbox, "center");
            draw.vAlign([text], bbox, "center");

            e.sender.surface.draw(text);
        }
    });
}

dl.generategrid6 = function(series){
	var center;
    var radius;
	var valueSum = 0;
	series.forEach(function(xx, idx){
		xx.category = xx.Category;
		xx.value = xx.Value;
		xx.color = chartColors[idx]
		valueSum = valueSum + xx.Value;
	});
	dl.pieSource2(series);
	$("#dlchart6").replaceWith("<div id='dlchart6' />")
    $("#dlchart6").kendoChart({
		title: {
		   text: "Deal Count",
		   color: "#0075B2",
		   font: chartFont
		},
        chartArea: {
            background: "transparent",
            height: 255,
            margin:0,
        },
		seriesDefaults: {
            overlay: {
              gradient: "none"
            },
        },
		dataSource: {
            data: series
        },
        legend: {
            visible: false,
            position:"bottom",
            labels:{
                font:chartFont
            }
        },
		transitions: false,
        //seriesColors: chartColors,
		series: [{
			padding: 0,
            type: "donut",
            field: "Value",
            categoryField: "Category",
			visual: function(e) {
              // Obtain parameters for the segments
              // Will run many times, but that's not an issue
              center = e.center;
              radius = e.radius;

              // Create default visual
              return e.createVisual();
            },
			labels: {
                visible: chartLabelDisplay,
                font:chartFont,
                color:"#FFF",
                background:"transparent",
				//template:"#:Convert(percentage)#",
                template:"#:replaceString(kendo.toString(percentage,'P0'))#",
                padding:0,
                margin:0,
            },
        }],
        tooltip: {
            visible: true,
            font:chartFont,
            template:"#: dataItem.category # - #:kendo.toString(value,'N0')#",
        },
		render: function(e) {
            var draw = kendo.drawing;
            var geom = kendo.geometry;
            var chart = e.sender;

            var circleGeometry = new geom.Circle(center, radius);
            var bbox = circleGeometry.bbox();

            var text = new draw.Text(kendo.toString(valueSum,"N0"), [0, 0], {
              font: "12px Helvetica Neue",
              color:"#58666e"
            });

            draw.align([text], bbox, "center");
            draw.vAlign([text], bbox, "center");

            e.sender.surface.draw(text);
        }
    });
};
//
dl.generateChartLegend = function(series){
	var center;
    var radius;
	var valueSum = 0;
	series.forEach(function(xx){
		xx.category = xx.Category;
		xx.value = xx.Value;
		valueSum = valueSum + xx.Value;
	});

	$("#dlchart7").replaceWith("<div id='dlchart7' />")
	$("#dlchart7").attr("style","margin-top:-167px");
    $("#dlchart7").kendoChart({
        chartArea: {
            background: "transparent",
            height: 200,
            margin:0,
        },
		seriesDefaults: {
            overlay: {
              gradient: "none"
            },
        },
		dataSource: {
            data: series
        },
        legend: {
            visible: true,
            position:"bottom",
            labels:{
                font:chartFont
            }
        },
		transitions: false,
        seriesDefaults: {
            type: "donut",
            size:40,
            tooltip: {
              visible: false,
              template: "SGD #:kendo.toString(value,'N0')#"
            },
            overlay: {
              gradient: "none"
            },
            labels: {
              visible: true,
              position: "center",
              template: "#:replaceString(kendo.toString(percentage,'P0'))#",
              color: "#FFFFFF",
              background: "transparent",
              font:chartFont,
            },
            color: "#ec7209",
        },
        series: [{
          visible:false,
          field: "Value",
          categoryField: "Category",
        }],
        seriesColors:chartColors,
		legendItemClick:function(e){
            //for(var i in arr){
				var leg = e.text;
                var obj1 = $("#dlchart5").getKendoChart();
				var obj2 = $("#dlchart6").getKendoChart();
                var source1 = [];
				var source2 = [];

				var checkInShow = Enumerable.From(dl.pieShow()).FirstOrDefault(null, "$ == '" + leg + "'");

				if(checkInShow != undefined){
					var pshow = Enumerable.From(dl.pieShow()).Where("$ != '" + leg +"'").ToArray()
					dl.pieShow(pshow);
					dl.pieHide.push(leg);
				}else{
					var phide = Enumerable.From(dl.pieHide()).Where("$ != '" + leg +"'").ToArray()
					dl.pieHide(phide)
					dl.pieShow.push(leg);
				}

				dl.pieSource1().forEach(function(xx, idx){
					var g1 = Enumerable.From(dl.pieShow()).FirstOrDefault(null, "$ == '" + xx.Category + "'")
					if(g1 != null)
						source1.push(xx)

					var g2 = Enumerable.From(dl.pieShow()).FirstOrDefault(null, "$ == '" + xx.Category + "'")
					if(g2 != null)
						source2.push(dl.pieSource2()[idx])
				})
				obj1.setDataSource(source1);
				obj2.setDataSource(source2);
				obj1.refresh();
				obj2.refresh();
        }
    });
};

dl.chartTop5 = function(data, target, globalAverage, regionalAverage, showAverage){
    if(showAverage == undefined)
        showAverage = false
    //change united arab emirate to UAE
    var uae = data.categories.indexOf("UNITED ARAB EMIRATES")
    if (uae !== -1) {
        data.categories[uae] = "UAE";
    }

    var kor = data.categories.indexOf("KOREA, REPUBLIC OF")
    if (kor !== -1) {
        data.categories[kor] = "KOREA";
    }

    var finalPlotGlobal = globalAverage;//avgPlot / 5;
    var finalPlotRegional = regionalAverage //regionalAverage;//avgPlot / 5;
    var rotateVal = 0;
    if(target == "dlChart9") {
    	rotateVal = 320;
    }

    var max = 0;
    data.series.forEach(function(xx){
        xx.data.forEach(function(yy){
            if (yy > max)
                max = yy
        });
    });

    $("#" + target).kendoChart({
        chartArea: {
            background: "transparent",
            // width: 300,
            height: 283
        },
        legend: {
            position: "bottom",
            visible:true,
            labels:{
                font:chartFont
            }
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            labels:{
                visible: chartLabelDisplay,
                font:chartFont,
                //position:"center",
                color:chartLabelColor,
                background:"transparent",
                template:"#:kendo.toString(value,'N0')#",
                padding:5,
                margin:0,
            }
        },
        seriesColors:chartColors,
        series: data.series,
        valueAxis: {
            name: "axs",
            line: {
                visible: false
            },
            labels:{
                font:chartFont,
                template:"#:kendo.toString(value,'N0')#",
                rotation: rotateVal,
            },
            majorGridLines: {
                visible: true
            },
            max: max * 1.5
        },
        categoryAxis: {
            name: "catAxis",
            categories: data.categories,//["CHINA", "Hong Kong", "India", "Singapore", "UAE"],//data.categories,//
            majorGridLines: {
                visible: false
            },
            labels:{
                font:chartFont,
            },
        },
        tooltip: {
            visible: true,
            template: " #= kendo.toString(value,'n2') #",//#= series.name #:
            font:chartFont,
        },

        render: function(e) {
            // if (showRender == true) {
                var valueAxis = e.sender.getAxis("axs");
                var categoryAxis = e.sender.getAxis("catAxis");

                var valueSlot = valueAxis.slot(finalPlotGlobal);
                var valueSlotRegion = valueAxis.slot(finalPlotRegional);

                var lastCategoryIndex = Math.max(1, categoryAxis.range().max);
                var minCategorySlot = categoryAxis.slot(0);
                var maxCategorySlot = categoryAxis.slot(lastCategoryIndex);


                var line = new kendo.drawing.Path({
                    stroke: {
                      color: "#8a8b8d",
                      width: 3
                    },
                });
                line.moveTo(valueSlot.origin).lineTo([valueSlot.origin.x, minCategorySlot.origin.y + 10]);

                var line2 = new kendo.drawing.Path({
                    stroke: {
                      color: "#f0ad4e",
                      width: 3
                    },
                });
                line2.moveTo(valueSlotRegion.origin).lineTo([valueSlotRegion.origin.x, minCategorySlot.origin.y + 10]);

                var labelPos = [valueSlot.origin.x - 10 , 0 ];
                var avgVal = kendo.toString(finalPlotGlobal, "n2")
                var label = new kendo.drawing.Text(avgVal, labelPos, {
                    fill: {
                      color: "#8a8b8d"
                    },
                    font: "11px 'Helvetica Neue'",
                });

                var labelPos2 = [valueSlotRegion.origin.x - 10 , valueSlot.origin.y ];
                var avgVal2 = kendo.toString(finalPlotRegional, "n2")
                var label2 = new kendo.drawing.Text(avgVal2, labelPos2, {
                    fill: {
                      color: "#f0ad4e"
                    },
                    font: "11px 'Helvetica Neue'",
                });

                var group = new kendo.drawing.Group();
                group.append(line, label);

                var group2 = new kendo.drawing.Group();
                group2.append(line2, label2);

                if(showAverage) {
                    if(target != "gcharttop2"){
                        var Mr = filter.MajorRegion();
                        if (Mr != "") {
                            e.sender.surface.draw(group);
                            e.sender.surface.draw(group2);
                        }else{
                            e.sender.surface.draw(group);
                        }
                    }
                }
        }
    });
}

function MajorRegionModalChange(e){
    var country = e.sender.value();
    GenerateDataTop5(dl.majorRegionGrid, country)
}

function GenerateDataTop5(majorRegion, country){
    if(majorRegion == ""){
        majorRegion = dl.majorRegionGrid;
    }
    var newFilter = ko.mapping.toJS(filter);
    if(model.Role.Role().toLowerCase() == "country")
        newFilter.Country = model.Role.selCon();
    else
        newFilter.Country = country;
    newFilter.MajorRegionMap = majorRegion;
    newFilter.ShowTop = parseInt(dl.Top.ShowTop());
    dl.getDetailDeals([])
    var titleModal = capitalizeFirstLetter(dl.Top.takeWhat()) + " Deals - " + majorRegion + " - Top " + dl.Top.ShowTop();
    $("#ModelTitleDeal").html(titleModal)
    ajaxPost("/dashboard/dealtop5", newFilter,
        function (res) {
            if(!res.success){
                alert(res.message);
                return;
            }
            var data = [];
            if(dl.Top.takeWhat() == "live"){
                data = res.data.LiveDeals;
            }else if(dl.Top.takeWhat() == "new"){
                data = res.data.NewDeals;
            }else if(dl.Top.takeWhat() == "lost"){
                data = res.data.LostDeals;
            }else if(dl.Top.takeWhat() == "won"){
                data = res.data.WonDeals;
            }
            data.forEach(function(xx){
                xx.Expected_Close_Date = moment(xx.Expected_Close_Date).toDate()
            });
            dl.getDetailDeals(data, titleModal)
        },
        function () {}
    )
}

$(function(){
    $(".ame").click(function(){
		$("#modalDeal").modal("show");
        dl.majorRegionGrid = "AME"
        var listCountry = Enumerable.From(filter.MasterRegionRaw()).Where("$.Major_Region == '" + dl.majorRegionGrid + "'").Select("$.Country").ToArray();
        dl.Top.listSelectedCountry(listCountry);
        GenerateDataTop5("AME");
	})

	$(".asa").click(function(){
		$("#modalDeal").modal("show")
        dl.majorRegionGrid = "ASA"
        var listCountry = Enumerable.From(filter.MasterRegionRaw()).Where("$.Major_Region == '" + dl.majorRegionGrid + "'").Select("$.Country").ToArray();
        dl.Top.listSelectedCountry(listCountry);
        GenerateDataTop5("ASA");
	})

	$(".gcna").click(function(){
		$("#modalDeal").modal("show")
        dl.majorRegionGrid = "GCNA"
        var listCountry = Enumerable.From(filter.MasterRegionRaw()).Where("$.Major_Region == '" + dl.majorRegionGrid + "'").Select("$.Country").ToArray();
        dl.Top.listSelectedCountry(listCountry);
        GenerateDataTop5("GCNA");
	})

    $(".europe").click(function(){
        $("#modalDeal").modal("show")
        dl.majorRegionGrid = "EUROPE"
        var listCountry = Enumerable.From(filter.MasterRegionRaw()).Where("$.Major_Region == '" + dl.majorRegionGrid + "'").Select("$.Country").ToArray();
        dl.Top.listSelectedCountry(listCountry);
        GenerateDataTop5("EUROPE");
    })

    $(".americas").click(function(){
        $("#modalDeal").modal("show")
        dl.majorRegionGrid = "AMERICAS"
        var listCountry = Enumerable.From(filter.MasterRegionRaw()).Where("$.Major_Region == '" + dl.majorRegionGrid + "'").Select("$.Country").ToArray();
        dl.Top.listSelectedCountry(listCountry);
        GenerateDataTop5("AMERICAS");
    })
})

// $(function(){
	// dl.GetDataDeal();

	// $(".ame").click(function(){
		// $("#modalDeal").modal("show");
        // GenerateDataTop5("AME");
		// var newFilter = filter;
		// newFilter.MajorRegionMap = "AME";
		// newFilter.ShowTop = parseInt(dl.Top.ShowTop());
		// dl.getDetailDeals([])
		// $("#ModelTitleDeal").html(capitalizeFirstLetter(dl.Top.takeWhat()) + " Deals - AME - Top " + dl.Top.ShowTop())
		// ajaxPost("/dashboard/dealtop5", filter,
		// 	function (res) {
		// 		if(!res.success){
		// 			alert(res.message);
		// 			return;
		// 		}
		// 		var data = [];
		// 		if(dl.Top.takeWhat() == "live"){
		// 			data = res.data.LiveDeals;
		// 		}else if(dl.Top.takeWhat() == "new"){
		// 			data = res.data.NewDeals;
		// 		}else if(dl.Top.takeWhat() == "lost"){
		// 			data = res.data.LostDeals;
		// 		}else if(dl.Top.takeWhat() == "won"){
		// 			data = res.data.WonDeals;
		// 		}
		// 		dl.getDetailDeals(data, capitalizeFirstLetter(dl.Top.takeWhat()) + " Deals - AME - Top " + dl.Top.ShowTop())
		// 	},
		// 	function () {}
		// )
	// })

	// $(".asa").click(function(){
		// $("#modalDeal").modal("show")
        // GenerateDataTop5("ASA");
		// var newFilter = filter;
		// newFilter.MajorRegionMap = "ASA";
		// newFilter.ShowTop = parseInt(dl.Top.ShowTop());
		// dl.getDetailDeals([])
		// $("#ModelTitleDeal").html(capitalizeFirstLetter(dl.Top.takeWhat()) + " Deals - ASA - Top " + dl.Top.ShowTop())
		// ajaxPost("/dashboard/dealtop5", filter,
		// 	function (res) {
		// 		if(!res.success){
		// 			alert(res.message);
		// 			return;
		// 		}
		// 		var data = [];
		// 		if(dl.Top.takeWhat() == "live"){
		// 			data = res.data.LiveDeals;
		// 		}else if(dl.Top.takeWhat() == "new"){
		// 			data = res.data.NewDeals;
		// 		}else if(dl.Top.takeWhat() == "lost"){
		// 			data = res.data.LostDeals;
		// 		}else if(dl.Top.takeWhat() == "won"){
		// 			data = res.data.WonDeals;
		// 		}
		// 		dl.getDetailDeals(data, capitalizeFirstLetter(dl.Top.takeWhat()) + " Deals - ASA - Top " + dl.Top.ShowTop())
		// 	},
		// 	function () {}
		// )
	// })

	// $(".gcna").click(function(){
		// $("#modalDeal").modal("show")
        // GenerateDataTop5("GCNA");
		// var newFilter = filter;
        // var listCountry = Enumerable.From(filter.MasterRegionRaw()).Where("$.Major_Region == 'GCNA'").Select("$.Country").ToArray();
        // dl.Top.listSelectedCountry(listCountry);
		// newFilter.Country = dl.Top.takeWhatCountry();
        // newFilter.MajorRegionMap = "GCNA";
		// newFilter.ShowTop = parseInt(dl.Top.ShowTop());
		// dl.getDetailDeals([])
        // var titleModal = capitalizeFirstLetter(dl.Top.takeWhat()) + " Deals - GCNA - Top " + dl.Top.ShowTop();
		// $("#ModelTitleDeal").html(titleModal)
		// ajaxPost("/dashboard/dealtop5", filter,
		// 	function (res) {
		// 		if(!res.success){
		// 			alert(res.message);
		// 			return;
		// 		}
		// 		var data = [];
		// 		if(dl.Top.takeWhat() == "live"){
		// 			data = res.data.LiveDeals;
		// 		}else if(dl.Top.takeWhat() == "new"){
		// 			data = res.data.NewDeals;
		// 		}else if(dl.Top.takeWhat() == "lost"){
		// 			data = res.data.LostDeals;
		// 		}else if(dl.Top.takeWhat() == "won"){
		// 			data = res.data.WonDeals;
		// 		}
		// 		dl.getDetailDeals(data, titleModal)
		// 	},
		// 	function () {}
		// )
	// })
// });

dl.generateTable = function(datasource){
    $("#table").modal("show");
    setTimeout(function() {
        datasource.column.forEach(function(d, i){
            if(i > 0){

                d.columns.forEach(function(c){
                    c.width = 100;
                })
            }
        });

        var data = [];
        if(filter.MajorRegion() != "" && filter.Country() == ""){
            datasource.data.forEach(function(d){
                if(d.group == filter.MajorRegion()){
                    data.push(d);
                }
            });

            filter.countryList().forEach(function(d){
                datasource.data.forEach(function(ds){
                    if(d == ds.group){
                        data.push(ds);
                    }
                });
            });
        }else if(filter.Country() != ""){
            datasource.data.forEach(function(d){
                if(d.group == filter.Country() || d.group == filter.MajorRegion()){
                    data.push(d);
                }
            });
        }else{
            data = datasource.data
        }

        var totalDealRegion = 0;
        var totalCallRegion = 0;
        var totalDealRegionTemp = 0;
        var totalCallRegionTemp = 0;
        var totalrmLastMonthTemp = 0;
        var columnLength
        data.forEach(function(d){
            var totalDeal = 0;
            var totalCall = 0;
            datasource.column.forEach(function(c, i){
                if(i != 0) {
                    var month = moment(c.title, "MMM YY").format("YYYYMM");
                    totalDeal += d['val_deal_'+month];
                    totalCall += d['val_cr_'+month];
                }
            })
            var lastMonth = moment(datasource.column[datasource.column.length-1].title, "MMM YY").format("YYYYMM");
            var rmLastMonth = d['val_rm_'+lastMonth];
            d["YTD_Deal"] = (totalDeal/rmLastMonth) / (datasource.column.length-1);
            d["YTD_Call"] = (totalCall/rmLastMonth) / (datasource.column.length-1);

            columnLength = datasource.column.length-1; 
            totalDealRegionTemp += totalDeal;
            totalCallRegionTemp += totalCall;
            totalrmLastMonthTemp += rmLastMonth;
        });
        
            totalDealRegion = totalDealRegionTemp/2;
            totalCallRegion = totalCallRegionTemp/2;
            rmLastMonth2 = totalrmLastMonthTemp/2;

            DealRegion = ((totalDealRegion/rmLastMonth2) / columnLength);
            CallRegion = ((totalCallRegion/rmLastMonth2) / columnLength);

        var column = {
            aggregates : "sum",
            field : "YTD_Deal",
            template: function(d){
                return kendo.toString(d.YTD_Deal, "N1");
            },
            footerTemplate : function(d){
                return kendo.toString(DealRegion, 'N1');
            },
            title : "YTD <br> Deals/RM/ <br> Month",
            width : 100,
        }
        datasource.column.push(column);
        column = {
            aggregates : "sum",
            field : "YTD_Call",
            template: function(d){
                return kendo.toString(d.YTD_Call, "N1");
            },
            footerTemplate : function(d){
                return kendo.toString(CallRegion, 'N1');
            },
            title : "YTD <br> Calls/RM/ <br> Month",
            width : 100,
        }
        datasource.column.push(column);

        datasource.aggregate.push({
            aggregate : "sum",
            field: "YTD_Deal"
        });

        datasource.aggregate.push({
            aggregate : "sum",
            field: "YTD_Call"
        });

        $("#gridTable").html("");
        $("#gridTable").kendoGrid({
            dataSource: {
                data: data,
                pageSize: 10,
                aggregate: datasource.aggregate
            },
            excel: {
                fileName: "CB Scorecard.xlsx",
                allPages: true,
            },
            excelExport: function(e) {
                var sheet = e.workbook.sheets[0];
                for (var i = 0; i < sheet.rows.length; i++) {
                    if(i == 1){
                        for(var j = 0; j < sheet.rows[i].cells.length; j++){
                            if(sheet.rows[i].cells[j].value.indexOf("<br> ")) {
                                var header =  sheet.rows[i].cells[j].value.replace(/<br> /g, "");
                                sheet.rows[i].cells[j].value = header;
                            }
                        }
                    }
                }
            },
            sortable: true,
            resizable: true,
            scrollable: {
                virtual: true
            },
            pageable: {
                numeric: false,
                previousNext: false,
                messages: {
                    display: "Showing {2} data items"
                }
            },
            columns: datasource.column
        });
    }, 300);
}

dl.exportSneakPeak = function(){
    var grid = $("#gridTable").data("kendoGrid");
    grid.saveAsExcel();
}