var tv = {
	Processing:ko.observable(false),
  TopStage: ko.observable("Total"),
  Top: ko.observable("")
};

tv.TopStage.subscribe(function(e){
  $('.TopStage').addClass('label-default');
  $('.TopStage').removeClass('label-primary');
  $('.'+e).addClass('label-primary');
})

var topx = {
    'Total' : [{
    'name' : 'Shincan',
    'AP' :'Maret2013'
  },{
    'name' : 'Shincan',
    'AP' :'Maret2013'
  },{
     'name' : 'Shincan',
    'AP' :'Maret2013'
  }],

  'LC' : [{
    'name' : 'Doraemon',
    'AP' :'Februari2017'
  },{
    'name' : 'Doraemon',
    'AP' :'Februari2017'
  },{
     'name' : 'Doraemon',
    'AP' :'Februari2017'
  }],

   'MM' : [{
    'name' : 'Robocop',
    'AP' :'Septemer2017'
  },{
    'name' : 'Robocop',
    'AP' :'Septemer2017'
  },{
     'name' : 'Robocop',
    'AP' :'Septemer2017'
  }],

   'ME' : [{
    'name' : 'Naruto',
    'AP' :'Januari211'
  },{
    'name' : 'Naruto',
    'AP' :'Januari211'
  },{
     'name' : 'Naruto',
    'AP' :'Januari211'
  }],
};

tv.Top(topx);

tv.makegrid = function(){

/* var data = [{"201612":0,"201701":0,"201702":0,"201703":0,"201704":0,"201705":3,"201706":0,"201707":0,"201708":0,"201709":0,"All_User_Ids":"1006584","All_User_Names":"Uzma Munawar","Country":"UNITED ARAB EMIRATES","Line_Manager":"Sumit Verma","category":"","lm_id":"","segment":""},{"201612":0,"201701":0,"201702":0,"201703":0,"201704":0,"201705":0,"201706":1,"201707":0,"201708":0,"201709":0,"All_User_Ids":"1006584","All_User_Names":"Uzma Munawar","Country":"UNITED ARAB EMIRATES","Line_Manager":"Sumit Verma","category":"","lm_id":"","segment":""},{"201612":3,"201701":0,"201702":0,"201703":0,"201704":0,"201705":0,"201706":0,"201707":0,"201708":0,"201709":0,"All_User_Ids":"1007267","All_User_Names":"Ndiye Kgatlhego","Country":"BOTSWANA","Line_Manager":"Kefilwe Tlhabologang","category":"BCA","lm_id":"1358581","segment":"High Value Small Business"},{"201612":0,"201701":0,"201702":5,"201703":0,"201704":0,"201705":0,"201706":0,"201707":0,"201708":0,"201709":0,"All_User_Ids":"1007267","All_User_Names":"Ndiye Kgatlhego","Country":"BOTSWANA","Line_Manager":"Kefilwe Tlhabologang","category":"BCA","lm_id":"1358581","segment":"High Value Small Business"},{"201612":0,"201701":0,"201702":0,"201703":0,"201704":0,"201705":0,"201706":1,"201707":0,"201708":0,"201709":0,"All_User_Ids":"1007267","All_User_Names":"Ndiye Kgatlhego","Country":"BOTSWANA","Line_Manager":"Kefilwe Tlhabologang","category":"BCA","lm_id":"1243149","segment":"High Value Small Business"},{"201612":0,"201701":0,"201702":0,"201703":0,"201704":0,"201705":0,"201706":0,"201707":2,"201708":0,"201709":0,"All_User_Ids":"1007267","All_User_Names":"Ndiye Kgatlhego","Country":"BOTSWANA","Line_Manager":"Kefilwe Tlhabologang","category":"BCA","lm_id":"1243149","segment":"High Value Small Business"},{"201612":0,"201701":0,"201702":0,"201703":0,"201704":0,"201705":0,"201706":0,"201707":0,"201708":3,"201709":0,"All_User_Ids":"1007267","All_User_Names":"Ndiye Kgatlhego","Country":"BOTSWANA","Line_Manager":"Kefilwe Tlhabologang","category":"BCA","lm_id":"1243149","segment":"High Value Small Business"},{"201612":0,"201701":0,"201702":0,"201703":0,"201704":0,"201705":0,"201706":0,"201707":0,"201708":0,"201709":4,"All_User_Ids":"1007267","All_User_Names":"Ndiye Kgatlhego","Country":"BOTSWANA","Line_Manager":"Kefilwe Tlhabologang","category":"BCA","lm_id":"1243149","segment":"High Value Small Business"},{"201612":0,"201701":0,"201702":0,"201703":4,"201704":0,"201705":0,"201706":0,"201707":0,"201708":0,"201709":0,"All_User_Ids":"1009198","All_User_Names":"Lawrence Kyalo Muendo","Country":"KENYA","Line_Manager":"Benard Kombo Shikhuyu","category":"BCA","lm_id":"1448114","segment":"High Value Small Business"},{"201612":0,"201701":0,"201702":0,"201703":0,"201704":0,"201705":1,"201706":0,"201707":0,"201708":0,"201709":0,"All_User_Ids":"1009198","All_User_Names":"Lawrence Kyalo Muendo","Country":"KENYA","Line_Manager":"Benard Kombo Shikhuyu","category":"BCA","lm_id":"1448114","segment":"High Value Small Business"}];*/
   var paramTemp = ko.mapping.toJS(filter)

    var param = {
        StartStr :  paramTemp.StartStr,
        FinishStr :  paramTemp.FinishStr,
        MajorRegion : paramTemp.MajorRegion,
        Country : paramTemp.Country
    }

  ajaxPost("/dashboard/teamviewcallreport", param, function(res){

  newArray = [];
  data = res.Data;
/*  var tmpglobal = {"201612":0,"201701":0,"201702":0,"201703":0,"201704":0,"201705":1,"201706":0,"201707":0,"201708":0,"201709":0,"All_User_Ids":"1009198","All_User_Names":"Total","Country":"Total","Line_Manager":"Total","category":"BCA","lm_id":"1448114","segment":"High Value Small Business"}	
  tempName = "";
	_.each(data, function(v,i){
			 		_.each(v, function(vv,ii){	
			 				if(vv.Country!=tempName){
								tempName=vv.Country;
								newArr.push(tmpglobal);
								newArr.push(vv)	
							}else{
								newArr.push(vv)	
							}
				//	newArr.push(tmpglobal);
					})
				 
		 //})
	})*/
//tv.dataTabel = ko.observable(data);
var temp = {"201701":"null","201702":"null","201703":"null","201704":"null","201705":"null","201706":"null","201707":"null","201708":"null","201709":"null","201710":"null","201711":"null","201712":"null","Name":"Total","Parent":"" ,"PSID":" ","Segment":"Local Corporates","Total":"null"};
newArray.push(temp);
_.each(data.Local_Corporates, function(v,i){   newArray.push(v)})
var tempx = {"201701":"null","201702":"null","201703":"null","201704":"null","201705":"null","201706":"null","201707":"null","201708":"null","201709":"null","201710":"null","201711":"null","201712":"null","Name":"Total","Parent":"","PSID":"  ","Segment":"Medium Enterprise","Total":"null"};
newArray.push(tempx);
_.each(data.Medium_Enterprise, function(v,i){  newArray.push(v)})
var tempy = {"201701":"null","201702":"null","201703":"null","201704":"null","201705":"null","201706":"null","201707":"null","201708":"null","201709":"null","201710":"null","201711":"null","201712":"null","Name":"Total","Parent":"","PSID":"   ","Segment":"Middle Markets","Total":"null"};
newArray.push(tempy);
_.each(data.Middle_Markets, function(v,i){  newArray.push(v)})

var userParent =  _.filter(newArray, function(x){return x.Parent==""})
var userChild =  _.filter(newArray, function(x){return x.Parent!=""})

tv.userParent = ko.observable(userParent);
tv.userChild = ko.observable(userChild);

newData = generateColumn(userParent,"parent");
baru = _.sortBy(newData.data, 'Segment');
METemp = [];
MMTemp = [];
//sort data cause total need in top 
ArrayMe = [];
_.each(baru, function(v,i){
  if(v.Segment == "Local Corporates" && v.Name == "Total" ){
    ArrayMe.unshift(v);
  }else if(v.Segment=="Local Corporates"){
    ArrayMe.push(v);
  }
})
_.each(baru, function(v,i){
  if(v.Segment == "Medium Enterprise" && v.Name == "Total" ){
    ArrayMe.push(v);
  }else if(v.Segment=="Medium Enterprise"){
    METemp.push(v);
  }
})
_.each(METemp, function(v,i){
  ArrayMe.push(v);
})

_.each(baru, function(v,i){
  if(v.Segment == "Middle Markets" && v.Name == "Total" ){
    ArrayMe.push(v);
  }else if(v.Segment=="Middle Markets"){
    MMTemp.push(v);
  }
})

_.each(MMTemp, function(v,i){
  ArrayMe.push(v);
})

	$("#gridx").kendoGrid({
		  dataSource: {
		    data: ArrayMe,
		  },
		  height: 500,
      detailInit: detailInit,
      dataBound: function() {
           this.expandRow(this.tbody.find("tr.k-master-row").first());
       },
/*		  excel:{
		  	fileName: "Call Report by Segment",
		  	allPages: true,
		  },

		toolbar: ["excel"],*/
		/*  sortable:true,*/
		  scrollable: true,
		  resizable: true,
		  pageable:false,
		  columns: newData.columnsGrid,
		})

  /*kendo.ui.progress($(".grid-loading"), false);
   $(".grid-loading").css("height", 0)*/
/*    setTimeout(function() {
        $("#gridx").getKendoGrid().refresh()
        MergeGridRows('gridx', 'Segment')
    }, 100);*/

jQuery.moveColumn('#gridx',0,2);
$('.k-hierarchy-col').css('width','100')
MergeGridRows('gridx', 'Segment');
$('.k-i-collapse').click();
_.each($(".k-hierarchy-cell.boldheader"), function(v, i){
  $(v).find("a").removeClass("k-icon k-i-expand")

})
})
}

jQuery.moveColumn = function (table, from, to) {
    var rows = jQuery('tr', table);
    var cols;
    rows.each(function() {
        cols = jQuery(this).children('th, td');
        cols.eq(from).detach().insertBefore(cols.eq(to));
    });
}

     function detailInit(e) {
      if(e.data.PSID.length > 3){
                   newData = generateColumn(tv.userChild(),"child");
                   $("<div/>").appendTo(e.detailCell).kendoGrid({
                         dataSource: {
                            data: newData.data,
                            filter: { field: "Parent", operator: "eq", value: e.data.PSID }

                          },
                    
                          scrollable: true,
                          resizable: true,
                          pageable:false,
                          columns: newData.columnsGrid,
                    });
                 }
    }

function generateColumn(arr,stage){

var distinct = Enumerable.From(arr).GroupBy("$.PSID").ToArray();
var startDate = parseInt(filter.Finish().getFullYear()+"01");
var dataTemp = [];
distinct.forEach(function(e){
        var row = {}
        e.source.forEach(function(v){

            row['Segment'] = v.Segment
            row['Parent'] = v.Parent;
            row['Name']  = v.Name;
            row["PSID"] = v.PSID;
            
            var keys = Object.keys(v);
            keys.forEach(function(v1){
                var key = parseInt(v1)
                if(!isNaN(key) && key >= startDate) {
                    var year = (""+key).substring(0,4)
                    var month = (""+key).substring(4,6)
                    var dateFormat = moment(year+"-"+month).format("MMMYY")
                    if(row[dateFormat] === undefined) {
                        row[dateFormat] = 0
                    }
                    if(v[key]=="null"){
                      row[dateFormat] = " ";
                    }else if(!isNaN(v[key] && v[key]!="null")){
                        row[dateFormat] += v[key]
                    } else {
                       row[dateFormat] += 0
                    }
                }
           
            })
        })
          row['Best_Global'] = " ";
          row['Region_Best'] = " ";
        dataTemp.push(row)
    })

  var columns = [];
  var columnsGrid = [];
  var aggregates = [];

   if(dataTemp.length > 0) {
        columns = Object.keys(dataTemp[0])
    }
    var count = 0;
    columns.forEach(function(e){
      if(++count > 4){
        
        if(e=="Best_Global"){
          columnsGrid.push({
            field : e,
            title : e,
            width : 80
          })
        }else if(e=="Region_Best"){
          columnsGrid.push({
            field : e,
            title : e,
            width : 80
          })
        }else{
            columnsGrid.push({
            field : e,
            title : e,
            width:50
      })
      }

    }else{
        if(e == "PSID"){
          columnsGrid.push({
            field: e,
            title: e,
            width:100,
/*            footerTemplate: "Total",
            footerAttributes:{
              style: "text-align: right"
            },
*/          })
        } else if (e=="Name"){
          columnsGrid.push({
            field:e,
            title:e,
            width:150
          })
        }else if (e=="Segment"){
          if(stage=="parent"){
              columnsGrid.push({
                field:e,
                title:e,
                width:25
              })
        }
        }else if (e=="Parent"){
         /* columnsGrid.push({
          title:"",
            width:25,
            template:function(e){
              console.log(e);
                return "<a href='#' onclick='detailInit('"+e.PSID+"') ><i class='fa fa-arrow-circle-o-right' aria-hidden='true'></i></a>";
            }
          })*/
        }else {
          columnsGrid.push({
            field:e,
            title:e
          })
        }
      }
    })
    
    newData = {
      data : dataTemp,
      columnsGrid : columnsGrid
    }
    return newData;
    }

function MergeGridRows(gridId, colTitle) {
 
        $('#' + gridId + '>.k-grid-content>table').each(function (index, item) {
            var dimension_col = 1;
            // First, scan first row of headers for the "Dimensions" column.
            $('#' + gridId + '>.k-grid-header>.k-grid-header-wrap>table').find('th').each(function() {
                var _this = $(this);
                if (_this.text() == colTitle) {
                    var bgColor = '#ffffff'
                    var foreColor = _this.css('color');
                    var rightBorderColor = _this.css('border-right-color');
                    // first_instance holds the first instance of identical td
                    var first_instance = null;
                    var cellText = '';
                    var arrCells = [];
                    $(item).find('tr').each(function(i,v) {
                        // find the td of the correct column (determined by the colTitle)
                        var dimension_td = $(this).find('td:nth-child(' + dimension_col + ')');
                        if(dimension_col>1){
             							var dimension_tr = $(this).find('td:not(:nth-child(' + dimension_col + '))');
             						}else{
             							var dimension_tr = $(this).find('td:not(:nth-child(' + dimension_col+ '))');
             						}	
                        if (first_instance == null) {
                            first_instance = dimension_td;
                            dimension_td.css('border-bottom', '0px');
                            cellText = first_instance.text();
                             dimension_tr.addClass('boldheader'); 

                        } else if (dimension_td.text() == cellText) {
                            // if current td is identical to the previous
                            dimension_td.css('border-top', '0px');
                            dimension_td.css('border-bottom', '0px');
                            dimension_tr.addClass('verticalScroll');
                        } else {

                            // this cell is different from the last
                            arrCells = ChangeMergedCells(arrCells, cellText, true);
                            //first_instance = dimension_td;
                            cellText = dimension_td.text();
                             dimension_td.css('border-bottom', '0px'); 
                             if(i!=2){
                              dimension_tr.addClass('boldheader');
                             } 
                             console.log(dimension_tr,i)
                        }

                        arrCells.push(dimension_td);
                        dimension_td.text("");
                        dimension_td.css('background-color', bgColor).css('color', foreColor).css('border-bottom-color', rightBorderColor);
                         
                        });
                    arrCells = ChangeMergedCells(arrCells, cellText, false);
                    return;
                }
                dimension_col++;
            });
 
        });
    }
 
    function ChangeMergedCells (arrCells, cellText, addBorderToCell) {
        var cellsCount = arrCells.length;
        if (cellsCount > 1) {
            var index = parseInt(cellsCount / 2);
            var cell = null;
            if (cellsCount % 2 == 0) { // even number
                cell = arrCells[index -1];
                arrCells[index -1].css('vertical-align', 'bottom');
            }
            else { // odd number
                cell = arrCells[index];
            }
            cell.text(cellText);
            if (addBorderToCell)
                arrCells[cellsCount -1].css('border-bottom', 'solid 1px #ddd');
            arrCells =[]; // clear array for next item
        }
        return arrCells;
    }


function onChecked(param){
	console.log(param)
}

$('.parent-tab a').click(function(e) {
        e.preventDefault();
        $(this).tab('show')
    })