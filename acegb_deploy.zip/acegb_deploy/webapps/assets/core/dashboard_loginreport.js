var lr = {
	Processing:ko.observable(true),
	IsFirstLoad: ko.observable(true),
	SelectedModules:ko.observableArray([]),
	SelectedSegment:ko.observable(),
	ModulesData:ko.observable(),
	TakeWhat: ko.observable("ytd"),
	DataRm:ko.observableArray([]),
};

lr.TakeWhat.subscribe(function(){
	lr.GetData();
});

lr.Reset = function(){
	resetFilter();
	lr.RemoveMultiSelect();
	lr.SelectedSegment("");
    lr.GetData();
}

lr.GetData = function(){
	if(ds.fromAnalytic()){
        resetDate();
        ds.fromAnalytic(false);
    }
	var LoginUser = moment(new Date(model.arrayLastDate().lastUpdateLoginUser)).format("MMM YY");
    model.lastDateData(LoginUser);
    
	lr.Processing(true);
	lr.createGrid();
	ajaxPost("/dashboard/getrmsegment","",function(data){

		$("#lrSegment").kendoDropDownList({
		    dataSource: data.data,
		    filter: "contains",
		    optionLabel: "All or Select"
    	});
	});

	ajaxPost("/dashboard/getmodulemap","",function(data){
		var container =[];
		for(var i in data.data){
			container.push({module:data.data[i]});
		}
		lr.ModulesData(container);
		if(lr.IsFirstLoad()){
			lr.CreateMultiSelect(container);
		}else{
			var multiselect = $("#lrModules").data("kendoMultiSelect");
			multiselect.setDataSource(container);
			multiselect.refresh();
		}
	});

	var parm = {};
	parm.MajorRegion = filter.MajorRegion();
	parm.Region = filter.Region();
	parm.Country = filter.Country();
	parm.StartStr = filter.StartStr();
	parm.FinishStr = filter.FinishStr();
	parm.Modules = lr.SelectedModules();
	parm.SubSegment = lr.SelectedSegment();
	parm.TakeWhat = lr.TakeWhat();
	ajaxPost("/dashboard/getsalesmodulesperrm",parm,function(res){
		if(res.data != undefined){
			if(!lr.IsFirstLoad()){
				lr.destroyGrid();
			}
			console.log(res.data.data)
			res.data.column.unshift({
				field: "rmname", 
				title:"Relationship Managers", 
				headerAttributes: {style: "vertical-align: middle;"}, 
				filterable:{
					ui : function(element){
					    element.kendoAutoComplete({
					        dataSource: res.data.data,
					        dataTextField: "rmname",
					        dataValueField: "rmname",
					        minLength: 2,
				   	 	});
					}	
				}
			});
			lr.DataRm(res.data.column);
			lr.createGrid(res.data.data, res.data.column);
		}
	});
	lr.Processing(false);
}

lr.CreateMultiSelect = function(data){
	$("#lrModules").kendoMultiSelect({
	    dataSource: data,
	    filter: "contains",
	    placeholder: "All or Select",
	    dataValueField : "module",
	    dataTextField : "module",
	    clearButton: false,
	    change: lr.GetMultiSelect
	});
	lr.IsFirstLoad(false);
}

lr.RemoveMultiSelect = function(){
	var multiselect = $("#lrModules").data("kendoMultiSelect");
	multiselect.value([]);
	lr.SelectedModules.removeAll();
}

lr.GetMultiSelect = function(){
	var multiselect = $("#lrModules").data("kendoMultiSelect");
	lr.SelectedModules(multiselect.value());
}

lr.destroyGrid = function(){
	var grid =  $("#lrGrid").data("kendoGrid");
	grid.destroy();
	$("#lrGrid").empty();
}

lr.createGrid = function (data, column) {
	// console.log(data["rmname"]);
	$("#lrGrid").html("");
    $("#lrGrid").kendoGrid({
    	toolbar: ["excel"],
		excel: {
			allPages: true,
			filterable: true,
		},
	    dataSource: {
	    	data: data,
            schema: {
	            model: {
	                fields: {
	                    apclientmap: { type: "number" },
	                    callreports: { type: "number" },
	                    clientpages: { type: "number" },
	                    contacts: { type: "number" },
	                    dealcentre: { type: "number" },
	                    dealpipeline: { type: "number" },
	                    epdm: { type: "number" },
	                    logins: { type: "number" },
	                    offboarding: { type: "number" },
	                    prospects: { type: "number" },
	                    raptor: { type: "number" },
	                    riskview: { type: "number" },
	                    scorecard: { type: "number" },
	                    sdm: { type: "number" },
	                    rmname: { type: "string" },
	                }
	            }
	        },
	    },
        pageable: {
        	pageSize: 10,
        	previousNext : true,
	        refresh: false,
	        pageSizes: true,
	        buttonCount: 5
        },
	    columns: column,
	    sortable: true,
	    // filterable: true,
		excelExport: function(e) {
		    e.workbook.fileName = "Login-Report.xlsx";
		 },
        filterable: {
            extra: false,
            operators: {
                string: {
                    contains: "Contains",
                    startswith : "Starts with",
                    eq: "Equal to",
                    
                },
                number: {
                    gte: "Greater than equal to",
                    lte: "Less than equal to",
                   
                }
            }
        }
	});

}

	lr.rmFilter = function(element) {
	    element.kendoAutoComplete({
	        dataSource: lr.DataRm(),
	        dataTextField: "rmname",
	        dataValueField: "rmname",
	    });
	}


lr.ExportExcel = function(){
	var grid = $("#lrGrid").data("kendoGrid");
    grid.saveAsExcel();
}

$(document).ready(function(){

})
