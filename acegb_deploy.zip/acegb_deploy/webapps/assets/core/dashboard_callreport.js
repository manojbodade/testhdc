var dcr = {
    PullRequest:ko.observable(0),
    Processing:ko.observable(true),
    CreateImgvann:ko.observable(false),
    GChart1:ko.observableArray([]),
    GChart2:ko.observableArray([]),
    GChart3:ko.observableArray([]),
    GChart4Monthly:ko.observableArray([]),
    GChart43Month:ko.observableArray([]),
    GChart5Monthly:ko.observableArray([]),
    GChart53Month:ko.observableArray([]),
    GChart6:ko.observableArray([]),
    GChart7:ko.observableArray([]),
    GChart8:ko.observableArray([]),
    GTable:ko.observableArray([]),
};

dcr.newReport = ko.observable(0);
dcr.mom = ko.observable(0);
dcr.perRmMom = ko.observable(0);
dcr.allReport = ko.observable(0);
dcr.clientCoverage = ko.observable(0);
dcr.perRmAll = ko.observable(0);

dcr.clientbyregionview = ko.observable("monthly")
dcr.clientbyregionview.subscribe(function(xx){
    if(xx == "monthly"){
        dcr.generategrid4(dcr.GChart4Monthly());
        dcr.generategrid5(dcr.GChart5Monthly());
    }else{
        dcr.generategrid4(dcr.GChart43Month());
        dcr.generategrid5(dcr.GChart53Month());
    }
})

dcr.PullRequest.subscribe(function(newval){
  
    if(newval==0){
        dcr.Processing(false);
        dcr.generategrid1(dcr.GChart1());
        dcr.generategrid2(dcr.GChart2());
        dcr.generategrid3(dcr.GChart3());
        dcr.generategrid6(dcr.GChart6());
        dcr.generategrid7(dcr.GChart7());

        if(dcr.clientbyregionview() == "monthly"){
            dcr.generategrid4(dcr.GChart4Monthly());
            dcr.generategrid5(dcr.GChart5Monthly());
        }else{
            dcr.generategrid4(dcr.GChart43Month());
            dcr.generategrid5(dcr.GChart53Month());
        }

        dg.chartTop5(dcr.GChart8(), "crchart8", dcr.GChart8().globalaverage, dcr.GChart8().regionalaverage, true);
    }
})
dcr.Reset = function(){
    resetFilter();
    dcr.GetDataCallReport();
}
dcr.GetDataCallReport = function(){
    if(ds.fromAnalytic()){
        resetDate();
        ds.fromAnalytic(false);
    }
    var CallReport = moment(new Date(model.arrayLastDate().lastUpdateCallReport)).format("MMM YY");
    model.lastDateData(CallReport);
    dcr.PullRequest(10);
    dcr.Processing(true);
	ajaxPost("/dashboard/callreportmtdytd", filter, 
		function (res) {
			if(!res.success){
				alert(res.message);
				return;
			}
			dcr.newReport(res.data.NewReport);
			dcr.mom(res.data.MOM);
			dcr.perRmMom(res.data.PreRmMoM);
			dcr.allReport(res.data.AllRec);
			dcr.clientCoverage(res.data.clientCoverage);
			dcr.perRmAll(res.data.PreRmYtd);
            pullRequestComplete(dcr.PullRequest);
		}, 
		function () {}
	)
	
	ajaxPost("/dashboard/callreportmom", filter, 
		function (res) {
			if(!res.success){
				alert(res.message);
				return;
			}
            dcr.GChart1(res.data);
            pullRequestComplete(dcr.PullRequest);
		}, 
		function () {}
	)	
	
	ajaxPost("/dashboard/callreportproductdisscussed", filter, 
		function (res) {
			if(!res.success){
				alert(res.message);
				return;
			}
            dcr.GChart2(res.data);
            pullRequestComplete(dcr.PullRequest);
		}, 
		function () {}
	)	
	
	ajaxPost("/dashboard/callreportcallscreated", filter, 
		function (res) {
			if(!res.success){
				alert(res.message);
				return;
			}
            dcr.GChart3(res.data);
            pullRequestComplete(dcr.PullRequest);
		}, 
		function () {}
	)

    ajaxPost("/dashboard/top5callreport", filter, 
        function (res) {
            if(!res.success){
                swal("",res.message,"error");
                return;   
            }
            dcr.GChart8(res.data);
            // setTimeout(function() {
            //     dg.chartTop5(res.data, "crchart8", res.data.globalaverage, res.data.regionalaverage)
            // }, 300);
        }, 
        function () {}
    )
    ajaxPost("/dashboard/discussiontype", filter, 
        function (res) {
            if(!res.success){
                swal("",res.message,"error");
                return;   
            }
            dcr.GChart7(res.data);
            pullRequestComplete(dcr.PullRequest);
            // dcr.generategrid7(res.data);
        }
    )
    ajaxPost("/dashboard/avgclientcallpermonth", filter, 
        function (res) {
            if(!res.success){
                swal("",res.message,"error");
                return;   
            }
            dcr.GChart6(res.data);
            // dcr.generategrid6(res.data);       
        }
    )
	
	var url = "/dashboard/callreportclient";
	ajaxPost(url, filter, 
		function (res) {
			if(!res.success){
				alert(res.message);
				return;
			}
			
            dcr.GChart4Monthly(res.data);
			// dcr.generategrid4(dcr.GChart4());
            pullRequestComplete(dcr.PullRequest);
		}, 
		function () {}
	)

    // var url = "/dashboard/callreportclient";
	// if(dcr.clientbyregionview() == "3month")
    var url = "/dashboard/callreportclient3month"
	ajaxPost(url, filter, 
		function (res) {
			if(!res.success){
				alert(res.message);
				return;
			}
            if(res.data.categories != undefined){
                var newCat = [];
                res.data.categories.forEach(function(cc){
                    cc.reverse();
                    if(cc.length == 1)
                        cc = cc[0]
                    if(cc.length == 2)
                        cc = cc[0] + " - " + cc[1]
                    if(cc.length == 3)
                        cc = cc[0] + " - " + cc[2]
                    newCat.push(cc);
                })
                
                res.data.categories = newCat;
                res.data.categories.reverse();
                
                res.data.series.forEach(function(cc){
                    cc.Data.reverse();
                })
            }
			
            dcr.GChart43Month(res.data);
            pullRequestComplete(dcr.PullRequest);
		}, 
		function () {}
	)
	
	url = "/dashboard/chart6";
	// if(dcr.clientbyregionview() == "3month")
	// 	url = "/dashboard/chart63month"
	ajaxPost(url, filter, 
		function (res) {
			if(!res.success){
				alert(res.message);
				return;
			}
			
            dcr.GChart5Monthly(res.data);
            pullRequestComplete(dcr.PullRequest);
		}, 
		function () {}
	)

    // url = "/dashboard/chart6";
	// if(dcr.clientbyregionview() == "3month")
    url = "/dashboard/chart63month"
	ajaxPost(url, filter, 
		function (res) {
			if(!res.success){
				alert(res.message);
				return;
			}
            if(res.data.categories != undefined){
                var newCat = [];
                res.data.categories.forEach(function(cc){
                    cc.reverse();
                    if(cc.length == 1)
                        cc = cc[0]
                    if(cc.length == 2)
                        cc = cc[0] + " - " + cc[1]
                    if(cc.length == 3)
                        cc = cc[0] + " - " + cc[2]
                    newCat.push(cc);
                })
                
                res.data.categories = newCat;
                res.data.categories.reverse();
                
                res.data.series.forEach(function(cc){
                    cc.Data.reverse();
                })
            }
			
            dcr.GChart53Month(res.data);
            pullRequestComplete(dcr.PullRequest);
		}, 
		function () {}
	)

    var url = "/dashboard/creatorlist";
    ajaxPost(url, filter, 
        function (res) {
            if(!res.success){
                alert(res.message);
                return;
            }
            
            dcr.GTable(res.data);
            pullRequestComplete(dcr.PullRequest);
        }, 
        function () {}
    )
}

dcr.generategrid1 = function(data){
	var maxCol = 0;
	var maxAvg = 0;
	data.Series.forEach(function(e){
		e.data = e.Data;
		e.name = e.Name;
		e.type = e.Type;
		e.axis = e.Axis;
        if(e.type != "line")
		    e.labels = {visible: false}
		e.Data.forEach(function(v){
			if(e.Axis == "col"){
				if(v > maxCol)
					maxCol = v
			}else{
				if(v > maxAvg){
					maxAvg = v 
				}
			}
			
		});
		
	});
    $("#crchart1").kendoChart({
        chartArea: {
            background: "transparent",
            height: 200
        },
        legend: {
            position: "bottom",
            visible:true,
            labels:{
                font:chartFont
            }
        },
        seriesColors:chartColors,
        seriesDefaults:{
            stack: true,
            labels: {
                visible: chartLabelDisplay,
                // visible: false,
                font:chartFont,
                color:chartLabelColor,
                background:"transparent",
                template:"#:kendo.toString(value,'N0')#",
                padding:0,
                margin:0,
            },
            overlay: {
              gradient: "none"
            },
        },
        series: data.Series,
        categoryAxis: {
            categories: data.Categories,
			labels:{
                font:chartFont,
                rotation: {
                    angle: 45,
                    align: "center"
                },
            },
            majorGridLines:{
                visible:false,
            },
            axisCrossingValues: [0, 12]
        },
		valueAxis: [
				{
                    name: "col",
					// max: Math.round(maxCol * 1.1),
                    min: 0,
                    labels:{
                        font:chartFont,
                        template:"#:kendo.toString(value,'N0')#"
                    },
                    majorGridLines: {
                        visible: true
                    },
                    line:{
                        visible:false
                    }
                },
				{
					visible: true,
					name: "avg",
					labels:{
	                    font:chartFont,
	                    template:"#:kendo.toString(value,'N0')#"
	                },
                    majorGridLines: {
                        visible: true
                    },
                    line:{
                        visible:false
                    }
                }
		],
        tooltip: {
            visible: true,
            template: "#= series.name #: #= kendo.toString(value,'N0') #",
            font:chartFont,
        }
    });
};

dcr.generategrid2 = function(data){
	data.series.forEach(function(ee){
		ee.data = ee.Data;
		ee.name = ee.Name;
	})
    $("#crchart2").kendoChart({
        chartArea: {
            background: "transparent",
            height: 200
        },
        legend: {
            position: "bottom",
            visible:true,
            labels:{
                font:chartFont
            }
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            labels:{
                visible: chartLabelDisplay,
                font:chartFont,
                color:chartLabelColor,
                background:"transparent",
                template:"#:kendo.toString(value,'N0')#",
                padding:0,
                margin:0,
            }
        },
        seriesColors:chartColors,
        series: data.series,
        valueAxis: {
            line: {
                visible: false
            },
            labels:{
                font:chartFont,
                template:"#:kendo.toString(value,'N0')#"
            },
            majorGridLines: {
                visible: true
            },
        },
        categoryAxis: {
            categories: data.categories,
            majorGridLines: {
                visible: false
            },
            labels:{
                font:chartFont,
            },
        },
        tooltip: {
            visible: true,
            template: "#= series.name #: #= value #",
            font:chartFont,
        }
    });
}

dcr.generategrid3 = function(data){
	data.series.forEach(function(ee, idx){
		ee.data = ee.Data;
		ee.name = ee.Name;
        if(idx+1 == data.series.length){
            ee.labels = {
                template: "#= stackValue #",
                visible: chartLabelDisplay
            }
        }
	})
    $("#crchart3").kendoChart({
        chartArea: {
            background: "transparent",
            height: 200
        },
        legend: {
            visible: true,
            position:"bottom",
            labels:{
                font:chartFont
            }
        },
        seriesDefaults: {
            type: "column",
            stack: true,
            overlay: {
              gradient: "none"
            },
            labels:{
                //position:"top",
                //visible: chartLabelDisplay,
                font:chartFont,
                color:chartLabelColor,
                background:"transparent",
                template:"#:kendo.toString(value,'N0')#",
                padding:0,
                margin:0,
            }
        },
        seriesColors:chartColors,
        series: data.series,
        valueAxis: {
            line: {
                visible: false
            },
            majorGridLines: {
                visible: true
            },
            labels: {
                font:chartFont,
                template:"#:kendo.toString(value,'N0')#"
            }
        },
        categoryAxis: {
			categories: data.categories,
            majorGridLines: {
                visible: false
            },
            labels: {
                font:chartFont,
                rotation: {
                    angle: 45,
                    align: "center"
                },
            }
        },
        tooltip: {
            font:chartFont,
            visible: true,
            template: "#= series.name #: #= value #"
        }
    });
};

dcr.generategrid4 = function(data){
	var series = [];
	data.series.forEach(function(x){
		x["name"] = x.Name
		x["field"] = x.Field
		x["data"] = x.Data
		if(x.Name.indexOf("percentage") < 0){
			series.push({field: x.field,name:x.Name})
		}
	});
	//if(dcr.clientbyregionview() == "monthly"){
    series.push({field: "bcaPercentage",
            name:"(% of Total Top/Next100/New90 Clients, Excluding SCF Clients)",
                visual: function (e) {
                return "";
            },
            labels:{
                position:"insideBase",
                template:"#:replaceString(kendo.toString(dataItem.bcaPercentage,'P0'))#"
            },
            tooltip: {
                visible: false,
            },
            color:"transparent"
        })
	//}
	
    var arrtotal = [];
    var arr = data.series[0].data;
    for(var i in arr){
        var v = arr[i]+data.series[1].data[i];
        arrtotal.push(v<50?50:v);
    }
    var totalseries = {
        name:"total",
		field:"total",
        data:arrtotal
    }
    var sources = [];
    for(var i in data.categories){
        var d = {
            period:data.categories[i]
        }
        for(var s in data.series){
            d[data.series[s].field] = data.series[s].data[i];    
        }
        var total = 0.1*d[data.series[data.series.length - 1].field];
		//if(dcr.clientbyregionview() == "monthly")
        	d["bcaPercentage"] = d["percentageofBCAGroup"];
		
        sources.push(d);
    }
	
	$("#crchart4").html("");
    $("#crchart4").kendoChart({
		dataSource: {
            data: sources
        },
        title: {
            visible:false,
        },
        chartArea:{
            height:200
        },
        legend: {
            visible: true,
            position:"bottom",
            labels:{
                font:chartFont
            }
        },
        seriesDefaults: {
            type: "column",
            stack:true,
            labels:{
                visible: chartLabelDisplay,
                font:chartFont,
                position:"center",
                color:chartLabelColor,
                background:"transparent",
                template:"#:numbformat(value)#",
                padding:0,
                margin:0,
            },
            overlay: {
              gradient: "none"
            },
        },
        series: series,
        valueAxis: {
            majorGridLines: {
                visible: true
            },
            line:{
                visible:false
            },
            labels:{
                font:chartFont,
                template:"#:value<=1000?kendo.toString(value,'N0'):kendo.toString(value/1000,'N0')+'k'#"
            },
            visible: true,
        },
        categoryAxis: {
            field: "period",
            majorGridLines: {
                visible: false
            },
            labels:{
                font:chartFont,
                rotation: {
                    angle: 45,
                    align: "center"
                },
            },
        },
        tooltip: {
            visible: true,
            font:chartFont,
            template: "#= series.name #: #= kendo.toString(value, 'N0') #"
        },
        seriesColors:chartColors
    });
};

dcr.generategrid5 = function(data){
    var series = [];
	data.series.forEach(function(x){
		x["name"] = x.Name
		x["field"] = x.Field
		x["data"] = x.Data
		if(x.Name.indexOf("Average") < 0 && x.Name != "Not Call"){
			series.push({field: x.Field,name:x.Name, stack: "Call"})
		}else if(x.Name.indexOf("Average") < 0 && x.Name == "Not Call"){
            series.push({field: x.Field,name:x.Name, stack: "NotCall"})
        }
	});

	//if(dcr.clientbyregionview() == "monthly"){
    series.push({field: "totaldisplay",
        visual: function (e) {
            return "";
        },
        labels:{
            position:"insideBase",
            template:"#:replaceString(kendo.toString(dataItem.totaldisplay,'P0'))#"
        },
        tooltip: {
            visible: false,
        },
        color:"transparent",
        stack: "Call"
    })
	//}

    series.push({field: "totaldisplaynotcall",
            name:"(% of Total RMs)",
                visual: function (e) {
                return "";
            },
            labels:{
                position:"insideBase",
                template:"#:replaceString(kendo.toString(dataItem.totaldisplaynotcall,'P0'))#"
            },
            tooltip: {
                visible: false,
            },
            color:"transparent",
            stack: "NotCall"
        })
	
    var arrtotal = [];
    var arr = data.series[0].data;
    for(var i in arr){
        var v = arr[i]+data.series[1].data[i];
        arrtotal.push(v<50?50:v);
    }
    var totalseries = {
        name:"total",
		field:"total",
        data:arrtotal
    }
    var sources = [];
    for(var i in data.categories){
        var d = {
            period:data.categories[i]
        }
        for(var s in data.series){
            d[data.series[s].Field] = data.series[s].data[i];    
        }
        var total = 0.1*d[data.series[data.series.length - 1].Name];
		//if(dcr.clientbyregionview() == "monthly")
        d["totaldisplay"] = d["Average"];
        d["totaldisplaynotcall"] = d["AverageNotCall"];
        sources.push(d);
    }
    $("#crchart5").kendoChart({
        dataSource: {
            data: sources
        },
        title: {
            visible:false,
        },
        chartArea:{
            height:200
        },
        legend: {
            visible: true,
            position:"bottom",
            labels:{
                font:chartFont
            }
        },
        seriesDefaults: {
            type: "column",
            // stack: true,
            labels:{
                visible: chartLabelDisplay,
                font:chartFont,
                position:"center",
                color:chartLabelColor,
                background:"transparent",
                template:"#:numbformat(value)#",
                padding:0,
                margin:0,
            },
            overlay: {
              gradient: "none"
            },
        },
        series: series,
        valueAxis: {
            majorGridLines: {
                visible: true
            },
            line:{
                visible:false
            },
            labels:{
                font:chartFont,
                template:"#:value<=1000?kendo.toString(value,'N0'):kendo.toString(value/1000,'N0')+'k'#"
            },
            visible: true,
        },
        categoryAxis: {
            field: "period",
            majorGridLines: {
                visible: false
            },
            labels:{
                font:chartFont,
                rotation: {
                    angle: 45,
                    align: "center"
                },
            },
        },
        tooltip: {
            visible: true,
            font:chartFont,
            template: "#= series.name #: #= kendo.toString(value, 'N0') #"
        },
        seriesColors:chartColors,
        seriesClick: function(e) {
            if(e.series.name == "Not Call"){
                var param = filter;
                param.Date = e.category;
                if (dcr.clientbyregionview()=='3month'){
                    param.Type = "3month";
                }else{
                    param.Type = "month";
                }
                ajaxPost("/dashboard/getdetailnotcall", param, function (res) {
                    if(!res.success){
                        swal("",res.message,"error");
                        return;   
                    }

                    var data = [];
                    if(param.Type == "3month") {
                        res.data.forEach(function(d){
                            data.push(d);
                        });
                    }else{
                        data = res.data;
                    }

                    $($("#modalNotCall").find("h4")).html("RM With No Calls in "+e.category);
                    $("#modalNotCall").modal("show");

                    $("#gridNotCall").html("");
                    $("#gridNotCall").kendoGrid({
                        dataSource: {
                            data: data,
                            pageSize: 10
                        },
                        sortable: true,
                        scrollable: true,
                        pageable: {
                            pageSizes: true,
                            buttonCount: 5
                        },
                        columns: [{
                            field: "RM_ID",
                            title: "RM ID"
                        }, {
                            field: "RM_Name",
                            title: "RM Name"
                        }, {
                            field: "RM_Location",
                            title: "RM Location"
                        }, {
                            field: "RM_Major_Region",
                            title: "Region"
                        }, {
                            field: "RM_Segment",
                            title: "RM Segment"
                        }, {
                            field: "RM_Category",
                            title: "RM Category"
                        }, {
                            field: "Line_Manager",
                            title: "LM Manager"
                        }, {
                            field: "LM_ID",
                            title: "LM ID"
                        }]
                    });
                });
            }
        },
    });
}

dcr.generategrid6 = function(data){
    $("#crchart6").kendoChart({
        chartArea: {
            background: "transparent",
            height: 200
        },
        legend: {
            position: "bottom",
            visible:true,
            labels:{
                font:chartFont
            }
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            labels:{
                visible: chartLabelDisplay,
                font:chartFont,
                color:chartLabelColor,
                background:"transparent",
                template: function(e){
                    var country = Enumerable.From(data.bca).Where("$.country == '" + e.category + "'").Sum("$.count");
                    var region = Enumerable.From(data.bca).Where("$.region == '" + e.category + "'").Sum("$.count");
                    var global = Enumerable.From(data.bca).Sum("$.count")

                    var rmL = (country == 0 ? region : country);
                    if(e.category == "GLOBAL"){
                        rmL = global;
                    }
                    var pct = toolkit.safeDivide(e.value, rmL)
                    return kendo.toString(e.value,'N0') + " (" + Math.round(pct*100, 0) + "%)" ;
                },
                padding:5,
                margin:0,
            }
        },
        seriesColors:chartColors,
        series: data.series,
        valueAxis: {
            line: {
                visible: false
            },
            labels:{
                font:chartFont,
                template:"#:kendo.toString(value,'N0')#"
            },
            majorGridLines: {
                visible: true
            },
        },
        categoryAxis: {
            categories: data.categories,
            majorGridLines: {
                visible: false
            },
            labels:{
                font:chartFont,
            },
        },
        tooltip: {
            visible: true,
            template: "#= category #: #= value #",
            font:chartFont,
        }
    });
}

dcr.generategrid7 = function(data){
    $("#crchart7").html("");
    var chart = venn.VennDiagram()
        chart.wrap(false) 
        .width($("#crchart7").width())
        .height(195);

    var div = d3.select("#crchart7").datum(data.sets).call(chart);

    var tooltip = d3.select("body").append("div")
        .attr("class", "venntooltip");

    div.selectAll("path")
        .style("stroke-opacity", 0)
        .style("stroke", "#fff")
        .style("stroke-width", 1)

    div.selectAll("g")
        .on("mouseover", function(d, i) {
            venn.sortAreas(div, d);

            tooltip.transition().duration(400).style("opacity", .9);

            tooltip.text(d.value.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));

            var selection = d3.select(this).transition("tooltip").duration(400);
            selection.select("path")
                .style("fill-opacity", d.sets.length == 1 ? .4 : .1)
                .style("stroke-opacity", 1);
        })

        .on("mousemove", function() {
            tooltip.style("left", (d3.event.pageX) + "px")
                   .style("top", (d3.event.pageY - 28) + "px");
        })

        .on("mouseout", function(d, i) {
            tooltip.transition().duration(400).style("opacity", 0);
            var selection = d3.select(this).transition("tooltip").duration(400);
            selection.select("path")
                .style("fill-opacity", d.sets.length == 1 ? .6 : .0)
                .style("stroke-opacity", 0);
        });

    function annotateSizes() {
        var txt = d3.select(this).select("text").text();
        if(txt != ""){
            d3.select(this).select("text")
                .append("tspan")
                .text(function(d) { return d.value.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,") })
                .attr("x", function() { return d3.select(this.parentNode).attr("x"); })
                .attr("dy", "1.5em")
                .style("color", "black")
                .style("font-size", "9"); 
        }else{
            d3.select(this).select("text")
                .append("tspan")
                .text(function(d) { return d.value.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,") })
                .attr("x", function() { return d3.select(this.parentNode).attr("x"); })
                .style("color", "black")
                .style("font-size", "9");
        }
    }     

    function updateVenn(sets) {
        var layout = chart(div),
            textCentres = layout.textCentres;
        div.selectAll("text").style("fill", "");
        div.selectAll("text").style("font-family", "hertifica neuw");
        div.selectAll("text").style("color", "black");
        div.selectAll("text").style("font-size", "11");
        div.selectAll(".venn-circle path").style("fill-opacity", .6);

        div.selectAll("g").transition("venn").on("end", annotateSizes).duration(0);
            
        return layout;
    }

    setTimeout(function() {
        updateVenn(data.sets);
    }, 200);
}

dcr.getPDF = function(title) {
    $("#img-out").html("")
    html2canvas($("#discussion-type"), {
        onrendered: function(canvas) {
            $("#img-out").append(canvas);
            dcr.CreateImgvann(true);

            model.TabMenuDasboard(title);
            var $div = $("<div>", {id: "foo", "class": "a"});
            $bodypage = $("body");
            $ReportHide = $(".app").find("#navbar").find("#mainMenu").css({"display":"none"});
            $ReportHide = $(".app").find("#navbar").find("#menuLogout").css({"display":"none"});
            $ReportHide = $(".app").find("#navbar").find("#mainTitle").css({"display":""});
            $ReportHide = $(".app").find(".btn-filter").css({"display":"none"});

            $ReportHide = $("#MainTab").css({"display":"none"});
            $footerReport = $(".footer").css({"position":"relative"});
            $EditCss = $(".app").find(".box-shadow").css({"box-shadow":"0px 0px 7px #707070;", "border-radius":"3px", "display":"block", "border":"2px solid #b7b7b7"});
            $EditCss = $(".app").find(".fa-search").css({"margin-right":"5px"});
            kendo.drawing.drawDOM($bodypage).then(function(group){
                kendo.drawing.pdf.saveAs(group, title+".pdf");
                $footerReport = $(".footer").css({"position":"fixed"});
                $ReportHide = $(".app").find("#navbar").find("#mainTitle").css({"display":"none"});
                $ReportHide = $(".app").find(".btn-filter").css({"display":""});
                $EditCss = $(".app").find(".box-shadow").css({"box-shadow":"0px 0px 7px #707070;", "border-radius":"3px", "display":"", "border":""});
                $(".app").find(".fa-search").css({"margin-right":"0px"})
                $(".app").find("#navbar").find("#mainMenu").css({"display":""});
                $(".app").find("#navbar").find("#menuLogout").css({"display":""});
                $("#MainTab").css({"display":""});
                dcr.CreateImgvann(false);
            });
            
        },
        width: 420,
        height: 220
    });
}

dcr.generateTable = function(datasource){
    $("#newTable").modal("show");
    setTimeout(function() {
        datasource.column[1].width = 200;
        var modalBody = parseFloat($("#newTable .modal-body").css("width").replace("px", ""))
        var wid = (modalBody - 310) / 3;
        datasource.column.forEach(function(d, i){
            if(i > 3){
                d.width = wid;
            }
        })
        // if(datasource.column.length < 8) {
        //     datasource.column.forEach(function(d, i){
        //         d.locked = false
        //     })
        // }

        $("#gridNewTable").html("");
        $("#gridNewTable").kendoGrid({
            dataSource: {
                data: datasource.data,
                pageSize: 50
            },
            excel: {
                fileName: "Call Report Creator.xlsx",
                allPages: true,
            },
            height: 380,
            sortable: true,
            resizable: true,
            scrollable: true,
            pageable: true,
            columns: datasource.column
        });

        setTimeout(function() {
            $("#gridNewTable").find(".k-grid-content.k-auto-scrollable").css("height", "100%")
        }, 100);
    }, 300);
}

dcr.exportShowCreator = function(){
    var grid = $("#gridNewTable").data("kendoGrid");
    grid.saveAsExcel();
}