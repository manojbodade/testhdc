var LoginUsers = {
    PullRequest:ko.observable(2),
    Processing:ko.observable(false),
    SelectedMajorRegion:ko.observableArray([]),
    PeriodValue:{
        Period:ko.observable(new Date()),
        Users:ko.observable(0),
        ActiveUsers:ko.observable(0),
        ActiveUsage:ko.observable(0),
    },
    YTD:{
        Users:ko.observable(0),
        ActiveUsers:ko.observable(0),
        ActiveUsage:ko.observable(0),
    },
    IsFirstLoad:ko.observable(true),
    DataSourceAll:ko.observableArray([]),
    DataSourceRM:ko.observableArray([]),
    FilterChartUsage:ko.observable("all"),
    Counter: ko.observable(0)
}
LoginUsers.FilterChartUsage.subscribe(function(){
    // LoginUsers.GetData()
    LoginUsers.Render();
})
LoginUsers.InitComplete = function(){
    LoginUsers.Processing(false);
}
LoginUsers.Counter.subscribe(function(val){
    if(val == 0){
        LoginUsers.Render()
        LoginUsers.Processing(false);
    }
})
// LoginUsers.Open = function(){
//     if(!LoginUsers.IsFirstLoad()){
//         LoginUsers.Processing(true);
//         setTimeout(function(){
//             LoginUsers.Processing(false);
//             LoginUsers.Render();
//         }, 500);
//     }
// }

LoginUsers.Render = function(){
    var dataSource = []
    if (LoginUsers.FilterChartUsage() == "all") {
        dataSource = LoginUsers.DataSourceAll()
    }else {
        dataSource = LoginUsers.DataSourceRM()
    }

    // if(LoginUsers.IsFirstLoad()){
    //     LoginUsers.IsFirstLoad(false)
    // }
    var pv = LoginUsers.PeriodValue;
    console.log(dataSource.SalesModuleData)
    // Merge Data
    var userSources = [];
    var SelectedPeriod = Enumerable.From(dataSource.ActiveUserData).GroupBy("$._id.period").OrderBy("$.Key()").ToArray();
    var ActiveUsers = 0;
    var RMUsers = 0;
    var TotalUsers = 0;
    var TotalActiveUsers = 0;
    var RMUsers = 0;

    for(var p in SelectedPeriod){
        var period = SelectedPeriod[p].Key();
        var d = {
            periodstr:period,
            period:new Date(period),
        }
        var SelectedMajorRegion = SelectedPeriod[p].source;
        for(var i in SelectedMajorRegion){
            d["allactiveuser"+SelectedMajorRegion[i]._id.major_region] = SelectedMajorRegion[i].allactiveuser;
            d["activeuser"+SelectedMajorRegion[i]._id.major_region] = SelectedMajorRegion[i].activeuser;
        }
        if(p==(SelectedPeriod.length-1)){
            ActiveUsers = Enumerable.From(SelectedMajorRegion).Sum("$.activeuser");
            TotalActiveUsers = Enumerable.From(SelectedMajorRegion).Sum("$.count");
        }
        userSources.push(d);
    }
    pv.ActiveUsers(ActiveUsers);
    var HeadCountSelectedPeriod = Enumerable.From(dataSource.HeadcountData).GroupBy("$._id.period").OrderBy("$.Key()").ToArray();
    // console.log("dataSource.SalesModuleData")
    // console.log(dataSource.SalesModuleData)
    for(var p in HeadCountSelectedPeriod){
        var period = HeadCountSelectedPeriod[p].Key();
        // console.log(new Date(period))
        // console.log("PERRRRRR")
        // dataSource.SalesModuleData.forEach(function(vv){
        //     console.log(new Date(vv._id))
        // })
        // console.log("+++++++++++++++++++++++++++++")
        var existingData = Enumerable.From(userSources).Where("$.periodstr == '"+period+"'").FirstOrDefault();
        var isFound = true;
        if(existingData===undefined){
            isFound = false;
            existingData = {
                periodstr:period,
                period:new Date(period),
            }
        }
        var SelectedMajorRegion = HeadCountSelectedPeriod[p].source;
        existingData["headcounttotal"] = Enumerable.From(SelectedMajorRegion).Sum("$.allactiveuser");
        for(var i in SelectedMajorRegion){
            existingData["headcount"+SelectedMajorRegion[i]._id.major_region] = SelectedMajorRegion[i].activeuser;
            // rm users
            var rmuser = Enumerable.From(dataSource.SalesModuleData).FirstOrDefault(undefined, "new Date($._id).toString() == '" + new Date(period).toString()+"'")
            if (rmuser == undefined){
                rmuser = { countMrUser : 0 }
                // console.log("Not Match!! ")
                // console.log(new Date(period))
                // dataSource.SalesModuleData.forEach(function(vv){
                //     console.log(new Date(vv._id))
                // })
            }
            var activeuser = existingData["activeuser"+SelectedMajorRegion[i]._id.major_region];
            var usage = SelectedMajorRegion[i].activeuser == 0 ? 0 : activeuser/rmuser.countMrUser;
            existingData["usage"+SelectedMajorRegion[i]._id.major_region] = usage;

            // all users
            var allactiveuser = existingData["allactiveuser"+SelectedMajorRegion[i]._id.major_region];
            var usage = SelectedMajorRegion[i].allactiveuser == 0 ? 0 : allactiveuser/SelectedMajorRegion[i].allactiveuser;
            existingData["allusage"+SelectedMajorRegion[i]._id.major_region] = usage;

            if(!isFound){
                userSources.push(existingData);
            }
        }

        if(p==(HeadCountSelectedPeriod.length-1)){
            TotalUsers = Enumerable.From(SelectedMajorRegion).Sum("$.count");
            RMUsers = Enumerable.From(SelectedMajorRegion).Sum("$.activeuser");
        }
        userSources.push(d);
    }
    pv.Users(dataSource.HeadcountRM);
    pv.ActiveUsage(pv.Users()==0?0:pv.ActiveUsers()/pv.Users());


    var ytd = LoginUsers.YTD;
    ytd.Users(TotalUsers)
    ytd.ActiveUsers(TotalActiveUsers);
    ytd.ActiveUsage(TotalUsers==0?0:TotalActiveUsers/TotalUsers);

    var MajorRegionList = Enumerable.From(dataSource.ActiveUserData).GroupBy("$._id.major_region").OrderBy("$.Key()").ToArray();

    var ActiveUsersSeries = [];
    var ActiveUsageSeries = [];
    var prefix = "";
    if(LoginUsers.FilterChartUsage()=="all"){
        prefix = "all";
    }
    for(var i in MajorRegionList){

        if(MajorRegionList[i].Key() == "Others"){
            continue;
        }

        //if("activeuser"+MajorRegionList[i].Key())
        ActiveUsersSeries.push({field:prefix+"activeuser"+MajorRegionList[i].Key(),name:MajorRegionList[i].Key(),axis:"users",
            labels:{
                template: "#:replaceString(kendo.toString(dataItem."+prefix+"usage"+MajorRegionList[i].Key()+" * 100,'N0'))#%",
            }
        });
        // ActiveUsersSeries.push({field:"usage"+MajorRegionList[i].Key(),name:MajorRegionList[i].Key(),axis:"usage",type:'line',
        //     labels:{
        //         template: "#:kendo.toString(value, 'P0') #",
        //     }
        // });
    }
    if(filter.MajorRegion() != ""){
        nm = filter.MajorRegion();
        if(filter.Region() != ""){
            nm = filter.Region();
            if(filter.Country() != ""){
                nm = filter.Country();
            }
        }
    };
    if(filter.MajorRegion() != ""){
        ActiveUsersSeries.forEach(function(xx){
            xx.name = nm;
        });
    }
    // Gen ActiveUsersPR Chart
    $("#ActiveUsersPR").html("");
    $("#ActiveUsersPR").kendoChart({
        // transitions: false,
        dataSource: {
            data: userSources
        },
        title: {
            visible:false,
        },
        chartArea:{
            height:200,
            background:"transparent"
        },
        legend: {
            visible: true,
            position:"bottom",
            labels:{
                font:chartFont
            }
        },
        seriesDefaults: {
            type: "column",
            stack: true,
            overlay: {
              gradient: "none"
            },
            labels:{
                // visible: chartLabelDisplay,
                visible: false,
                font:chartFont,
                color:chartLabelColor,
                background:"transparent",
                template: "#:kendo.toString(value, 'N0') #",
                padding:0,
                margin:0,
            }
        },
        series: ActiveUsersSeries,
        valueAxis:[
            {
                name:"users",
                majorGridLines: {
                    visible: true
                },
                line:{
                    visible:false
                },
                labels:{
                    font:chartFont,
                    template:"#:kendo.toString(value,'N0')#"
                },
                visible: true
            },
            {
                name:"usage",
                majorGridLines: {
                    visible: true
                },
                line:{
                    visible:false
                },
                labels:{
                    font:chartFont,
                    template:"#:replaceString(kendo.toString(value,'P0'))#"
                },
                visible: false
            }
        ],
        categoryAxis: {
            field: "period",
            majorGridLines: {
                visible: false
            },
            labels:{
                font:chartFont,
                rotation: {
                    angle: 45,
                    align: "center"
                },
            },
            axisCrossingValues: [0, 12]
        },
        tooltip: {
            visible: true,
            font:chartFont,
            template: "#= series.name #: #= series.axis=='usage'? kendo.toString(value, 'P2') : series.name == 'AME' ? kendo.toString(value, 'N0') +'<br/>' + replaceString(kendo.toString(dataItem.allusageAME * 100,'N0')) +'%' : series.name == 'ASA' ? kendo.toString(value, 'N0') +'<br/>' + replaceString(kendo.toString(dataItem.allusageASA * 100,'N0')) +'%' : kendo.toString(value, 'N0') +'<br/>' + replaceString(kendo.toString(dataItem.allusageGCNA * 100,'N0')) +'%' #"
        },
        seriesColors:chartColors,
    });


    var SalesModulesData = dataSource.SalesModuleData;
    // var maxValue = Enumerable.From(SalesModulesData).Max("$.countMrUser");
    // maxValue = 60*Math.ceil(maxValue/50);
    // SalesModulesData.push({
    //     _id:"",
    // })
     var seriesList;
    if(LoginUsers.FilterChartUsage()=="rm"){
        var seriesList = [
            {field:"apclientmap",name:"Account Plan"},
            {field:"callreports",name:"Call Reports"},
            {field:"dealpipeline",name:"Deal Pipeline"},
            {field:"prospects",name:"Prospects"},
            {field:"countMrUser",name:"Total Headcount",color:'#000'},
        ]
    }else{
        var seriesList = [
            {field:"apclientmap",name:"Account Plan"},
            {field:"callreports",name:"Call Reports"},
            {field:"dealpipeline",name:"Deal Pipeline"},
            {field:"prospects",name:"Prospects"},
        ]
    }

    //console.log(seriesList)
    $("#SalesModules").html("");
    $("#SalesModules").kendoChart({
        // transitions: false,
        dataSource: {
            data: SalesModulesData
        },
        title: {
            visible:false,
        },
        chartArea:{
            height:200
        },
        legend: {
            visible: true,
            position:"bottom",
            labels:{
                font:chartFont
            }
        },
        seriesDefaults: {
            type: "line",
            labels: {
                visible: false,//chartLabelDisplay,
                font:chartFont,
                color:chartLabelColor,
                background:"transparent",
                template: "#:kendo.toString(value, 'N0') #",
                padding:0,
                margin:0,
            },
            overlay: {
              gradient: "none"
            },
        },
        series: seriesList,
        valueAxis:{
            // max:maxValue,
            majorGridLines: {
                visible: true
            },
            line:{
                visible:false
            },
            labels:{
                font:chartFont,
                template:"#:kendo.toString(value,'N0')#",

            },
            visible: true
        },
        categoryAxis: {
            field: "_id",
            majorGridLines: {
                visible: false
            },
            labels:{
                font:chartFont,
                template:"#:value!==''?moment(value).format('MMM YY'):''#",
                rotation: {
                    angle: 45,
                    align: "center"
                },
            },

            axisCrossingValues: [0, 10]
        },
        tooltip: {
            visible: true,
            font:chartFont,
            template: "#= series.name #: #= kendo.toString(value, 'N0') #"
        },
        seriesColors:chartColors
    });

    setTimeout(function() {
        var tooltip = $("#SalesModules").data("kendoChart")._tooltip;
        var tooltipOffset = $.proxy(tooltip._offset, tooltip);
        tooltip._offset = function() {
        var offset = tooltipOffset();
        offset.left -= 40;

        return offset;
        }
    }, 200);
}
LoginUsers.Reset =function(){
    resetFilter();
    LoginUsers.GetData();
}
LoginUsers.GetData = function(){
    if(ds.fromAnalytic()){
        resetDate();
        ds.fromAnalytic(false);
    }
    var LoginUser = moment(new Date(model.arrayLastDate().lastUpdateLoginUser)).format("MMM YY");
    model.lastDateData(LoginUser);
    LoginUsers.Processing(true);
    var parm = ko.mapping.toJS(filter);
    parm.AllorRM = "all";//LoginUsers.FilterChartUsage()
    LoginUsers.Counter(2)
    ajaxPost("/dashboard/getdataloginusers",parm,function(res){
        if(res.IsError){
            swal("","Invalid password!","error");
            LoginUsers.Processing(false);
            return false;
        }
        LoginUsers.DataSourceAll(res.Data);
        // LoginUsers.Render(res.Data);
        LoginUsers.Counter(LoginUsers.Counter()-1)
    });

    parm.AllorRM = "rm";
    ajaxPost("/dashboard/getdataloginusers",parm,function(res){
        if(res.IsError){
            swal("","Invalid password!","error");
            LoginUsers.Processing(false);
            return false;
        }
        LoginUsers.DataSourceRM(res.Data);
        // LoginUsers.Render(res.Data);
        LoginUsers.Counter(LoginUsers.Counter()-1)
    });

    ajaxPost("/dashboard/loginuserpermodule", parm,function(res){
        var indexLine = res.data.indexDivider;

        var indexCategoryAP = res.data.APClientMap.categories[indexLine];
        var indexCategoryCall = res.data.CallReports.categories[indexLine];
        var indexCategoryDeal = res.data.DealPipeline.categories[indexLine];
        var indexCategoryPros = res.data.Prospects.categories[indexLine];
        LoginUsers.BarChartLoginUser("chart1", res.data.APClientMap, indexCategoryAP, res.data.RMList);
        LoginUsers.BarChartLoginUser("chart2", res.data.CallReports, indexCategoryCall, res.data.RMList);
        LoginUsers.BarChartLoginUser("chart3", res.data.DealPipeline, indexCategoryDeal, res.data.RMList);
        LoginUsers.BarChartLoginUser("chart4", res.data.Prospects, indexCategoryPros, res.data.RMList);

    });
}

LoginUsers.BarChartLoginUser = function(tagetChart, data, index, rmList){
    var max = 0;
    var g = data.series[0].data == undefined ? [0] : data.series[0].data;
    var _m = Enumerable.From(g).Max();
    max = _m * 1.5;

    $("#"+tagetChart).kendoChart({
        chartArea: {
            background: "transparent",
            width: 300,
            height: filter.MajorRegion() == "ASA"? 310 : 200
        },
        legend: {
            position: "bottom",
            visible:false,
            labels:{
                font:chartFont
            }
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            labels:{
                visible: chartLabelDisplay,
                font:chartFont,
                color:chartLabelColor,
                background:"transparent",
                template: function(e){
                    var country = Enumerable.From(rmList).Where("$.country == '" + e.category + "'").Sum("$.count");
                    var region = Enumerable.From(rmList).Where("$.region == '" + e.category + "'").Sum("$.count");
                    var global = Enumerable.From(rmList).Sum("$.count")

                    var rmL = (country == 0 ? region : country);
                    if(e.category == "GLOBAL"){
                        rmL = global;
                    }
                    var pct = toolkit.safeDivide(e.value, rmL)
                    return kendo.toString(e.value,'N0') + " (" + Math.round(pct*100, 0) + "%)" ;
                },//"#:kendo.toString(value,'N0')#",
                padding:5,
                margin:0,
            }
        },
        seriesColors:chartColors,
        series: data.series, //[{ name: "Total Visits",data: [307, 104, 134, 69, 20, 13, 63, 32, 23]}],
        valueAxis: {
            max: max,
            name: "valueAxis",
            line: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels: {
                font:chartFont,
            }
        },
        categoryAxis: {
            name: "categoryAxis",
            categories: data.categories,//["Global", "GCNA", "ASA", "AME", "UAE", "Singapore", "India", "Hongkong", "china"],
            majorGridLines: {
                visible: false
            },
            labels:{
                font:chartFont,
            },
        },
        tooltip: {
            visible: true,
            font:chartFont,
            template: function(e){
                return e.category + " : " + e.value
            }
        },
        render: function(e) {
                var valueAxis = e.sender.getAxis("categoryAxis");
                var categoryAxis = e.sender.getAxis("valueAxis");

                var valueSlot = valueAxis.slot(index);
                var lastCategoryIndex = Math.max(1, categoryAxis.range().max);
                var minCategorySlot = categoryAxis.slot(0);
                var maxCategorySlot = categoryAxis.slot(lastCategoryIndex);

                // Render a line element
                var line = new kendo.drawing.Path({
                    stroke: {
                        color: "#6ba8d0",
                        width: 3
                    }
                });

                line.moveTo(valueSlot.origin).lineTo([maxCategorySlot.origin.x, valueSlot.origin.y]);
                var group = new kendo.drawing.Group();
                group.append(line);
                  // Draw on chart surface
                e.sender.surface.draw(group);
        }
    });
}
LoginUsers.Init = function(){
    setTimeout(function(){
        LoginUsers.GetData();
    }, 2000);
    // LoginUsers.PullRequest(1);
    // LoginUsers.Processing(true);
    // ajaxPost("/mastercountry/getdata",{},function(res){
    //     LoginUsers.Filter.CountryList(res.Data);
    //     pullRequestComplete(LoginUsers.PullRequest,LoginUsers.InitComplete());
    // })
}