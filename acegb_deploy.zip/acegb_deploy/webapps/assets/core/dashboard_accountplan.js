var AccountPlan = {
    PullRequest:ko.observable(2),
    Processing:ko.observable(false),
    SelectedMajorRegion:ko.observableArray([]),
    PeriodValue:{
        Period:ko.observable(new Date()),
        Approved:ko.observable(0),
        Initiated:ko.observable(0),
        MoM:ko.observable(0),
    },
    YTD:{
        Approved:ko.observable(0),
        BCAGroups:ko.observable(0),
        Completed:ko.observable(0),
    },
    IsFirstLoad:ko.observable(true),
    DataSource:ko.observable()
}
AccountPlan.Table = {
    Header : ko.observableArray([]),
    Body : ko.observableArray([])
}
AccountPlan.InitComplete = function(){
    AccountPlan.Processing(false);
}
AccountPlan.Open = function(){
    if(!AccountPlan.IsFirstLoad()){
        AccountPlan.Processing(true);
        setTimeout(function(){
            AccountPlan.Processing(false);
            AccountPlan.Render(AccountPlan.DataSource());
        }, 500);
    }
}
AccountPlan.Render = function(dataSource){
    var periodStart = filter.Start();
    if(AccountPlan.IsFirstLoad()){
        AccountPlan.IsFirstLoad(false)
    }
    var monthlySource = dataSource.MonthlyData;
    // Render Snapshoot Box
    var pv = AccountPlan.PeriodValue;
    pv.Period(filter.Finish());
    var selectedPeriod = parseInt(kendo.toString(pv.Period(),"yyyyMM"));
    var d = Enumerable.From(dataSource.MonthlyData).Where("$._id == "+selectedPeriod).FirstOrDefault();
    if(d !== undefined){
        pv.Approved(d.approved);
        pv.Initiated(d.initiated);
    }else{
        pv.Approved(0);
        pv.Initiated(0);
    }
    if(dataSource.PrevMonth.length > 0 ){
        var p = dataSource.PrevMonth[0];
        var MoM = p.approved == 0 ? 0 : (d.approved-p.approved)/p.approved;
        pv.MoM(MoM);
    }else{
        pv.MoM(0);
    }
    var approvedytd = 0;
    for(var i in monthlySource){
        var my = monthlySource[i]._id.toString();
        monthlySource[i].perioddate = new Date(moment(my.substr(0,4)+"-"+my.substr(4,2)));
        monthlySource[i].period = moment(my.substr(0,4)+"-"+my.substr(4,2)).format("MMM")
        if(monthlySource[i].period=="Jan"){
            approvedytd = 0;
        }
        approvedytd += monthlySource[i].approved;
        monthlySource[i].total =  approvedytd+monthlySource[i].initiated;
        var total = 0.1*monthlySource[i].total;
        monthlySource[i].totaldisplay =   total < 50 ? 50 : total;
        monthlySource[i].approvedytd =  approvedytd;
    }

    var y = AccountPlan.YTD;
    y.Approved(0);
    // if(dataSource.BCAData.length>0){
    //     y.BCAGroups(dataSource.BCAData[0].count);
    // }else{
    //     y.BCAGroups(dataSource.BCAData.length);
    // }
    y.BCAGroups(dataSource.BCAData[0] == undefined ? 0 : dataSource.BCAData[0].totalbca);
    if(monthlySource.length>0){
        y.Approved(monthlySource[monthlySource.length-1].approvedytd);
    }
    var Completed = y.BCAGroups()==0?0:y.Approved()/y.BCAGroups();
    y.Completed(Completed);
    // Render Account Plan Status
    $("#AccountPlanStatus").html("");
    $("#AccountPlanStatus").kendoChart({
        dataSource: {
            data: Enumerable.From(monthlySource).Where(function(x){return x.perioddate >= periodStart}).ToArray()
        },
        title: {
            visible:false,
        },
        chartArea:{
            height:250
        },
        legend: {
            visible: true,
            position:"bottom",
            labels:{
                font:chartFont
            }
        },
        seriesDefaults: {
            type: "column",
            stack:true,
            labels:{
                visible: chartLabelDisplay,
                font:chartFont,
                position:"center",
                color:chartLabelColor,
                background:"transparent",
                template:"#:numbformat(value)#",
                padding:0,
                margin:0,
            },
            overlay: {
              gradient: "none"
            },
        },
        series: [
            {field: "approvedytd",name:"Approved", labels: {visible: false}},
            {field: "initiated",name:"Initiated", labels: {visible: false}},
            {field: "totaldisplay",
            name:"",
                visual: function (e) {
                return "";
            },
            labels:{
                visible: chartLabelDisplay,
                position:"insideBase",
                template:"#:kendo.toString(dataItem.total,'N0')#"
            },
            tooltip: {
                visible: false,
            },
            color:"transparent"
        },
        ],
        valueAxis: {
            majorGridLines: {
                visible: true
            },
            line:{
                visible:false
            },
            labels:{
                font:chartFont,
                template:"#:kendo.toString(value,'N0')#"
            },
            visible: true,
        },
        categoryAxis: {
            field: "period",
            majorGridLines: {
                visible: false
            },
            labels:{
                font:chartFont,
                rotation: {
                    angle: 45,
                    align: "center"
                },
            },
        },
        tooltip: {
            visible: true,
            font:chartFont,
            template: "#= series.name #: #= kendo.toString(value, 'N0') #"
        },
        seriesColors:chartColors
    });

    // Render Major Region Chart
    var arr = Enumerable.From(dataSource.MajorRegionData).Where("$._id.majorregion != ''").GroupBy("$._id.majorregion").ToArray();
    var SelectedMajorRegion = Enumerable.From(dataSource.MajorRegionData).GroupBy("$._id.majorregion").Select("$.Key()").ToArray();
    AccountPlan.SelectedMajorRegion(arr);
    for(var i in arr){
        var Key = arr[i].Key();
        var obj = $("#ChartMajorRegion"+i);
        var source = arr[i].source;


        var approvedytd = 0;
        for(var i in source){
            var my = source[i]._id.monthyear.toString();
            source[i].period = moment(my.substr(0,4)+"-"+my.substr(4,2)).format("MMM")
            if(source[i].period=="Jan"){
                approvedytd = 0;
            }
            approvedytd += source[i].approved;
			//console.log(source[i].approved)
            source[i].total =  approvedytd+source[i].initiated;
            var total = 0.1*source[i].total;
            source[i].totaldisplay =   total < 50 ? 50 : total;
            source[i].approvedytd =  approvedytd;
        }
        obj.html("");
        obj.kendoChart({
            chartArea:{
                height:200
            },
            dataSource: {
                data: source
            },
            title: {
                visible:false,
            },
            legend: {
                visible: true,
                position:"bottom",
                labels:{
                    font:chartFont
                }
            },
            seriesDefaults: {
                type: "column",
                stack:true,
                labels: {
                    position:"center",
                    visible: chartLabelDisplay,
                    font:chartFont,
                    color:chartLabelColor,
                    background:"transparent",
                    template:"#:numbformat(value)#",
                    padding:0,
                    margin:0,
                },
                overlay: {
                  gradient: "none"
                },
            },
            series: [
                {field: "approvedytd",name:"Approved", labels: {visible: false}},
                {field: "initiated",name:"Initiated", labels: {visible: false}},
                {field: "totaldisplay",
                    name:"",
                        visual: function (e) {
                        return "";
                    },
                    labels:{
                        visible: chartLabelDisplay,
                        position:"insideBase",
                        template:"#:kendo.toString(dataItem.total,'N0')#"
                    },
                    tooltip: {
                        visible: false,
                    },
                    color:"transparent"
                }
            ],
            valueAxis: {
                majorGridLines: {
                    visible: true
                },
                line:{
                    visible:false
                },
                labels:{
                    font:chartFont,
                    template:"#:kendo.toString(value,'N0')#"
                },
                visible: true
            },
            categoryAxis: {
                field: "period",
                majorGridLines: {
                    visible: false
                },
                labels:{
                    font:chartFont,
                    rotation: {
                        angle: 45,
                        align: "center"
                    },
                },
            },
            tooltip: {
                visible: true,
                font:chartFont,
                template: "#= series.name #: #= kendo.toString(value, 'N0') #"
            },
            seriesColors:chartColors
        })
    }

}
AccountPlan.Reset =function(){
    resetFilter();
    AccountPlan.GetData();
}
AccountPlan.GetData = function(){
    filter.Start(new Date(2016, 12, 1))
    filter.Finish(new Date(2017, 11, 1))
    if(ds.fromAnalytic()){
        resetDate();
        ds.fromAnalytic(false);
    }
    var AcountPlan = moment(new Date(model.arrayLastDate().lastUpdateAcountPlan)).format("MMM YY");
    model.lastDateData(AcountPlan);

    AccountPlan.Processing(true);
    var parm = ko.mapping.toJS(filter);
    // parm.Start = new Date(parm.Start.getFullYear(),0,1);
    // parm.StartStr = kendo.toString(parm.Start,'yyyy-MM-dd');
    ajaxPost("/dashboard/getdataaccountplan",parm,function(res){
        if(res.IsError){
            swal("",res.Message,"error");
            AccountPlan.Processing(false);
            return false;
        }
        AccountPlan.DataSource(res.Data);
        AccountPlan.Render(res.Data);
        AccountPlan.Processing(false);
    });

    ajaxPost("/dashboard/accountplanapproved",parm,function(res){
        if(res.IsError){
            swal("",res.Message,"error");
            AccountPlan.Processing(false);
            return false;
        }
        var data = res.Data;
        res.Data.Header.forEach(function(e) {
            if(e.Type == "BCAGroup"){
                // e.Title = e.Title + "*"
                e.Title = "Top/Next100/New90 Group*"
            }else if(e.Type == "BCAGroupNoAP"){
                e.Title = "Top/Next100/New90 With No AP"
            }
        })

        var tb = AccountPlan.Table;
        tb.Header([]);
        tb.Body([]);
        tb.Header(res.Data.Header)
        var majorRegion = ["AME", "ASA", "GCNA"];//"CB",
        var listCountry = ["HONG KONG", "INDIA", "UNITED ARAB EMIRATES", "SINGAPORE", "CHINA"];
        if(filter.MajorRegion() == "AME")
			listCountry = ["UNITED ARAB EMIRATES", "NIGERIA", "KENYA", "PAKISTAN", "UGANDA", "GHANA"]
		else if(filter.MajorRegion() == "ASA")
			listCountry = ["INDIA", "SINGAPORE", "MALAYSIA", "BANGLADESH", "INDONESIA"]
		else if(filter.MajorRegion() == "GCNA")
			listCountry = ["HONG KONG", "KOREA, REPUBLIC OF", "CHINA", "TAIWAN"]


        var pushData = [];
        tb.Header().forEach(function(yy){
            if(yy.Type == "region"){
                pushData.push("GB");
            }
            if(yy.Type == "TotalApproved"){
                var sm = Enumerable.From(data.MonthlyApproved).Where("$._id.monthYear.toString().substring(0,4) == " + filter.FinishStr().substring(0,4)).Select("$.approved").Sum()
                pushData.push(sm.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
            }
            if(yy.Type == "ApproveMonthly"){
                var sm = Enumerable.From(data.MonthlyApproved).Where("$._id.monthYear == " + yy.DateMonth).Select("$.approved").Sum()
                pushData.push(sm.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
            }
            if(yy.Type == "InitiatedFinish"){
                var sm = Enumerable.From(data.MonthlyApproved).Where("$._id.monthYear == " + yy.DateMonth).Select("$.initiated").Sum()
                pushData.push(sm.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
            }
            if(yy.Type == "BCAGroup"){
                var sm = Enumerable.From(data.bcaMajorRegion).Select("$.totalbca").Sum()
                pushData.push(sm.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
            }
            if(yy.Type == "BCAGroupNoAP"){
                var bcaTot = Enumerable.From(data.bcaMajorRegion).Select("$.totalbca").Sum()
                var app = Enumerable.From(data.MonthlyApproved).Where("$._id.monthYear.toString().substring(0,4) == " + filter.FinishStr().substring(0,4)).Select("$.approved").Sum()
                var tot = (bcaTot - app) < 0 ? 0 : (bcaTot - app)
                pushData.push(tot.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
            }
            if(yy.Type == "Completed"){
                var bcaTot = Enumerable.From(data.bcaMajorRegion).Select("$.totalbca").Sum()
                var appTot = Enumerable.From(data.MonthlyApproved).Where("$._id.monthYear.toString().substring(0,4) == " + filter.FinishStr().substring(0,4)).Select("$.approved").Sum()
                var sm = (appTot/bcaTot) > 1 ? 1 : (appTot/bcaTot)
                pushData.push(kendo.toString(sm, "P0"));
            }
        })
        tb.Body.push(pushData)

        majorRegion.forEach(function(xx){
            var pushData = [];
            var filteredDataRegionApprove = Enumerable.From(data.MonthlyApproved).Where("$._id.major_region == '" + xx + "' && " + "$._id.monthYear.toString().substring(0,4) == " + filter.FinishStr().substring(0,4)).ToArray();
            var filteredDataRegionBCA = Enumerable.From(data.bcaMajorRegion).Where("$._id.Major_Region == '" + xx + "'").ToArray();
            tb.Header().forEach(function(yy){
                if(yy.Type == "region"){
                    pushData.push(xx);
                }
                if(yy.Type == "TotalApproved"){
                    var sm = Enumerable.From(filteredDataRegionApprove).Select("$.approved").Sum()
                    pushData.push(sm.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
                }
                if(yy.Type == "ApproveMonthly"){
                    var sm = Enumerable.From(data.MonthlyApproved).Where("$._id.major_region == '" + xx + "' && " + "$._id.monthYear == " + yy.DateMonth).Select("$.approved").Sum()
                    pushData.push(sm.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
                }
                if(yy.Type == "InitiatedFinish"){
                    var sm = Enumerable.From(filteredDataRegionApprove).Where("$._id.monthYear == " + yy.DateMonth).Select("$.initiated").Sum()
                    pushData.push(sm.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
                }
                if(yy.Type == "BCAGroup"){
                    var sm = Enumerable.From(filteredDataRegionBCA).Select("$.totalbca").Sum()
                    pushData.push(sm.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
                    // if (filter.MajorRegion() == "") {
                    //     var sm = Enumerable.From(filteredDataRegionBCA).Select("$.totalbca").Sum()
                    //     pushData.push(sm.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
                    // } else if (filter.MajorRegion() == xx) {
                    //     var sm = Enumerable.From(filteredDataRegionBCA).Select("$.totalbca").Sum()
                    //     pushData.push(sm.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
                    // }else if (filter.MajorRegion() != xx) {
                    //     var sm = 0
                    //     pushData.push(sm.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
                    // }
                    
                }
                if(yy.Type == "BCAGroupNoAP"){
                        var bcaTot = Enumerable.From(filteredDataRegionBCA).Select("$.totalbca").Sum()
                        var app = Enumerable.From(filteredDataRegionApprove).Select("$.approved").Sum()
                        var tot = (bcaTot - app) < 0 ? 0 : (bcaTot - app)
                        pushData.push(tot.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
                    // if (filter.MajorRegion() == "") {
                    //     var bcaTot = Enumerable.From(filteredDataRegionBCA).Select("$.totalbca").Sum()
                    //     var app = Enumerable.From(filteredDataRegionApprove).Select("$.approved").Sum()
                    //     pushData.push((bcaTot - app).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
                    // }else if (filter.MajorRegion() == xx) {
                    //     var bcaTot = Enumerable.From(filteredDataRegionBCA).Select("$.totalbca").Sum()
                    //     var app = Enumerable.From(filteredDataRegionApprove).Select("$.approved").Sum()
                    //     pushData.push((bcaTot - app).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
                    // }else if (filter.MajorRegion() != xx) {
                    //     var bcaTot = 0
                    //     var app = 0
                    //     pushData.push((bcaTot - app).toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
                    // }
                    
                }
                if(yy.Type == "Completed"){
                    var bcaTot = Enumerable.From(filteredDataRegionBCA).Select("$.totalbca").Sum()
                    var appTot = Enumerable.From(filteredDataRegionApprove).Select("$.approved").Sum()
                    var sm = (appTot/bcaTot) > 1 ? 1 : (appTot/bcaTot)
                    pushData.push(kendo.toString(sm, "P0"));
                }
                
            })
            tb.Body.push(pushData)
        });

        pushData = [];
        tb.Header().forEach(function(yy){
            pushData.push("");
        })
        tb.Body.push(pushData)
        
        listCountry.forEach(function(xx){
            var pushData = [];
            var filteredDataRegionApprove = Enumerable.From(data.MonthlyApproved).Where("$._id.country == '" + xx + "'").ToArray();
            var filteredDataRegionBCA = Enumerable.From(data.bcaMajorRegion).Where("$._id.Country == '" + xx + "'").ToArray();
            tb.Header().forEach(function(yy){
                if(yy.Type == "region"){
                    if(xx == "UNITED ARAB EMIRATES")
                        pushData.push("UAE");
                    else if(xx == "KOREA, REPUBLIC OF")
                        pushData.push("KOREA");
                    else
                        pushData.push(xx);
                }
                if(yy.Type == "TotalApproved"){
                    var sm = Enumerable.From(filteredDataRegionApprove).Where("$._id.monthYear.toString().substring(0,4) == " + filter.FinishStr().substring(0,4)).Select("$.approved").Sum()
                    pushData.push(sm.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
                }
                if(yy.Type == "ApproveMonthly"){
                    var sm = Enumerable.From(filteredDataRegionApprove).Where("$._id.monthYear == " + yy.DateMonth).Select("$.approved").Sum()
                    pushData.push(sm.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
                }
                if(yy.Type == "InitiatedFinish"){
                    var sm = Enumerable.From(filteredDataRegionApprove).Where("$._id.monthYear == " + yy.DateMonth).Select("$.initiated").Sum()
                    pushData.push(sm.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
                }
                if(yy.Type == "BCAGroup"){
                    var sm = Enumerable.From(filteredDataRegionBCA).Select("$.totalbca").Sum()
                    pushData.push(sm.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
                }
                if(yy.Type == "BCAGroupNoAP"){
                    var bcaTot = Enumerable.From(filteredDataRegionBCA).Select("$.totalbca").Sum()
                    var app = Enumerable.From(filteredDataRegionApprove).Where("$._id.monthYear.toString().substring(0,4) == " + filter.FinishStr().substring(0,4)).Select("$.approved").Sum()
                    var tot = (bcaTot - app) < 0 ? 0 : (bcaTot - app)
                    pushData.push(tot.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
                }
                if(yy.Type == "Completed"){
                    var bcaTot = Enumerable.From(filteredDataRegionBCA).Select("$.totalbca").Sum()
                    var appTot = Enumerable.From(filteredDataRegionApprove).Where("$._id.monthYear.toString().substring(0,4) == " + filter.FinishStr().substring(0,4)).Select("$.approved").Sum()
                    var sm = (appTot/bcaTot) > 1 ? 1 : (appTot/bcaTot)
                    pushData.push(kendo.toString(sm, "P0"));
                }
                
            })
            tb.Body.push(pushData)
        });

    });
}
AccountPlan.Init = function(){
    setTimeout(function(){
        AccountPlan.GetData();
    }, 2000);
    // AccountPlan.PullRequest(1);
    // AccountPlan.Processing(true);
    // ajaxPost("/mastercountry/getdata",{},function(res){
    //     AccountPlan.Filter.CountryList(res.Data);
    //     pullRequestComplete(AccountPlan.PullRequest,AccountPlan.InitComplete());
    // })
}