var usersett = {
    //
    titleModel : ko.observable("New User"),
    loading : ko.observable(false),
    edit : ko.observable(true),
    TitelFilter: ko.observable(" Hide Filter"),
    //var field
    Id : ko.observable(""),
    psid: ko.observable(""),
    userName : ko.observable(""),
    fullName : ko.observable(""),
    email : ko.observable(""),
    password : ko.observable(""),
    confirmPassword : ko.observable(""),
    role : ko.observable(""),

    //var Filter
    filterUser : ko.observableArray([]),
    filterRole : ko.observableArray([]),

    //var List
    listUserName : ko.observableArray([]),
    listRole : ko.observableArray([]),

    //var region
    allCountries : ko.observableArray([]),
    allRegion : ko.observableArray([]),
    MasterRegionRaw: ko.observableArray([]),
    regionList: ko.observableArray([]),
    countryList: ko.observableArray([]),
    majorRegionList: ko.observableArray([]),
    selectedRegion: ko.observableArray([]),
    selectedCountry: ko.observableArray([]),
    enaRegion: ko.observable(false),
    enaCountry: ko.observable(false),
};

modal = {
    loading: ko.observable(false)
};

usersett.ClearField = function(){
    usersett.Id("");
    usersett.psid("");
    usersett.userName("");
    usersett.fullName("");
    usersett.email("");
    usersett.password("");
    usersett.confirmPassword("");
    usersett.role("");
    usersett.selectedRegion([]);
    usersett.selectedCountry([]);
    usersett.enaCountry(false);
    usersett.enaRegion(false);
}

usersett.Search = function(){
    usersett.GetDataUser();
}


usersett.Reset = function(){
    $("#filterUser").html("");
    $("#filterRole").html("");
    var multiUser = $("#filterUser").data("kendoMultiSelect");
    var multiRole = $("#filterRole").data("kendoMultiSelect");
    multiUser.value([]);
    multiRole.value([]);
    $('#StatusFilter').bootstrapSwitch('state', true);    
    usersett.GetDataUser();
    usersett.enaCountry(false);
    usersett.enaRegion(false);
}

usersett.AddNew = function(){
    usersett.ClearField();
    $("#userModal").modal("show");
    $("#nav-dex").css('z-index', '0');
    $("#userModal").modal({
        backdrop: 'static',
        keyboard: false
    });
    usersett.titleModel("New User");
    $('#filterStatus').bootstrapSwitch('state',true)
    usersett.edit(false);
    var validator = $("#AddUserSetting").kendoValidator().data("kendoValidator");
    validator.hideMessages();
}

usersett.SaveData = function(e){

    var statusBool = $('#Status').bootstrapSwitch('state');
    var dropRole = $("#role").data("kendoDropDownList");
    var Region = [];
    var Countries = [];
    if(dropRole.text()=="SuperUser" || dropRole.text()=="Admin"){
        Region = usersett.allRegion();
        Countries = usersett.allCountries();
    }else{
        if(dropRole.text()=="Regional"){
            Region = usersett.selectedRegion();
            if(usersett.selectedRegion().length != 0){
                usersett.selectedRegion().forEach(function(r){
                    usersett.MasterRegionRaw().forEach(function(d){
                        if(d.Major_Region == r){
                            Countries.push(d.Country);
                        }
                    });
                });
            }
            // Countries = usersett.countryList();
        }else{
            if(usersett.selectedCountry().length != 0){
                usersett.selectedCountry().forEach(function(d){
                    Countries.push(d);
                    var finder = Enumerable.From(usersett.MasterRegionRaw()).FirstOrDefault(undefined, "$.Country == '" + d + "'");
                    if(finder != undefined){
                        var exist = _.filter(Region, function(r){
                            return r == finder.Major_Region;
                        });
                        if(exist.length == 0){
                            Region.push(finder.Major_Region);
                        }
                    }
                });
            }
        }
    }
    var param = {
        "PSID": usersett.psid(),
        "UserName": usersett.userName(),
        "FullName": usersett.fullName(),
        "Email": usersett.email(),
        "Enable": statusBool,
        "Password": usersett.password(),
        "Role": dropRole.text(),
        "Region": Region,
        "Country":Countries,
    }
    var url = "/usersetting/savedata";
    usersett.initValidator(dropRole.text());
    var validator = $("#AddUserSetting").data("kendoValidator");

    if(validator==undefined){
        usersett.initValidator(dropRole.text());
        validator= $("#AddUserSetting").kendoValidator().data("kendoValidator");
    }
    if (validator.validate()) {
        modal.loading(true);
        ajaxPost(url, param, function(res){
            modal.loading(false);
            if(res.IsError != true){
                $("#userModal").modal("hide");
                $("#nav-dex").css('z-index', 'none');
                usersett.ClearField();
                usersett.Reset();
                swal("Success!", res.Message, "success");
                usersett.getRole();
                usersett.getUserName();
            }else{
                return swal("Error!", res.Message, "error");
            }
        });
    }
}

usersett.initValidator = function(val){
    var container = $("#AddUserSetting");
    kendo.init(container);
    if(val == "Regional"){
        container.kendoValidator({
        rules:{
            custom1: function(input){
                if(input.is("[name=majorRegion]")){
                    return input.val() !== "";
                }
                return true;
            },
            // custom2: function(input){
            //     if(input.is("[name=confirmPassword]")){
            //         var confirmPass = input.val(),
            //         pass = usersett.password();
            //         if(confirmPass !== pass){
            //             return false;
            //         }
            //     }
            //     return true;
            // }
        },
        messages: {
            custom1: "Major Region are required",
            // custom2: "Confirm Password must has same value with Password"
        }
        });
    } else if(val =="Country"){
        container.kendoValidator({
        rules:{
            custom1: function(input){
                if(input.is("[name=country]")){
                    return input.val() !== "";
                }
                return true;
            },
            custom2: function(input){
                if(input.is("[name=Major_Region]")){
                    return input.val() !== "";
                }
                return true;
            },
            // custom3: function(input){
            //     if(input.is("[name=confirmPassword]")){
            //         var confirmPass = input.val(),
            //         pass = usersett.password();
            //         if(confirmPass !== pass){
            //             return false;
            //         }
            //     }
            //     return true;
            // }
        },
        messages: {
            custom1: "Country are required",
            custom2: "Major Region are required",
            // custom3: "Confirm Password must has same value with Password"
        }
        });
    }
    // else{
        // container.kendoValidator({
        // rules:{
        //     custom1: function(input){
        //         if(input.is("[name=password]")){
        //             var password = input.val()
        //             if(password == ''){
                 
        //                 return false;
        //             }
        //         }
        //         return true;
        //     },
        //     custom2: function(input){
        //         if(input.is("[name=confirmPassword]")){
        //             var confirmPass = input.val(),
        //             pass = usersett.password();
        //             if(confirmPass !== pass){
        //                 return false;
        //             }
        //         }
        //         return true;
        //     },
        //     custom3: function(input){
        //         if(input.is("[name=password]")){
        //             var password = input.val(),
        //             re = /(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*.?&])[A-Za-z\d.$@$!%*?&]{8,}/
        //             if(!re.test(password)){
                 
        //                 return false;
        //             }
        //         }
        //         return true;
        //     },
        //     custom4: function(input){
        //         if(input.is("[name=confirmPassword]")){
        //             var confirmPass = input.val()
        //             if(confirmPass == ''){
                 
        //                 return false;
        //             }
        //         }
        //         return true;
        //     },
        //     custom5: function(input){
        //         if(input.is("[name=confirmPassword]")){
        //             var confirmPass = input.val(),
        //             re = /(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*.?&])[A-Za-z\d.$@$!%*?&]{8,}/
        //             if(!re.test(confirmPass)){
                 
        //                 return false;
        //             }
        //         }
        //         return true;
        //     },
            
        // },
        // messages: {
        //     custom1: "Password required",
        //     custom2: "Confirm Password must has same value with Password",
        //     custom3: "Password Policy is min 8 characters, with uppercase, number and special character",
        //     custom4: "Confirm Password required",
        //     custom5: "Password Policy is min 8 characters, with uppercase, number and special character",
            
        // }
        // });
    // }
}

usersett.UpdateData = function(){
    var statusBool = $('#Status').bootstrapSwitch('state');
    var dropRole = $("#role").data("kendoDropDownList");
    var Region = [];
    var Countries = [];

    if(dropRole.text()=="SuperUser" || dropRole.text()=="Admin"){
        Region = usersett.allRegion();
        Countries = usersett.allCountries();
    }else{
        if(dropRole.text()=="Regional"){
            Region = usersett.selectedRegion();
            if(usersett.selectedRegion().length != 0){
                usersett.selectedRegion().forEach(function(r){
                    usersett.MasterRegionRaw().forEach(function(d){
                        if(d.Major_Region == r){
                            Countries.push(d.Country);
                        }
                    });
                });
            }
        }else{
            if(usersett.selectedCountry().length != 0){
                usersett.selectedCountry().forEach(function(d){
                    Countries.push(d);
                    var finder = Enumerable.From(usersett.MasterRegionRaw()).FirstOrDefault(undefined, "$.Country == '" + d + "'");
                    if(finder != undefined){
                        var exist = _.filter(Region, function(r){
                            return r == finder.Major_Region;
                        });
                        if(exist.length == 0){
                            Region.push(finder.Major_Region);
                        }
                    }
                });
            }
        }
    }

   
    var param = {
        "Id" : usersett.Id(),
        "PSID": usersett.psid(),
        "UserName": usersett.userName(),
        "FullName": usersett.fullName(),
        "Email": usersett.email(),
        "Enable": statusBool,
        "Password": usersett.password(),
        "Role": dropRole.text(),
        "Region": Region,
        "Country": Countries,
    }
    var url = "/usersetting/savedata";
    usersett.initValidator(dropRole.text());
    var validator = $("#AddUserSetting").data("kendoValidator");
    if(validator==undefined){
        usersett.initValidator(dropRole.text());
        validator= $("#AddUserSetting").kendoValidator().data("kendoValidator");
    }
    if (validator.validate()) {
        ajaxPost(url, param, function(res){
            if(res.IsError != true){
                $("#userModal").modal("hide");
                $("#nav-dex").css('z-index', 'none');
                usersett.ClearField();
                usersett.Reset();
                swal("Success!", res.Message, "success");
                usersett.getRole();
                usersett.getUserName();
            }else{
                return swal("Error!", res.Message, "error");
            }
        });
    }
}

usersett.DeleteData = function(){
    swal({
      title: 'Are you sure?',
      text: "You are about to delete user",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!',
      closeOnConfirm: false 
    },
    function(){
       
        var param = {
        "Id" :usersett.Id(),
        }
        var url = "/usersetting/deleteuser";
        ajaxPost(url, param, function(res){
            
            if(res.success){
                $("#userModal").modal("hide");
                $("#nav-dex").css('z-index', 'none');
                usersett.ClearField();
                usersett.Reset();
                swal("Deleted!", "User has been deleted.", "success");
                usersett.getRole();
                usersett.getUserName();
            }else{
                return swal("Error!", res.message, "error");
            }
        });
    });
}

usersett.EditData = function(idUser){
    var validator = $("#AddUserSetting").data("kendoValidator");
    if(validator != undefined)
        validator.hideMessages();
    var param = {
        "Id" : idUser,
    }
    var url = "/usersetting/getdata";
    ajaxPost(url, param, function(res){
        if(res.IsError != true){
            usersett.edit(true);
            usersett.titleModel("Update User");
            $("#nav-dex").css('z-index', '0');
            $("#userModal").modal({
                backdrop: 'static',
                keyboard: false
            });
            var dataUser = res.Data.Records[0];
            $("#userModal").modal("show");
            usersett.Id(dataUser.Id);
            usersett.psid(dataUser.PSID);
            usersett.userName(dataUser.Username);
            usersett.fullName(dataUser.Fullname);
            usersett.email(dataUser.Email);
            usersett.password("");//dataUser.Password
            usersett.confirmPassword(dataUser.Password);
            usersett.role(dataUser.Roles);
            $('#Status').bootstrapSwitch('state', dataUser.Enable);
            $("#role").data("kendoDropDownList").text(dataUser.Roles);
            usersett.checkRoles(usersett.role());
            if(usersett.role() == "Country" || usersett.role() == "Regional"){
                usersett.selectedCountry(dataUser.Country);
                usersett.selectedRegion(dataUser.Region);
            }
            // usersett.changeRoles();
        }else{
            return swal("Error!", res.Message, "error");
        }
    });
}

usersett.Cancel = function(){
    $("#userModal").modal("hide");
    $("#nav-dex").css('z-index', 'none');
    usersett.ClearField();
}

usersett.filterUser.subscribe(function(value){
  if(model.View() != "false"){
   usersett.GetDataUser();
  }
});

usersett.filterRole.subscribe(function(value){
  if(model.View() != "false"){
   usersett.GetDataUser();
  }
});

usersett.GetDataUser = function(){
    usersett.loading(false);
    var param =  {
        "UserName" : usersett.filterUser(),
        "Role" : usersett.filterRole(),
        "Status" : $('#StatusFilter').bootstrapSwitch('state')
    };
    var dataSource = [];
    var url = "/usersetting/getdata";
    $("#MasterGridUser").html("");
    $("#MasterGridUser").kendoGrid({
            dataSource: {
                    transport: {
                        read: {
                            url: url,
                            data: param,
                            dataType: "json",
                            type: "POST",
                            contentType: "application/json",
                        },
                        parameterMap: function(data) {
                           return JSON.stringify(data);
                        },
                    },
                    schema: {
                        data: function(data) {
                            usersett.loading(false);
                            if (data.Data.Count == 0) {
                                return dataSource;
                            } else {
                                return data.Data.Records;
                            }
                        },
                        total: "Data.Count",
                    },
                    pageSize: 15,
                    serverPaging: true,
                    serverSorting: true,
                },
                resizable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
                columnMenu: false,
            columns: [
                {
                    field:"PSID",
                    title:"PSID",
                    width:75,
                },
                {
                    field:"Username",
                    title:"User Name",
                    width:75,
                    // template: "#if(model.Edit() != 'false'){#<a class='grid-select' href='javascript:usersett.EditData(\"#: Id #\")'>#: Username #</a>#}else{#<div>#: Username #</div>#}#"

                },
                {
                    field:"Fullname",
                    title:"Full Name",
                    width:100

                },
                {
                    field:"Enable",
                    title:"Enable",
                    width:50

                },
                {
                    field:"Email",
                    title:"Email",
                    width:100

                },
                {
                    field:"Roles",
                    title:"Roles",
                    width:75

                },
                {
                    field:"",
                    title:"Action",
                    width:50,
                    attributes: {
                        style: "text-align: center;"
                    },
                    // attributes: {"class": "align-center"},
                     template: function (d) {
                            return [
                                
                                "<button onclick='usersett.EditData(\"" + d.Id + "\")' name='delete' type='button' class='btn btn-info btn-xs tooltipster' title='Edit User'><span class='fa fa-pencil-square-o'></span></button>",
                            ].join(" ");
                        }
                }]
    });
}

usersett.checkRoles = function(val){
    if( val == "Regional"){
        usersett.enaRegion(true);
        usersett.enaCountry(false);
    }else if(val == "Country"){
        usersett.enaCountry(true);
        usersett.enaRegion(false);
    }else{
        usersett.enaCountry(false);
        usersett.enaRegion(false);
    }
}

usersett.changeRoles = function(e){
    usersett.selectedCountry([]);
    usersett.selectedRegion([]);
    var val = e.sender.value();
    // var majorDrop = $("#majorRegion").data("kendoDropDownList");
    usersett.checkRoles(val);
    
    // majorDrop.refresh();
    // majorDrop.dataSource.read();
}

usersett.changeMajor = function(e){
    usersett.selectedCountry("");
}

// usersett.selectedRegion.subscribe(function(val){
//     var selectedCountry = [];
//     if(val == "")
//         selectedRegion = Enumerable.From(usersett.MasterRegionRaw()).Select("$.Region").Distinct().ToArray();
//     else
//         selectedRegion = Enumerable.From(usersett.MasterRegionRaw()).Where("$.Major_Region == '" + val + "'").Select("$.Region").Distinct().ToArray();
        
//     if(val == ""){
//         var g = Enumerable.From(usersett.MasterRegionRaw()).Select("$.Country").Distinct().ToArray();
//         if(g.length > 0){
//             selectedCountry = g;
//         }
//     }
//     else{
//         selectedRegion.forEach(function(e){
//             var g = Enumerable.From(usersett.MasterRegionRaw()).Where("$.Region == '" + e + "'").Select("$.Country").Distinct().ToArray();
//             if(g.length > 0){
//                 selectedCountry = selectedCountry.concat(g)
//             }
//         });
//     }
        
//     // usersett.regionList(selectedRegion);
//     usersett.countryList(selectedCountry);
// })

usersett.changeCountry = function(e){
    var val = e.sender.value();
    var finder = Enumerable.From(usersett.MasterRegionRaw()).FirstOrDefault(undefined, "$.Country == '" + val + "'");
    if(finder != undefined){
        usersett.selectedRegion(finder.Major_Region)
    }
}

usersett.getTerritory = function(){
        ajaxPost("/dashboard/preparefilter", {}, 
        function (res) {
            if(res.data != undefined){
                var majorRegionList = Enumerable.From(res.data.RegionSet).Select("$.Major_Region").Distinct().ToArray();
                var regionList = Enumerable.From(res.data.RegionSet).Select("$.Region").Distinct().ToArray();
                var countryList = Enumerable.From(res.data.RegionSet).Select("$.Country").Distinct().ToArray();
                usersett.allRegion(majorRegionList);
                usersett.allCountries(countryList);
                usersett.MasterRegionRaw(res.data.RegionSet);
                usersett.regionList(regionList);
                usersett.countryList(countryList);
                usersett.majorRegionList(majorRegionList)
            }
        });
}

// usersett.getDataFilter = function(){
//     ajaxPost("/usersetting/getusername", {}, 
//         function (res) {
//             if(res.data != undefined){
//                 var majorRegionList = Enumerable.From(res.data).Select("$.Major_Region").Distinct().ToArray();
//                 var regionList = Enumerable.From(res.data).Select("$.Region").Distinct().ToArray();
//                 var countryList = Enumerable.From(res.data).Select("$.Country").Distinct().ToArray();
//                 usersett.MasterRegionRaw(res.data);
//                 usersett.regionList(regionList);
//                 usersett.countryList(countryList);
//                 usersett.majorRegionList(majorRegionList)
//             }
//     });
// }

usersett.getUserName = function(){
    var param = {
        "UserName" :[],
        "Role" : [],
        "Status" :true
    }
    var url = "/usersetting/getalluser";
    usersett.listUserName([]);
    ajaxPost(url, param, function(res){
        usersett.listUserName(res.data);
    });
}

usersett.getRole = function(){
    var param = {
    }
    var url = "/usersetting/getallroles";
    usersett.listRole([]);
    ajaxPost(url, param, function(res){
        usersett.listRole(res.data);
    });
}

usersett.toggleFilter = function(){
    var panelFilter = $('.panel-filter');
    var panelContent = $('.panel-content');

  if (panelFilter.is(':visible')) {
    panelFilter.hide();
    panelContent.attr('class', 'col-md-12 col-sm-12 ez panel-content');
    $('.breakdown-filter').removeAttr('style');
  } else {
    panelFilter.show();
    panelContent.attr('class', 'col-md-9 col-sm-9 ez panel-content');
    //panelContent.css('margin-top', '1.3%');
    $('.breakdown-filter').css('width', '60%');
  }

  $('.k-grid').each(function (i, d) {
    try {
      $(d).data('kendoGrid').refresh();
    } catch (err) {}
  });

  $('.k-pivot').each(function (i, d) {
    $(d).data('kendoPivotGrid').refresh();
  });

  $('.k-chart').each(function (i, d) {
    $(d).data('kendoChart').redraw();
  });
  usersett.panel_relocated();
  var FilterTitle = usersett.TitelFilter();
  if (FilterTitle == " Hide Filter") {
    usersett.TitelFilter(" Show Filter");
  } else {
    usersett.TitelFilter(" Hide Filter");
  }
}

usersett.panel_relocated = function(){
  if ($('.panel-yo').size() == 0) {
    return;
  }

  var window_top = $(window).scrollTop();
  var div_top = $('.panel-yo').offset().top;
  if (window_top > div_top) {
    $('.panel-fix').css('width', $('.panel-yo').width());
    $('.panel-fix').addClass('contentfilter');
    $('.panel-yo').height($('.panel-fix').outerHeight());
  } else {
    $('.panel-fix').removeClass('contentfilter');
    $('.panel-yo').height(0);
  }
}

$(document).ready(function () {
    // usersett.FilterStatus();
    $("#lastDateData").css({"display":"none"});
    $('#StatusFilter').bootstrapSwitch('state', true);
    usersett.getTerritory();
    usersett.getUserName();
    usersett.getRole();
    usersett.GetDataUser();
});