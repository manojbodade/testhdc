var ds = {};
var filter = {};

ds.fromAnalytic = ko.observable(false);

filter.Start = ko.observable(new Date(2016, 11, 1));
filter.DefaultDate = ko.observable(new Date(2016, 11, 1));
filter.Finish = ko.observable(new Date(2017, 11, 1));
filter.Finish().setMonth(filter.Finish().getMonth() - 1);
var tempFinish = new Date(filter.Finish().getFullYear(), filter.Finish().getMonth() + 1, 0)
filter.StartStr = ko.observable(moment(new Date(filter.Start())).format("YYYY-MM-DD"));
filter.FinishStr = ko.observable(moment(tempFinish).format("YYYY-MM-DD"));
filter.maxDateFilter = ko.observable(filter.Finish())

filter.Start.subscribe(function(val){
	var dt = moment(val).format("YYYY-MM-DD");
	filter.StartStr(dt)
	var mxFilter = new Date(filter.Start().getFullYear(), filter.Start().getMonth() + 13, 0)
	filter.maxDateFilter(mxFilter)
	if(filter.Finish() > filter.maxDateFilter()){
		filter.Finish(filter.maxDateFilter())
	}

});
filter.Finish.subscribe(function(val){
	var nd = new Date(val.getFullYear(), val.getMonth() + 1, 0)
	var dt = moment(nd).format("YYYY-MM-DD");
	filter.FinishStr(dt)
});

filter.MajorRegion = ko.observable('');
filter.majorRegionList = ko.observableArray([]);
filter.Region = ko.observable('');
filter.regionList = ko.observableArray([]);
filter.Country = ko.observable('');
filter.countryList = ko.observableArray([]);

filter.MasterRegionRaw = ko.observableArray([]);
function replaceString(value) {
    return value.replace(/\s/g, '');
}
function resetFilter(){
	// filter.Start(new Date(2016, 9, 1));
	// filter.Finish(new Date(2017, 8, 1));
	// if($('.nav-pills .active').text() == "Analytics Usage"){
		// filter.Start(new Date(filter.DefaultDate().getFullYear(), filter.DefaultDate().getMonth()+1, filter.DefaultDate().getDate()));
  //   	filter.Finish(new Date(filter.Start().getFullYear()+1, filter.Start().getMonth()-1, 30));
	// }else{
		filter.Start(new Date(filter.DefaultDate().getFullYear(), filter.DefaultDate().getMonth(), filter.DefaultDate().getDate()));
    	filter.Finish(new Date(filter.Start().getFullYear()+1, filter.Start().getMonth()-1, 30));
	// }
	filter.MajorRegion('');
	filter.Region('');
	filter.Country('');
}

function resetDate(status){
	console.log(status)
	// if($('.nav-pills .active').text() == "Analytics Usage"){
	if (status) {
		filter.Start(new Date(filter.DefaultDate().getFullYear(), filter.DefaultDate().getMonth()+1, filter.DefaultDate().getDate()));
    	filter.Finish(new Date(filter.Start().getFullYear()+1, filter.Start().getMonth()-1, 30));
	}else{
		filter.Start(new Date(filter.DefaultDate().getFullYear(), filter.DefaultDate().getMonth(), filter.DefaultDate().getDate()));
    	filter.Finish(new Date(filter.Start().getFullYear()+1, filter.Start().getMonth()-1, 30));
	}
}

function MajorRegionChange(e){
	var val = e.sender.value();
	var selectedRegion = [];
	var selectedCountry = [];
	if(val == "")
		selectedRegion = Enumerable.From(filter.MasterRegionRaw()).Select("$.Region").Distinct().ToArray();
	else
		selectedRegion = Enumerable.From(filter.MasterRegionRaw()).Where("$.Major_Region == '" + val + "'").Select("$.Region").Distinct().ToArray();

	if(val == ""){
		var g = Enumerable.From(filter.MasterRegionRaw()).Select("$.Country").Distinct().ToArray();
		if(g.length > 0){
			selectedCountry = g;
		}
	}
	else{
		selectedRegion.forEach(function(e){
			var g = Enumerable.From(filter.MasterRegionRaw()).Where("$.Region == '" + e + "'").Select("$.Country").Distinct().ToArray();
			if(g.length > 0){
				selectedCountry = selectedCountry.concat(g)
			}
		});
	}
 	selectedCountryOrder = Enumerable.From(selectedCountry).OrderBy(function (x) { return x }).ToArray();
	filter.regionList(selectedRegion);
	filter.countryList(selectedCountryOrder);
	filter.Region("");
	filter.Country("");
}

function RegionChange(e){
	var val = e.sender.value();
	var selectedCountry = [];
	if(val == "" && filter.MajorRegion() == "")
		selectedCountry = Enumerable.From(filter.MasterRegionRaw()).Select("$.Country").Distinct().ToArray();
	else if (val == "" && filter.MajorRegion() != "")
		selectedCountry = Enumerable.From(filter.MasterRegionRaw()).Where("$.Major_Region == '" + filter.MajorRegion() + "'").Select("$.Country").Distinct().ToArray();
	else
		selectedCountry = Enumerable.From(filter.MasterRegionRaw()).Where("$.Region == '" + val + "'").Select("$.Country").Distinct().ToArray();

	filter.countryList(selectedCountry);
	filter.Country("");
}

function CountryChange(e){
	var val = e.sender.value();

	if(val == ""){
		filter.Region("");
	}

	var finder = Enumerable.From(filter.MasterRegionRaw()).FirstOrDefault(undefined, "$.Country == '" + val + "'");
	if(finder != undefined){
		filter.Region(finder.Region)
		filter.MajorRegion(finder.Major_Region)
	}

}

function PrepareDataFilter(){
	ajaxPost("/dashboard/preparefilter", {},
		function (res) {
			if(res.data != undefined){
				var majorRegionList = Enumerable.From(res.data.RegionSet).Select("$.Major_Region").Distinct().ToArray();
				var regionList = Enumerable.From(res.data.RegionSet).Select("$.Region").Distinct().ToArray();
				var countryList = Enumerable.From(res.data.RegionSet).Select("$.Country").Distinct().ToArray();
				filter.MasterRegionRaw(res.data.RegionSet);
				// filter.regionList(regionList);


				var countries = Enumerable.From(res.data.Country).OrderBy(function (x) { return x }).ToArray();
				filter.countryList(countries);
				filter.majorRegionList(res.data.MajorRegion)

				// var mj = ko.mapping.toJS(model.Role.selReg());
				// var ct = ko.mapping.toJS(model.Role.selCon());
				// filter.MajorRegion(mj);
				// setTimeout(function() {
				// 	filter.Country(ct);
				// }, 100);

				pullRequestComplete(ds.pullFirst);
			}
		},
		function () {}
	)
}

model.getPDF = function(title) {
    model.TabMenuDasboard(title);
    $bodypage = $("body");
    $ReportHide = $(".app").find("#navbar").find("#mainMenu").css({"display":"none"});
    $ReportHide = $(".app").find("#navbar").find("#menuLogout").css({"display":"none"});
    $ReportHide = $(".app").find("#navbar").find("#mainTitle").css({"display":""});
    $ReportHide = $(".app").find(".btn-filter").css({"display":"none"});
    $ReportHide = $("#MainTab").css({"display":"none"});
    $footerReport = $(".footer").css({"position":"relative"});
    $EditCss = $(".app").find(".box-shadow").css({"font-family": "'Helvetica Neue'", "box-shadow":"0px 0px 7px #707070;", "border-radius":"3px", "display":"block", "border":"2px solid #b7b7b7"});
    $EditCss = $(".app").find(".fa-search").css({"margin-right":"5px"});

	kendo.pdf.defineFont({
		"Helvetica Neue": "/static/fonts/HelveticaNeue.ttf",
		"Helvetica Neu Bold": "/static/fonts/helvetica-neue-bold.ttf",
	// 	"HelveticaNeue BlackCond": "/static/fonts/HelveticaNeue BlackCond.ttf",
	// 	"HelveticaNeue Light": "/static/fonts/HelveticaNeue Light.ttf",
	// 	"HelveticaNeue Medium": "/static/fonts/HelveticaNeue Medium.ttf",
	// 	"HelveticaNeue Thin": "/static/fonts/HelveticaNeue Thin.ttf",
	// 	"HelveticaNeueBd": "/static/fonts/HelveticaNeueBd.ttf",
	// 	"HelveticaNeueHv": "/static/fonts/HelveticaNeueHv.ttf",
	// 	"HelveticaNeueIt": "/static/fonts/HelveticaNeueIt.ttf",
	// 	"HelveticaNeueLt": "/static/fonts/HelveticaNeueLt.ttf",
	// 	"HelveticaNeueMed": "/static/fonts/HelveticaNeueMed.ttf"
	});

    kendo.drawing.drawDOM($bodypage).then(function(group){
        kendo.drawing.pdf.saveAs(group, title+".pdf");
        $footerReport = $(".footer").css({"position":"fixed"});
        $ReportHide = $(".app").find("#navbar").find("#mainTitle").css({"display":"none"});
        $ReportHide = $(".app").find(".btn-filter").css({"display":""});
        $EditCss = $(".app").find(".box-shadow").css({"box-shadow":"0px 0px 7px #707070;", "border-radius":"3px", "display":"", "border":""});
        $(".app").find(".fa-search").css({"margin-right":"0px"})
        $(".app").find("#navbar").find("#mainMenu").css({"display":""});
        $(".app").find("#navbar").find("#menuLogout").css({"display":""});
        $("#MainTab").css({"display":""});
    });
}

function LastUpdateDetail(){
	ajaxPost("/dashboard/lastupdatedataall", {}, function (res) {
        if(res.IsError == true){
            return swal("",res.message,"error");
        }
		model.arrayLastDate(res.Data);
		model.arrayLastDate().lastUpdateAcountPlan = new Date(2017, 10, 2);
		model.arrayLastDate().lastUpdateCallReport = new Date(2017, 10, 2);
		model.arrayLastDate().lastUpdateDealPipeline = new Date(2017, 10, 2);
		model.arrayLastDate().lastUpdateLoginUser = new Date(2017, 10, 2);
		model.arrayLastDate().lastUpdateProspects = new Date(2017, 10, 2);
        var AcountPlan = moment(new Date(model.arrayLastDate().lastUpdateAcountPlan)).format("MMM YY");
        var CallReport = moment(new Date(model.arrayLastDate().lastUpdateCallReport)).format("MMM YY");
        var DealPipeline = moment(new Date(model.arrayLastDate().lastUpdateDealPipeline)).format("MMM YY");
        var LoginUser = moment(new Date(model.arrayLastDate().lastUpdateLoginUser)).format("MMM YY");
        var Prospects = moment(new Date(model.arrayLastDate().lastUpdateProspects)).format("MMM YY");
        var allDate = [AcountPlan, CallReport, DealPipeline, LoginUser, Prospects];
        var stringName = [];
        var hist = {};
        allDate.map( function (a) {
            if (a in hist) hist[a] ++;
            else{
                stringName.push(a);
                hist[a] = 1;
            }
        } );
        var max = 0;
        var label = "";
        for(var i in stringName){
            if(hist[stringName[i]] > max){
                max = hist[stringName[i]];
                label = stringName[i]
            }
        }
        model.lastDateData(label);
    });
}

ds.pullFirst = ko.observable(1)
ds.pullFirst.subscribe(function(val){
	if(val == 0){
    	GetData();// function in dashboard_global
	}
})
function getAllPdf(activeTab){

	$('#modalLoadDashboard').modal('show');
	$("#tab-01").addClass('active')
	$("#tab-06").addClass('active')
	$("#tab-02").addClass('active')
	$("#tab-03").addClass('active')
	$("#tab-04").addClass('active')
	$("#tab-05").addClass('active')
	$("#tab-08").addClass('active')
	$("#tab-09").addClass('active')

	au.GetData()
	LoginUsers.GetData()
	dcr.GetDataCallReport()
	dl.GetDataDeal()
	Prospect.GetData()
	lr.GetData()
	AccountPlan.GetData()

	var interval = setInterval(function(){

		if(!LoginUsers.Processing() && !dcr.Processing() && !dl.Processing() && !AccountPlan.Processing() && !Prospect.Processing() && !au.Processing() && !lr.Processing()){
		    $ReportHide = $(".app").find("#navbar").find("#mainMenu").css({"display":"none"});
		    $ReportHide = $(".app").find("#navbar").find("#menuLogout").css({"display":"none"});
		    $ReportHide = $(".app").find("#navbar").find("#mainTitle").css({"display":""});
		    $ReportHide = $(".app").find(".btn-filter").css({"display":"none"});
		    $ReportHide = $("#MainTab").css({"display":"none"});
		    $footerReport = $(".footer").css({"position":"relative"});
		    $EditCss = $(".app").find(".box-shadow").css({"font-family": "'Helvetica Neue'", "box-shadow":"0px 0px 7px #707070;", "border-radius":"3px", "display":"block", "border":"2px solid #b7b7b7"});
		    $EditCss = $(".app").find(".fa-search").css({"margin-right":"5px"});

		    kendo.pdf.defineFont({
				"Helvetica Neue": "/static/fonts/HelveticaNeue.ttf",
				"Helvetica Neu Bold": "/static/fonts/helvetica-neue-bold.ttf",

			});
			clearInterval(interval);
			setTimeout(function(){
				var dataPdf;
				model.TabMenuDasboard('Dashboard Summary');

				$(".loginusers-dashboard").css({"display":"none"});
				$(".callReport-dashboard").css({"display":"none"});
				$(".deal-dashboard").css({"display":"none"});
				$(".accountplan-dashboard").css({"display":"none"});
				$(".prospect-dashboard").css({"display":"none"});
				$(".loginReport-dashboard").css({"display":"none"});
				$(".analyticsusage-dashboard").css({"display":"none"});

				kendo.drawing.drawDOM( $('.content-app'),
					{
					   	margin: { left: "0mm", top: "15mm", right: "0mm", bottom: "10mm" }
					}).then(function (documentgroup) {

					documentgroup.options.pdf = {multiPage: true}
 					dataPdf = documentgroup;

 					model.TabMenuDasboard('User Activity');

					$(".global-dashboard").css({"display":"none"});
					$(".loginusers-dashboard").css({"display":""});

 					kendo.drawing.drawDOM( $('.content-app'),
					{
					   	margin: { left: "0mm", top: "15mm", right: "0mm", bottom: "10mm" }
					}).then(function (documentgroup) {
	 					dataPdf.children.push(documentgroup.children[0])

	 					model.TabMenuDasboard('Call Report');

		 				$(".loginusers-dashboard").css({"display":"none"});
						$(".callReport-dashboard").css({"display":""});
		 				$("#img-out").html("")
					    html2canvas($("#discussion-type"), {
					        onrendered: function(canvas) {
					            $("#img-out").append(canvas);
					            dcr.CreateImgvann(true);
								kendo.drawing.drawDOM( $('.content-app'),
								{
								   	margin: { left: "0mm", top: "15mm", right: "0mm", bottom: "10mm" }
								}).then(function (documentgroup) {
				 					dataPdf.children.push(documentgroup.children[0])

				 					model.TabMenuDasboard('Deal Pipeline');

									$(".callReport-dashboard").css({"display":"none"});
									$(".deal-dashboard").css({"display":""});
									dcr.CreateImgvann(false);
									kendo.drawing.drawDOM( $('.content-app'),
									{
									   	margin: { left: "0mm", top: "15mm", right: "0mm", bottom: "10mm" }
									}).then(function (documentgroup) {
					 					dataPdf.children.push(documentgroup.children[0])

										model.TabMenuDasboard('Account Plan');

										$(".deal-dashboard").css({"display":"none"});
										$(".accountplan-dashboard").css({"display":""});

										kendo.drawing.drawDOM( $('.content-app'),
										{
										   	margin: { left: "0mm", top: "15mm", right: "0mm", bottom: "10mm" }
										}).then(function (documentgroup) {
						 					dataPdf.children.push(documentgroup.children[0])

						 					model.TabMenuDasboard('Prospect');

											$(".accountplan-dashboard").css({"display":"none"});
											$(".prospect-dashboard").css({"display":""});

											kendo.drawing.drawDOM( $('.content-app '),
											{
											   	margin: { left: "0mm", top: "15mm", right: "0mm", bottom: "10mm" }
											}).then(function (documentgroup) {
							 					dataPdf.children.push(documentgroup.children[0])

												model.TabMenuDasboard('Login Report');

							 					$(".prospect-dashboard").css({"display":"none"});
												$(".loginReport-dashboard").css({"display":""});

												kendo.drawing.drawDOM( $('.content-app '),
												{
												   	margin: { left: "0mm", top: "15mm", right: "0mm", bottom: "10mm" }
												}).then(function (documentgroup) {
													// dataPdf.children.push(documentgroup.children[0])
													model.TabMenuDasboard('Analytics Usage');

								 					$(".loginReport-dashboard").css({"display":"none"});
													$(".analyticsusage-dashboard").css({"display":""});

													kendo.drawing.drawDOM( $('.content-app '),
													{
													   	margin: { left: "0mm", top: "15mm", right: "0mm", bottom: "10mm" }
													}).then(function (documentgroup) {
														dataPdf.children.push(documentgroup.children[0])
														kendo.drawing.pdf.saveAs(dataPdf, "dashboard.pdf");

														$(".global-dashboard").css({"display":""});
														$(".loginusers-dashboard").css({"display":""});
														$(".callReport-dashboard").css({"display":""});
														$(".deal-dashboard").css({"display":""});
														$(".accountplan-dashboard").css({"display":""});
														$(".prospect-dashboard").css({"display":""});
														$(".loginReport-dashboard").css({"display":""});
														$(".analyticsusage-dashboard").css({"display":""});

														$("#tab-01").removeClass('active')
														$("#tab-06").removeClass('active')
														$("#tab-02").removeClass('active')
														$("#tab-03").removeClass('active')
														$("#tab-04").removeClass('active')
														$("#tab-05").removeClass('active')
														$("#tab-08").removeClass('active')
														$("#tab-09").removeClass('active')

														$("#tab-"+activeTab).addClass('active')

														$footerReport = $(".footer").css({"position":"fixed"});
			       										$ReportHide = $(".app").find("#navbar").find("#mainTitle").css({"display":"none"});
			        									$ReportHide = $(".app").find(".btn-filter").css({"display":""});
			        									$EditCss = $(".app").find(".box-shadow").css({"box-shadow":"0px 0px 7px #707070;", "border-radius":"3px", "display":"", "border":""});
			        									$(".app").find(".fa-search").css({"margin-right":"0px"})
			        									$(".app").find("#navbar").find("#mainMenu").css({"display":""});
			        									$(".app").find("#navbar").find("#menuLogout").css({"display":""});
			        									$("#MainTab").css({"display":""});
			        									$('#modalLoadDashboard').modal('hide');
													});
												});
											});
										});
									});
								});
							},
        					width: 420,
       						height: 220
    					});
					});

				});

			},3000)

		}
	},100)

}
$(document).ready(function(){
	LastUpdateDetail();
	PrepareDataFilter();
	// filter.Start(new Date(2016, 11, 1))
})