var rolesett = {
    //
    titleModel : ko.observable("New Roles"),
    loading : ko.observable(false),
    edit : ko.observable(true),
    disableRolename : ko.observable(true),
    temp: ko.observableArray([]),
    filterStatus: ko.observable(),
    //var field 
    Id : ko.observable(""),
    roleName : ko.observable(""),
    page : ko.observable(""),

    //var Filter
    filterRole : ko.observableArray([]),

    //var List
    listRole : ko.observableArray([]),

    //var Landing Page
    listPage : ko.observableArray([]),
    listlanding : ko.observableArray([]),
    landingUrl : ko.observable(""),
};

rolesett.templateRole = {
    name: "",
    status: false,
    menu: [],
    landing: "",
};
rolesett.mappingRole = ko.mapping.fromJS(rolesett.templateRole);

rolesett.ClearField = function(){
    rolesett.roleName("");
    $('#Status').bootstrapSwitch('state',true);
}

rolesett.Search = function(){
    rolesett.GetDataRole();
}

rolesett.Reset = function(){
    var multiSelect = $('#filterRole').data("kendoMultiSelect");
    multiSelect.value([]);
    $('#filterStatus').bootstrapSwitch('state', true);
    rolesett.GetDataRole();
}

rolesett.AddNew = function(){
    var landing = $("#role").data("kendoDropDownList");
    $("#roleModal").modal("show");
    $("#nav-dex").css('z-index', '0');
    $("#roleModal").modal({
        backdrop: 'static',
        keyboard: false
    });
    $('.rolecheck-value-check-all').prop('checked', false);
    $('.rolecheck-value-Access').prop('checked', false);
    $('.rolecheck-value-Create').prop('checked', false);
    $('.rolecheck-value-Delete').prop('checked', false);
    $('.rolecheck-value-Edit').prop('checked', false);
    $('.rolecheck-value-View').prop('checked', false);
    $('.rolecheck-value-Approve').prop('checked', false);
    $('.rolecheck-value-Process').prop('checked', false);
    rolesett.titleModel("New Roles");
    rolesett.disableRolename(true);
    rolesett.ClearField();
    rolesett.edit(false);
    rolesett.getTopMenu();
}

rolesett.SaveData = function(){
    var displayedData = $("#MasterGridMenu").data().kendoTreeList.dataSource.view();
    rolesett.mappingRole.name(rolesett.roleName());
    rolesett.mappingRole.status($('#Status').bootstrapSwitch('state'));
    rolesett.mappingRole.landing("Dashboard");
    
    rolesett.mappingRole.menu([]);
    for (var i in displayedData){
        if (displayedData[i].id != undefined){
            var Access = $("#check-Access-"+displayedData[i].Id).is(":checked");
                rolesett.mappingRole.menu.push({
                    "menuid" : displayedData[i].id,
                    "menuname" : displayedData[i].Title,
                    "haschild" : displayedData[i].Haschild,
                    "enable" : displayedData[i].Enable,
                    "parent" : displayedData[i].parentId == null?"":displayedData[i].parentId,
                    "checkall" : $("#check-all-new"+displayedData[i].id).is(":checked"),
                    "access" : $("#check-Access-"+displayedData[i].id).is(":checked"),
                    "view" : $("#check-View-"+displayedData[i].id).is(":checked"),
                    "create" : $("#check-Create-"+displayedData[i].id).is(":checked"),
                    "approve" : $("#check-Approve-"+displayedData[i].id).is(":checked"),
                    "delete" : $("#check-Delete-"+displayedData[i].id).is(":checked"),
                    "process" : $("#check-Process-"+displayedData[i].id).is(":checked"),
                    "edit" : $("#check-Edit-"+displayedData[i].id).is(":checked"),
                    "Url": displayedData[i].Url
                });
        }


    }
    
    var param =  ko.mapping.toJS(rolesett.mappingRole);
    var url = "/sysroles/savedata";
    var validator = $("#AddRole").data("kendoValidator");
    if(validator==undefined){
       validator= $("#AddRole").kendoValidator().data("kendoValidator");
    }
    if (validator.validate()) {
        ajaxPost(url, param, function(res){
            if(res.IsError != true){
                $("#roleModal").modal("hide");
                rolesett.Cancel();
                rolesett.Reset();
                // $("#nav-dex").css('z-index', 'none');
                swal("Success!", res.Message, "success");
                // location.reload();
            }else{
                return swal("Error!", res.Message, "error");
            }
        });
    }
}

rolesett.UpdateData = function(){
    var displayedData = $("#MasterGridMenu").data().kendoTreeList.dataSource.view();
    rolesett.mappingRole.name(rolesett.roleName());
    rolesett.mappingRole.status($('#Status').bootstrapSwitch('state'));
    rolesett.mappingRole.landing('Dashboard');
    
    rolesett.mappingRole.menu([]);
    for (var i in displayedData){
        if (displayedData[i].id != undefined){
            var Access = $("#check-Access-"+displayedData[i].Id).is(":checked");
                rolesett.mappingRole.menu.push({
                    "menuid" : displayedData[i].id,
                    "menuname" : displayedData[i].Title,
                    "haschild" : displayedData[i].Haschild,
                    "enable" : displayedData[i].Enable,
                    "parent" : displayedData[i].parentId == null?"":displayedData[i].parentId,
                    "checkall" : $("#check-all-new"+displayedData[i].id).is(":checked"),
                    "access" : $("#check-Access-"+displayedData[i].id).is(":checked"),
                    "view" : $("#check-View-"+displayedData[i].id).is(":checked"),
                    "create" : $("#check-Create-"+displayedData[i].id).is(":checked"),
                    "approve" : $("#check-Approve-"+displayedData[i].id).is(":checked"),
                    "delete" : $("#check-Delete-"+displayedData[i].id).is(":checked"),
                    "process" : $("#check-Process-"+displayedData[i].id).is(":checked"),
                    "edit" : $("#check-Edit-"+displayedData[i].id).is(":checked"),
                    "Url": displayedData[i].Url
                });
        }
    }

    var param =  ko.mapping.toJS(rolesett.mappingRole);
    param.Id = rolesett.Id();
    var url = "/sysroles/savedata";
    var validator = $("#AddRole").data("kendoValidator");
    if(validator==undefined){
       validator= $("#AddRole").kendoValidator().data("kendoValidator");
    }
    if (validator.validate()) {
        ajaxPost(url, param, function(res){
            if(res.IsError != true){
                rolesett.Cancel();
                rolesett.Reset();
                rolesett.getRole();
                // $("#nav-dex").css('z-index', 'none');
                $("#roleModal").modal("hide");
                swal("Success!", res.Message, "success");
                // location.reload();
            }else{
                return swal("Error!", res.Message, "error");
            }
        });
    }
}

rolesett.EditData = function(IdRole){
    var url = "/sysroles/getmenuedit";
    var param = {
            Id : IdRole
        }
        ajaxPost(url, param, function(res){
            if(res.IsError != true){
                rolesett.disableRolename(false);
                $("#roleModal").modal("show");
                $("#nav-dex").css('z-index', '0');
                $("#roleModal").modal({
                    backdrop: 'static',
                    keyboard: false
                });
                rolesett.titleModel("Update Roles");
                rolesett.edit(true);
                var Records = res.Data.Records[0];
                rolesett.Id(Records.Id);
                rolesett.roleName(Records.Name);
                rolesett.landingUrl(Records.Landing);
                var landing = $("#role").data("kendoDropDownList");
                $('#Status').bootstrapSwitch('state',Records.Status);
                var dataMenu = res.Data.Records[0].Menu;
                var newRecords = [];
                for (var d in dataMenu){
                    newRecords.push({
                        "id": dataMenu[d].Menuid,
                        "Title": dataMenu[d].Menuname,
                        "parentId": dataMenu[d].Parent == ""?null:dataMenu[d].Parent,
                        "Enable": dataMenu[d].Enable,
                        "Haschild": dataMenu[d].Haschild,
                        "Url": dataMenu[d].Url,
                        "Checkall": dataMenu[d].Checkall,
                        "Access": dataMenu[d].Access,
                        "Create": dataMenu[d].Create,
                        "Edit": dataMenu[d].Edit,
                        "Delete": dataMenu[d].Delete,
                        "View": dataMenu[d].View,
                        "Approve": dataMenu[d].Approve,
                        "Process": dataMenu[d].Process
                    });
                }
                rolesett.GetDataMenu(newRecords);
            }else{
                return swal("Error!", res.Message, "error");
            }
    }); 
}

rolesett.DeleteData = function(RoleName, IdRole){
    var url = "/sysroles/deleterole";
    var param = {
            Id : IdRole,
            RoleName : RoleName
        }
    swal({
            title: "Are you sure?",
            text: "Are you sure remove this role!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: '#DD6B55',
            confirmButtonText: 'Yes, I am sure!',
            cancelButtonText: "No, cancel it!",
            closeOnConfirm: false,
            closeOnCancel: false
        },
        function(isConfirm) {
            if (isConfirm) {
                ajaxPost(url, param, function(data){
                    if (data.IsError == false){
                        rolesett.Cancel();
                        rolesett.Reset();
                        rolesett.getRole();
                        swal("Success!",data.Message,"success");
                    }else{
                        swal("Error!",data.Message,"error");
                    }
                });
            } else {
                swal("Cancelled", "Cancelled Delete Menu", "error");
            }
        });
}

rolesett.Cancel = function(){
    $("#roleModal").modal("hide");
    $("#nav-dex").css('z-index', 'none');
}

rolesett.filterRole.subscribe(function(value){
  if(model.View() != "false"){
   rolesett.GetDataRole();
  }
});

rolesett.GetDataRole = function(){
    rolesett.loading(false);
    var param =  {
        "Name" : rolesett.filterRole(),
        "Status" : $('#filterStatus').bootstrapSwitch('state')
    };
    var dataSource = [];
    var url = "/sysroles/getdata";
    $("#MasterGridRole").html("");
    $("#MasterGridRole").kendoGrid({
            dataSource: {
                    transport: {
                        read: {
                            url: url,
                            data: param,
                            dataType: "json",
                            type: "POST",
                            contentType: "application/json",
                        },
                        parameterMap: function(data) {                                 
                           return JSON.stringify(data);                                 
                        },
                    },
                    schema: {
                        data: function(data) {
                            rolesett.loading(false);
                            if (data.Data.Count == 0) {
                                return dataSource;
                            } else {
                                return data.Data.Records;
                            }
                        },
                        total: function(data){
                            if (data.Data.Count == 0) {
                                return 0;
                            } else {
                                return data.Data.Records.length;
                            }
                        },
                    },
                    pageSize: 15,
                    serverPaging: true,
                    serverSorting: true,
                },
                resizable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
                columnMenu: false,
            columns: [
                {
                    field:"Name",
                    title:"Role Name",
                    width:150,
                },
                {
                    field:"Status",
                    title:"Status",
                    width:50

                },
                {
                    field:"",
                    title:"Action",
                    width:20,
                    attributes: {
                        style: "text-align: center;"
                    },
                    // attributes: {"class": "align-center"},
                     template: function (d) {
                            return [
                                "<button onclick='rolesett.DeleteData(\"" + d.Name + "\", \"" + d.Id + "\")' name='delete' type='button' class='btn btn-danger btn-xs tooltipster' title='Delete Rele'><span class='fa fa-times'></span></button>",
                                "<button onclick='rolesett.EditData(\"" + d.Id + "\")' name='delete' type='button' class='btn btn-info btn-xs tooltipster' title='Edit Role'><span class='fa fa-pencil-square-o'></span></button>",
                            ].join(" ");
                        }
                }],
                dataBound: function () {
                    $("#MasterGridRole").find(".tooltipster").tooltipster({
                          trigger: 'hover',
                          theme: 'tooltipster-val',
                          animation: 'grow',
                          delay: 0,
                      });

                    $(".k-header-column-menu").kendoTooltip({
                        content: "column menu"
                    });
                }
    });
}

rolesett.getTopMenu = function(){
    var param = {
    }
    var url = "/sysroles/getmenu";
    ajaxPost(url, param, function(res){
        if(res.IsError != true){
            var dataMenu = res.Data.Records;
            var newRecords = [];
            for (var d in dataMenu){
                newRecords.push({
                    "id": dataMenu[d].Id,
                    "Title": dataMenu[d].Title,
                    "parentId": dataMenu[d].Parent == ""?null:dataMenu[d].Parent,
                    "Enable": dataMenu[d].Enable,
                    "Haschild": dataMenu[d].Haschild,
                    "IndexMenu": dataMenu[d].IndexMenu,
                    "PageId": dataMenu[d].PageId,
                    "Url": dataMenu[d].Url,
                    "Checkall": false,
                    "Access": false,
                    "Create": false,
                    "Edit": false,
                    "Delete": false,
                    "View": false,
                    "Approve": false,
                    "Process": false
                });
            }
            rolesett.GetDataMenu(newRecords);
        }else{
            return swal("Error!", res.Message, "error");
        }
    });
}

rolesett.GetDataMenu = function(e){
    var myData = new kendo.data.TreeListDataSource({
        data: e,
        schema: {
            model: {
                id: "id",
                expanded: true
            }
        }
    });
    
    if ($("#MasterGridMenu").data("kendoTreeList") !== undefined) {
      $("#MasterGridMenu").data("kendoTreeList").setDataSource(myData);
      return;
    }

    $("#MasterGridMenu").kendoTreeList({
         dataSource: myData,
         height: 400,
         columns: [
            { 
                field: "Title",
                title:"Title", 
                width: 200 
            },
            { 
                field:"Checkall",
                title:"Check All", 
                width: 70,
                attributes:{"class": "align-center"},
                template: "#if(parentId != '' || Haschild == false){#<input id='check-all-new#:id#' class='rolecheck-value-check-all' type='checkbox' onclick='rolesett.Checkall(#:id#)' #: Checkall==true ? 'checked' : '' #/>#}#"
            },
            {
                field:"Access",
                title:"Access",
                width:70,
                attributes: {"class": "align-center"},
                template:"#if(parentId != '' || Haschild == false){#<input id='check-Access-#:id #' class='rolecheck-value-Access' onclick='rolesett.unCheck(#:id#)' type='checkbox' #: Access==true ? 'checked' : '' #/>#}#"              
            },
            {
                field:"Create",
                title:"Create",
                width:70,
                attributes: {"class": "align-center"},
                template:"#if(parentId != '' || Haschild == false){#<input id='check-Create-#:id #' class='rolecheck-value-Create' onclick='rolesett.unCheck(#:id#)' type='checkbox' #: Create==true ? 'checked' : '' #/>#}#"              
            },
            {
                field:"Edit",
                title:"Edit",
                width:70,
                attributes: {"class": "align-center"},
                template:"#if(parentId != '' || Haschild == false){#<input id='check-Edit-#:id #' class='rolecheck-value-Edit' onclick='rolesett.unCheck(#:id#)' type='checkbox' #: Edit==true ? 'checked' : '' #/>#}#"  
            },
            {
                field:"Delete",
                title:"Delete",
                width:70,
                attributes: {"class": "align-center"},
                template:"#if(parentId != '' || Haschild == false){#<input id='check-Delete-#:id #' class='rolecheck-value-Delete' onclick='rolesett.unCheck(#:id#)' type='checkbox' #: Delete==true ? 'checked' : '' #/>#}#"
            },
            {
                field:"View",
                title:"View",
                width:70,
                attributes: {"class": "align-center"},
                template:"#if(parentId != '' || Haschild == false){#<input id='check-View-#:id #' class='rolecheck-value-View' onclick='rolesett.unCheck(#:id#)' type='checkbox' #: View==true ? 'checked' : '' #/>#}#"
            },
            {
                field:"Approve",
                title:"Approve",
                width:70,
                attributes: {"class": "align-center"},
                template:"#if(parentId != '' || Haschild == false){#<input id='check-Approve-#:id #' class='rolecheck-value-Approve' onclick='rolesett.unCheck(#:id#)' type='checkbox' #: Approve==true ? 'checked' : '' #/>#}#"
            },
            {
                field:"Process",
                title:"Process",
                width:70,
                attributes: {"class": "align-center"},
                template:"#if(parentId != '' || Haschild == false){#<input id='check-Process-#:id #' class='rolecheck-value-Process' onclick='rolesett.unCheck(#:id#)' type='checkbox' #: Process==true ? 'checked' : '' #/>#}#"
            }
         ],

    });  
}

rolesett.Getlanding = function(){
    var url = "/sysroles/getlanding";
    rolesett.listlanding([]);
    var param = {
        }
        ajaxPost(url, param, function(res){
            var listMenu = res.Data.Records;
            if(res.IsError != true){
                for (var i in listMenu){
                    rolesett.listlanding.push({
                        text : listMenu[i].Title,
                        value : listMenu[i].Title,
                    });
                }
                rolesett.landingUrl(rolesett.listlanding()[0].value);
            }
    });  
}

rolesett.unCheck = function(Menuid){
    if(!$("#check-Access-"+Menuid).prop('checked') || !$("#check-Create-"+Menuid).prop('checked') || !$("#check-Edit-"+Menuid).prop('checked') || !$("#check-Delete-"+Menuid).prop('checked') || !$("#check-View-"+Menuid).prop('checked') || !$("#check-Approve-"+Menuid).prop('checked') || !$("#check-Process-"+Menuid).prop('checked')){
        $('#check-all'+Menuid).prop('checked', false);
        $('#check-all-new'+Menuid).prop('checked', false);
    }else if($("#check-Access-"+Menuid).prop('checked') == true && $("#check-Create-"+Menuid).prop('checked')== true && $("#check-Edit-"+Menuid).prop('checked') == true && $("#check-Delete-"+Menuid).prop('checked') == true && $("#check-View-"+Menuid).prop('checked') == true && $("#check-Approve-"+Menuid).prop('checked') == true && $("#check-Process-"+Menuid).prop('checked') == true){
        $('#check-all'+Menuid).prop('checked', true);
        $('#check-all-new'+Menuid).prop('checked', true); 
    }
}

rolesett.Checkall = function(Menuid){
    $('#check-all-new'+Menuid).change(function(){
        $("#check-Access-"+Menuid).prop('checked', $(this).prop('checked'));
        $("#check-Create-"+Menuid).prop('checked', $(this).prop('checked'));
        $("#check-Edit-"+Menuid).prop('checked', $(this).prop('checked'));
        $("#check-Delete-"+Menuid).prop('checked', $(this).prop('checked'));
        $("#check-View-"+Menuid).prop('checked', $(this).prop('checked'));
        $("#check-Approve-"+Menuid).prop('checked', $(this).prop('checked'));
        $("#check-Process-"+Menuid).prop('checked', $(this).prop('checked'));
    });
}

rolesett.getRole = function(){
    var param = {
    }
    var url = "/databrowser/getroles";
    rolesett.listRole([]);
    ajaxPost(url, param, function(res){
        var dataRole = Enumerable.From(res).OrderBy("$.name").ToArray();
        for (var r in dataRole){
            rolesett.listRole.push({
                "text" : dataRole[r].name,
                "value" : dataRole[r].name,
            });
        }
    });
}

rolesett.toggleFilter = function(){
  var panelFilter = $('.panel-filter');
  var panelContent = $('.panel-content');

  if (panelFilter.is(':visible')) {
    panelFilter.hide();
    panelContent.attr('class', 'col-md-12 col-sm-12 ez panel-content');
    $('.breakdown-filter').removeAttr('style');
  } else {
    panelFilter.show();
    panelContent.attr('class', 'col-md-9 col-sm-9 ez panel-content');
    //panelContent.css('margin-top', '1.3%');
    $('.breakdown-filter').css('width', '60%');
  }

  $('.k-grid').each(function (i, d) {
    try {
      $(d).data('kendoGrid').refresh();
    } catch (err) {}
  });

  $('.k-pivot').each(function (i, d) {
    $(d).data('kendoPivotGrid').refresh();
  });

  $('.k-chart').each(function (i, d) {
    $(d).data('kendoChart').redraw();
  });
  rolesett.panel_relocated();
}

rolesett.panel_relocated = function(){
  if ($('.panel-yo').size() == 0) {
    return;
  }

  var window_top = $(window).scrollTop();
  var div_top = $('.panel-yo').offset().top;
  if (window_top > div_top) {
    $('.panel-fix').css('width', $('.panel-yo').width());
    $('.panel-fix').addClass('contentfilter');
    $('.panel-yo').height($('.panel-fix').outerHeight());
  } else {
    $('.panel-fix').removeClass('contentfilter');
    $('.panel-yo').height(0);
  }
}

rolesett.getLandingPage = function(){
    var param = {
    }
    var url = "/sysroles/getlandingpage";
    rolesett.listPage([]);
    ajaxPost(url, param, function(res){
        var dataPage = Enumerable.From(res).OrderBy("$.Title").ToArray();
        for (var u in dataPage){
            rolesett.listPage.push({
                "text" : dataPage[u].Title,
                "value" : dataPage[u].Title,
            });
        }
    });
}

$(document).ready(function (){ 
    $("#lastDateData").css({"display":"none"});
    $('#filterStatus').bootstrapSwitch('state',true);
    rolesett.getRole();
    rolesett.GetDataRole();
    rolesett.getLandingPage();
    rolesett.Getlanding();
});