var tv = {}
tv.Processing = ko.observable(false)
tv.segmentList = ko.observableArray(["Local Corporates","Middle Markets","Medium Enterprise","HVSB"])
// tv.segmentList = ko.observableArray([])
tv.monthList = ko.observableArray([])
tv.dataList = ko.observableArray([])
tv.totalList = ko.observableArray([])
tv.inputdata = ko.observable('')
tv.callreportList = ko.observableArray([])
tv.crsegment = ko.observable('')
tv.crrm = ko.observable()
tv.crclient = ko.observable()
tv.arrayList = ko.observableArray([])
tv.expand = ko.observable(true)
tv.average = ko.observableArray([])

tv.dealmonthList = ko.observableArray([])
tv.dealdataList = ko.observableArray([])
tv.dealtotalList = ko.observableArray([])
tv.dealpipelineList = ko.observableArray([])
tv.dpsegment = ko.observable('')
tv.avgdealsnumber = ko.observable()
tv.avgdealssize = ko.observable()
tv.prctstaledeals = ko.observable()
tv.rmwithnodeal = ko.observable()
tv.dealarrayList = ko.observableArray([])
tv.dealexpand = ko.observable(true)
tv.dealaverage = ko.observableArray([])

tv.accountmonthList = ko.observableArray([])
tv.accountdataList = ko.observableArray([])
tv.accounttotalList = ko.observableArray([])
tv.accountplanList = ko.observableArray([])
tv.apsegment = ko.observable('')
tv.averageperrm = ko.observable()
tv.clientofforecast = ko.observable()
tv.accountarrayList = ko.observableArray([])
tv.accountexpand = ko.observable(true)
tv.accountaverage = ko.observableArray([])


tv.GetData = function(){
	tv.average([])
 	tv.Processing(true)

	var payload = {
		Country : '',
		Region : '',
		Department : tv.inputdata(),
		StartDateString: kendo.toString(new Date(filter.StartStr()), "dd-MMM-yyyy"),
		EndDateString: kendo.toString(new Date(filter.FinishStr()), "dd-MMM-yyyy"),
	}
	ajaxPost("/dashboard/teamviewcallreport", payload, function(res){
  		// var datas = [];
        // $.each(res.Data.data, function(i,v){
        //     datas.push(v)
        // });
        tv.dataList(res.Data.data);
        // tv.segmentList(_.sortBy(_.uniq(res.Data.totalSegment, 'Segment'), 'Segment').reverse())
        tv.monthList(_.sortBy(res.Data.period, 'Date'))
        tv.totalList(res.Data.totalSegment);
    	tv.Processing(false)
 	})

 	// tv.getGlobalSegmentChart()
 	tv.getNoCallsRM()
	tv.getRMsCreatedCall()
	tv.getClientsCalled()
 	tv.GetCallReportData()
 	tv.GetCallReportRMWithNoCallData()
	tv.GetCallReportClientWithNoCallData()
}
tv.getDetail = function(manager, managerid){
	var man = manager.replace(/[^a-zA-Z ]/g, '').replace(/\s/g, '');
	var id = man + managerid
	$( '#'+id ).slideToggle( "slow" )
}
tv.order = function(totals){
	// var month = ['01','02','03','04','05','06','07','08','09','10', '11'];
	var datas = [];

	// _.each(month, function(d){
	_.each(tv.monthList(), function(d){
		// var MonthYear = parseInt("2017" + d); 
		var MonthYear = d.YearMonth; 
		var date = _.findWhere(totals, {MonthYear : MonthYear });
		if(date == undefined)
			datas.push({MonthYear: MonthYear, CallTotal:0, MonthAverage:0});
		else	
			datas.push(date)
	});
	return datas
}
tv.groupOrder = function(details){ 
	var details = _.groupBy(details, 'RMName'); 
	var data = [];
	var index = 0;
	_.each(details, function(e,i){

 		var d = { RMName: i, RMID: 10, Total:[] };
 	 	var details = [];
 		var rmid = "";
 		_.each(e, function(d,i){ 
 			if(i == 0){
				rmid = d.RMID;
 			}
 			details.push({
 				MonthYear: d.MonthYear,
 				CallTotal: d.CallNumber,
 			});
 		});
 		d.RMID = rmid;
 		d.Total = details;
		data.push(d);
 		index++;
	});
	return data;
}
tv.totalsegmentOrder = function(segment){
	var segment = _.groupBy(segment, 'Segment');
	// var month = ['01','02','03','04','05','06','07','08','09','10', '11'];
	var datas = [];	
	var lists = [];
	_.each(segment, function(d){
		_.each(d, function(e){

		});
		lists.push(d)
		_.each(tv.monthList(), function(f){
			var MonthYear = f.YearMonth;
			var date = _.findWhere(d, {MonthYear : MonthYear });
			if(date == undefined)
				datas.push({Segment:"", MonthYear: MonthYear, CallNumber:0});
			else	
				datas.push(date)
		});
	});
	return datas
}
tv.GetCallReportData = function(){
	var payload = {
		Country : '',
		Region : '',
		Segment : tv.crsegment(),
		StartDateString: kendo.toString(new Date(filter.StartStr()), "dd-MMM-yyyy"),
		EndDateString: kendo.toString(new Date(filter.FinishStr()), "dd-MMM-yyyy"),
	}
	ajaxPost("/dashboard/top10callreport", payload, function(res){
        tv.callreportList(res.Data.data);
		tv.arrayList([0, 1, 2, 3, 4])
 	})
}
tv.viewMore = function(){
	if (!tv.expand()) {
		tv.expand(true)
		tv.arrayList([0, 1, 2, 3, 4])
	}else{
		tv.expand(false)
		tv.arrayList([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
	}
}
tv.changecrsegment = function(segment){
	return function(){
		if (segment == 'LC'){
			$('.btn-crsegment').removeClass('btn-selected')
			$('#LC').addClass('btn-selected')
			tv.crsegment('LC')
			tv.GetCallReportData()
		}else if (segment == 'MM'){
			$('.btn-crsegment').removeClass('btn-selected')
			$('#MM').addClass('btn-selected')
			tv.crsegment('MM')
			tv.GetCallReportData()
		}else if (segment == 'ME'){
			$('.btn-crsegment').removeClass('btn-selected')
			$('#ME').addClass('btn-selected')
			tv.crsegment('ME')
			tv.GetCallReportData()
		}else if (segment == 'HVSB'){
			$('.btn-crsegment').removeClass('btn-selected')
			$('#HVSB').addClass('btn-selected')
			tv.crsegment('HVSB')
			tv.GetCallReportData()
		}else{
			$('.btn-crsegment').removeClass('btn-selected')
			$('#Total').addClass('btn-selected')
			tv.crsegment('')
			tv.GetCallReportData()
		}
	}
}
tv.GetCallReportRMWithNoCallData = function(){
	ajaxPost("/dashboard/callreportrmwithnocall", {}, function(res){
        tv.crrm(res.Data.data);
 	})
}
tv.GetCallReportClientWithNoCallData = function(){
	ajaxPost("/dashboard/callreportclientwithnocall", {}, function(res){
        tv.crclient(res.Data.data);
 	})
}
tv.changeview = function(view){
	return function(){
		if (view == 'CB'){
			$('.btn-view').removeClass('btn-viewed')
			$('#CB').addClass('btn-viewed')
			tv.inputdata('CB')
			tv.GetData()
		}else if (view == 'Product Partner'){
			$('.btn-view').removeClass('btn-viewed')
			$('#PP').addClass('btn-viewed')
			tv.inputdata('Product Partner')
			tv.GetData()
		}else{
			$('.btn-view').removeClass('btn-viewed')
			$('#All').addClass('btn-viewed')
			tv.inputdata('')
			tv.GetData()
		}
	}
}
tv.getGlobalSegmentChart = function(){
	// $("#LocalCorporates").kendoChart({
	//   legend: {
	//   	visible: false
	//   },
	//   chartArea: {
	//     height: 80
	//   },
	//   seriesDefaults: {
	//     type: "bar",
	//     overlay: {
	// 		gradient: "none"
	// 	},
 //    	gap: 0.5,
	//   },
	//   series: [{
	// 	name: "Global Avg",
	// 	data:[2],
	// 	// categoryField: "_id",
	// 	// field: "Count",
	// 	color: "#71D4EF",

	// },{
	// 	name: "Segment Avg",
 //        data: [1],
 //     	// field: "Count",
 //        color: "#0097C9",
 //    }],
	//   categoryAxis: {
	//     categories: ["Jan", "Feb"],
	//     line: {
	//       visible: false
	//     },
	//     majorGridLines: {
	//       visible: false
	//     }
	//   },
	//   valueAxis: {
	//     labels:{
	//       visible: false
	//     },
	//     line: {
	//       visible: false
	//     },
	//     majorGridLines: {
	//       visible: false
	//     },
	//   }
	// });

	// $("#MiddleMarkets").kendoChart({
	//   chartArea: {
	//     height: 80
	//   },
	//   seriesDefaults: {
	//     type: "bar",
	//     overlay: {
	// 		gradient: "none"
	// 	},
 //    	gap: 0.5,
	//   },
	//   series: [ {
	//     labels: {
	//       visible: true
	//     },
	//     data: [1, 2]
	//   }],
	//   categoryAxis: {
	//     categories: ["Jan", "Feb"],
	//     line: {
	//       visible: false
	//     },
	//     majorGridLines: {
	//       visible: false
	//     }
	//   },
	//   valueAxis: {
	//     labels:{
	//       visible: false
	//     },
	//     line: {
	//       visible: false
	//     },
	//     majorGridLines: {
	//       visible: false
	//     },
	//   }
	// });

	// $("#MediumEnterprise").kendoChart({
	//   chartArea: {
	//     height: 80
	//   },
	//   seriesDefaults: {
	//     type: "bar",
	//     overlay: {
	// 		gradient: "none"
	// 	},
 //    	gap: 0.5,
	//   },
	//   series: [ {
	//     labels: {
	//       visible: true
	//     },
	//     data: [1, 2]
	//   }],
	//   categoryAxis: {
	//     categories: ["Jan", "Feb"],
	//     line: {
	//       visible: false
	//     },
	//     majorGridLines: {
	//       visible: false
	//     }
	//   },
	//   valueAxis: {
	//     labels:{
	//       visible: false
	//     },
	//     line: {
	//       visible: false
	//     },
	//     majorGridLines: {
	//       visible: false
	//     },
	//   }
	// });
}
tv.getNoCallsRM = function(){
	var payload = {
		Country : '',
		Region : '',
		Segment : tv.crsegment(),
		StartDateString: kendo.toString(new Date(filter.StartStr()), "dd-MMM-yyyy"),
		EndDateString: kendo.toString(new Date(filter.FinishStr()), "dd-MMM-yyyy"),
	}
	ajaxPost("/dashboard/noofcallsperrm", payload, function(res){
        $.each(res.Data.dataaverage, function(i,v){
	       tv.average().push(kendo.toString(v, 'N0'))
	  	})
		$("#nocallsrm").kendoChart({
	        title: {
	            text: "No of Calls per RM"
	        },
	        legend: {
	            visible: true,
	          	position: 'top'
	        },
	    	chartArea: {
				width:400
			},
	        seriesDefaults: {
	            stack: true,
	          	overlay:{
	              gradient: "none"
	                },
	        },
	        series: [{
	            type: "line",
	            markers: {
	              visible: true,
	              background: "#666"
	            },
	            data: tv.average(),
	            name: "Average",
	            color: "#666",
	            axis: "average"
	        },{
	            name: "Local Corporates",
	            data: res.Data.datatotal.LC,
	            color: "#0097C9",
	            axis: "temp"
	        }, {
	            name: "Middle Markets",
	            data: res.Data.datatotal.MM,
	            color: "#71D4EF",
	            axis: "temp"
	        }, {
	            name: "Middle Enterprise",
	            data: res.Data.datatotal.ME,
	            color: "#4CA841",
	            axis: "temp"
	        }, {
	            name: "HVSB",
	            data: res.Data.datatotal.HVSB,
	            color: "#7DCA37",
	            axis: "temp"
	        }],
          	valueAxes: [{
            	name: "average",
	            line: {
	                visible: false
	            },
	            majorGridLines: {
	                visible: false
	            },
	            minorGridLines: {
	                visible: false
	            }
          	},{
            	name: "temp",
	            line: {
	                visible: false
	            },
	            majorGridLines: {
	                visible: false
	            },
	            minorGridLines: {
	                visible: false
	            }
          	}],
	        categoryAxis: {
	            categories: res.Data.series,
	            axisCrossingValues: [32,0],
                labels: {
	                rotation: -50,
	            },
	            line: {
	                visible: false
	            },
	            majorGridLines: {
	                visible: false
	            },
	            minorGridLines: {
	                visible: false
	            }
	        },
	        tooltip: {
	            visible: true,
	            template: "#= series.name #: #= value #"
	        }
	    });
 	})
}
tv.getRMsCreatedCall = function(){
	var payload = {
		Country : '',
		Region : '',
		Segment : tv.crsegment(),
		StartDateString: kendo.toString(new Date(filter.StartStr()), "dd-MMM-yyyy"),
		EndDateString: kendo.toString(new Date(filter.FinishStr()), "dd-MMM-yyyy"),
	}
	ajaxPost("/dashboard/rmcreatedcalls", payload, function(res){
		$("#rmcreatedcall").kendoChart({
	        title: {
	            text: "% of RMs who created calls"
	        },
	        legend: {
	            visible: true,
	          	position: 'top'
	        },
	    	chartArea: {
				width:400
			},
	        seriesDefaults: {
	            stack: true,
	          	overlay:{
	              gradient: "none"
	                },
	        },
	        series: [{
	            name: "Local Corporates",
	            data: res.Data.otputrm.LC,
	            color: "#0097C9"
	        }, {
	            name: "Middle Markets",
	            data: res.Data.otputrm.MM,
	            color: "#71D4EF"
	        }, {
	            name: "Middle Enterprise",
	            data: res.Data.otputrm.ME,
	            color: "#4CA841"
	        }, {
	            name: "HVSB",
	            data: res.Data.otputrm.HVSB,
	            color: "#7DCA37"
	        },{
	            data: res.Data.outputprct,
	            color: "#fff",
	            border: {
	                width: 0,
	            },
				labels: {	
				 	position:"insideBase",
				 	template: function(e){
	                 	return kendo.toString(e.dataItem, 'P0')
	                },
	                visible: true
	            },
	            tooltip: {
		            visible: false,
		        }
	        }],
	        valueAxis: {
	            line: {
	                visible: false
	            },
	            majorGridLines: {
	                visible: false
	            },
	            minorGridLines: {
	                visible: false
	            }
	        },
	        categoryAxis: {
	            categories: res.Data.series,
                labels: {
	                rotation: -50,
	            },
	            line: {
	                visible: false
	            },
	            majorGridLines: {
	                visible: false
	            },
	            minorGridLines: {
	                visible: false
	            }
	        },
	        tooltip: {
	            visible: true,
	            template: "#= series.name #: #= value #"
	        }
	    });
 	})
}
tv.getClientsCalled = function(){
	var payload = {
		Country : '',
		Region : '',
		Segment : tv.crsegment(),
		StartDateString: kendo.toString(new Date(filter.StartStr()), "dd-MMM-yyyy"),
		EndDateString: kendo.toString(new Date(filter.FinishStr()), "dd-MMM-yyyy"),
	}
	ajaxPost("/dashboard/calledclient", payload, function(res){
		$("#clientscalled").kendoChart({
	        title: {
	            text: "% of clients called"
	        },
	        legend: {
	            visible: true,
	          	position: 'top'
	        },
	    	chartArea: {
				width:400
			},
	        seriesDefaults: {
	            stack: true,
	          	overlay:{
	              gradient: "none"
	                },
	        },
	        series: [{
	            name: "Local Corporates",
	            data: res.Data.outputdata.LC,
	            color: "#0097C9"
	        }, {
	            name: "Middle Markets",
	            data: res.Data.outputdata.MM,
	            color: "#71D4EF"
	        }, {
	            name: "Middle Enterprise",
	            data: res.Data.outputdata.ME,
	            color: "#4CA841"
	        }, {
	            name: "HVSB",
	            data: res.Data.outputdata.HVSB,
	            color: "#7DCA37"
	        },{
	            data: res.Data.outputprct,
	            color: "#fff",
	            border: {
	                width: 0,
	            },
				labels: {	
				 	position:"insideBase",
				 	template: function(e){
	                 	return kendo.toString(e.dataItem, 'P0')
	                },
	                visible: true
	            },
	            tooltip: {
		            visible: false,
		        }
	        }],
	        valueAxis: {
	            line: {
	                visible: false
	            },
	            majorGridLines: {
	                visible: false
	            },
	            minorGridLines: {
	                visible: false
	            }
	        },
	        categoryAxis: {
	            categories: res.Data.series,
                labels: {
	                rotation: -50,
	            },
	            line: {
	                visible: false
	            },
	            majorGridLines: {
	                visible: false
	            },
	            minorGridLines: {
	                visible: false
	            }
	        },
	        tooltip: {
	            visible: true,
	            template: "#= series.name #: #= value #"
	        }
	    });
 	})
}
tv.excelProcess = function(){
 	tv.Processing(true)
	
	var payload = {
		Country : '',
		Region : '',
		Department : tv.inputdata(),
		StartDateString: kendo.toString(new Date(filter.StartStr()), "dd-MMM-yyyy"),
		EndDateString: kendo.toString(new Date(filter.FinishStr()), "dd-MMM-yyyy"),
		GenExcel : true,
	}

	ajaxPost("/dashboard/teamviewcallreport", payload, function(res){
        window.location.href = res.Data.filepath
    	tv.Processing(false)
	})
}

tv.GetPipelineData = function(){
	tv.dealaverage([])
 	tv.Processing(true)

	var payload = {
		Country : '',
		Region : '',
		StartDateString: kendo.toString(new Date(filter.StartStr()), "dd-MMM-yyyy"),
		EndDateString: kendo.toString(new Date(filter.FinishStr()), "dd-MMM-yyyy"),
	}
	ajaxPost("/dashboard/teamviewdealpipeline", payload, function(res){
        tv.dealdataList(res.Data.data);
        tv.dealmonthList(_.sortBy(res.Data.period, 'Date'))
        tv.dealtotalList(res.Data.totalSegment);
    	tv.Processing(false)
 	})

	tv.getNoDealsRM()
	tv.getRMsCreatedDeal()
 	tv.GetDealPipelineData()
 	tv.GetDealBottomBox()
}
tv.getDealDetail = function(manager, managerid){
	var man = manager.replace(/[^a-zA-Z ]/g, '').replace(/\s/g, '');
	var id = man + managerid
	$( '#'+id+'2' ).slideToggle( "slow" )
}
tv.dealorder = function(totals){
	var datas = [];

	_.each(tv.dealmonthList(), function(d){
		var MonthYear = d.YearMonth; 
		var date = _.findWhere(totals, {MonthYear : MonthYear });
		if(date == undefined)
			datas.push({MonthYear: MonthYear, DealTotal:0, MonthAverage:0});
		else	
			datas.push(date)
	});
	return datas
}
tv.dealgroupOrder = function(details){ 
	var details = _.groupBy(details, 'RMName'); 
	var data = [];
	var index = 0;
	_.each(details, function(e,i){

 		var d = { RMName: i, RMID: 10, Total:[] };
 	 	var details = [];
 		var rmid = "";
 		_.each(e, function(d,i){ 
 			if(i == 0){
				rmid = d.RMID;
 			}
 			details.push({
 				MonthYear: d.MonthYear,
 				DealTotal: d.DealNumber,
 			});
 		});
 		d.RMID = rmid;
 		d.Total = details;
		data.push(d);
 		index++;
	});
	return data;
}
tv.dealtotalsegmentOrder = function(segment){
	var segment = _.groupBy(segment, 'Segment');
	var datas = [];	
	var lists = [];
	_.each(segment, function(d){
		_.each(d, function(e){

		});
		lists.push(d)
		_.each(tv.dealmonthList(), function(f){
			var MonthYear = f.YearMonth;
			var date = _.findWhere(d, {MonthYear : MonthYear });
			if(date == undefined)
				datas.push({Segment:"", MonthYear: MonthYear, DealNumber:0});
			else	
				datas.push(date)
		});
	});
	return datas
}
tv.GetDealPipelineData = function(){
	var payload = {
		Country : '',
		Region : '',
		Segment : tv.dpsegment(),
		StartDateString: kendo.toString(new Date(filter.StartStr()), "dd-MMM-yyyy"),
		EndDateString: kendo.toString(new Date(filter.FinishStr()), "dd-MMM-yyyy"),
	}
	ajaxPost("/dashboard/top10dealpipeline", payload, function(res){
        tv.dealpipelineList(res.Data.data);
		tv.dealarrayList([0, 1, 2, 3, 4])
 	})
}
tv.viewMoreDeal = function(){
	if (!tv.dealexpand()) {
		tv.dealexpand(true)
		tv.dealarrayList([0, 1, 2, 3, 4])
	}else{
		tv.dealexpand(false)
		tv.dealarrayList([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
	}
}
tv.changedpsegment = function(segment){
	return function(){
		if (segment == 'LC'){
			$('.btn-dpsegment').removeClass('btn-selected')
			$('#dpLC').addClass('btn-selected')
			tv.dpsegment('LC')
			tv.GetDealPipelineData()
		}else if (segment == 'MM'){
			$('.btn-dpsegment').removeClass('btn-selected')
			$('#dpMM').addClass('btn-selected')
			tv.dpsegment('MM')
			tv.GetDealPipelineData()
		}else if (segment == 'ME'){
			$('.btn-dpsegment').removeClass('btn-selected')
			$('#dpME').addClass('btn-selected')
			tv.dpsegment('ME')
			tv.GetDealPipelineData()
		}else if (segment == 'HVSB'){
			$('.btn-dpsegment').removeClass('btn-selected')
			$('#dpHVSB').addClass('btn-selected')
			tv.dpsegment('HVSB')
			tv.GetDealPipelineData()
		}else{
			$('.btn-dpsegment').removeClass('btn-selected')
			$('#dpTotal').addClass('btn-selected')
			tv.dpsegment('')
			tv.GetDealPipelineData()
		}
	}
}
tv.GetDealBottomBox = function(){
	var payload = {
		Country : '',
		Region : '',
		Segment : tv.dpsegment(),
		StartDateString: kendo.toString(new Date(filter.StartStr()), "dd-MMM-yyyy"),
		EndDateString: kendo.toString(new Date(filter.FinishStr()), "dd-MMM-yyyy"),
	}
	ajaxPost("/dashboard/avgdealsandsizeperrm", payload, function(res){
        tv.avgdealsnumber(res.Data.avgdealsnumber);
        tv.avgdealssize(res.Data.avgdealssize);
        tv.prctstaledeals(res.Data.prctstaledeals);
        tv.rmwithnodeal(res.Data.rmwithnodeal);
 	})
}
tv.getNoDealsRM = function(){
	var payload = {
		Country : '',
		Region : '',
		Segment : tv.dpsegment(),
		StartDateString: kendo.toString(new Date(filter.StartStr()), "dd-MMM-yyyy"),
		EndDateString: kendo.toString(new Date(filter.FinishStr()), "dd-MMM-yyyy"),
	}
	ajaxPost("/dashboard/noofdealsperrm", payload, function(res){
        $.each(res.Data.dataaverage, function(i,v){
	       tv.dealaverage().push(kendo.toString(v, 'N0'))
	  	})
		$("#nodealsrm").kendoChart({
	        title: {
	            text: "No of Deals per RM"
	        },
	        legend: {
	            visible: true,
	          	position: 'top'
	        },
	    	chartArea: {
				width:400
			},
	        seriesDefaults: {
	            stack: true,
	          	overlay:{
	              gradient: "none"
	                },
	        },
	        series: [{
	            type: "line",
	            markers: {
	              visible: true,
	              background: "#666"
	            },
	            data: tv.average(),
	            name: "Average",
	            color: "#666",
	            axis: "average"
	        },{
	            name: "Local Corporates",
	            data: res.Data.datatotal.LC,
	            color: "#0097C9",
	            axis: "temp"
	        }, {
	            name: "Middle Markets",
	            data: res.Data.datatotal.MM,
	            color: "#71D4EF",
	            axis: "temp"
	        }, {
	            name: "Middle Enterprise",
	            data: res.Data.datatotal.ME,
	            color: "#4CA841",
	            axis: "temp"
	        }, {
	            name: "HVSB",
	            data: res.Data.datatotal.HVSB,
	            color: "#7DCA37",
	            axis: "temp"
	        }],
          	valueAxes: [{
            	name: "average",
	            line: {
	                visible: false
	            },
	            majorGridLines: {
	                visible: false
	            },
	            minorGridLines: {
	                visible: false
	            }
          	},{
            	name: "temp",
	            line: {
	                visible: false
	            },
	            majorGridLines: {
	                visible: false
	            },
	            minorGridLines: {
	                visible: false
	            }
          	}],
	        categoryAxis: {
	            categories: res.Data.series,
	            axisCrossingValues: [32,0],
                labels: {
	                rotation: -50,
	            },
	            line: {
	                visible: false
	            },
	            majorGridLines: {
	                visible: false
	            },
	            minorGridLines: {
	                visible: false
	            }
	        },
	        tooltip: {
	            visible: true,
	            template: "#= series.name #: #= value #"
	        }
	    });
 	})
}
tv.getRMsCreatedDeal = function(){
	var payload = {
		Country : '',
		Region : '',
		Segment : tv.dpsegment(),
		StartDateString: kendo.toString(new Date(filter.StartStr()), "dd-MMM-yyyy"),
		EndDateString: kendo.toString(new Date(filter.FinishStr()), "dd-MMM-yyyy"),
	}
	ajaxPost("/dashboard/rmcreateddeals", payload, function(res){
		$("#rmcreateddeal").kendoChart({
	        title: {
	            text: "% of RMs who created deals"
	        },
	        legend: {
	            visible: true,
	          	position: 'top'
	        },
	    	chartArea: {
				width:400
			},
	        seriesDefaults: {
	            stack: true,
	          	overlay:{
	              gradient: "none"
	                },
	        },
	        series: [{
	            name: "Local Corporates",
	            data: res.Data.datatotal.LC,
	            color: "#0097C9"
	        }, {
	            name: "Middle Markets",
	            data: res.Data.datatotal.MM,
	            color: "#71D4EF"
	        }, {
	            name: "Middle Enterprise",
	            data: res.Data.datatotal.ME,
	            color: "#4CA841"
	        }, {
	            name: "HVSB",
	            data: res.Data.datatotal.HVSB,
	            color: "#7DCA37"
	        },{
	            data: res.Data.dataaverage,
	            color: "#fff",
	            border: {
	                width: 0,
	            },
				labels: {	
				 	position:"insideBase",
				 	template: function(e){
	                 	return kendo.toString(e.dataItem, 'P0')
	                },
	                visible: true
	            },
	            tooltip: {
		            visible: false,
		        }
	        }],
	        valueAxis: {
	            line: {
	                visible: false
	            },
	            majorGridLines: {
	                visible: false
	            },
	            minorGridLines: {
	                visible: false
	            }
	        },
	        categoryAxis: {
	            categories: res.Data.series,
                labels: {
	                rotation: -50,
	            },
	            line: {
	                visible: false
	            },
	            majorGridLines: {
	                visible: false
	            },
	            minorGridLines: {
	                visible: false
	            }
	        },
	        tooltip: {
	            visible: true,
	            template: "#= series.name #: #= value #"
	        }
	    });
	})
}

tv.GetPlanData = function(){
	tv.accountaverage([])
 	tv.Processing(true)

	var payload = {
		Country : '',
		Region : '',
		StartDateString: kendo.toString(new Date(filter.StartStr()), "dd-MMM-yyyy"),
		EndDateString: kendo.toString(new Date(filter.FinishStr()), "dd-MMM-yyyy"),
	}
	ajaxPost("/dashboard/teamviewaccountplan", payload, function(res){
        tv.accountdataList(res.Data.data);
        tv.accountmonthList(_.sortBy(res.Data.period, 'Date'))
        tv.accounttotalList(res.Data.totalSegment);
    	tv.Processing(false)
 	})

	tv.getPrctAccountPlanApproved()
 	tv.GetAccountPlanData()
 	tv.GetAPAvgAccountPlanPerRM()
	tv.GetAPClientBelow90Percent()
}
tv.getAccountDetail = function(manager, managerid){
	var man = manager.replace(/[^a-zA-Z ]/g, '').replace(/\s/g, '');
	var id = man + managerid
	$( '#'+id+'3' ).slideToggle( "slow" )
}
tv.accountorder = function(totals){
	var datas = [];

	_.each(tv.accountmonthList(), function(d){
		var MonthYear = d.YearMonth; 
		var date = _.findWhere(totals, {MonthYear : MonthYear });
		if(date == undefined)
			datas.push({MonthYear: MonthYear, AccTotal:0, MonthAverage:0});
		else	
			datas.push(date)
	});
	return datas
}
tv.accountgroupOrder = function(details){ 
	var details = _.groupBy(details, 'RMName'); 
	var data = [];
	var index = 0;
	_.each(details, function(e,i){

 		var d = { RMName: i, RMID: 10, Total:[] };
 	 	var details = [];
 		var rmid = "";
 		_.each(e, function(d,i){ 
 			if(i == 0){
				rmid = d.RMID;
 			}
 			details.push({
 				MonthYear: d.MonthYear,
 				AccTotal: d.AccNumber,
 			});
 		});
 		d.RMID = rmid;
 		d.Total = details;
		data.push(d);
 		index++;
	});
	return data;
}
tv.accounttotalsegmentOrder = function(segment){
	var segment = _.groupBy(segment, 'Segment');
	var datas = [];	
	var lists = [];
	_.each(segment, function(d){
		_.each(d, function(e){
		});
		lists.push(d)
		_.each(tv.accountmonthList(), function(f){
			var MonthYear = f.YearMonth;
			var date = _.findWhere(d, {MonthYear : MonthYear });
			if(date == undefined)
				datas.push({Segment:"", MonthYear: MonthYear, AccNumber:0});
			else	
				datas.push(date)
		});
	});
	return datas
}
tv.GetAccountPlanData = function(){
	var payload = {
		Country : '',
		Region : '',
		Segment : tv.apsegment(),
		StartDateString: kendo.toString(new Date(filter.StartStr()), "dd-MMM-yyyy"),
		EndDateString: kendo.toString(new Date(filter.FinishStr()), "dd-MMM-yyyy"),
	}
	ajaxPost("/dashboard/top10accountplan", payload, function(res){
        tv.accountplanList(res.Data.data);
		tv.accountarrayList([0, 1, 2, 3, 4])
 	})
}
tv.viewMoreAccount = function(){
	if (!tv.accountexpand()) {
		tv.accountexpand(true)
		tv.accountarrayList([0, 1, 2, 3, 4])
	}else{
		tv.accountexpand(false)
		tv.accountarrayList([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
	}
}
tv.changeapsegment = function(segment){
	return function(){
		if (segment == 'LC'){
			$('.btn-apsegment').removeClass('btn-selected')
			$('#apLC').addClass('btn-selected')
			tv.apsegment('LC')
			tv.GetAccountPlanData()
		}else if (segment == 'MM'){
			$('.btn-apsegment').removeClass('btn-selected')
			$('#apMM').addClass('btn-selected')
			tv.apsegment('MM')
			tv.GetAccountPlanData()
		}else if (segment == 'ME'){
			$('.btn-apsegment').removeClass('btn-selected')
			$('#apME').addClass('btn-selected')
			tv.apsegment('ME')
			tv.GetAccountPlanData()
		}else if (segment == 'HVSB'){
			$('.btn-apsegment').removeClass('btn-selected')
			$('#apHVSB').addClass('btn-selected')
			tv.apsegment('HVSB')
			tv.GetAccountPlanData()
		}else{
			$('.btn-apsegment').removeClass('btn-selected')
			$('#apAvg').addClass('btn-selected')
			tv.apsegment('')
			tv.GetAccountPlanData()
		}
	}
}
tv.GetAPAvgAccountPlanPerRM = function(){
	var payload = {
		Country : '',
		Region : '',
		Segment : tv.apsegment(),
		StartDateString: kendo.toString(new Date(filter.StartStr()), "dd-MMM-yyyy"),
		EndDateString: kendo.toString(new Date(filter.FinishStr()), "dd-MMM-yyyy"),
	}
	ajaxPost("/dashboard/avgaccountplanperrm", payload, function(res){
        tv.averageperrm(res.Data.avgapnumber);
 	})
}
tv.GetAPClientBelow90Percent = function(){
	var payload = {
		Country : '',
		Region : '',
		Segment : tv.apsegment(),
		StartDateString: kendo.toString(new Date(filter.StartStr()), "dd-MMM-yyyy"),
		EndDateString: kendo.toString(new Date(filter.FinishStr()), "dd-MMM-yyyy"),
	}
	ajaxPost("/dashboard/clientbelow90percent", payload, function(res){
        tv.clientofforecast(res.Data.clientnumber);
 	})
}
tv.getPrctAccountPlanApproved = function(){
	var payload = {
		Country : '',
		Region : '',
		Segment : tv.apsegment(),
		StartDateString: kendo.toString(new Date(filter.StartStr()), "dd-MMM-yyyy"),
		EndDateString: kendo.toString(new Date(filter.FinishStr()), "dd-MMM-yyyy"),
	}
	ajaxPost("/dashboard/prctaccountplanapproved", payload, function(res){
		$("#noofapapproved").kendoChart({
	        title: {
	            text: "No of AP approved"
	        },
	        legend: {
	            visible: true,
	          	position: 'top'
	        },
	    	chartArea: {
				width:400
			},
	        seriesDefaults: {
	            stack: true,
	          	overlay:{
	              gradient: "none"
	                },
	        },
	        series: [{
	            name: "Local Corporates",
	            data: res.Data.datatotal.LC,
	            color: "#0097C9"
	        }, {
	            name: "Middle Markets",
	            data: res.Data.datatotal.MM,
	            color: "#71D4EF"
	        }, {
	            name: "Middle Enterprise",
	            data: res.Data.datatotal.ME,
	            color: "#4CA841"
	        }, {
	            name: "HVSB",
	            data: res.Data.datatotal.HVSB,
	            color: "#7DCA37"
	        },{
	            data: res.Data.dataaverage,
	            color: "#fff",
	            border: {
	                width: 0,
	            },
				labels: {	
				 	position:"insideBase",
				 	template: function(e){
	                 	return kendo.toString(e.dataItem, 'P0')
	                },
	                visible: true
	            },
	            tooltip: {
		            visible: false,
		        }
	        }],
	        valueAxis: {
	            line: {
	                visible: false
	            },
	            majorGridLines: {
	                visible: false
	            },
	            minorGridLines: {
	                visible: false
	            }
	        },
	        categoryAxis: {
	            categories: res.Data.series,
                labels: {
	                rotation: -50,
	            },
	            line: {
	                visible: false
	            },
	            majorGridLines: {
	                visible: false
	            },
	            minorGridLines: {
	                visible: false
	            }
	        },
	        tooltip: {
	            visible: true,
	            template: "#= series.name #: #= value #"
	        }
	    });
 	})
}