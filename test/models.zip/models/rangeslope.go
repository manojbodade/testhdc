package models

import (
	"github.com/eaciit/orm"
	// "gopkg.in/mgo.v2/bson"
)

type RangeSlopeModel struct {
	orm.ModelBase `bson:"-",json:"-"`
	Id            			float64 `bson:"_id" , json:"_id"`
	Minimum       			float64 `bson:"min", json:"min"`
	Maximum       			float64 `bson:"max", json:"max"`
	Minimumori     			float64 `bson:"minori", json:"minori"`
	Maximumori     			float64 `bson:"maxori", json:"maxori"`
	Diff 	     			float64 `bson:"diff", json:"diff"`
	Range 	     			float64 `bson:"range", json:"range"`
	B1 	     				float64 `bson:"B1", json:"B1"`
	B2 	     				float64 `bson:"B2", json:"B2"`
	B3 	     				float64 `bson:"B3", json:"B3"`
	B4 	     				float64 `bson:"B4", json:"B4"`
	B5 	    	 			float64 `bson:"B5", json:"B5"`
	B6 		     			float64 `bson:"B6", json:"B6"`
	B7	 	     			float64 `bson:"B7", json:"B7"`
}

func (e *RangeSlopeModel) RecordID() interface{} {
	return e.Id
}

func (m *RangeSlopeModel) TableName() string {
	return "masterrangeslope"
}