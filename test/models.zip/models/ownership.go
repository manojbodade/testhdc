package models

import (
	"gopkg.in/mgo.v2/bson"
	"github.com/eaciit/orm"
)

type OwnershipModel struct {
	orm.ModelBase       `bson:"-",json:"-"`
	Id                  bson.ObjectId `bson:"_id" , json:"_id" `
	Selectedtype        string `bson:"selectedtype" , json:"selectedtype" `
	Datatype        	string `bson:"datatype" , json:"datatype" `
	Point         		float64 `bson:"point" , json:"point" `
}

func NewOwnershipModel() *OwnershipModel {
	m := new(OwnershipModel)
	m.Id = bson.NewObjectId()
	return m
}
func (e *OwnershipModel) RecordID() interface{} {
	return e.Id
}

func (m *OwnershipModel) TableName() string {
	return "masterownership"
}
