package models

import (
	"github.com/eaciit/orm"
	// "gopkg.in/mgo.v2/bson"
)

type RangeBenchmarkModel struct {
	orm.ModelBase `bson:"-",json:"-"`
	Id            			float64 `bson:"_id" , json:"_id"`
	Benchmark      			float64 `bson:"benchmark", json:"benchmark"`
	Libor       			float64 `bson:"libor", json:"libor"`	
}

func (e *RangeBenchmarkModel) RecordID() interface{} {
	return e.Id
}

func (m *RangeBenchmarkModel) TableName() string {
	return "masterbenchmark"
}