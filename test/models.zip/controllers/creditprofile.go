package controllers

import (
	// . "eaciit/dcm/dcmlive/models"
	// db "github.com/eaciit/dbox"
	"github.com/eaciit/knot/knot.v1"
	tk "github.com/eaciit/toolkit"
	// "math"
	// "sort"
	// "strings"
	// "sync"
)

type CreditProfileController struct {
	*BaseController
}

func (d *CreditProfileController) GetLoanBorrower(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Search Data", "search issuer")
	defer d.LogBase(k, &resdata)

	result := []tk.M{}
	for i := 1; i<=3; i++ {
		title := "Title-" + tk.ToString(i)
		value := 30 * i
		obj := tk.M{}
		obj.Set("Category",title)
		obj.Set("Value",value)
		obj.Set("Name","")
		result = append(result, obj)
	}
	sendData := tk.M{}.Set("Datasource", result).Set("Max", 90).Set("Min", 30)
	resdata.Total = len(result)
	resdata.Data = sendData
	resdata.IsError = false
	resdata.Message = "Get Data Success"
	return resdata
}

func (d *CreditProfileController) GetAssetQuality(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Search Data", "search issuer")
	defer d.LogBase(k, &resdata)

	bar := []tk.M{}
	for i := 1; i<=3; i++ {
		title := "Title-" + tk.ToString(i)
		value := 30 * i
		obj := tk.M{}
		obj.Set("Category",title)
		obj.Set("Value",value)
		obj.Set("Name","")
		bar = append(bar, obj)
	}

	line := []tk.M{}
	for i := 1; i<=3; i++ {
		title := "Title-" + tk.ToString(i)
		value := 30 * i
		obj := tk.M{}
		obj.Set("Category",title)
		obj.Set("Value",value)
		obj.Set("Name","")
		line = append(line, obj)
	}
	result := tk.M{}
	result.Set("Bar", bar)
	result.Set("Line", line)

	min := tk.M{}.Set("Line",30).Set("Bar",30)
	max := tk.M{}.Set("Line",90).Set("Bar",90)

	sendData := tk.M{}.Set("Datasource", result).Set("Min", min).Set("Max", max)
	resdata.Data = sendData
	resdata.IsError = false
	resdata.Message = "Get Data Success"
	return resdata
}

func (d *CreditProfileController) GetLoanIndustry(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Search Data", "search issuer")
	defer d.LogBase(k, &resdata)

	result := []tk.M{}
	for i := 1; i<=3; i++ {
		title := "Title-" + tk.ToString(i)
		value := 30 * i
		obj := tk.M{}
		obj.Set("Category",title)
		obj.Set("Value",value)
		obj.Set("Name","")
		result = append(result, obj)
	}

	sendData := tk.M{}.Set("Datasource", result).Set("Max", 90).Set("Min", 30)
	resdata.Total = len(result)
	resdata.Data = sendData
	resdata.IsError = false
	resdata.Message = "Get Data Success"
	return resdata
}

func (d *CreditProfileController) GetRevenueIncome(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Search Data", "search issuer")
	defer d.LogBase(k, &resdata)

	result := []tk.M{}
	for i := 1; i<=3; i++ {
		title := "Title-" + tk.ToString(i)
		value := 30 * i
		obj := tk.M{}
		obj.Set("Category",title)
		obj.Set("Value",value)
		obj.Set("Name","")
		result = append(result, obj)
	}

	sendData := tk.M{}.Set("Datasource", result).Set("Max", 90).Set("Min", 30)
	resdata.Total = len(result)
	resdata.Data = sendData
	resdata.IsError = false
	resdata.Message = "Get Data Success"
	return resdata
}

func (d *CreditProfileController) GetNIMAvg(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Search Data", "search issuer")
	defer d.LogBase(k, &resdata)

	result := []tk.M{}
	for i := 1; i<=3; i++ {
		title := "Title-" + tk.ToString(i)
		value := 30 * i
		obj := tk.M{}
		obj.Set("Category",title)
		obj.Set("Value",value)
		obj.Set("Name","")
		result = append(result, obj)
	}

	sendData := tk.M{}.Set("Datasource", result).Set("Max", 90).Set("Min", 30)
	resdata.Total = len(result)
	resdata.Data = sendData
	resdata.IsError = false
	resdata.Message = "Get Data Success"
	return resdata
}

func (d *CreditProfileController) GetFunding(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Search Data", "search issuer")
	defer d.LogBase(k, &resdata)

	result := []tk.M{}
	for i := 1; i<=3; i++ {
		title := "Title-" + tk.ToString(i)
		value := 30 * i
		obj := tk.M{}
		obj.Set("Category",title)
		obj.Set("Value1",value)
		obj.Set("Value2",value)
		obj.Set("Value3",value)
		obj.Set("Name","")
		result = append(result, obj)
	}

	min := tk.M{}.Set("Line",30).Set("Bar",30)
	max := tk.M{}.Set("Line",90).Set("Bar",90)

	sendData := tk.M{}.Set("Datasource", result).Set("TotalStuck", 3).Set("TotalValueStack", 180).Set("Min", min).Set("Max", max)
	resdata.Total = len(result)
	resdata.Data = sendData
	resdata.IsError = false
	resdata.Message = "Get Data Success"
	return resdata
}

func (d *CreditProfileController) GetCapitalAdequacy(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Search Data", "search issuer")
	defer d.LogBase(k, &resdata)

	bar := []tk.M{}
	for i := 1; i<=3; i++ {
		title := "Title-" + tk.ToString(i)
		value := 30 * i
		obj := tk.M{}
		obj.Set("Category",title)
		obj.Set("Value1",value)
		obj.Set("Value2",value)
		obj.Set("Value3",value)
		obj.Set("Name","")
		bar = append(bar, obj)
	}

	line := []tk.M{}
	for i := 1; i<=3; i++ {
		title := "Title-" + tk.ToString(i)
		value := 30 * i
		obj := tk.M{}
		obj.Set("Category",title)
		obj.Set("Value",value)
		obj.Set("Name","")
		line = append(line, obj)
	}
	result := tk.M{}
	result.Set("Bar", bar)
	result.Set("Line", line)

	min := tk.M{}.Set("Line",30).Set("Bar",30)
	max := tk.M{}.Set("Line",90).Set("Bar",90)

	sendData := tk.M{}.Set("Datasource", result).Set("TotalStuck", 3).Set("TotalValueStack", 180).Set("Min", min).Set("Max", max)
	resdata.Total = len(result)
	resdata.Data = sendData
	resdata.IsError = false
	resdata.Message = "Get Data Success"
	return resdata
}