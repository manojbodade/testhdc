package controllers

import (
	// "eaciit/dcm/dcmlive/helper"
	// . "eaciit/dcm/dcmlive/models"
	"strings"
	// "github.com/sourcegraph/go-ses"
	"github.com/eaciit/acl/v1.0"
	"github.com/eaciit/dbox"
	"github.com/eaciit/knot/knot.v1"
	"github.com/eaciit/toolkit"
	"time"
	// "io/ioutil"
	// "encoding/base64"
)

type AclSysAdminController struct {
	*BaseController
	// accessid string = "SYSADMIN"
}

func (a *AclSysAdminController) Default(k *knot.WebContext) interface{} {
	a.LoadBase(k)
	k.Config.NoLog = true
	k.Config.OutputType = knot.OutputTemplate
	// k.Config.LayoutTemplate = ""
	k.Config.IncludeFiles = []string{"aclsysadmin/user.html", "aclsysadmin/session.html", "aclsysadmin/access.html", "aclsysadmin/group.html", "aclsysadmin/changePassword.html"}

	resdata := ResultInfo{}
	defer a.LogBase(k, &resdata)

	resdata.IsError = false
	resdata.Message = "View Page Sys-Admin"
	resdata.StartTime = time.Now()
	resdata.Action = "Access Page"

	return ""
}

func (a *AclSysAdminController) SaveDataUser(k *knot.WebContext) interface{} {
	k.Config.NoLog = true
	k.Config.OutputType = knot.OutputJson

	resdata := ResultInfo{}
	defer a.LogBase(k, &resdata)

	resdata.IsError = true
	resdata.Message = "Save data user"
	resdata.StartTime = time.Now()
	resdata.Action = "Get Data"

	payload := toolkit.M{}

	err := k.GetPayload(&payload)
	if err != nil {
		resdata.Message = toolkit.Sprintf("get payload found : %v", err.Error())
		return resdata
	}

	//userid
	tUser := new(acl.User)
	if payload.Has("userid") && payload.GetString("userid") != "" {
		err = acl.FindByID(tUser, payload.GetString("userid"))
	}

	if err != nil {
		resdata.Message = toolkit.Sprintf("109. get user by id found : %v", err.Error())
		return resdata
	}

	if payload.Has("fullname") && payload.GetString("fullname") != "" {
		tUser.FullName = payload.GetString("fullname")
	}

	if payload.Has("email") && payload.GetString("email") != "" {
		tUser.Email = strings.ToLower(payload.GetString("email"))
		if payload.Has("loginid") && payload.GetString("loginid") != "" {
			tUser.LoginID = payload.GetString("loginid")
		}
		if payload.Has("bankid") && payload.GetString("bankid") != "" {
			tUser.LoginID = payload.GetString("bankid")
		}
	}

	if payload.Has("enable") {
		tUser.Enable = payload.Get("enable", false).(bool)
	}

	if payload.Has("groups") {
		var groups []string
		for _, v := range payload.Get("groups", []interface{}{}).([]interface{}) {
			groups = append(groups, toolkit.ToString(v))
		}

		tUser.Groups = groups
	}

	tUser.LoginType = acl.LogTypeBasic

	if tUser.LoginID == "" || tUser.FullName == "" || tUser.Email == "" {
		resdata.Message = toolkit.Sprintf("110. save user found : %s", "Data loginid, fullname, email cannot blank")
		return resdata
	}

	if acl.IsUserExist(tUser.LoginID) && payload.GetString("userid") == "" {
		resdata.Message = toolkit.Sprintf("110. save user found : %s", "User is exist")
		return resdata
	}

	if err := acl.Save(tUser); err != nil {
		resdata.Message = toolkit.Sprintf("110. save user found : %v", err.Error())
		return resdata
	}

	if payload.GetString("userid") == "" {
		// uname, tokenid, err := acl.ResetPasswordByParam(tUser.Email, "email")
		// if err != nil {
		// 	resdata.Message = toolkit.Sprintf("Save user auto password, Found : %s", err.Error())
		// 	return resdata
		// }

		// 		linkstr 		:= toolkit.Sprintf("<a href='%v/acluser/confirmreset?1=%v&2=%v'>Click</a>", k.Request.Header.Get("Origin"), uname, tokenid)
		// 		url 			:= a.Attachemail
		// 		bt, _ 			:= ioutil.ReadFile(url)
		// 		from 			:= a.AccAmazone
		// 		to 				:= strings.ToLower(payload.GetString("email"))
		// 		AccessKeyID 	:= a.AccessKeyID
		// 		SecretAccessKey := a.SecretAccessKey
		// 		Endpoint 		:= a.Endpoint
		// 		attachment 		:= base64.StdEncoding.EncodeToString(bt)
		// 		raw 			:= `To: %s
		// From: %s
		// Subject: Welcome to OCIR Focus
		// Content-Type: multipart/mixed; boundary="_003_97DCB304C5294779BEBCFC8357FCC4D2"
		// MIME-Version: 1.0

		// --_003_97DCB304C5294779BEBCFC8357FCC4D2
		// Content-Type: text/html;

		// <html>
		//   <head>
		//     <style type="text/css">
		//     body {
		//       font-size: 12px;
		//       font-family: 'Arial';
		//     }
		//     .emailgreen{
		//       color:#3F9E35;
		//     }
		//     </style>
		//   </head>
		//   <body>
		//     <table width="960">
		//       <tr>
		//         <td>
		//           <img src="http://ocir.exellerator.io/static/img/emaillogo.jpg">
		//         </td>
		//         <td colspan="2">
		//           <h2>Operational Continuity in Resolution </h2>
		//         </td>
		//         <td>
		//           <span>21 November 2016</span>
		//         </td>
		//       </tr>
		//       <tr>
		//         <td colspan="4">
		//           <img src="http://ocir.exellerator.io/static/img/emailline.jpg">
		//         </td>
		//       </tr>
		//       <tr>
		//         <td colspan="4">
		//           Dear All,<br>
		//           As you may already be aware, Operational Continuity In Resolution (“OCIR”) is a Group wide, multi-year programme that has been launched to demonstrate pro-active intent to regulators on the bank’s Recovery & Resolution Planning. Critical success criteria for the programme will be demonstrating our compliance with the PRA proposed regulations (and ultimately the final regulations) on operational continuity. <br><br>
		//           As Global Systemically Important Bank (“G-SIB”), SCB is expected to:
		//           <ul>
		//           <li><b>Identify it’s CEFs</b> in each country (and each legal entity) and seek regulator endorsement</li>
		//           <li><b>Map the dependencies for these CEFs</b> identifying and identify the CSS and relevant contracts that support them</li>
		//           <li><b>Assess</b> the findings to against the proposed PRA rules on Operational Continuity</li>
		//           <li><b>Remediate</b> the identified barriers to ensure that continuation of these CSS will not be involuntarily terminated by Resolution</li>
		//           </ul><br>
		//           <b>OCIR Focus</b><br>
		//           The OCIR Programme, in conjunction with the eXellerator team and Fintech vendor EACIIT, has developed a new reporting and analytics system called <span class="emailgreen">OCIR Focus</span> to:
		//         </td>
		//       </tr>
		//       <tr>
		//         <td colspan="4">
		//           <img style="width: 600px;" src="http://ocir.exellerator.io/static/img/emailcontent.png">
		//         </td>
		//       </tr>
		//       <tr>
		//         <td colspan="4">
		//         <span class="emailgreen">OCIR Focus</span> includes the following highlighted features:
		//           <ul>
		//           <li><b>Visualisation of SCB Service Catalogue</b> – Presenting relationships and dependencies across the bank via a geographic overlay will engage users, increase  knowledge, and test assumptions. Users are enabled with a seamless flow into drilldown analytics.</li>
		//           <li><b>Summary Dashboard and Drilldown Analysis</b> – A single point of reference to view the bank’s service catalogue data via flexible and interactive user interfaces. Gain insights into your Business’/Function’s operating model or sense check its resolution readiness down to the lowest available details and take action where required. </li>
		//           <li><b>Customizable and Intuitive Report Generation</b> – Build your own reporting field-by-field or utilize the standard reporting suite to assist in regulatory engagements, management reporting, and/or Business/Function reviews. The Widget Analysis screen enable users to build multi-page, visually appealing PDF reports within minutes as well as save as a template for future, recurrent usage.</li>
		//           <li><b>Single-click Scenario Builder</b> – Streamline existing data gathering exercises for Stabilization or Restructuring events by view impact from the service recipient and supplier views.</li>
		//           </ul><br>
		//           By receiving this email, you already have an auto-generated user account for <span class="emailgreen">OCIR Focus</span>. Administrative and support details can be found below.<br><br>
		//           <b>Initial Login URL: </b><br>
		//           Link to OCIR Focus: %s<br>
		//           <span>Please right click on "Click", copy and paste the hyperlink  in Google Chrome to access the application. For subsequent login, please use <a href="https://ocir.exellerator.io/">ocir.exellerator.io</a></span><br><br>
		//           <b>Login Details</b><br>
		//           Please find below your user id and password details:<br>
		//           <b>User ID:</b> Your PSID<br>
		//           <b>Password:</b> Generated by user upon initial login<br><br>
		//           <b>Starter Pack</b><br>
		//           Please find attached the Starter Pack highlighting key pages and functionality available to users.<br><br>
		//           <b>Support</b><br>
		//           For queries on <span class="emailgreen">OCIR Focus</span> functionality or the data reflected on any screens, please reach out to your dedicated Business/Functional Implementation Manager and/or your Regional Implementation Manager.<br><br>
		//           For queries on system access – please reach out to the support team at <a href="mailto:support.ocir@sc.com" target="_top">support.ocir@sc.com</a>.
		//         </td>
		//       </tr>
		//       <tr>
		//         <td colspan="2"><br><br>
		//             <b>Steven Ebrill</b><br>
		//             Accountable Executive, OCIR
		//         </td>
		//         <td colspan="2">
		//             <b>Philip Joyce</b><br>
		//             Programme Manager, OCIR
		//         </td>
		//       </tr>
		//     </table>
		//   </body>
		// </html>

		// --_003_97DCB304C5294779BEBCFC8357FCC4D2
		// Content-Type: application/vnd.openxmlformats-officedocument.presentationml.presentation; name="OCIR_Starter_Pack.pptx"
		// Content-Description: OCIR_Starter_Pack.pptx
		// Content-Disposition: attachment; filename="OCIR_Starter_Pack.pptx"; size=%d;
		// Content-Transfer-Encoding: base64

		// %s

		// --_003_97DCB304C5294779BEBCFC8357FCC4D2
		// `
		// _, err = ses.EnvConfig.SendRawEmail([]byte(toolkit.Sprintf(raw, to, from, linkstr, len(attachment), attachment)), AccessKeyID, SecretAccessKey, Endpoint)
		// if err != nil {
		// 	resdata.Message = toolkit.Sprintf("110. create new user send email found : %v", err.Error())
		// 	return resdata
		// }
	}

	resdata.IsError = false
	return resdata
}

func (a *AclSysAdminController) DeleteDataUser(k *knot.WebContext) interface{} {
	k.Config.NoLog = true
	k.Config.OutputType = knot.OutputJson

	resdata := ResultInfo{}
	defer a.LogBase(k, &resdata)

	resdata.IsError = true
	resdata.Message = "Delete data user"
	resdata.StartTime = time.Now()
	resdata.Action = "Get Data"

	payload := toolkit.M{}

	err := k.GetPayload(&payload)
	if err != nil {
		resdata.Message = toolkit.Sprintf("get payload found : %v", err.Error())
		return resdata
	}

	//userid
	tUser := new(acl.User)
	if payload.Has("userid") && payload.GetString("userid") != "" {
		tUser.ID = payload.GetString("userid")
		err = acl.Delete(tUser)
		if err != nil {
			resdata.Message = toolkit.Sprintf("delete user found : %v", err.Error())
		} else {
			resdata.IsError = false
		}
	} else {
		resdata.Message = toolkit.Sprintf("User ID not found")
	}

	return resdata
}

func (a *AclSysAdminController) ResetPasswordByAdmin(k *knot.WebContext) interface{} {
	k.Config.NoLog = true
	k.Config.OutputType = knot.OutputJson

	resdata := ResultInfo{}
	defer a.LogBase(k, &resdata)

	resdata.IsError = true
	resdata.Message = "Reset user password"
	resdata.StartTime = time.Now()
	resdata.Action = "Get Data"

	payload := toolkit.M{}
	if err := k.GetPayload(&payload); err != nil {
		resdata.Message = toolkit.Sprintf("Reset user password, Found : %s", err.Error())
		return resdata
	}

	if !payload.Has("email") || !payload.Has("baseurl") {
		resdata.Message = toolkit.Sprintf("Reset user password, Found : %s", "Data is not completed")
		return resdata
	}

	uname, tokenid, err := acl.ResetPasswordByLoginID(payload.GetString("loginid"))
	if err != nil {
		resdata.Message = toolkit.Sprintf("Reset user password, Found : %s", err.Error())
		return resdata
	}

	linkstr := toolkit.Sprintf("<a href='%v/acluser/confirmreset?1=%v&2=%v'>Click</a>", payload.GetString("baseurl"), uname, tokenid)

	mailmsg := toolkit.Sprintf("Hi, <br/><br/> We received a request to reset your password, <br/><br/>")
	mailmsg = toolkit.Sprintf("%vFollow the link below to set a new password : <br/><br/> %v <br/><br/>", mailmsg, linkstr)
	mailmsg = toolkit.Sprintf("%vIf you don't want to change your password, you can ignore this email <br/><br/> Thanks,</body></html>", mailmsg)

	// if err := helper.OcirSendEmail(strings.ToLower(payload.GetString("email")), mailmsg); err != nil {
	// 	resdata.Message = toolkit.Sprintf("Reset user password, Found : %s", err.Error())
	// 	return resdata
	// }

	resdata.IsError = false
	return resdata
}

func (a *AclUserController) ChangeUserPassword(k *knot.WebContext) interface{} {
	k.Config.NoLog = true
	k.Config.OutputType = knot.OutputJson

	resdata := ResultInfo{}
	defer a.LogBase(k, &resdata)

	resdata.IsError = true
	resdata.Message = "Change user password"
	resdata.StartTime = time.Now()
	resdata.Action = "Get Data"

	payload := toolkit.M{}
	if err := k.GetPayload(&payload); err != nil {
		return toolkit.M{}.Set("message", err.Error())
	}

	err := acl.ChangePassword(payload.GetString("userid"), payload.GetString("newpassword"))
	if err != nil {
		resdata.Message = toolkit.Sprintf("Change user password, found : %s", err.Error())
		return resdata
	}

	resdata.IsError = false

	return resdata
}

func (a *AclSysAdminController) GetDataUser(k *knot.WebContext) interface{} {
	k.Config.NoLog = true
	k.Config.OutputType = knot.OutputJson

	resdata := ResultInfo{}
	defer a.LogBase(k, &resdata)

	resdata.IsError = true
	resdata.Message = "Get data user"
	resdata.StartTime = time.Now()
	resdata.Action = "Get Data"

	payload := toolkit.M{}

	err := k.GetPayload(&payload)
	if err != nil {
		a.WriteLog(err)
		resdata.Message = toolkit.Sprintf("get payload found : %v", err.Error())
		return resdata
	}

	var filter *dbox.Filter
	if payload.Has("userid") {
		// filter = dbox.And(dbox.Eq("userid", UserID), dbox.Eq("purpose", TokenPurpose))
		filter = dbox.Eq("_id", payload.GetString("userid"))
	}

	//	c, err := acl.Find(tUser, filter, toolkit.M{}.Set("take", take).Set("skip", skip))
	c, err := acl.Find(new(acl.User), filter, nil)
	if err != nil {
		return a.SetResultInfo(true, "109. Cursor found error", err)
	}
	defer c.Close()

	ds := []toolkit.M{}
	err = c.Fetch(&ds, 0, false)
	if err != nil {
		return a.SetResultInfo(true, "115. "+err.Error(), nil)
	}

	resdata.IsError = false
	resdata.Total = len(ds)
	resdata.Data = ds

	return resdata
}

func (a *AclSysAdminController) GetDataAccess(k *knot.WebContext) interface{} {
	k.Config.NoLog = true
	k.Config.OutputType = knot.OutputJson

	resdata := ResultInfo{}
	defer a.LogBase(k, &resdata)

	resdata.IsError = true
	resdata.Message = "Get data access"
	resdata.StartTime = time.Now()
	resdata.Action = "Get Data"

	// payload := toolkit.M{}

	// err := k.GetPayload(&payload)
	// if err != nil {
	// 	a.WriteLog(err)
	// 	output.Set("message", toolkit.Sprintf("get payload found : %v", err.Error()))
	// 	return output
	// }

	var filter *dbox.Filter
	// filter = dbox.And(dbox.Eq("userid", UserID), dbox.Eq("purpose", TokenPurpose))

	//	c, err := acl.Find(tUser, filter, toolkit.M{}.Set("take", take).Set("skip", skip))
	c, err := acl.Find(new(acl.Access), filter, nil)
	if err != nil {
		return a.SetResultInfo(true, "109. Cursor found error", err)
	}
	defer c.Close()

	ds := []toolkit.M{}
	err = c.Fetch(&ds, 0, false)
	if err != nil {
		return a.SetResultInfo(true, "115. "+err.Error(), nil)
	}

	resdata.IsError = false
	resdata.Total = len(ds)
	resdata.Data = ds

	return resdata
}

func (a *AclSysAdminController) GetDataGroup(k *knot.WebContext) interface{} {
	k.Config.NoLog = true
	k.Config.OutputType = knot.OutputJson

	resdata := ResultInfo{}
	defer a.LogBase(k, &resdata)

	resdata.IsError = true
	resdata.Message = "Get data group"
	resdata.StartTime = time.Now()
	resdata.Action = "Get Data"

	// payload := toolkit.M{}

	// err := k.GetPayload(&payload)
	// if err != nil {
	// 	a.WriteLog(err)
	// 	output.Set("message", toolkit.Sprintf("get payload found : %v", err.Error()))
	// 	return output
	// }

	var filter *dbox.Filter
	// filter = dbox.And(dbox.Eq("userid", UserID), dbox.Eq("purpose", TokenPurpose))

	//	c, err := acl.Find(tUser, filter, toolkit.M{}.Set("take", take).Set("skip", skip))
	c, err := acl.Find(new(acl.Group), filter, nil)
	if err != nil {
		return a.SetResultInfo(true, "109. Cursor found error", err)
	}
	defer c.Close()

	ds := []toolkit.M{}
	err = c.Fetch(&ds, 0, false)
	if err != nil {
		return a.SetResultInfo(true, "115. "+err.Error(), nil)
	}

	resdata.IsError = false
	resdata.Total = len(ds)
	resdata.Data = ds

	return resdata
}

func (a *AclSysAdminController) GetDataSession(k *knot.WebContext) interface{} {
	k.Config.NoLog = true
	k.Config.OutputType = knot.OutputJson

	resdata := ResultInfo{}
	defer a.LogBase(k, &resdata)

	resdata.IsError = true
	resdata.Message = "Get data session login"
	resdata.StartTime = time.Now()
	resdata.Action = "Get Data"

	// payload := toolkit.M{}

	// err := k.GetPayload(&payload)
	// if err != nil {
	// 	a.WriteLog(err)
	// 	output.Set("message", toolkit.Sprintf("get payload found : %v", err.Error()))
	// 	return output
	// }

	var filter *dbox.Filter
	// filter = dbox.And(dbox.Eq("userid", UserID), dbox.Eq("purpose", TokenPurpose))

	//	c, err := acl.Find(tUser, filter, toolkit.M{}.Set("take", take).Set("skip", skip))
	c, err := acl.Find(new(acl.Session), filter, nil)
	if err != nil {
		return a.SetResultInfo(true, "109. Cursor found error", err)
	}
	defer c.Close()

	ds := []toolkit.M{}
	err = c.Fetch(&ds, 0, false)
	if err != nil {
		return a.SetResultInfo(true, "115. "+err.Error(), nil)
	}

	resdata.IsError = false
	resdata.Total = len(ds)
	resdata.Data = ds

	return resdata
}

func (a *AclSysAdminController) GetListTab(k *knot.WebContext) interface{} {
	a.LoadBase(k)
	k.Config.OutputType = knot.OutputJson

	resdata := ResultInfo{}
	defer a.LogBase(k, &resdata)

	resdata.IsError = true
	resdata.Message = "Get data list tab"
	resdata.StartTime = time.Now()
	resdata.Action = "Get Data"

	sessionid := toolkit.ToString(k.Session("sessionid", ""))
	arrmenu, err := acl.GetListTabBySessionId(sessionid, "SYSADMIN")

	if err != nil {
		resdata.Message = err.Error()
		return resdata
	}

	resdata.IsError = false
	resdata.Data = arrmenu

	return resdata
}

//HasAccess(ID interface{}, IDType IDTypeEnum, AccessID string, AccessFind AccessTypeEnum) (found bool)
func (a *AclSysAdminController) IsAuthenticate(k *knot.WebContext) interface{} {
	a.LoadBase(k)
	k.Config.OutputType = knot.OutputJson

	resdata := a.InitialResultInfo("Has Access", "ACL has Access check")
	defer a.LogBase(k, &resdata)

	tkm := toolkit.M{}
	err := k.GetPayload(&tkm)
	if err != nil {
		resdata.Message = err.Error()
		return resdata
	}

	sessionid := toolkit.ToString(k.Session("sessionid", ""))
	resdata.Data = acl.HasAccess(sessionid, acl.IDTypeSession, tkm.GetString("accessid"), 2)
	resdata.IsError = false

	return resdata
}
