package controllers

import (
	. "eaciit/dcm/dcmlive/models"
	// db "github.com/eaciit/dbox"
	"github.com/eaciit/knot/knot.v1"
	tk "github.com/eaciit/toolkit"
	"math"
	"sort"
	"strings"
	"sync"
)

type DashboardController struct {
	*BaseController
}

type ByNumber []QuerysheetModel

func (s ByNumber) Len() int {
	return len(s)
}

func (s ByNumber) Swap(i, j int) {
	s[i], s[j] = s[j], s[i]
}

func (s ByNumber) Less(i, j int) bool {
	if s[i].Point == s[j].Point {
		return s[i].Issuer < s[j].Issuer
	}
	return s[i].Point < s[j].Point
}

type ArrayFloat []float64

func (list ArrayFloat) Len() int { return len(list) }

func (list ArrayFloat) Swap(i, j int) { list[i], list[j] = list[j], list[i] }

func (list ArrayFloat) Less(i, j int) bool {
	var si float64 = list[i]
	var sj float64 = list[j]
	return si < sj
}

type FilterEmailWidget struct {
	Issuer       string
	Tenor        []float64
	Tenorx       []float64
	Ranking      string
	Currency     string
	Comp         int
	Productmoody string
	Productsp    string
	Productfitch string
	Product      string
	Ownership    string
}

type FilterSlope struct {
	Issuer            []interface{}
	Tenor             []float64
	Tenorx            []float64
	Ranking           string
	Currency          string
	Comp              int
	Country           string
	Industry          string
	Spissuerating     string
	Moodysissuerating string
	Fitchissuerrating string
	Product           string
	Region            string
	Superindustry     string
	Bucket            string
	Ownership         string
	Typevalue 		  string
}

func (c *DashboardController) Default(k *knot.WebContext) interface{} {
	access := c.LoadBase(k)
	k.Config.NoLog = true
	k.Config.IncludeFiles = []string{
		"dashboard/script_template.html",
		"dashboard/home.html",
		"dashboard/pricebond.html",
		"dashboard/pb-formwizard.html",
		"dashboard/pb-instrument.html",
		"dashboard/pb-currency.html",
		"dashboard/pb-tenor.html",
		"dashboard/pb-comp.html",
		"dashboard/pb-result.html",
		"dashboard/tb-clienthome.html",
		"dashboard/tb-creditprofile.html",
		"dashboard/tb-outstandingbonds.html",
		"dashboard/tb-tradingcomparables.html",
		"dashboard/tb-creditcomparables.html",
		"dashboard/tb-keyinvestors.html",
		"dashboard/pb-detailgrid.html",
		"dashboard/dg-tenordifferential.html",
		"dashboard/dg-ratingdifferential.html",
		"dashboard/dg-nipornic.html",
		"dashboard/dg-liquiditypremium.html",
		"dashboard/term-sheet.html",
		"dashboard/popup-create-termsheet.html",
	}
	k.Config.OutputType = knot.OutputTemplate
	k.Config.OutputType = knot.OutputTemplate
	DataAccess := Previlege{}

	for _, o := range access {
		DataAccess.Create = o["Create"].(bool)
		DataAccess.View = o["View"].(bool)
		DataAccess.Delete = o["Delete"].(bool)
		DataAccess.Process = o["Process"].(bool)
		DataAccess.Delete = o["Delete"].(bool)
		DataAccess.Edit = o["Edit"].(bool)
		DataAccess.Menuid = o["Menuid"].(string)
		DataAccess.Menuname = o["Menuname"].(string)
		DataAccess.Approve = o["Approve"].(bool)
		DataAccess.Username = o["Username"].(string)
	}

	return DataAccess
}

func (d *DashboardController) GetIssuer(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Search Data", "search issuer")
	defer d.LogBase(k, &resdata)

	payload := struct {
		Ranking           string
		Country           string
		Industry          string
		Spissuerating     string
		Moodysissuerating string
		Fitchissuerrating string
		Product           string
		Region            string
		Superindustry     string
		Bucket            string
		Ownership         string
		Currency          string
	}{}
	err := k.GetPayload(&payload)
	if err != nil {
		resdata.IsError = true
		resdata.Message = err.Error()
		resdata.Data = nil
	}
	Where := tk.M{}
	if payload.Product == "IG" || payload.Product == "Crossover" {
		if payload.Country != "" {
			Where.Set("country", payload.Country)
		}
	} else if payload.Product == "HY" || payload.Product == "Unrated" {
		if payload.Region != "" {
			Where.Set("region", payload.Region)
		}
	}

	if payload.Superindustry != "" {
		Where.Set("super_industry", payload.Superindustry)
	}

	// if len(payload.Issuer) != 0 {
	// 	Where.Set("issuer", tk.M{}.Set("$in", payload.Issuer))
	// }

	if payload.Ranking == "Senior" {
		Where.Set("perp", "N")
	}

	if payload.Currency == "USD" {
		Where.Set("currency", "USD")
	}

	if payload.Ranking != "" {
		Where.Set("ranking", payload.Ranking)
	} else {
		Where.Set("ranking", tk.M{}.Set("$ne", ""))
	}

	if payload.Bucket != "" {
		Where.Set("bucket", payload.Bucket)
	}

	if payload.Product != "" {
		Where.Set("product", payload.Product)
	}

	if payload.Ownership == "Private - Listed" || payload.Ownership == "Private - Unlisted" {
		Where.Set("ownership", tk.M{}.Set("$in", []string{"Private - Unlisted", "Private - Listed"}))
	} else if payload.Ownership == "SOE" || payload.Ownership == "Sovereign" || payload.Ownership == "Supranational" {
		Where.Set("ownership", tk.M{}.Set("$in", []string{"SOE", "Sovereign", "Supranational"}))
	}

	GroupBy := tk.M{}.Set("issuer", "$issuer").Set("aliasname", "$aliasname").
		Set("country", "$country").Set("industry", "$industry").
		Set("moodys_issuer_rating", "$moodys_issuer_rating").
		Set("sp_issuer_rating", "$sp_issuer_rating").
		Set("fitch_issuer_rating", "$fitch_issuer_rating").
		Set("product_moody", "$product_moody").
		Set("product_sp", "$product_sp").
		Set("product_fitch", "$product_fitch").
		Set("product", "$product").
		Set("super_industry", "$super_industry").
		Set("region", "$region").
		Set("bucket", "$bucket").
		Set("ownership", "$ownership")

	pipe := []tk.M{
		tk.M{
			"$match": Where,
		},
		tk.M{
			"$group": tk.M{
				"_id": GroupBy,
			},
		},
		tk.M{
			"$sort": tk.M{
				"_id": 1,
			},
		},
	}

	crsx, ex := d.Ctx.Connection.NewQuery().
		Command("pipe", pipe).
		From("bondsmaster").
		Cursor(nil)
	if crsx == nil {
		resdata.IsError = true
		resdata.Message = "109. Cursor Not initialized.."
		resdata.Data = nil
	}
	defer crsx.Close()
	result := []tk.M{}
	ex = crsx.Fetch(&result, 0, false)
	if ex != nil {
		resdata.IsError = true
		resdata.Message = "115. " + ex.Error()
		resdata.Data = nil
	}

	resdata.Data = result
	resdata.IsError = false
	resdata.Message = "Get Data Success"
	return resdata
}

func (d *DashboardController) QuerySheet(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Search Data", "search issuer")
	defer d.LogBase(k, &resdata)

	payload := FilterEmailWidget{}
	err := k.GetPayload(&payload)
	if err != nil {
		resdata.IsError = true
		resdata.Message = err.Error()
		resdata.Data = nil
	}

	WhereCond := tk.M{}
	tablename := "bondsmaster"

	if payload.Issuer != "" {
		WhereCond.Set("issuer", payload.Issuer)
	}

	project := d.QuerySheetProject()

	pipe := []tk.M{
		tk.M{
			"$match": WhereCond,
		},
		tk.M{
			"$project": project,
		},
		tk.M{
			"$limit": 1,
		},
	}

	crsx, ex := d.Ctx.Connection.NewQuery().
		Command("pipe", pipe).
		From(tablename).
		Cursor(nil)
	if crsx == nil {
		resdata.IsError = true
		resdata.Message = "109. Cursor Not initialized.."
		resdata.Data = nil
	}
	defer crsx.Close()
	result := make([]QuerysheetModel, 0)
	ex = crsx.Fetch(&result, 0, false)
	if ex != nil {
		resdata.IsError = true
		resdata.Message = "115. " + ex.Error()
		resdata.Data = nil
	}

	// tk.Println(tenor,">>",result[0].Issuer,">>", result)
	final := make([]QuerysheetModel, 0)
	if len(result) != 0 {
		final = d.GetQueryData(tablename, result, payload)
	}

	resdata.Data = final
	resdata.IsError = false
	resdata.Message = "Get Data Success"
	return resdata
}

func (d *DashboardController) QuerySheetProject() tk.M {

	//Now using dynamic value, user can choose value from the UI, bid z spread, g spread, and bid YTM
	// elseValue := tk.M{"$cond": []interface{}{tk.M{"$eq": []string{"$product", "Crossover"}}, "$bid_z_spread", tk.M{"$multiply": []interface{}{"$bid_ytm", 100.0}}}}
	// Value := tk.M{"$cond": []interface{}{tk.M{"$eq": []string{"$product", "IG"}}, "$bid_z_spread", elseValue}}
	// Ranking := tk.M{"$cond": []interface{}{tk.M{"$eq": []string{"$ranking", "AT1"}}, "$bid_z_spread", Value}}

	obj := tk.M{}.Set("issuer", 1).Set("ranking", 1).Set("moodys_issuer_rating", 1).Set("sp_issuer_rating", 1).Set("fitch_issuer_rating", 1).
		Set("industry", 1).Set("currency", 1).Set("country", 1).Set("region", 1).Set("continent", 1).Set("years_to_maturity", 1).
		Set("issue_date", 1).Set("size", 1).Set("bid_price", 1).Set("bid_ytm", 1).Set("bid_t_spread", 1).Set("bid_g_spread", 1).
		Set("bid_z_spread", 1).Set("isin", 1).Set("security", 1).Set("ownership", 1).Set("issue_date_str", 1).Set("product_moody", 1).
		Set("product_sp", 1).Set("product_fitch", 1).Set("product", 1).Set("super_industry", 1).Set("guarantor_name", 1).
		Set("parent_company_name", 1).Set("maturity_date", 1).Set("coupon", 1)//.Set("value", Ranking)

	return obj
}

func (d *DashboardController) SlopeProject() tk.M {
	obj := tk.M{}.Set("issuer", 1).Set("ranking", 1).Set("moodys_issuer_rating", 1).Set("sp_issuer_rating", 1).Set("fitch_issuer_rating", 1).
		Set("bid_z_spread", 1).Set("bid_ytm", 1).Set("years_to_maturity", 1).Set("tenor", 1).Set("product", 1).Set("bid_g_spread", 1)
	return obj
}

func (d *DashboardController) TestingMgo(k *knot.WebContext) interface{} {
	// Where := tk.M{}.Set("issuer", "Standard Chartered Plc")
	// countstr := MgoQuery("bondsmaster", "FindUseWhere", []string{}, "", "", Where)
	// count := tk.ToFloat64(countstr.Error(), 0, tk.RoundingAuto)
	// tk.Println(count, "totaaaaal")
	return nil
}

func (d *DashboardController) GetQueryData(tablename string, result []QuerysheetModel, payload FilterEmailWidget) []QuerysheetModel {
	arryCall := make([]QuerysheetModel, 0)
	WhereCon := tk.M{}.Set("ranking", payload.Ranking)
	if payload.Ranking == "Senior" {
		WhereCon.Set("perp", "N")
		WhereCon.Set("product", payload.Product)
	}
	if payload.Currency == "USD" {
		WhereCon.Set("currency", "USD")
	}

	if payload.Ownership == "Private - Listed" || payload.Ownership == "Private - Unlisted" {
		WhereCon.Set("ownership", tk.M{}.Set("$in", []string{"Private - Unlisted", "Private - Listed"}))
	} else if payload.Ownership == "SOE" || payload.Ownership == "Sovereign" || payload.Ownership == "Supranational" {
		WhereCon.Set("ownership", tk.M{}.Set("$in", []string{"SOE", "Sovereign", "Supranational"}))
	}

	countstr := MgoQuery("bondsmaster", "FindUseWhere", []string{}, "", "", WhereCon)
	count := tk.ToFloat64(countstr.Error(), 0, tk.RoundingAuto)
	// tk.Println(count, "totaaaaal")
	project := d.QuerySheetProject()

	if count > 100.00 {
		takefloat := math.Ceil(count / 10.00)
		take := tk.ToInt(takefloat, tk.RoundingAuto)
		//Go Routine Properties
		wg := new(sync.WaitGroup)
		var mutex = &sync.Mutex{}

		for i := 1; i <= 10; i++ {
			wg.Add(1)
			go func(i int) {
				skip := (i - 1) * take
				// tk.Println("script", skip, "==>", take)

				pipe := []tk.M{
					tk.M{
						"$match": WhereCon,
					},
					tk.M{
						"$project": project,
					},
					tk.M{
						"$skip": skip,
					},
					tk.M{
						"$limit": take,
					},
				}

				c, err := d.Ctx.Connection.NewQuery().
					Command("pipe", pipe).
					From(tablename).
					Cursor(nil)

				if err != nil {
					tk.Println(err.Error())
					wg.Done()
					return
				}

				arrm := make([]QuerysheetModel, 0, 0)
				if err := c.Fetch(&arrm, 0, false); err != nil {
					tk.Println(err.Error())
					wg.Done()
					return
				}
				mutex.Lock()
				// tk.Println("range", skip, "==>", take, "==>", len(arrm))
				arryCall = append(arryCall, arrm...)
				mutex.Unlock()
				wg.Done()

			}(i)
		}

		wg.Wait()
	} else {
		pipe := []tk.M{
			tk.M{
				"$match": WhereCon,
			},
			tk.M{
				"$project": project,
			},
		}

		c, err := d.Ctx.Connection.NewQuery().
			Command("pipe", pipe).
			From(tablename).
			Cursor(nil)

		if err != nil {
			tk.Println(err.Error())
			return nil
		}

		if err := c.Fetch(&arryCall, 0, false); err != nil {
			tk.Println(err.Error())
			return nil
		}
	}

	Mastermoody, Mastersp, Masterfitch := d.GetMasterRating()
	MasterOwnership := d.GetMasterOwnership()
	MaxIssueDate, MinIssueDate := d.GetMaxMin(WhereCon, tablename)
	MaxDiffTime := DiffDays(MaxIssueDate, "2006/1/2", MinIssueDate, "2006/1/2")
	createdata := make(map[float64][]QuerysheetModel, 0)
	issuer := result[0].Issuer
	industry := result[0].Industry
	country := result[0].Country
	region := result[0].Region
	continent := result[0].Continent
	moody := result[0].Moodysissuerating
	sp := result[0].Spissuerating
	fitch := result[0].Fitchissuerrating
	ownership := result[0].Ownership
	currency := payload.Currency
	ranking := payload.Ranking
	ChoosenMoody := Mastermoody[moody]
	ChoosenSP := Mastersp[sp]
	ChoosenFitch := Masterfitch[fitch]

	for _, str := range arryCall {
		final := str
		if strings.Index(final.Issuer, issuer) > -1 {
			final.Issuerpoint = 10.0
		}
		if strings.Index(final.Industry, industry) > -1 {
			final.Industrypoint = 10.0
		} else if strings.Index(final.Superindustry, industry) > -1 {
			final.Industrypoint = 5.0
		}
		if strings.Index(final.Country, country) > -1 {
			final.Countrypoint = 8.0
		}
		if strings.Index(final.Region, region) > -1 {
			final.Regionpoint = 5.0
		}
		if strings.Index(final.Currency, currency) > -1 {
			final.Currencypoint = 10.0
		}
		if strings.Index(final.Continent, continent) > -1 {
			final.Continentpoint = 2.0
		}
		if strings.Index(final.Ranking, ranking) > -1 {
			final.Rankingpoint = 10.0
		}
		if strings.Index(strings.ToLower(final.Guarantorname), strings.ToLower(issuer)) > -1 {
			final.Guarantorpoint = 10.0
		}
		if strings.Index(strings.ToLower(final.Parentcompanyname), strings.ToLower(issuer)) > -1 {
			final.Parentcompanypoint = 10.0
		}

		//Ownership Point
		keyOwner := ownership + final.Ownership
		final.Ownershippoint = MasterOwnership[keyOwner]

		//Rating Point
		EachDataMoody := Mastermoody[final.Moodysissuerating]
		EachDataSP := Mastersp[final.Spissuerating]
		EachDataFitch := Masterfitch[final.Fitchissuerrating]
		s1, s2, s3 := d.CalculateRating(EachDataMoody, EachDataSP, EachDataFitch, ChoosenMoody, ChoosenSP, ChoosenFitch, final.Isin)
		totalRating := 0.0
		if ChoosenMoody != 0.0 {
			totalRating += s1
		}
		if ChoosenSP != 0.0 {
			totalRating += s2
		}
		if ChoosenFitch != 0.0 {
			totalRating += s3
		}
		final.Ratingpoint = totalRating * 20.0
		final.Bidytm = final.Bidytm * 100

		// if final.Isin == "XS1489814779" {
		// 	tk.Println(EachDataMoody, "+++", final.Moodysissuerating)
		// 	tk.Println(EachDataSP, "+++", final.Spissuerating)
		// 	tk.Println(EachDataFitch, "+++", final.Fitchissuerrating)
		// 	tk.Println(ChoosenMoody, "+++", moody)
		// 	tk.Println(ChoosenSP, "+++", sp)
		// tk.Println(ChoosenFitch,"++++++++++++++++++++++++++++++++++++++++++++", fitch)
		// tk.Println("===============>",s1, "==",s2,"---" ,s3)
		// tk.Println("===============>",totalRating,"+++",final.Ratingpoint)
		// }

		//Issue Date Point
		DataDiffTime := DiffDays(MaxIssueDate, "2006/1/2", final.Issuedate, "1/2/2006")
		final.Issuedatepoint = 10.0 * (MaxDiffTime - DataDiffTime) / MaxDiffTime

		//Tenor Point
		for _, tenor := range payload.Tenor {
			deviation := math.Abs(final.Yearsmaturity - tenor)
			weight := (math.Abs(tenor - deviation)) / tenor
			if weight > 1 {
				final.Yearsmaturitypoint = 0.0
			} else {
				final.Yearsmaturitypoint = 10.0 * weight
			}

			final.Point = final.Issuerpoint + final.Industrypoint + final.Countrypoint + final.Regionpoint +
				final.Currencypoint + final.Continentpoint + final.Rankingpoint + final.Yearsmaturitypoint +
				final.Ratingpoint + final.Ownershippoint + final.Issuedatepoint + final.Guarantorpoint +
				final.Parentcompanypoint

			createdata[tenor] = append(createdata[tenor], final)
		}
	}

	MergeData := []QuerysheetModel{}
	CheckIsin := make(map[string][]QuerysheetModel, 0)
	DoubleIsin := make(map[string][]float64, 0)

	for _, numbertenor := range payload.Tenor {
		DataSort := createdata[numbertenor]
		sort.Sort(sort.Reverse(ByNumber(DataSort)))
		for i, data := range DataSort {
			if i == 50 { //Hardcode not using payload.Comp but Top 50
				break
			} else {
				key := data.Isin
				if _, byNameExist := CheckIsin[key]; !byNameExist {
					CheckIsin[key] = []QuerysheetModel{data}
					MergeData = append(MergeData, data)
				} else {
					DoubleIsin[key] = append(DoubleIsin[key], data.Point)
				}
			}
		}
	}

	finaldata := []QuerysheetModel{}
	for _, LastProcess := range MergeData {
		sendData := LastProcess
		key := sendData.Isin
		totalDouble := float64(len(DoubleIsin[key])) + 1.0
		if totalDouble > 1 {
			AverageTotal := sendData.Point
			for _, getTotalDouble := range DoubleIsin[key] {
				AverageTotal += getTotalDouble
			}
			sendData.Point = AverageTotal / totalDouble
		}
		finaldata = append(finaldata, sendData)
	}

	sort.Sort(sort.Reverse(ByNumber(finaldata)))
	finalNow := []QuerysheetModel{}
	for increment, now := range finaldata {
		if increment == payload.Comp {
			break
		} else {
			finalNow = append(finalNow, now)
		}
	}

	return finalNow
}

func (d *DashboardController) GetInstrument(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Search Data", "search issuer")
	defer d.LogBase(k, &resdata)

	pipe := []tk.M{
		tk.M{}.Set("$group", tk.M{}.Set("_id", "$ranking")),
		tk.M{}.Set("$sort", tk.M{}.Set("_id", 1))}
	crsx, ex := d.Ctx.Connection.NewQuery().
		Command("pipe", pipe).
		From("bondsmaster").
		Cursor(nil)
	if crsx == nil {
		resdata.IsError = true
		resdata.Message = "109. Cursor Not initialized.."
		resdata.Data = nil
	}
	defer crsx.Close()
	result := []tk.M{}
	ex = crsx.Fetch(&result, 0, false)
	if ex != nil {
		resdata.IsError = true
		resdata.Message = "115. " + ex.Error()
		resdata.Data = nil
	}

	resdata.Data = result
	resdata.IsError = false
	resdata.Message = "Get Data Success"
	return resdata.Data
}

func (d *DashboardController) GetMasterRating() (map[string]float64, map[string]float64, map[string]float64) {
	moody := make(map[string]float64, 0)
	sp := make(map[string]float64, 0)
	fitch := make(map[string]float64, 0)
	data6 := make([]RatingModel, 0)

	cursor6, err6 := d.Ctx.Find(new(RatingModel), nil)
	if err6 != nil {
		tk.Println(err6.Error())
	}
	err6 = cursor6.Fetch(&data6, 0, false)
	if err6 != nil {
		tk.Println(err6.Error())
	}
	defer cursor6.Close()

	for _, i6 := range data6 {
		moody[i6.Moody] = i6.Point
		sp[i6.Sp] = i6.Point
		fitch[i6.Fitch] = i6.Point
	}

	return moody, sp, fitch
}

func (d *DashboardController) GetMasterOwnership() map[string]float64 {
	owner := make(map[string]float64, 0)
	data := make([]OwnershipModel, 0)

	cursor6, err6 := d.Ctx.Find(new(OwnershipModel), nil)
	if err6 != nil {
		tk.Println(err6.Error())
	}
	err6 = cursor6.Fetch(&data, 0, false)
	if err6 != nil {
		tk.Println(err6.Error())
	}
	defer cursor6.Close()

	for _, i := range data {
		key := i.Selectedtype + i.Datatype
		owner[key] = i.Point
	}

	return owner
}

func (d *DashboardController) GetMaxMin(Where tk.M, tablename string) (string, string) {
	Max := ""
	Min := ""
	data := []tk.M{}

	pipe := []tk.M{
		tk.M{
			"$match": Where,
		},
		tk.M{
			"$group": tk.M{
				"_id":      "",
				"MaxValue": tk.M{"$max": "$issue_date_str"},
				"MinValue": tk.M{"$min": "$issue_date_str"},
			},
		},
	}

	c, err := d.Ctx.Connection.NewQuery().
		Command("pipe", pipe).
		From(tablename).
		Cursor(nil)

	if err != nil {
		tk.Println(err.Error())
	}

	if err := c.Fetch(&data, 0, false); err != nil {
		tk.Println(err.Error())
	}

	if len(data) != 0 {
		Max = data[0].GetString("MaxValue")
		Min = data[0].GetString("MinValue")
	}

	return Max, Min
}

func (d *DashboardController) GetMasterRatingProduct() (map[string]string, map[string]string, map[string]string) {
	moody := make(map[string]string, 0)
	sp := make(map[string]string, 0)
	fitch := make(map[string]string, 0)
	data6 := make([]RatingModel, 0)

	cursor6, err6 := d.Ctx.Find(new(RatingModel), nil)
	if err6 != nil {
		tk.Println(err6.Error())
	}
	err6 = cursor6.Fetch(&data6, 0, false)
	if err6 != nil {
		tk.Println(err6.Error())
	}
	defer cursor6.Close()

	for _, i6 := range data6 {
		moody[i6.Moody] = i6.Product
		sp[i6.Sp] = i6.Product
		fitch[i6.Fitch] = i6.Product
	}

	return moody, sp, fitch
}

func (d *DashboardController) CalculateRating(EachDataMoody float64, EachDataSP float64, EachDataFitch float64, ChoosenMoody float64, ChoosenSP float64, ChoosenFitch float64, isin string) (float64, float64, float64) {
	s1, s2, s3 := 0.0, 0.0, 0.0
	SamelogicMoody := false
	SamelogicSP := false
	SamelogicFitch := false
	HaveValue := 0.0
	if EachDataMoody == 0.0 && ChoosenMoody != 0.0 {
		s1 = 0.0
		if ChoosenMoody != 0.0 {
			HaveValue += 1.0
		}
	} else {
		SamelogicMoody = true
		if ChoosenMoody != 0.0 {
			HaveValue += 1.0
		}
	}

	if EachDataSP == 0.0 && ChoosenSP != 0.0 {
		s2 = 0.0
		if ChoosenSP != 0.0 {
			HaveValue += 1.0
		}
	} else {
		SamelogicSP = true
		if ChoosenSP != 0.0 {
			HaveValue += 1.0
		}
	}

	if EachDataFitch == 0.0 && ChoosenFitch != 0.0 {
		s3 = 0.0
		if ChoosenFitch != 0.0 {
			HaveValue += 1.0
		}
	} else {
		SamelogicFitch = true
		if ChoosenFitch != 0.0 {
			HaveValue += 1.0
		}
	}

	if SamelogicMoody {
		s1 = d.SameLogicCalcualtion(HaveValue, EachDataMoody, ChoosenMoody, isin, "moody")
	}

	if SamelogicSP {
		s2 = d.SameLogicCalcualtion(HaveValue, EachDataSP, ChoosenSP, isin, "SP")
	}

	if SamelogicFitch {
		s3 = d.SameLogicCalcualtion(HaveValue, EachDataFitch, ChoosenFitch, isin, "Fitch")
	}

	// if isin == "XS1489814779" {
	// tk.Println(EachDataMoody, "====", ChoosenMoody)
	// tk.Println(EachDataSP, "====", ChoosenSP)
	// tk.Println(EachDataFitch, "====", ChoosenFitch)
	// tk.Println("SSS ",s1, "==",s2, "==",s3)
	// tk.Println("###############")
	// tk.Println(HaveValue, "----",EachDataMoody,"------",ChoosenMoody, "------", SamelogicMoody)
	// }

	return s1, s2, s3
}

func (d *DashboardController) SameLogicCalcualtion(HaveValue float64, datafl float64, choosenfl float64, isin string, ratingtype string) float64 {
	if HaveValue == 0.0 {
		HaveValue = 1.0
	}
	r := math.Abs(datafl - choosenfl)
	s := 0.0
	s = (1 / HaveValue) - (r / 60)

	// if isin == "XS1489814779" {
	// 	tk.Println(HaveValue, "===", r, "+++" , s, "----", ratingtype)
	// }

	return s
}

func (d *DashboardController) QuerySlope(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Search Data", "search issuer")
	defer d.LogBase(k, &resdata)

	payload := FilterSlope{}
	err := k.GetPayload(&payload)
	if err != nil {
		resdata.IsError = true
		resdata.Message = err.Error()
		resdata.Data = nil
	}

	tablename := "bondsmaster"
	flagNan := false
	final := []tk.M{}
	InterceptSlope := []tk.M{}

	final, flagNan, InterceptSlope = d.GetDataSlope(tablename, payload, flagNan)

	if flagNan {
		resdata.IsError = true
		resdata.Message = "Result NaN found in Line Chart"
	} else {
		resdata.IsError = false
		resdata.Message = "Get Data Success"
	}

	resdata.GridData = InterceptSlope
	resdata.Data = final

	return resdata
}

func (d *DashboardController) GetDataSlope(tablename string, payload FilterSlope, flagNan bool) ([]tk.M, bool, []tk.M) {
	arryCall := make([]SlopeModel, 0)
	WhereCon := tk.M{}

	// if payload.Industry != "" {
	// WhereCon.Set("industry", payload.Industry)
	// }

	if payload.Product == "IG" || payload.Product == "Crossover" {
		if payload.Country != "" {
			WhereCon.Set("country", payload.Country)
		}
	} else if payload.Product == "HY" || payload.Product == "Unrated" {
		if payload.Region != "" {
			WhereCon.Set("region", payload.Region)
		}
	}

	if payload.Superindustry != "" {
		WhereCon.Set("super_industry", payload.Superindustry)
	}

	if len(payload.Issuer) != 0 {
		WhereCon.Set("issuer", tk.M{}.Set("$in", payload.Issuer))
	}

	if payload.Ranking == "Senior" {
		WhereCon.Set("perp", "N")
	}

	if payload.Currency == "USD" {
		WhereCon.Set("currency", "USD")
	}

	if payload.Ranking != "" {
		WhereCon.Set("ranking", payload.Ranking)
	}

	if payload.Bucket != "" {
		WhereCon.Set("bucket", payload.Bucket)
	}

	if payload.Product != "" {
		WhereCon.Set("product", payload.Product)
	}

	if payload.Ownership == "Private - Listed" || payload.Ownership == "Private - Unlisted" {
		WhereCon.Set("ownership", tk.M{}.Set("$in", []string{"Private - Unlisted", "Private - Listed"}))
	} else if payload.Ownership == "SOE" || payload.Ownership == "Sovereign" || payload.Ownership == "Supranational" {
		WhereCon.Set("ownership", tk.M{}.Set("$in", []string{"SOE", "Sovereign", "Supranational"}))
	}

	// if payload.Spissuerating != ""  || payload.Moodysissuerating != "" || payload.Fitchissuerrating != "" {   // change with bucket
	// 	OrCondition	:= []tk.M{}
	// 	OrCondition  = append(OrCondition, tk.M{}.Set("sp_issuer_rating",payload.Spissuerating))
	// 	OrCondition  = append(OrCondition, tk.M{}.Set("moodys_issuer_rating",payload.Moodysissuerating))
	// 	OrCondition  = append(OrCondition, tk.M{}.Set("fitch_issuer_rating",payload.Fitchissuerrating))
	// 	WhereCon.Set("$or", OrCondition)
	// }

	countstr := MgoQuery("bondsmaster", "FindUseWhere", []string{}, "", "", WhereCon)
	count := tk.ToFloat64(countstr.Error(), 0, tk.RoundingAuto)
	// tk.Println(count, "totaaaaal")
	project := d.SlopeProject()

	if count > 100.00 {
		takefloat := math.Ceil(count / 10.00)
		take := tk.ToInt(takefloat, tk.RoundingAuto)
		//Go Routine Properties
		wg := new(sync.WaitGroup)
		var mutex = &sync.Mutex{}

		for i := 1; i <= 10; i++ {
			wg.Add(1)
			go func(i int) {
				skip := (i - 1) * take
				// tk.Println("script", skip, "==>", take)

				pipe := []tk.M{
					tk.M{
						"$match": WhereCon,
					},
					tk.M{
						"$project": project,
					},
					tk.M{
						"$skip": skip,
					},
					tk.M{
						"$limit": take,
					},
				}

				c, err := d.Ctx.Connection.NewQuery().
					Command("pipe", pipe).
					From(tablename).
					Cursor(nil)

				if err != nil {
					tk.Println(err.Error())
					wg.Done()
					return
				}

				arrm := make([]SlopeModel, 0, 0)
				if err := c.Fetch(&arrm, 0, false); err != nil {
					tk.Println(err.Error())
					wg.Done()
					return
				}
				mutex.Lock()
				// tk.Println("range", skip, "==>", take, "==>", len(arrm))
				arryCall = append(arryCall, arrm...)
				mutex.Unlock()
				wg.Done()

			}(i)
		}

		wg.Wait()
	} else {
		pipe := []tk.M{
			tk.M{
				"$match": WhereCon,
			},
			tk.M{
				"$project": project,
			},
		}

		c, err := d.Ctx.Connection.NewQuery().
			Command("pipe", pipe).
			From(tablename).
			Cursor(nil)

		if err != nil {
			tk.Println(err.Error())
			return nil, false, nil
		}

		if err := c.Fetch(&arryCall, 0, false); err != nil {
			tk.Println(err.Error())
			return nil, false, nil
		}
	}

	// tk.Println(len(arryCall),"=== All Data len")

	//Average
	AvgData := []tk.M{}
	pipeAvg := []tk.M{
		tk.M{
			"$match": WhereCon,
		},
		tk.M{
			"$group": tk.M{
				"_id":          "$years_to_maturity",
				"count":        tk.M{"$sum": 1},
				"bid_ytm":      tk.M{"$sum": "$bid_ytm"},
				"bid_z_spread": tk.M{"$sum": "$bid_z_spread"},
				"bid_g_spread": tk.M{"$sum": "$bid_g_spread"},
			},
		},
	}

	c, errAvg := d.Ctx.Connection.NewQuery().
		Command("pipe", pipeAvg).
		From("bondsmaster").
		Cursor(nil)

	if errAvg != nil {
		tk.Println(errAvg.Error())
		return nil, false, nil
	}

	if errAvgF := c.Fetch(&AvgData, 0, false); errAvgF != nil {
		tk.Println(errAvgF.Error())
		return nil, false, nil
	}

	ValueTotal := make(map[float64]float64, 0)
	Count := make(map[float64]float64, 0)
	Tenor := make(map[float64]float64, 0)
	MinimumSlope, MaximumSlope := d.GetMasterRangeSlope()

	for _, eachdata := range AvgData {
		countTotal := eachdata.GetFloat64("count")
		YTM := 0.000
		GetValue := 0.000
		YTM = eachdata.GetFloat64("_id")
		GetValue = eachdata.GetFloat64(payload.Typevalue)
		
		for _, tenorCheck := range payload.Tenor {
			if YTM > MinimumSlope[tenorCheck] && YTM <= MaximumSlope[tenorCheck] {
				Tenor[tenorCheck] += (YTM * countTotal) // im using YTM as group by but tenor must be real value of YTM, so multiple by count
				Count[tenorCheck] += countTotal
				ValueTotal[tenorCheck] += GetValue
			}
		}
	}

	AvgTenor := make(map[float64]float64, 0)
	AvgValue := make(map[float64]float64, 0)
	for _, listTenor := range payload.Tenor {
		AvgTenor[listTenor] = Tenor[listTenor] / Count[listTenor]
		AvgValue[listTenor] = ValueTotal[listTenor] / Count[listTenor]
		// tk.Println("AVG Tenor", AvgTenor[listTenor])
		// tk.Println("AVG Value", AvgValue[listTenor])
	}

	xy := make(map[float64]float64, 0)
	x2 := make(map[float64]float64, 0)

	//Process
	for _, process := range arryCall {
		valueData := 0.000
		switch payload.Typevalue {
		case "bid_g_spread":
			valueData = process.Bidgspread
			break
		case "bid_z_spread":
			valueData = process.Bidzspread
			break
		case "bid_ytm":
			valueData = process.Bidytm * 100
			break
		default:
			break
		}

		YTM := process.Yearsmaturity
		for _, TNRCheck := range payload.Tenor {
			if YTM > MinimumSlope[TNRCheck] && YTM <= MaximumSlope[TNRCheck] {
				xyData, x2Data := d.ImplementAvgLogic(valueData, process.Yearsmaturity, AvgValue[TNRCheck], AvgTenor[TNRCheck])
				xy[TNRCheck] += xyData
				x2[TNRCheck] += x2Data
			}
		}
	}

	finalNow := []tk.M{}
	SlopeIntercept := []tk.M{}
	for i, keyTenor := range payload.Tenor {
		Slope := xy[keyTenor] / x2[keyTenor]
		// tk.Println(xy[keyTenor])
		// tk.Println(x2[keyTenor])
		// tk.Println(Slope)
		// tk.Println("============================")
		finalSub := []tk.M{}
		if !math.IsNaN(Slope) {
			yIntercept := AvgValue[keyTenor] - Slope*AvgTenor[keyTenor]

			for _, tenorXData := range payload.Tenorx {
				if tenorXData > MinimumSlope[keyTenor] && tenorXData <= MaximumSlope[keyTenor] {
					res := SlopeTenorLogic(Slope, yIntercept, tenorXData)
					tkm := tk.M{}.Set("x", tenorXData).Set("y", res)
					finalSub = append(finalSub, tkm)
				}
			}

			StartSpread := SlopeTenorLogic(Slope, yIntercept, MinimumSlope[keyTenor])
			EndSpread := SlopeTenorLogic(Slope, yIntercept, MaximumSlope[keyTenor])
			DiffSpread := EndSpread - StartSpread
			TkmSlopeIntercept := tk.M{}
			TkmSlopeIntercept.Set("IncStart", MinimumSlope[keyTenor])
			TkmSlopeIntercept.Set("Inc", MaximumSlope[keyTenor])
			TkmSlopeIntercept.Set("Spread", DiffSpread)
			TkmSlopeIntercept.Set("Tenor", keyTenor)
			SlopeIntercept = append(SlopeIntercept, TkmSlopeIntercept)
			title := "line" + tk.ToString(i)
			finalNow = append(finalNow, tk.M{}.Set(title, finalSub))
		} else {
			TkmSlopeIntercept := tk.M{}
			TkmSlopeIntercept.Set("IncStart", MinimumSlope[keyTenor])
			TkmSlopeIntercept.Set("Inc", MaximumSlope[keyTenor])
			TkmSlopeIntercept.Set("Spread", 0)
			title := "line" + tk.ToString(i)
			finalNow = append(finalNow, tk.M{}.Set(title, finalSub))
		}
	}

	return finalNow, flagNan, SlopeIntercept
}

func (d *DashboardController) ImplementAvgLogic(ValueData float64, TenorData float64, AvgValue float64, AvgTenor float64) (float64, float64) {
	TenorMinus := TenorData - AvgTenor
	ValueMinus := ValueData - AvgValue
	xyData := TenorMinus * ValueMinus
	x2Data := TenorMinus * TenorMinus
	return xyData, x2Data
}

func (d *DashboardController) GetMasterRangeSlope() (map[float64]float64, map[float64]float64) {
	data6 := make([]RangeSlopeModel, 0)
	minValue := make(map[float64]float64, 0)
	maxValue := make(map[float64]float64, 0)

	cursor6, err6 := d.Ctx.Find(new(RangeSlopeModel), nil)
	if err6 != nil {
		tk.Println(err6.Error())
	}
	err6 = cursor6.Fetch(&data6, 0, false)
	if err6 != nil {
		tk.Println(err6.Error())
	}
	defer cursor6.Close()

	for _, i6 := range data6 {
		minValue[i6.Id] = i6.Minimum
		maxValue[i6.Id] = i6.Maximum
	}

	return minValue, maxValue
}

func (d *DashboardController) GetMasterRangeSlopeOri(order string) []RangeSlopeModel {
	data6 := make([]RangeSlopeModel, 0)
	asc := 1
	if order == "DESC" {
		asc = -1
	}

	Where := tk.M{}
	Where.Set("_id", tk.M{}.Set("$ne", 7.0))
	sort := tk.M{}
	sort.Set("_id", asc)

	pipe := []tk.M{
		tk.M{
			"$match": Where,
		},
		tk.M{
			"$sort": sort,
		},
	}

	cursor6, err6 := d.Ctx.Connection.NewQuery().
		Command("pipe", pipe).
		From("masterrangeslope").
		Cursor(nil)

	if err6 != nil {
		tk.Println(err6.Error())
	}

	err6 = cursor6.Fetch(&data6, 0, false)
	if err6 != nil {
		tk.Println(err6.Error())
	}
	defer cursor6.Close()

	return data6
}

type FilterTradingCurve struct {
	Tenor              []float64
	Yearsmaturitybasis float64
	GridData           []SpreadStruct
	Valuebasis         float64
}

type FilterSyndicate struct {
	Tenor              []float64
	Yearsmaturitybasis float64
	Valuebasis         float64
	Bucket             string
}

type SpreadStruct struct {
	Inc      float64
	IncStart float64
	Spread   float64
	Tenor    float64
}

func (d *DashboardController) TermSheet(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Search Data", "search issuer")
	defer d.LogBase(k, &resdata)

	payload := FilterTradingCurve{}
	err := k.GetPayload(&payload)
	if err != nil {
		resdata.IsError = true
		resdata.Message = err.Error()
		resdata.Data = nil
	}

	Spread := make(map[float64]float64, 0)
	for _, spreadlist := range payload.GridData {
		key := spreadlist.Tenor
		Spread[key] = spreadlist.Spread
		tk.Println( spreadlist.Spread, "===", tk.ToFloat64(spreadlist.Spread, 2, tk.RoundingAuto) , ">>", tk.Sprintf("%.2f", spreadlist.Spread))
	}

	MasterRange := d.GetMasterRangeSlopeOri("ASC")
	final := []tk.M{}
	for _, tenorUI := range payload.Tenor {
		MinValue := tenorUI
		MaxValue := payload.Yearsmaturitybasis
		Minus := -1.0
		if tenorUI > payload.Yearsmaturitybasis {
			MinValue = payload.Yearsmaturitybasis
			MaxValue = tenorUI
			Minus = 1.0
		}

		res := 0.00
		for _, MR := range MasterRange {
			if MaxValue > MR.Minimumori && MinValue < MR.Maximumori {
				if (MaxValue - MR.Minimumori) <= 0 {
					break
				}

				DiffLeft := MR.Diff
				if (tenorUI > MR.Minimumori && tenorUI <= MR.Maximumori) && (payload.Yearsmaturitybasis > MR.Minimumori && payload.Yearsmaturitybasis <= MR.Maximumori) {
					//Same Bucket
					DiffLeft = math.Abs(payload.Yearsmaturitybasis - tenorUI)
				} else {
					//Normal Conditions for Different Value
					if MR.Minimumori < MinValue && MinValue <= MR.Maximumori {
						DiffLeft = math.Abs(MR.Maximumori - MinValue)
					}
					//Normal Conditions for Different Value
					if MR.Minimumori < MaxValue && MaxValue <= MR.Maximumori {
						DiffLeft = math.Abs(MaxValue - MR.Minimumori)
					}
				}
				doProcess := LogicTermSheet(Spread[MR.Id], MR.Diff, DiffLeft)
				res += doProcess

			}
		}

		// res = (res * Minus) + payload.Valuebasis
		res = (res * Minus) //+ payload.Valuebasis
		obj := tk.M{}
		obj.Set("tenor", tenorUI)
		obj.Set("result", res)
		final = append(final, obj)

	}

	resdata.Data = final
	resdata.IsError = false
	return resdata
}

func (d *DashboardController) TermSheetSyndicate(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Search Data", "search issuer")
	defer d.LogBase(k, &resdata)

	payload := FilterSyndicate{}
	err := k.GetPayload(&payload)
	if err != nil {
		resdata.IsError = true
		resdata.Message = err.Error()
		resdata.Data = nil
	}

	MasterRange := d.GetMasterRangeSlopeOri("ASC")
	final := []tk.M{}
	for _, tenorUI := range payload.Tenor {
		MinValue := tenorUI
		MaxValue := payload.Yearsmaturitybasis
		Minus := -1.0
		if tenorUI > payload.Yearsmaturitybasis {
			MinValue = payload.Yearsmaturitybasis
			MaxValue = tenorUI
			Minus = 1.0
		}

		res := 0.00
		for _, MR := range MasterRange {
			if MaxValue > MR.Minimumori && MinValue < MR.Maximumori {
				if (MaxValue - MR.Minimumori) <= 0 {
					break
				}

				DiffLeft := MR.Diff
				if (tenorUI > MR.Minimumori && tenorUI <= MR.Maximumori) && (payload.Yearsmaturitybasis > MR.Minimumori && payload.Yearsmaturitybasis <= MR.Maximumori) {
					//Same Bucket
					DiffLeft = math.Abs(payload.Yearsmaturitybasis - tenorUI)
				} else {
					//Normal Conditions for Different Value
					if MR.Minimumori < MinValue && MinValue <= MR.Maximumori {
						DiffLeft = math.Abs(MR.Maximumori - MinValue)
					}
					//Normal Conditions for Different Value
					if MR.Minimumori < MaxValue && MaxValue <= MR.Maximumori {
						DiffLeft = math.Abs(MaxValue - MR.Minimumori)
					}
				}

				Spread := 0.00
				switch payload.Bucket {
				case "B1":
					Spread = MR.B1
					break
				case "B2":
					Spread = MR.B2
					break
				case "B3":
					Spread = MR.B3
					break
				case "B4":
					Spread = MR.B4
					break
				case "B5":
					Spread = MR.B5
					break
				case "B6":
					Spread = MR.B6
					break
				case "B7":
					Spread = MR.B7
					break
				default:
					break
				}

				doProcess := LogicTermSheet(Spread, MR.Diff, DiffLeft)
				res += doProcess
				// tk.Println(MR.Minimumori,"++",MR.Maximumori,":::",Spread, "-Spread", MR.Diff, "-Minus-", DiffLeft, "-res-", doProcess)
			}
		}
		// res = (res * Minus) + payload.Valuebasis
		res = (res * Minus) //+ payload.Valuebasis
		obj := tk.M{}
		obj.Set("tenor", tenorUI)
		obj.Set("result", res)
		final = append(final, obj)

	}

	resdata.Data = final
	resdata.IsError = false
	return resdata
}

type FilterRatingDifferential struct {
	Moodyrating string
	Sprating    string
	Fitchrating string
	Moodybasis  string
	Spbasis     string
	Fitchbasis  string
}

func (d *DashboardController) RatingDifferential(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Search Data", "search issuer")
	defer d.LogBase(k, &resdata)

	payload := FilterRatingDifferential{}
	err := k.GetPayload(&payload)
	if err != nil {
		resdata.IsError = true
		resdata.Message = err.Error()
		resdata.Data = nil
	}

	Mastermoody, Mastersp, Masterfitch := d.GetMasterRating()
	ArrayIssuer := []float64{Mastermoody[payload.Moodyrating], Mastersp[payload.Sprating], Masterfitch[payload.Fitchrating]}
	ArrayBasis := []float64{Mastermoody[payload.Moodybasis], Mastersp[payload.Spbasis], Masterfitch[payload.Fitchbasis]}
	sort.Sort(ArrayFloat(ArrayIssuer))
	sort.Sort(ArrayFloat(ArrayBasis))

	PointIssuer := 0.00
	PointBasis := 0.00
	res := 0.00
	for _, issue := range ArrayIssuer {
		if issue != 0.00 {
			PointIssuer = issue
			break
		}
	}

	for _, basis := range ArrayBasis {
		if basis != 0.00 {
			PointBasis = basis
			break
		}
	}

	if PointIssuer != PointBasis {
		// tk.Println(ArrayIssuer,"==========>", PointIssuer)
		// tk.Println(ArrayBasis,"=========>", PointBasis)

		MinValue := PointIssuer
		MaxValue := PointBasis
		Multiply := -1.0
		if PointIssuer > PointBasis {
			MinValue = PointBasis
			MaxValue = PointIssuer
			Multiply = 1.0
		}

		// tk.Println(MinValue, MaxValue,"================")

		Where := tk.M{}.Set("point", tk.M{"$gte": MinValue, "$lte": MaxValue})
		pipeSUM := []tk.M{
			tk.M{
				"$match": Where,
			},
			tk.M{
				"$group": tk.M{
					"_id":          "",
					"differential": tk.M{"$sum": "$differential"},
				},
			},
		}

		crsx, ex := d.Ctx.Connection.NewQuery().
			Command("pipe", pipeSUM).
			From("masterrating").
			Cursor(nil)
		if crsx == nil {
			resdata.IsError = true
			resdata.Message = "109. Cursor Not initialized.."
			resdata.Data = nil
		}
		defer crsx.Close()
		result := []tk.M{}
		ex = crsx.Fetch(&result, 0, false)
		if ex != nil {
			resdata.IsError = true
			resdata.Message = "115. " + ex.Error()
			resdata.Data = nil
		}

		// tk.Println(result)

		if len(result) != 0 {
			res = result[0].GetFloat64("differential") * Multiply
		}
	} else {
		res = 0.0
	}
	resdata.Data = res
	resdata.IsError = false
	return resdata
}

func (d *DashboardController) GetMasterBenchmark() (map[float64]float64, map[float64]float64) {
	libor := make(map[float64]float64, 0)
	bench := make(map[float64]float64, 0)
	data6 := make([]RangeBenchmarkModel, 0)

	cursor6, err6 := d.Ctx.Find(new(RangeBenchmarkModel), nil)
	if err6 != nil {
		tk.Println(err6.Error())
	}
	err6 = cursor6.Fetch(&data6, 0, false)
	if err6 != nil {
		tk.Println(err6.Error())
	}
	defer cursor6.Close()

	for _, i6 := range data6 {
		libor[i6.Id] = i6.Libor
		bench[i6.Id] = i6.Benchmark
	}

	return libor, bench
}

type FilterBenchmark struct {
	Product 	string
	Total   	[]float64
	Tenor   	[]float64
	Flag    	string
	Range   	float64
	Typevalue	string
}

func (d *DashboardController) Benchmark(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Search Data", "search issuer")
	defer d.LogBase(k, &resdata)

	payload := FilterBenchmark{}
	err := k.GetPayload(&payload)
	if err != nil {
		resdata.IsError = true
		resdata.Message = err.Error()
		resdata.Data = nil
	}

	MasterLibor, MasterBench := d.GetMasterBenchmark()

	final := []tk.M{}
	for inc, tenorUI := range payload.Tenor {

		halfRange := payload.Range / 2
		BenchMaster := MasterBench[tenorUI]
		LiborMaster := MasterLibor[tenorUI]
		Total := payload.Total[inc]
		BY := "CT" + tk.Sprintf("%.4g", tenorUI) + " at " + tk.Sprintf("%.4g", tk.ToFloat64((BenchMaster/100), 2, tk.RoundingAuto))

		obj := tk.M{}
		obj.Set("tenor", tenorUI)
		obj.Set("benchmarkyield", BY)

		// tk.Sprintf("%.4g", tk.ToFloat64(Total, 0, tk.RoundingAuto))
		if payload.Typevalue != "bid_ytm" {
			tk.Println()

			yield := Total + BenchMaster
			strTotal := FormatNumber(tk.ToFloat64(Total, 0, tk.RoundingAuto), 0) + " Area"
			strYield := FormatNumber(tk.ToFloat64(yield/100, 2, tk.RoundingAuto), 2) + " Area"
			strYieldRange := FormatNumber( tk.ToFloat64((Total-halfRange) /100 + (BenchMaster/100)  , 2, tk.RoundingAuto), 2) + " - " + FormatNumber(tk.ToFloat64((Total+halfRange) /100 + (BenchMaster/100), 2, tk.RoundingAuto), 2)
			strSpreadBenchmark := FormatNumber(tk.ToFloat64(Total-halfRange, 0, tk.RoundingAuto), 0) + " - " + FormatNumber(tk.ToFloat64(Total+halfRange, 0, tk.RoundingAuto), 0)
			afterSwamp := yield - LiborMaster
			strAfterSwamp := FormatNumber(tk.ToFloat64(afterSwamp, 0, tk.RoundingAuto), 0) + " Area"
			strAfterSwampRange := FormatNumber(tk.ToFloat64((afterSwamp-halfRange), 0, tk.RoundingAuto), 0) + " - " + FormatNumber(tk.ToFloat64((afterSwamp+halfRange), 0, tk.RoundingAuto), 0)

			switch payload.Flag {
			case "Single Point":
				obj.Set("spreadbenchmark", FormatNumber(tk.ToFloat64(Total, 0, tk.RoundingAuto), 0))
				obj.Set("yield", FormatNumber(tk.ToFloat64(yield/100, 2, tk.RoundingAuto), 2))
				obj.Set("afterswamp", FormatNumber(tk.ToFloat64(afterSwamp, 0, tk.RoundingAuto), 0))
				break
			case "Area":
				obj.Set("spreadbenchmark", strTotal)
				obj.Set("yield", strYield)
				obj.Set("afterswamp", strAfterSwamp)
				break
			case "Range":
				obj.Set("spreadbenchmark", strSpreadBenchmark)
				obj.Set("yield", strYieldRange)
				obj.Set("afterswamp", strAfterSwampRange)
				break
			default:
				break
			}
		} else {

			yield := Total - BenchMaster
			strTotal := FormatNumber(tk.ToFloat64((Total/100.0), 2, tk.RoundingAuto), 2) + " Area"
			strYield := FormatNumber(tk.ToFloat64(yield, 0, tk.RoundingAuto), 0) + " Area"
			strYieldRange := FormatNumber(tk.ToFloat64((yield-halfRange), 0, tk.RoundingAuto), 0) + " - " + FormatNumber(tk.ToFloat64((yield+halfRange), 0, tk.RoundingAuto), 0)
			strSpreadBenchmark := FormatNumber(tk.ToFloat64(((Total-halfRange)/100.0), 2, tk.RoundingAuto), 2) + " - " + FormatNumber(tk.ToFloat64(((Total+halfRange)/100.0), 2, tk.RoundingAuto), 2)
			afterSwamp := Total - LiborMaster
			strAfterSwamp := FormatNumber(tk.ToFloat64(afterSwamp, 0, tk.RoundingAuto), 0) + " Area"
			strAfterSwampRange := FormatNumber(tk.ToFloat64((afterSwamp-halfRange), 0, tk.RoundingAuto), 0) + " - " + FormatNumber(tk.ToFloat64((afterSwamp+halfRange), 0, tk.RoundingAuto), 0)

			switch payload.Flag {
			case "Single Point":
				obj.Set("spreadbenchmark", FormatNumber(tk.ToFloat64(yield, 0, tk.RoundingAuto), 0))
				obj.Set("yield", FormatNumber(tk.ToFloat64((Total/100), 2, tk.RoundingAuto), 2))
				obj.Set("afterswamp", FormatNumber(tk.ToFloat64(afterSwamp, 0, tk.RoundingAuto), 0))
				break
			case "Area":
				obj.Set("spreadbenchmark", strYield)
				obj.Set("yield", strTotal)
				obj.Set("afterswamp", strAfterSwamp)
				break
			case "Range":
				obj.Set("spreadbenchmark", strYieldRange)
				obj.Set("yield", strSpreadBenchmark)
				obj.Set("afterswamp", strAfterSwampRange)
				break
			default:
				break
			}
		}

		final = append(final, obj)
	}

	resdata.Data = final
	resdata.IsError = false
	return resdata
}
