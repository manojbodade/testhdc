package controllers

import (
	. "eaciit/dcm/dcmlive/models"
	// db "github.com/eaciit/dbox"
	"github.com/eaciit/knot/knot.v1"
	tk "github.com/eaciit/toolkit"
)

type PriceBondController struct {
	*BaseController
}

func (c *PriceBondController) Default(k *knot.WebContext) interface{} {
	access := c.LoadBase(k)
	k.Config.NoLog = true
	k.Config.OutputType = knot.OutputTemplate
	k.Config.IncludeFiles = []string{"pricebond/instrument.html", "pricebond/currency.html", "pricebond/tenor.html", "pricebond/comp.html", "pricebond/result.html", "pricebond/script_template.html"}
	resdata := c.InitialResultInfo("Access Page", "View Page")
	defer c.LogBase(k, &resdata)

	resdata.IsError = false

	DataAccess := Previlege{}

	for _, o := range access {
		DataAccess.Create = o["Create"].(bool)
		DataAccess.View = o["View"].(bool)
		DataAccess.Delete = o["Delete"].(bool)
		DataAccess.Process = o["Process"].(bool)
		DataAccess.Delete = o["Delete"].(bool)
		DataAccess.Edit = o["Edit"].(bool)
		DataAccess.Menuid = o["Menuid"].(string)
		DataAccess.Menuname = o["Menuname"].(string)
		DataAccess.Approve = o["Approve"].(bool)
		DataAccess.Username = o["Username"].(string)
	}

	return DataAccess
}

type FilterTenorDifferential struct {
	Issuer            []interface{}
	Ranking           string
	Isin              string
	Tenor             []float64
	Country           string
	Industry          string
	Spissuerating     string
	Moodysissuerating string
	Fitchissuerrating string
	Product           string
	Region            string
	Superindustry     string
	Bucket            string
	Ownership         string
	Currency          string
	Typevalue         string
}

func (d *PriceBondController) GetTenorDifferential(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Get Data", "Get Data TenorDifferential")
	defer d.LogBase(k, &resdata)

	payload := FilterTenorDifferential{}
	err := k.GetPayload(&payload)
	if err != nil {
		resdata.IsError = true
		resdata.Message = err.Error()
		resdata.Data = nil
	}

	WhereCond := tk.M{}

	if payload.Product == "IG" || payload.Product == "Crossover" {
		if payload.Country != "" {
			WhereCond.Set("country", payload.Country)
		}
	} else if payload.Product == "HY" || payload.Product == "Unrated" {
		if payload.Region != "" {
			WhereCond.Set("region", payload.Region)
		}
	}

	if payload.Superindustry != "" {
		WhereCond.Set("super_industry", payload.Superindustry)
	}

	if len(payload.Issuer) != 0 {
		WhereCond.Set("issuer", tk.M{}.Set("$in", payload.Issuer))
	}

	if payload.Ranking == "Senior" {
		WhereCond.Set("perp", "N")
	}

	if payload.Currency == "USD" {
		WhereCond.Set("currency", "USD")
	}

	if payload.Ranking != "" {
		WhereCond.Set("ranking", payload.Ranking)
	}

	if payload.Bucket != "" {
		WhereCond.Set("bucket", payload.Bucket)
	}

	if payload.Product != "" {
		WhereCond.Set("product", payload.Product)
	}

	if payload.Ownership == "Private - Listed" || payload.Ownership == "Private - Unlisted" {
		WhereCond.Set("ownership", tk.M{}.Set("$in", []string{"Private - Unlisted", "Private - Listed"}))
	} else if payload.Ownership == "SOE" || payload.Ownership == "Sovereign" || payload.Ownership == "Supranational" {
		WhereCond.Set("ownership", tk.M{}.Set("$in", []string{"SOE", "Sovereign", "Supranational"}))
	}

	// if payload.Spissuerating != ""  || payload.Moodysissuerating != "" || payload.Fitchissuerrating != "" {   // change with bucket
	// 	OrCondition	:= []tk.M{}
	// 	OrCondition  = append(OrCondition, tk.M{}.Set("sp_issuer_rating",payload.Spissuerating))
	// 	OrCondition  = append(OrCondition, tk.M{}.Set("moodys_issuer_rating",payload.Moodysissuerating))
	// 	OrCondition  = append(OrCondition, tk.M{}.Set("fitch_issuer_rating",payload.Fitchissuerrating))
	// 	WhereCon.Set("$or", OrCondition)
	// }

	project := d.QueryProject()

	pipe := []tk.M{
		tk.M{
			"$match": WhereCond,
		},
		tk.M{
			"$project": project,
		},
	}

	crsx, ex := d.Ctx.Connection.NewQuery().
		Command("pipe", pipe).
		From("bondsmaster").
		Cursor(nil)
	if crsx == nil {
		resdata.IsError = true
		resdata.Message = "109. Cursor Not initialized.."
		resdata.Data = nil
	}
	ds := []tk.M{}
	defer crsx.Close()
	ex = crsx.Fetch(&ds, 0, false)
	if ex != nil {
		resdata.IsError = true
		resdata.Message = "115. " + ex.Error()
		resdata.Data = nil
	}

	res1 := []tk.M{}
	MinimumSlope, MaximumSlope := d.GetMasterRangeSlope()
	for _, i := range ds {
		obj1 := tk.M{}
		y 	 := i.GetFloat64(payload.Typevalue)
		YTM  := i.GetFloat64("years_to_maturity")

		for _, TNRCheck := range payload.Tenor {
			if YTM > MinimumSlope[TNRCheck] && YTM <= MaximumSlope[TNRCheck] {
				obj1.Set("x", YTM)
				obj1.Set("y", y)
				obj1.Set("isin", i.GetString("isin"))
				obj1.Set("currency", i.GetString("currency"))
				obj1.Set("size", i.GetFloat64("size"))
				obj1.Set("issuer", i.GetString("issuer"))
				res1 = append(res1, obj1)
			}
		}
	}

	final := tk.M{}
	final.Set("DataSource", res1)
	// tk.Println(res1)
	resdata.Total = len(ds)
	resdata.Data = final
	resdata.IsError = false
	resdata.Message = "Get Data Success"
	return resdata
}

func (d *PriceBondController) QueryProject() tk.M {
	obj := tk.M{}.Set("issuer", 1).Set("ranking", 1).Set("product_fitch", 1).Set("product_sp", 1).Set("product_moody", 1).
		Set("years_to_maturity", 1).Set("bid_ytm", 1).Set("bid_z_spread", 1).Set("isin", 1).Set("size", 1).Set("currency", 1).
		Set("product", 1).Set("bid_g_spread", 1)
	return obj
}

func (d *PriceBondController) GetMasterRangeSlope() (map[float64]float64, map[float64]float64) {
	data6 := make([]RangeSlopeModel, 0)
	minValue := make(map[float64]float64, 0)
	maxValue := make(map[float64]float64, 0)

	cursor6, err6 := d.Ctx.Find(new(RangeSlopeModel), nil)
	if err6 != nil {
		tk.Println(err6.Error())
	}
	err6 = cursor6.Fetch(&data6, 0, false)
	if err6 != nil {
		tk.Println(err6.Error())
	}
	defer cursor6.Close()

	for _, i6 := range data6 {
		minValue[i6.Id] = i6.Minimum
		maxValue[i6.Id] = i6.Maximum
	}

	return minValue, maxValue
}

func (d *PriceBondController) GetDataGridSlope(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Get Data", "Get Data Grid Master Range Slope")
	defer d.LogBase(k, &resdata)

	crsx, ex := d.Ctx.Connection.NewQuery().
		From("masterrangeslope").
		Cursor(nil)
	if crsx == nil {
		resdata.IsError = true
		resdata.Message = "109. Cursor Not initialized.."
		resdata.Data = nil
	}
	ds := []tk.M{}
	defer crsx.Close()
	ex = crsx.Fetch(&ds, 0, false)
	if ex != nil {
		resdata.IsError = true
		resdata.Message = "115. " + ex.Error()
		resdata.Data = nil
	}

	res := []tk.M{}
	for _, i := range ds {
		obj := tk.M{}
		obj.Set("fromyear", i.GetFloat64("minori"))
		obj.Set("toyear", i.GetFloat64("maxori"))
		obj.Set("B1", i.GetFloat64("B1"))
		obj.Set("B2", i.GetFloat64("B2"))
		obj.Set("B3", i.GetFloat64("B3"))
		obj.Set("B4", i.GetFloat64("B4"))
		obj.Set("B5", i.GetFloat64("B5"))
		obj.Set("B6", i.GetFloat64("B6"))
		obj.Set("B7", i.GetFloat64("B7"))

		res = append(res, obj)
	}

	resdata.Total = len(ds)
	resdata.Data = res
	resdata.IsError = false
	resdata.Message = "Get Data Success"
	return resdata
}
