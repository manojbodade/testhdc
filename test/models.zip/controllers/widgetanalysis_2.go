package controllers

import (
	"github.com/eaciit/knot/knot.v1"
	tk "github.com/eaciit/toolkit"
	. "eaciit/dcm/dcmlive/models"
	"gopkg.in/mgo.v2/bson"
	"strings"
	"math"
	"sync"
)

type FilterWidgetSyndicate struct {
	Ownership         []interface{}
	Currency          []interface{}
	Ranking           []interface{}
	Product           []interface{}
	Ratingtype 		  string
	Ratingaction 	  string
	Ratingvalue		  float64
	Flag		  	  string
	Take              int
	Skip              int
	Sort              []tk.M
	Filter            Filter
}

func (d *WidgetAnalysisController) GetFilterRating(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson

	resdata := d.InitialResultInfo("Search Data", "aearch legal entity supplier")
	defer d.LogBase(k, &resdata)

	payload := FilterWidgetSyndicate{}
	err := k.GetPayload(&payload)
	if err != nil {
		resdata.IsError = true
		resdata.Message = err.Error()
		resdata.Data = nil
	}

	WhereCond := d.GetFilterRatingDefault(payload)

	groupby := "$" + payload.Flag
	pipe := []tk.M{
		tk.M{}.Set("$match", WhereCond),
		tk.M{}.Set("$group", tk.M{}.Set("_id", groupby)),
		tk.M{}.Set("$sort", tk.M{}.Set("_id", 1))}

	if strings.Index(payload.Flag, "point") > -1 {
		grp1 := "$moodys_issuer_rating"
		switch payload.Flag {
			case "point_sp":
				grp1 = "$sp_issuer_rating"
				break
			case "point_fitch":
				grp1 = "$fitch_issuer_rating"
				break
			default:
				break
			}

	
		Group := tk.M{}
		Group.Set("displayui", groupby).
			  Set("sendbackend", grp1)
		pipe = []tk.M{
			tk.M{}.Set("$match", WhereCond),
			tk.M{}.Set("$group", tk.M{}.Set("_id", Group)),
			tk.M{}.Set("$sort", tk.M{}.Set("_id", 1))}
	}

	
	crsx, ex := d.Ctx.Connection.NewQuery().
		Command("pipe", pipe).
		From("bondsmaster").
		Cursor(nil)
	if crsx == nil {
		resdata.IsError = true
		resdata.Message = "109. Cursor Not initialized.."
		resdata.Data = nil
	}
	defer crsx.Close()
	ds := []tk.M{}
	ex = crsx.Fetch(&ds, 0, false)
	if ex != nil {
		resdata.IsError = true
		resdata.Message = "115. " + ex.Error()
		resdata.Data = nil
	}

	resdata.Data = ds
	resdata.IsError = false
	resdata.Message = "Get Data Success"
	return resdata.Data
}

func (d *WidgetAnalysisController) GetFilterRatingDefault(payload FilterWidgetSyndicate) tk.M {
	WhereCond := tk.M{}

	if len(payload.Ownership) != 0 {
		WhereCond.Set("ownership", tk.M{}.Set("$in", payload.Ownership))
	}

	if len(payload.Currency) != 0 {
		WhereCond.Set("currency", tk.M{}.Set("$in", payload.Currency))
	}

	if len(payload.Ranking) != 0 {
		WhereCond.Set("ranking", tk.M{}.Set("$in", payload.Ranking))
	}

	if len(payload.Product) != 0 {
		WhereCond.Set("product", tk.M{}.Set("$in", payload.Product))
	}else{
		WhereCond.Set("product", tk.M{}.Set("$ne", ""))
	}

	if payload.Ratingvalue != 99.0 {
		WhereCond.Set(payload.Ratingtype, tk.M{}.Set(payload.Ratingaction, payload.Ratingvalue))
	}

	if payload.Filter.Logic != "" {
		for i, _ := range payload.Filter.Filters {
			if payload.Filter.Filters[i].Value != "" {
				switch payload.Filter.Filters[i].Operator {
				case "eq":
					WhereCond.Set(strings.ToLower(payload.Filter.Filters[i].Field), payload.Filter.Filters[i].Value)
					break
				case "neq":
					WhereCond.Set(strings.ToLower(payload.Filter.Filters[i].Field), tk.M{}.Set("$ne", payload.Filter.Filters[i].Value))
					break
				case "doesnotcontain":
					WhereCond.Set(strings.ToLower(payload.Filter.Filters[i].Field), tk.M{}.Set("$ne", payload.Filter.Filters[i].Value))
					break
				case "startswith":
					WhereCond.Set(strings.ToLower(payload.Filter.Filters[i].Field), bson.RegEx{"^" + payload.Filter.Filters[i].Value, "i"})
					break
				case "endswith":
					WhereCond.Set(strings.ToLower(payload.Filter.Filters[i].Field), bson.RegEx{payload.Filter.Filters[i].Value + "$", "i"})
					break
				default:
					WhereCond.Set(strings.ToLower(payload.Filter.Filters[i].Field), bson.RegEx{payload.Filter.Filters[i].Value, "i"})
					break
				}
			}
		}
	}

	return WhereCond
}

func (d *WidgetAnalysisController) GetMasterRangeSlopeOri(order string) []RangeSlopeModel {
	data6 := make([]RangeSlopeModel, 0)
	asc := 1
	if order == "DESC" {
		asc = -1
	}

	Where := tk.M{}
	Where.Set("_id", tk.M{}.Set("$ne", 7.0))
	sort := tk.M{}
	sort.Set("_id", asc)

	pipe := []tk.M{
		tk.M{
			"$match": Where,
		},
		tk.M{
			"$sort": sort,
		},
	}

	cursor6, err6 := d.Ctx.Connection.NewQuery().
		Command("pipe", pipe).
		From("masterrangeslope").
		Cursor(nil)

	if err6 != nil {
		tk.Println(err6.Error())
	}

	err6 = cursor6.Fetch(&data6, 0, false)
	if err6 != nil {
		tk.Println(err6.Error())
	}
	defer cursor6.Close()

	return data6
}

func (d *WidgetAnalysisController) WidgetSyndicate(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Search Data", "search issuer")
	defer d.LogBase(k, &resdata)

	payload := FilterWidgetSyndicate{}
	err := k.GetPayload(&payload)
	if err != nil {
		resdata.IsError = true
		resdata.Message = err.Error()
		resdata.Data = nil
	}
	WhereCond := d.GetFilterRatingDefault(payload)
	tablename := "bondsmaster"
	project := d.SyndicateProject()
	arryCall := d.FetchData(tablename, WhereCond, project, payload)
	MasterRange := d.GetMasterRangeSlopeOri("ASC")
	tenorDefault := []float64{3.0, 5.0, 7.0, 10.0}

	finalArray := []SyndicateModel{}
	for _,structData := range arryCall{
		listdata := structData
		for _, tenorUI := range tenorDefault {
			MinValue := tenorUI
			MaxValue := listdata.Yearsmaturity
			Minus := -1.0
			if tenorUI > listdata.Yearsmaturity {
				MinValue = listdata.Yearsmaturity
				MaxValue = tenorUI
				Minus = 1.0
			}

			res := 0.00
			for _, MR := range MasterRange {
				if MaxValue > MR.Minimumori && MinValue < MR.Maximumori {
					if (MaxValue - MR.Minimumori) <= 0 {
						break
					}

					DiffLeft := MR.Diff
					if (tenorUI > MR.Minimumori && tenorUI <= MR.Maximumori) && (listdata.Yearsmaturity > MR.Minimumori && listdata.Yearsmaturity <= MR.Maximumori) {
						//Same Bucket
						DiffLeft = math.Abs(listdata.Yearsmaturity - tenorUI)
					} else {
						//Normal Conditions for Different Value
						if MR.Minimumori < MinValue && MinValue <= MR.Maximumori {
							DiffLeft = math.Abs(MR.Maximumori - MinValue)
						}
						//Normal Conditions for Different Value
						if MR.Minimumori < MaxValue && MaxValue <= MR.Maximumori {
							DiffLeft = math.Abs(MaxValue - MR.Minimumori)
						}
					}

					Spread := 0.00
					switch listdata.Bucket {
					case "B1":
						Spread = MR.B1
						break
					case "B2":
						Spread = MR.B2
						break
					case "B3":
						Spread = MR.B3
						break
					case "B4":
						Spread = MR.B4
						break
					case "B5":
						Spread = MR.B5
						break
					case "B6":
						Spread = MR.B6
						break
					case "B7":
						Spread = MR.B7
						break
					default:
						break
					}

					doProcess := LogicTermSheet(Spread, MR.Diff, DiffLeft)
					res += doProcess
					// tk.Println(MR.Minimumori,"++",MR.Maximumori,":::",Spread, "-Spread", MR.Diff, "-Minus-", DiffLeft, "-res-", doProcess)
				}
			}
			// res = (res * Minus) + payload.Valuebasis
			res = (res * Minus) //+ payload.Valuebasis
			switch tenorUI {
			case 3.0:
				listdata.Three = res
				break
			case 5.0:
				listdata.Five = res
				break
			case 7.0:
				listdata.Seven = res
				break
			default:
				listdata.Ten = res
				break
			}

			finalArray = append(finalArray, listdata)

		}
	}

	resdata.Data = finalArray
	resdata.IsError = false
	return resdata
}

func (d *WidgetAnalysisController) SyndicateProject() tk.M {
	elseValue := tk.M{"$cond": []interface{}{tk.M{"$eq": []string{"$product", "Crossover"}}, "$bid_z_spread", tk.M{"$multiply": []interface{}{"$bid_ytm", 100.0}}}}
	Value := tk.M{"$cond": []interface{}{tk.M{"$eq": []string{"$product", "IG"}}, "$bid_z_spread", elseValue}}
	obj := tk.M{}.Set("issuer", 1).Set("product", 1).Set("industry", 1).Set("country", 1).Set("years_to_maturity", 1).Set("value", Value).Set("bucket", 1)

	return obj
}

func (d *WidgetAnalysisController) FetchAllData(tablename string, WhereCond tk.M, project tk.M) []SyndicateModel {
	arryCall := make([]SyndicateModel, 0)
	countstr := MgoQuery(tablename, "FindUseWhere", []string{}, "", "", WhereCond)
	count := tk.ToFloat64(countstr.Error(), 0, tk.RoundingAuto)
	if count > 100.00 {
		takefloat := math.Ceil(count / 10.00)
		take := tk.ToInt(takefloat, tk.RoundingAuto)
		//Go Routine Properties
		wg := new(sync.WaitGroup)
		var mutex = &sync.Mutex{}

		for i := 1; i <= 10; i++ {
			wg.Add(1)
			go func(i int) {
				skip := (i - 1) * take
				// tk.Println("script", skip, "==>", take)

				pipe := []tk.M{
					tk.M{
						"$match": WhereCond,
					},
					tk.M{
						"$project": project,
					},
					tk.M{
						"$skip": skip,
					},
					tk.M{
						"$limit": take,
					},
				}

				c, err := d.Ctx.Connection.NewQuery().
					Command("pipe", pipe).
					From(tablename).
					Cursor(nil)

				if err != nil {
					tk.Println(err.Error())
					wg.Done()
					return
				}

				arrm := make([]SyndicateModel, 0, 0)
				if err := c.Fetch(&arrm, 0, false); err != nil {
					tk.Println(err.Error())
					wg.Done()
					return
				}
				mutex.Lock()
				// tk.Println("range", skip, "==>", take, "==>", len(arrm))
				arryCall = append(arryCall, arrm...)
				mutex.Unlock()
				wg.Done()

			}(i)
		}

		wg.Wait()
	} else {
		pipe := []tk.M{
			tk.M{
				"$match": WhereCond,
			},
			tk.M{
				"$project": project,
			},
		}

		c, err := d.Ctx.Connection.NewQuery().
			Command("pipe", pipe).
			From(tablename).
			Cursor(nil)

		if err != nil {
			tk.Println(err.Error())
			return nil
		}

		if err := c.Fetch(&arryCall, 0, false); err != nil {
			tk.Println(err.Error())
			return nil
		}
	}

	return arryCall
}

func (d *WidgetAnalysisController) FetchData(tablename string, WhereCond tk.M, project tk.M, payload FilterWidgetSyndicate) []SyndicateModel {
	
	Flimit := payload.Skip + payload.Take
	pipe := []tk.M{
		tk.M{
			"$match": WhereCond,
		},
		tk.M{
				"$project": project,
		},
		tk.M{}.Set("$limit", Flimit),
		tk.M{}.Set("$skip", payload.Skip),
	}

	crsx, ex := d.Ctx.Connection.NewQuery().
		Command("pipe", pipe).
		From(tablename).
		Cursor(nil)
	if crsx == nil {
		d.ErrorResultInfo("Cursor Not initialized..", nil)
	}
	defer crsx.Close()
	ds := make([]SyndicateModel, 0)
	ex = crsx.Fetch(&ds, 0, false)
	if ex != nil {
		d.ErrorResultInfo(ex.Error(), nil)
	}

	return ds
}

func (d *WidgetAnalysisController) GetDonutDistributionStatistic(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Get Data", "GetDonutInvestorOne")
	defer d.LogBase(k, &resdata)

	payload := FilterWidget{}
	err := k.GetPayload(&payload)
	if err != nil {
		resdata.IsError = true
		resdata.Message = err.Error()
		resdata.Data = nil
	}

	WhereCond := d.GetFilterWidgetDefault(payload)

	project := tk.M{}.Set("us_value", 1).Set("emea_value", 1).Set("asia_value", 1)
	sumtkm := tk.M{
					"$group": tk.M{
						"_id":       "",
						"us_value"	: tk.M{"$sum": "$us_value"},
						"emea_value": tk.M{"$sum": "$emea_value"},
						"asia_value": tk.M{"$sum": "$asia_value"},
					},
				}

	if payload.Flag != "Geography" {
		project = tk.M{}.Set("banks_value", 1).Set("pb_value", 1).Set("fm_value", 1).
					  Set("insurance_value", 1).Set("others_value", 1)

		sumtkm = tk.M{
				"$group": tk.M{
					"_id":       "",
					"banks_value"	: tk.M{"$sum": "$banks_value"},
					"pb_value"		: tk.M{"$sum": "$pb_value"},
					"fm_value"		: tk.M{"$sum": "$fm_value"},
					"insurance_value": tk.M{"$sum": "$insurance_value"},
					"others_value"	: tk.M{"$sum": "$others_value"},
				},
			}
	}

	

	pipe := []tk.M{
		tk.M{
			"$match": WhereCond,
		},
		sumtkm,
		tk.M{
				"$project": project,
		},
	}

	result := []tk.M{}
	csr, ex := d.Ctx.Connection.NewQuery().
		Command("pipe", pipe).
		From("bondsmaster").
		Cursor(nil)
	defer csr.Close()
	ex = csr.Fetch(&result, 0, false)

	if ex != nil {
		resdata.IsError = true
		resdata.Message = "115. " + ex.Error()
		resdata.Data = nil
	}

	resdata.Data = result
	resdata.IsError = false
	resdata.Message = "Get Data Success"
	return resdata
}