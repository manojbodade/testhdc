var wa_AlcChart = {
	f:{
		input1:ko.observable(0),
		input2:ko.observable(0),
	},
	pullRequest: ko.observable(0),
	loading: ko.observable(false),
};
wa_AlcChart.pullRequest.subscribe(function(n){
	if(n == 0)
		return wa_AlcChart.loading(false);
})
wa_AlcChart.RenderGrid = function(payload, selector){
	var $selector = $(selector).find(".wa_alcChart #grid");
	payload.InputOne = parseFloat( wa_AlcChart.f.input1() );
	payload.InputTwo = parseFloat( wa_AlcChart.f.input2() );
	var url = "/widgetanalysis/getgridallocation";

	// var maxAllocated = 0;

	$selector.html("");
	$selector.kendoGrid({
		dataSource: {
			transport: {
				read:function(option){
					payload.skip = option.data.skip;
					payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : '';
					payload.take = option.data.take;
                    ajaxPost(url, payload, function(res){
                        option.success({ Records: res.Data, Count: res.Total });
                    })
                },
			},
			schema: {
				data: function(data) {
                    return data.Records;
				},
				total: "Count",
			},
			pageSize: 20,
			serverPaging: true,
			serverSorting: true,
		},
		sortable: true,
		pageable: {
              numeric: true,
              previousNext: true,
              messages: {
                  display: "Showing {2} data items"
              }
        },
		columns: [
			{
				title: "Investor Name",
				field: "investor_name",
			 	attributes: {
	                "class": "align-left"
                },
                headerAttributes: {
					"class": "align-left"
                },
			},
			{
				title: "Issue Date",
				field: "issue_date",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Issuer",
				field: "issuer",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Issue Size",
				field: "size",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Currency",
				field: "currency",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Ranking(Senior AT1 Tier2)",
				field: "ranking",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Product(HY/IG)",
				field: "product",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			}
		]
	});
};
// wa_AlcChart.init =  function(payload, selector){
// 	wa_AlcChart.loading(true);
// 	wa_AlcChart.pullRequest(1);
// 	wa_AlcChart.RenderGrid(payload, selector);
// };
//
wa_AlcChart.GenerateChart =  function(){
	var payload =  wa.getPayload();
	var $selector = wa.$getSelectorPage();
	var template = wa.getActivePage();
	template.mainPage.mode('preview');
	template.mainPage.type('allocation');
	wa_AlcChart.RenderGrid(payload, $selector);
};
wa_AlcChart.init =  function(){
	$modal = $("#wa_AlcChartModal");
	$modal.modal("show");
	if(wa.config.realoadProcess()){
		wa_AlcChart.GenerateChart();
	}
};
