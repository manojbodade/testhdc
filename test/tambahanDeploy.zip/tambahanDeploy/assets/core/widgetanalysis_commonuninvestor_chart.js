var wa_CommonUnInvChart = {
	f:{
		commonInvestorsList: ko.observableArray([]),
		commonInvestorsVal: ko.observableArray([]),
		commonInvestedList: ko.observableArray([]),
		commonInvestedVal: ko.observableArray([]),
	}
};

wa_CommonUnInvChart.GetDatacommonUnInv = function() {
  var payload = wa.getPayload();
  payload["Flag"] = "issuer";
  getFilter("/widgetanalysis/getcountrydetail", payload, wa_commonInvChart.f.commonInvestorsList);
  payload["Flag"] = "issuer";
  getFilter("/widgetanalysis/getcountrydetail", payload, wa_commonInvChart.f.commonInvestedList);
}
wa_CommonUnInvChart.RenderGrid = function(payload, selector){
	var $selector = $(selector).find(".wa_alcChart #grid");
	var url = "/widgetanalysis/getgridallocation";

	// var maxAllocated = 0;

	$selector.html("");
	$selector.kendoGrid({
		dataSource: {
			transport: {
				read:function(option){
					payload.skip = option.data.skip;
					payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : '';
					payload.take = option.data.take;
                    ajaxPost(url, payload, function(res){
                        option.success({ Records: res.Data, Count: res.Total });
                    })
                },
			},
			schema: {
				data: function(data) {
                    return data.Records;
				},
				total: "Count",
			},
			pageSize: 20,
			serverPaging: true,
			serverSorting: true,
		},
		sortable: true,
		pageable: {
              numeric: true,
              previousNext: true,
              messages: {
                  display: "Showing {2} data items"
              }
        },
		columns: [
			{
				title: "Investor Name",
				field: "investor_name",
			 	attributes: {
	                "class": "align-left"
                },
                headerAttributes: {
					"class": "align-left"
                },
			},
			{
				title: "Issue Date",
				field: "issue_date",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Issuer",
				field: "issuer",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Issue Size",
				field: "size",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Currency",
				field: "currency",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Ranking(Senior AT1 Tier2)",
				field: "ranking",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Product(HY/IG)",
				field: "product",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			}
		]
	});
};
wa_CommonUnInvChart.GenerateChart =  function(){
 	$("#commonUnInvestorModal").modal("hide");
	var payload =  wa.getPayload();
	var $selector = wa.$getSelectorPage();
	var template = wa.getActivePage();
	template.mainPage.mode('preview');
	template.mainPage.type('allocation');
	payload['Flag'] = 'Uninvestor';
	payload['Issuerdetail'] = wa_CommonUnInvChart.f.commonInvestorsVal();
	payload['Issuerdetail2'] = wa_CommonUnInvChart.f.commonInvestedVal();
	wa_CommonUnInvChart.RenderGrid(payload, $selector);
};
wa_CommonUnInvChart.GetDatacommonUnInv = function(){
	var payload = wa.getPayload();
	payload["Flag"] = "issuer";
	getFilter("/widgetanalysis/getcountrydetail", payload, wa_CommonUnInvChart.f.commonInvestorsList);
	payload["Flag"] = "issuer";
	getFilter("/widgetanalysis/getcountrydetail", payload, wa_CommonUnInvChart.f.commonInvestedList);
}
wa_CommonUnInvChart.init =  function(){
	wa_CommonUnInvChart.GetDatacommonUnInv();
	$("#commonUnInvestorModal").modal("show");
};
