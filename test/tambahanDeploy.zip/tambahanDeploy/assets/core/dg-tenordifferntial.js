var dgTenorDifferent 	 = {}
dgTenorDifferent.loading = ko.observable(false);
dgTenorDifferent.widget  = { id:"chart0", loading:ko.observable(false) }; 
dgTenorDifferent.filter  = {
	list:{
		issuer : ko.observableArray([])
	},
	value:{
		issuer : ko.observableArray([]),
		isin : ko.observable(""),
	}
};

dgTenorDifferent.pullRequest = ko.observable(0);
dgTenorDifferent.getPayload = function(type){
	return {
		Tenor     	: pbGrid.firstChecked.tenor(),
		Ranking     : pbGrid.firstChecked.instrument(),
		Currency	: pbGrid.firstChecked.currency(),
		Comp 		: pbFormWizard.comp.value(),
		issuer 		: dgTenorDifferent.filter.value.issuer(),
		Country 	: ds.issuerSelected.country,
		Industry 	: ds.issuerSelected.industry,
		Spissuerating 		: ds.issuerSelected.sp_issuer_rating, 
		Moodysissuerating 	: ds.issuerSelected.moodys_issuer_rating,
		Fitchissuerrating 	: ds.issuerSelected.fitch_issuer_rating,		
		Product 			: ds.issuerSelected.product,
		Region 				: ds.issuerSelected.region,
		Superindustry 		: ds.issuerSelected.super_industry,
		Bucket 				: ds.issuerSelected.bucket,
		Ownership 			: ds.issuerSelected.ownership,
	};
};

dgTenorDifferent.pullRequest.subscribe(function(newVal){
	if(newVal == 0)
		dgTenorDifferent.loading(false);
});
dgTenorDifferent.filter.value.issuer.subscribe(function(newVal){
	dgTenorDifferent.getDataChart();
});
dgTenorDifferent.refreshChart = function(id,isin){ 
	dgTenorDifferent.filter.value.isin(isin);
	$("#"+id).find(".contentWidget").data("kendoChart").redraw();  
};
dgTenorDifferent.createSeriesChart = function(id,circelData, lineDatas){
	var circelSeries = 	{
			type: "scatter",
			xField: "x",
			yField: "y",
			data: circelData,
			color : function(e){
				if(e.dataItem.isin == dgTenorDifferent.filter.value.isin())
					return  "#00CC99"; 
				else 
					return  "#7BBFF6";
			},
			markers: {
				size: function(e){
				 
					if(e.dataItem.isin == dgTenorDifferent.filter.value.isin())
						return 13
					else 
						return 8 
				}, 
				background : function(e){
					if(e.dataItem.isin == dgTenorDifferent.filter.value.isin())
						return  "#00CC99";
					else 
						return  "#7BBFF6";
				}
			},
			tooltip:{
				background:"#353D47",
	            border: {
	                width: 1,
	                color: "#DDD"
	            },
	            visible:true,
				template:function(e){
					if(e.dataItem.isin != dgTenorDifferent.filter.value.isin()){
						return "<table>"+
									"<tr>"+
										"<td>Issuer</td>"+ 
										"<td>"+e.dataItem.issuer+"</td>"+ 
									"</tr>"+
									"<tr>"+
										"<td>Size</td>"+ 
										"<td>"+kendo.toString(e.dataItem.size, 'n2')+"</td>"+ 
									"</tr>"+
									"<tr>"+
										"<td>Bid YTM</td>"+ 
										"<td>"+kendo.toString(e.dataItem.y, 'n2')+"</td>"+ 
									"</tr>"+
									"<tr>"+
										"<td>Tenor</td>"+ 
										"<td>"+kendo.toString(e.dataItem.x, 'n2')+"</td>"+ 
									"</tr>"+
									"<tr>"+
										"<td>Currency</td>"+ 
										"<td>"+e.dataItem.currency+"</td>"+ 
									"</tr>"+
									"<tr>"+
										"<td>Spread</td>"+ 
										"<td>"+ kendo.toString(e.dataItem.Spread,'n2')+"</td>"+ 
									"</tr>"+
									 "<tr>"+
										"<td colspan='2'><div  onclick='dgTenorDifferent.refreshChart(\""+id+"\",\""+e.dataItem.isin+"\" )'  style=' background: #7BBFF6; color: #000; padding: 2px 6px; cursor:pointer' class='button-tooltip'>Mark as Basis</div></td>"+ 
									"</tr>"+
								"</table>";
					}else{
						return "<table>"+
									"<tr>"+
										"<td>Issuer</td>"+ 
										"<td>"+e.dataItem.issuer+"</td>"+ 
									"</tr>"+
									"<tr>"+
										"<td>Size</td>"+ 
										"<td>"+e.dataItem.size+"</td>"+ 
									"</tr>"+
									"<tr>"+
										"<td>Bid YTM</td>"+ 
										"<td>"+kendo.toString(e.dataItem.y, 'n2')+"</td>"+ 
									"</tr>"+
									"<tr>"+
										"<td>Tenor</td>"+ 
										"<td>"+kendo.toString(e.dataItem.x, 'n2')+"</td>"+ 
									"</tr>"+
									"<tr>"+
										"<td>Currency</td>"+ 
										"<td>"+e.dataItem.currency+"</td>"+ 
									"</tr>"+
									"<tr>"+
										"<td>Spread</td>"+ 
										"<td>"+ kendo.toString(e.dataItem.Spread,'n2')+"</td>"+ 
									"</tr>"+
									"<tr>"+
										"<td colspan='2'><div style=' background: #0CB38B; color: #000; padding: 2px 6px;' class='button-tooltip'>Marked as Basis</div></td>"+ 
									"</tr>"+
								"</table>";
					}
				}
			}
		}
	var series 		 = [circelSeries];

	var lineKeyPrefix    = "line"; 
	_.each(lineDatas, function(line,idx){
		var keyId = lineKeyPrefix + String(idx);
		series.push({
			name 	: keyId,
			type 	: "scatterLine",
			xField 	: "x",
			yField 	: "y",
			data 	: line[keyId],
			width 	: 2,
			style 	: "smooth", 
			color 	:"#8497B0", 
			markers : {
				size 	: 0,
				visible : false
			}
		});
	});
	return series;
};
dgTenorDifferent.createChart = function(id,series, error){
	var allSeriesData  		   = _.flatten(_.pluck(series, 'data'));;
	var scatterlineSeriesData  = _.flatten(_.pluck(series,
												_.findWhere(series,  {type:'scatterLine'})
						  				  ));
	var maxY = _.max(_.clone(allSeriesData), function(data){
					if(!_.has(data,'y'))
						return 0;
				 	return data.y;
				}).y;
 

	$("#"+id).find(".contentWidget").kendoChart({
		series: series,
		legend:{
			visible:false
		},
		xAxis: {
			labels: { 
			      font: ds.font('9px'),
			},
          	majorGridLines:{
            	visible:false
            }, 
        },
        yAxis:{
        	max   : ( maxY == undefined )? 1 : maxY * 1.1,
    		labels: { 
			      font: ds.font('9px'),
			},
        	min:0,
        	plotBands: plotband(maxY),
        	notes: {
				label: {
		        	template:  error ? "Result NaN found in Line Chart" : "Y = Mx + b", 
		        	rotation: -30,
		        	color   :  error ?  "#E74C3C" : "#000"  
		      	},
		      	data: [{value:  (scatterlineSeriesData > 0 && _.has(scatterlineSeriesData,'y')) ? scatterlineSeriesData[0].y : 2}]
		    }
        },
		pannable 	: true,
        zoomable 	: false,
        render 		: function(){
        	setTimeout(function(){
        		$("#"+id).find(".contentWidget").find("svg > g > g:nth-child(3)  circle").attr("stroke-width",0)
        	},300);
        }
	});
};

function plotband(maxY){
	var majorunit = maxY / 10;
	var plotband = [];
	for (i = 0; i < maxY / majorunit; i++) {
		var mod = i % 2;
		plotband.push({
			from 	: (i == 0)? 0 : majorunit * i,
			to 		: (majorunit * i) + majorunit,
			color 	: (mod == 0)? '#f5f5f5' : '#fff'
		});
	};
 
	return plotband
}
dgTenorDifferent.GetIssur = function(){
	var payload = dgTenorDifferent.getPayload();
	ajaxPost("/dashboard/getissuer", payload, function (res){
		dgTenorDifferent.filter.list.issuer(res.Data);
		dgTenorDifferent.pullRequest(dgTenorDifferent.pullRequest() - 1);
	});
};
dgTenorDifferent.getDataChart = function(){
	var config = dgTenorDifferent.widget;
	var customPayloadTenor =  function(tenors){ 
		if(tenors.indexOf(7) > -1)
			return [3,5,7,10];
		else
			return [3,5,10];
	};

	config.loading(true);
	$("#"+config.id).find(".contentWidget").html("");

	var payload       = dgTenorDifferent.getPayload(); 
		payload.Tenor = customPayloadTenor(payload.Tenor);

 	ajaxPost("/pricebond/gettenordifferential" , payload , function(res){
		if(res.IsErrors)
			return;
		var circelData = res.Data.DataSource;

		var payloadQuerySlope 		 = dgTenorDifferent.getPayload(); 
			payloadQuerySlope.Tenor  = customPayloadTenor(payload.Tenor);
			payloadQuerySlope.Tenorx = _.pluck(circelData, 'x').sort();

		ajaxPost("/dashboard/queryslope", payloadQuerySlope, function (resQuerySlope){
			config.loading(false);
			var lineDatas = resQuerySlope.Data;
			
			_.each(circelData, function(circle){
				circle.Spread = 0
				var gridData = _.filter(resQuerySlope.GridData, function(o){ if(circle.x >= o.IncStart && circle.x < o.Inc) return o  })[0];				
				if(gridData != undefined || _.has(gridData, 'Spread'))
					circle.Spread = gridData.Spread;
			});
			
			return dgTenorDifferent.createChart(
												 config.id, 
											 	 dgTenorDifferent.createSeriesChart(config.id, circelData, lineDatas), 
												 resQuerySlope.IsError
												);
		});
	});
};
dgTenorDifferent.init = function(){
	ds.breadcrumb([ {title:'Dashboard',event:ds.ChangeTab,tab:'Dashboard' }, {title: ds.alias(),event:priceBond.ChangeTab, tab:'home' }, {title:'Client Search'}]);
	dgTenorDifferent.filter.value.isin("");
	dgTenorDifferent.pullRequest(1);	
	dgTenorDifferent.loading(true);
	dgTenorDifferent.GetIssur();
	dgTenorDifferent.getDataChart();
};