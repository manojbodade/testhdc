var wa_SlsPersonChart = {
	pullRequest: ko.observable(0),
	loading: ko.observable(false)
};
wa_SlsPersonChart.pullRequest.subscribe(function(n){
	if(n == 0)
		return wa_SlsPerson.loading(false);
})

wa_SlsPersonChart.RenderGrid = function(url, payload, $selector){
	var $selector = $($selector).find("#grid");
	payload.Flag = "sales_person";
	var maxAllocated = 0;

	$selector.html("");
	$selector.kendoGrid({
		dataSource: {
			transport: {
				read:function(option){
					payload.skip = option.data.skip
					payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : [];
					payload.take = option.data.take
					ajaxPost(url, payload, function(res){
				 		wa_SlsPersonChart.pullRequest(wa_SlsPersonChart.pullRequest() - 1);
						maxAllocated = res.Data.max;
						option.success({ Records: _.sortBy(res.Data.data, 'allocated').reverse(), Count: res.Total });
					})
	      	},
		},
		schema: {
			data: function(data) {
                return data.Records;
			},
			total: "Count",
		},
	    pageSize: 20,
		serverPaging: true,
		serverSorting: true,
		serverFiltering: true,
		},
		sortable: true,
		pageable: {
			numeric: true,
			previousNext: true,
			messages: {
				display: "Showing {2} data items"
			}
		},
		columns: [
			{
				title: "Investor Name",
				field: "_id",
				width: 300,
			 	attributes: {
	                "class": "align-left"
	            },
	            headerAttributes: {
					"class": "align-left"
	            },
			},
			{
				title: "Firm",
				field: "firm",
				width: 100,
				attributes: {
	                "class": "align-center"
	            },
	            headerAttributes: {
	                "class": "align-center"
	            },
			},
			{
				title: "Allocation Amount",
				field: "allocated",
				attributes: {
					"class": "progressbar-cel"
				},
				headerAttributes: {
	                "class": "align-center"
	            },
				template: function(e){

					var percentage = ( maxAllocated == 0 ) ? 0 : 92 / ( maxAllocated / e.allocated );
					return  "<div class='pull-left series-bar' style='width: "+ percentage +"%'></div>" +
							"<div class='pull-left number'> " + e.allocated + "</div>";
				}
			}
		]
	});
};

wa_SlsPersonChart.generateDataViz = function() {
	var payload = wa.getPayload();
	var template = wa.getActivePage();
	template.mainPage.mode('preview');
	template.mainPage.type('wa_SlsPersonChart');
	wa_SlsPersonChart.RenderGrid(
							"/widgetanalysis/getgridtransaction",
							wa.getPayload(),
							wa.$getSelectorPage().find(".wa_SlsPersonChart")
						);
}

wa_SlsPersonChart.init = function(){
 	wa_SlsPersonChart.generateDataViz();
};
