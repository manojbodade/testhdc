var wa_DisChart = {
  f:{
    defaultTypes: ['Contains', 'Equals'],
    investorsList: ko.observableArray([]),
    investedList: ko.observableArray([]),
    val: {
      Countrydetail: ko.observableArray([]),
      Actions: ko.observable("Equals"),
      Text: ko.observable(""),
      Textmulti: ko.observableArray([]),
    }
  },
	pullRequest: ko.observable(0),
	loading: ko.observable(false),
	columns: ko.observableArray([])
};
var columns = [], gridSelector;
var url = "/widgetanalysis/getgriddistributions";

wa_DisChart.pullRequest.subscribe(function(n){
	if(n == 0)
		return wa_DisChart.loading(false);
});
function generateColumn(payload, cb) {
	payload.skip = 0;
	payload.take = 10;
	payload.sort = [];
	ajaxPost(url, payload, function(res) {
		if(res.Data.column.length > 0) {
      _.each(res.Data.column, function(o) {
  			columns.push({
  				title: o,
  				field: o,
  				width: 100,
  				attributes: {
  					"class": "text-center"
  				},
  				headerAttributes: {
  					"class": "text-center"
  				},
  				template: function(dataItem) {
  					if(dataItem[o] == 'x') {
  						return "<span class='fa fa-times'></span>"
  					} else {
  						return "<span class='fa fa-check'></span>"
  					}
  				}
  			});
  		});
  		cb(payload);
    } else {
      gridSelector.html("data not found");
    }
	})
}
var generateGrid = function(payload) {
  console.log(columns);
	gridSelector.kendoGrid({
		dataSource: {
			transport: {
				read: function(option) {
					payload.skip = option.data.skip;
					payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : [];
					payload.take = option.data.take;
					ajaxPost(url, payload, function(res) {
						option.success({ Records: res.Data.data, Count: res.Total });
					});
				}
			},
			schema: {
				data: "Records",
				total: "Count"
			},
			serverPaging: true,
			serverSorting: true,
			serverFiltering: true,
			pageSize: 20,
		},
		scrollable: true,
		pageable: {
              numeric: true,
              previousNext: true,
              messages: {
                  display: "Showing {2} data items"
              }
        },
		columns: columns
	});
}
wa_DisChart.RenderGrid = function(payload, $selector){
 	$selector = $selector.find("#grid");


	$selector.html("");
	gridSelector = $selector;
	columns = [];
	columns.push({
		title: "Investor Name",
		field: "investorname",
		width: 200,
		locked: true,
		lockable: false,
		attributes: {
							"class": "align-left"
						},
						headerAttributes: {
			"class": "align-left"
						},
	});
	generateColumn(payload, generateGrid);
};

wa_DisChart.generateDataViz = function(){
  var template = wa.getActivePage();
  template.mainPage.mode('preview');
  template.mainPage.type('wa_DisChart');

  var payload = wa.getPayload();
  payload['Countrydetail'] = payload['Countrydetail'] ? payload['Countrydetail'] : wa_DisChart.f.val.Countrydetail();
  payload['Actions'] = payload['Actions'] ? payload['Actions'] : wa_DisChart.f.val.Actions();
  payload['Text'] = payload['Text'] ? payload['Text'] : wa_DisChart.f.val.Text();
  payload['Textmulti'] = payload['Textmulti'] ? payload['Textmulti'] : wa_DisChart.f.val.Textmulti();

  wa.config.caption("Page of Investors");

  var $selector = wa.$getSelectorPage().find('.wa_DisChart');
  wa_DisChart.RenderGrid(payload, $selector);
};

wa_DisChart.GetDataDistributions = function( ) {
  var payload = wa.getPayload();
  payload["Flag"] = "country";
  getFilter("/widgetanalysis/getcountrydetail", payload, wa_DisChart.f.investorsList);
  payload["Flag"] = "issuer";
  getFilter("/widgetanalysis/getcountrydetail", payload, wa_DisChart.f.investedList);
}
wa_DisChart.init =  function(){
  wa_DisChart.GetDataDistributions();
  $("#wa_DisChartModal").modal("show");
};
