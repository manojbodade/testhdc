var creditProfile 	= {};

creditProfile.widget = {
	summaryFinancial :{
		id 	 :"summaryFinancial",
		title:"Summary Financials",
		url  :"#",
		loading : ko.observable(false),
	},
	loanByborrower :{
		id 	 :"loanByborrower",
		title:"Loans by borrower type (KRW bn)",
		url  :"/creditprofile/getloanborrower",
		loading : ko.observable(false),
	},
	fundingMix :{
		id 	 :"fundingMix",
		title:"Funding mix",
		url  :"/creditprofile/getfunding",
		loading : ko.observable(false),
	},
	nimAndAverage:{
		id 	 :"nimAndAverage",
		title:"NIM and average interest earned (%)",
		url  :"/creditprofile/getnimavg",
		loading : ko.observable(false),
	},
	assetQuality :{
		id 	 :"assetQuality",
		title:"Asset Quality (%)",
		url  :"/creditprofile/getassetquality",
		loading : ko.observable(false),
	},
	loanByIndustry:{
		id 	 :"loanByIndustry",
		title:"Loans by Industry (KRW bn)",
		url  :"/creditprofile/getloanindustry",
		loading : ko.observable(false),
	},
	capitalAdquaecy:{
		id 	 :"capitalAdquaecy",
		title:"Capital adequacy and ROE %",
		url  :"/creditprofile/getcapitaladequacy",
		loading : ko.observable(false),
	},
	revenueBytype:{
		id 	 :"revenueBytype",
		title:"Revenue by type of income (KRW bn)",
		url  :"/creditprofile/getrevenueincome",
		loading : ko.observable(false),
	},
};

creditProfile.getPayload = function(){
	return {
		issuer:ds.search(),
	}
};
creditProfile.widget.summaryFinancial.Render = function(){
	with(creditProfile.widget.summaryFinancial){
		var payload = creditProfile.getPayload()
	}
};

creditProfile.widget.loanByborrower.Render = function(){
	with(creditProfile.widget.loanByborrower){
		loading(true);

		var payload = creditProfile.getPayload()
		ajaxPost(url, payload, function(res){
			$sel = $("#"+id).find(".contentWidget");
			$sel.html("");
			loading(false);		 
			if(res.IsError)
				return; 

			ds.drawChartBar($sel, [
										{
											categoryField:'Category',
											field:  "Value",
											type: "bar",
											data: res.Data.Datasource,
										}
									]
							);
			
		});
	};
};

creditProfile.widget.fundingMix.Render = function(){
	with(creditProfile.widget.fundingMix){ 
		loading(true); 

		var payload = creditProfile.getPayload()
		ajaxPost(url, payload, function(res){
			$sel = $("#"+id).find(".contentWidget");
			$sel.html("");
			loading(false);		 
			if(res.IsError)
				return; 

		 	ds.drawChartBar($sel, ds.generateSeriesStackBar(res.Data.TotalStuck,  res.Data.Datasource));
		});	 	 
	};
};
creditProfile.widget.nimAndAverage.Render = function(){
	with(creditProfile.widget.nimAndAverage){
		loading(true); 

		var payload = creditProfile.getPayload()
		ajaxPost(url, payload, function(res){
			$sel = $("#"+id).find(".contentWidget");
			$sel.html("");
			loading(false);		 
			if(res.IsError)
				return; 

			ds.drawChartBar($sel, [
										{
											categoryField:'Category',
											field:  "Value",
											type: "line", 
											data: res.Data.Datasource,
										}
									]
							);
			
		});
	};
};
creditProfile.widget.assetQuality.Render = function(){
	with(creditProfile.widget.assetQuality){ 
		loading(true);
		$("#"+id).find(".contentWidget").html("");;
		var payload = creditProfile.getPayload()
		ajaxPost(url, payload, function(res){
			$sel = $("#"+id).find(".contentWidget");
			$sel.html("");
			loading(false);		 
			if(res.IsError)
				return; 
			$("#"+id).find(".contentWidget").kendoChart({
				seriesColors: ds.chartSeriesColor,
				theme: "flat",
				series:[{
					categoryField:'Category',
					field:  "Value",
					type: "column",
					data: res.Data.Datasource.Bar,
				},{
					categoryField:'Category',
					field:  "Value",
					type: "line",
					name:"line",
					data: res.Data.Datasource.Line, 
				}],
	            legend: {
	                visible: false
	            },
	            seriesDefaults: {
					overlay: {
						gradient: "none"
					},
					gap: 0.1,
				},
	            valueAxis: [
					
					{
						max: (res.Data.Max.Bar == 0) ? 0 : res.Data.Max.Bar * 1.2,
						line: {
							visible: true,
							color: '#f1f1f1'
						},
						majorGridLines: {
							visible: false
						},
						labels: {
							color: "#4c5356",
							font: ds.font('9px'),
							visible: true,
							background: "transparent",
						},
					},
					{ 
						min:0,
						max: (res.Data.Max.Line == 0 ) ? 0 : res.Data.Max.Line * 1.25,
						name:"line", 
						line: {
							visible: true,
							color: '#f1f1f1'
						},
						 
						majorGridLines: {
							visible: false
						},
						labels: {
							color: "#4c5356",
							font: ds.font('9px'),
							visible: true,
							background: "transparent",
						},
					}

				],
	            categoryAxis: {
					labels: {
						color: "#4c5356",
						font: ds.font('9px'),
						visible: true,
						background: "transparent",
					},
					majorGridLines: {
						visible: false
					},
					line:{
						visible: true
					},
					axisCrossingValue:[0,10]
	            },
	            tooltip: {
	                visible: true,
	                template: "  #= value #"
	            }
	        })
		});
	
	};
};
creditProfile.widget.loanByIndustry.Render = function(){
	with(creditProfile.widget.loanByIndustry){
		loading(true);
		 
		var payload = creditProfile.getPayload()
		ajaxPost(url, payload, function(res){
			$sel = $("#"+id).find(".contentWidget");
			$sel.html("");
			
			loading(false);		 
			if(res.IsError)
				return; 
			
			ds.drawChartBar($sel, [
										{
											categoryField:'Category',
											field:  "Value",
											type: "bar", 
											data: res.Data.Datasource,
										}
									]
							);
		});
	};
};

creditProfile.widget.capitalAdquaecy.Render = function(){
	with(creditProfile.widget.capitalAdquaecy){ 
		loading(true);
		 
		var payload = creditProfile.getPayload()
		ajaxPost(url, payload, function(res){
			$sel = $("#"+id).find(".contentWidget");
			$sel.html("");

			loading(false);		 
			if(res.IsError)
				return; 
			
			var series = [];
			series = series.concat(ds.generateSeriesStackBar(res.Data.TotalStuck, res.Data.Datasource.Bar));
	 		series.push({
				categoryField:'Category',
				field : "Value",
				type  : "line", 
				name  : "line",
				data  : res.Data.Datasource.Line,
			})
			$("#"+id).find(".contentWidget").kendoChart({
				seriesColors: ds.chartSeriesColor,
				theme: "flat",
				series:series,
	            legend: {
	                visible: false
	            },
	            seriesDefaults: {
					overlay: {
						gradient: "none"
					},
					gap: 0.1,
				},
	            valueAxis: [
					
					{
						max: (res.Data.TotalValueStack == 0) ? 0 : res.Data.TotalValueStack * 1.2,
						line: {
							visible: true,
							color: '#f1f1f1'
						},
						majorGridLines: {
							visible: false
						},
						labels: {
							color: "#4c5356",
							font: ds.font('9px'),
							visible: true,
							background: "transparent",
						},
					},
					{ 
						min:0,
						max: (res.Data.Max.Line == 0 ) ? 0 : res.Data.Max.Line * 1.25,
						name:"line", 
						line: {
							visible: true,
							color: '#f1f1f1'
						},
						 
						majorGridLines: {
							visible: false
						},
						labels: {
							color: "#4c5356",
							font: ds.font('9px'),
							visible: true,
							background: "transparent",
						},
					}

				],
	            categoryAxis: {
					labels: {
						color: "#4c5356",
						font: ds.font('9px'), 
						visible: true,
						background: "transparent",
					},
					majorGridLines: {
						visible: false
					},
					line:{
						visible: true
					},
					axisCrossingValue:[0,10]
	            },
	            tooltip: {
	                visible: true,
	                template: " #= value #"
	            }
	        })
		});	 	 
	};
};
creditProfile.widget.revenueBytype.Render = function(){
	with(creditProfile.widget.revenueBytype){
		loading(true);
		 
		var payload = creditProfile.getPayload()
		ajaxPost(url, payload, function(res){
			$sel = $("#"+id).find(".contentWidget");
			$sel.html("");
			
			loading(false);		 
			if(res.IsError)
				return; 
			
			ds.drawChartBar($sel, [
										{
											categoryField:'Category',
											field:  "Value",
											type: "bar", 
											data: res.Data.Datasource,
										}
									]
							);
		})
	};
};



creditProfile.init =  function(){
	setTimeout(function(){ creditProfile.widget.loanByborrower.Render()}, 10);
	setTimeout(function(){ creditProfile.widget.fundingMix.Render() }, 10);
	setTimeout(function(){ creditProfile.widget.nimAndAverage.Render() }, 10); 
	setTimeout(function(){ creditProfile.widget.assetQuality.Render() }, 10);
	setTimeout(function(){ creditProfile.widget.loanByIndustry.Render() }, 10); 
	setTimeout(function(){ creditProfile.widget.capitalAdquaecy.Render() }, 10);
	setTimeout(function(){ creditProfile.widget.revenueBytype.Render() }, 10);
};