var wa_CommonInvChart = {
	f:{
		investorsList: ko.observableArray([]),
		val: {
			Issuerdetail: ko.observableArray([]),
		}
	}
};

wa_CommonInvChart.GetDatacommonUnInv = function() {
  var payload = wa.getPayload();
  payload["Flag"] = "issuer";
  getFilter("/widgetanalysis/getcountrydetail", payload, wa_CommonInvChart.f.commonInvestorsList);
  payload["Flag"] = "issuer";
  getFilter("/widgetanalysis/getcountrydetail", payload, wa_CommonInvChart.f.commonInvestedList);
};

wa_CommonInvChart.RenderGrid = function(url, payload, $selector){
	var $selector = $($selector).find("#grid");
	var maxAllocated = 0;

	$selector.html("");
	$selector.kendoGrid({
		dataSource: {
			transport: {
				read:function(option){
					payload.skip = option.data.skip
					payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : [];
					payload.take = option.data.take
					ajaxPost(url, payload, function(res){
					//        	var datas = res;
					// var sortDatas = sortBarChart(datas)
					// console.log('sss',sortDatas)
						wa_DefChart.pullRequest(wa_DefChart.pullRequest() - 1);
						maxAllocated = res.Data.max;
						option.success({ Records: _.sortBy(res.Data.data, 'allocated').reverse(), Count: res.Total });
					})
	      	},
		},
		schema: {
			data: function(data) {
                return data.Records;
			},
			total: "Count",
		},
	    pageSize: 20,
		serverPaging: true,
		serverSorting: true,
		serverFiltering: true,
		},
		sortable: true,
		pageable: {
			numeric: true,
			previousNext: true,
			messages: {
				display: "Showing {2} data items"
			}
		},
		columns: [
			{
				title: "Investor Name",
				field: "_id",
				width: 300,
			 	attributes: {
	                "class": "align-left"
	            },
	            headerAttributes: {
					"class": "align-left"
	            },
			},
			{
				title: "Firm",
				field: "firm",
				width: 100,
				attributes: {
	                "class": "align-center"
	            },
	            headerAttributes: {
	                "class": "align-center"
	            },
			},
			{
				title: "Allocation Amount",
				field: "allocated",
				attributes: {
					"class": "progressbar-cel"
				},
				headerAttributes: {
	                "class": "align-center"
	            },
				template: function(e){

					var percentage = ( maxAllocated == 0 ) ? 0 : 92 / ( maxAllocated / e.allocated );
					return  "<div class='pull-left series-bar' style='width: "+ percentage +"%'></div>" +
							"<div class='pull-left number'> " + e.allocated + "</div>";
				}
			}
		]
	});
};

wa_CommonInvChart.generateDataViz =  function(){
	var payload =  wa.getPayload();
	var $selector = wa.$getSelectorPage().find(".wa_CommonInvChart");
	var template = wa.getActivePage();
	template.mainPage.mode('preview');
	template.mainPage.type('wa_CommonInvChart');
	$("#commonInvestorModal").modal("hide");
	payload['Flag'] = 'investor_name';
	payload['Issuerdetail'] = payload['Issuerdetail'] ? payload['Issuerdetail'] : wa_CommonInvChart.f.val.Issuerdetail();
	wa_CommonInvChart.RenderGrid("/widgetanalysis/getgridtransaction",  payload, $selector);
};


wa_CommonInvChart.GetDataCommonInvestor = function() {
  var payload = wa.getPayload();
  payload["Flag"] = "issuer";
  getFilter("/widgetanalysis/getcountrydetail", payload, wa_CommonInvChart.f.investorsList);
};

wa_CommonInvChart.init =  function(){
	wa_CommonInvChart.GetDataCommonInvestor();
	$("#commonInvestorModal").modal("show");
};
