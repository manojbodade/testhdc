var outstandingbonds 	= {};

outstandingbonds.init =  function(){
};