var wa_CommonUnInvChart = {
	f:{
		commonInvestorsList: ko.observableArray([]),
		commonInvestedList: ko.observableArray([]),
		val: {
			Issuerdetail: ko.observableArray([]),
			Issuerdetail2: ko.observableArray([]),
		}
	}
};

wa_CommonUnInvChart.RenderGrid = function(url, payload, $selector){
	var $selector = $($selector).find("#grid");
	var maxAllocated = 0;

	$selector.html("");
	$selector.kendoGrid({
		dataSource: {
			transport: {
				read:function(option){
					payload.skip = option.data.skip
					payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : [];
					payload.take = option.data.take
					ajaxPost(url, payload, function(res){
					//        	var datas = res;
					// var sortDatas = sortBarChart(datas)
					// console.log('sss',sortDatas)
						wa_DefChart.pullRequest(wa_DefChart.pullRequest() - 1);
						maxAllocated = res.Data.max;
						option.success({ Records: _.sortBy(res.Data.data, 'allocated').reverse(), Count: res.Total });
					})
	      	},
		},
		schema: {
			data: function(data) {
                return data.Records;
			},
			total: "Count",
		},
	    pageSize: 20,
		serverPaging: true,
		serverSorting: true,
		serverFiltering: true,
		},
		sortable: true,
		pageable: {
			numeric: true,
			previousNext: true,
			messages: {
				display: "Showing {2} data items"
			}
		},
		columns: [
			{
				title: "Investor Name",
				field: "_id",
				width: 300,
			 	attributes: {
	                "class": "align-left"
	            },
	            headerAttributes: {
					"class": "align-left"
	            },
			},
			{
				title: "Firm",
				field: "firm",
				width: 100,
				attributes: {
	                "class": "align-center"
	            },
	            headerAttributes: {
	                "class": "align-center"
	            },
			},
			{
				title: "Allocation Amount",
				field: "allocated",
				attributes: {
					"class": "progressbar-cel"
				},
				headerAttributes: {
	                "class": "align-center"
	            },
				template: function(e){

					var percentage = ( maxAllocated == 0 ) ? 0 : 92 / ( maxAllocated / e.allocated );
					return  "<div class='pull-left series-bar' style='width: "+ percentage +"%'></div>" +
							"<div class='pull-left number'> " + e.allocated + "</div>";
				}
			}
		]
	});
};

wa_CommonUnInvChart.generateDataViz =  function(){
 	$("#commonUnInvestorModal").modal("hide");
	var payload =  wa.getPayload();
	var $selector = wa.$getSelectorPage().find(".wa_CommonUnInvChart");
	var template = wa.getActivePage();
	template.mainPage.mode('preview');
	template.mainPage.type('wa_CommonUnInvChart');
	payload['Flag'] = 'Uninvestor';
	payload['Issuerdetail'] = payload['Issuerdetail'] ? payload['Issuerdetail'] : wa_CommonUnInvChart.f.val.Issuerdetail();
	payload['Issuerdetail2'] = payload['Issuerdetail2'] ? payload['Issuerdetail2'] : wa_CommonUnInvChart.f.val.Issuerdetail2();
	wa_CommonUnInvChart.RenderGrid("/widgetanalysis/getgridtransaction", payload, $selector);
};
wa_CommonUnInvChart.GetDatacommonUnInv = function(){
	var payload = wa.getPayload();
	payload["Flag"] = "issuer";
	getFilter("/widgetanalysis/getcountrydetail", payload, wa_CommonUnInvChart.f.commonInvestorsList);
	payload["Flag"] = "issuer";
	getFilter("/widgetanalysis/getcountrydetail", payload, wa_CommonUnInvChart.f.commonInvestedList);
}
wa_CommonUnInvChart.init =  function(){
	wa_CommonUnInvChart.GetDatacommonUnInv();
	$("#commonUnInvestorModal").modal("show");
};
