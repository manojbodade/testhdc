package controllers

import (
	// . "eaciit/dcm/dcmlive/models"
	// db "github.com/eaciit/dbox"
	"github.com/eaciit/knot/knot.v1"
	tk "github.com/eaciit/toolkit"
	// "strings"
)

type GenerateController struct {
	*BaseController
}

func (c *GenerateController) Default(k *knot.WebContext) interface{} {
	access := c.LoadBase(k)
	k.Config.NoLog = true
	k.Config.OutputType = knot.OutputTemplate
	resdata := c.InitialResultInfo("Access Page", "View Page")
	defer c.LogBase(k, &resdata)

	resdata.IsError = false

	DataAccess := Previlege{}

	for _, o := range access {
		DataAccess.Create = o["Create"].(bool)
		DataAccess.View = o["View"].(bool)
		DataAccess.Delete = o["Delete"].(bool)
		DataAccess.Process = o["Process"].(bool)
		DataAccess.Delete = o["Delete"].(bool)
		DataAccess.Edit = o["Edit"].(bool)
		DataAccess.Menuid = o["Menuid"].(string)
		DataAccess.Menuname = o["Menuname"].(string)
		DataAccess.Approve = o["Approve"].(bool)
		DataAccess.Username = o["Username"].(string)
	}

	return DataAccess
}

func (d *GenerateController) UpdateBonds(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Generate Data", "UpdateBonds")
	defer d.LogBase(k, &resdata)

	result := []tk.M{}
	csr, _ := d.Ctx.Connection.NewQuery().
		From("bondsmaster").
		Cursor(nil)
	defer csr.Close()
	_ = csr.Fetch(&result, 0, false)

	pipe := []tk.M{
		tk.M{}.Set("$group", tk.M{}.Set("_id", tk.M{}.Set("isin", "$isin")).
			Set("firm", tk.M{}.Set("$sum", "$firm")).
			Set("allocated", tk.M{}.Set("$sum", "$allocated")))}

	result2 := []tk.M{}
	csr2, _ := d.Ctx.Connection.NewQuery().
		Command("pipe", pipe).
		From("detailbonds").
		Cursor(nil)
	defer csr2.Close()
	_ = csr2.Fetch(&result2, 0, false)

	firmtot := make(map[string]float64, 0)
	allocatedtot := make(map[string]float64, 0)

	for _, i := range result2 {
		idx := i["_id"].(tk.M)
		key := idx.GetString("isin")
		firm := i.GetFloat64("firm")
		allocated := i.GetFloat64("allocated")

		firmtot[key] = firmtot[key] + firm
		allocatedtot[key] = allocatedtot[key] + allocated
	}

	ex := d.Ctx.Connection.NewQuery().
		From("bondsmaster").
		SetConfig("multiexec", true).
		Save()

	o := tk.M{}
	for _, o = range result {
		isin := o.GetString("isin")

		o.Set("firm", firmtot[isin])
		o.Set("allocated_month", allocatedtot[isin])

		err := ex.Exec(tk.M{}.Set("data", o))
		if err != nil {
			tk.Println(err)
		}
	}

	return "success"
}

// func (d *GenerateController) UpdateDetail(k *knot.WebContext) interface{} {
// 	d.LoadBase(k)
// 	k.Config.OutputType = knot.OutputJson
// 	resdata := d.InitialResultInfo("Generate Data", "UpdateDetail")
// 	defer d.LogBase(k, &resdata)

// 	result := []tk.M{}
// 	csr, _ := d.Ctx.Connection.NewQuery().
// 		From("detailbonds").
// 		Cursor(nil)
// 	defer csr.Close()
// 	_ = csr.Fetch(&result, 0, false)

// 	GroupBy := tk.M{}

// 	GroupBy.Set("isin", "$isin").
// 		Set("issuer", "$issuer").
// 		Set("parent_company_name", "$parent_company_name").
// 		Set("continent", "$continent").
// 		Set("region", "$region").
// 		Set("country", "$country").
// 		Set("super_industry", "$super_industry").
// 		Set("industry", "$industry").
// 		Set("ownership", "$ownership").
// 		Set("currency", "$currency").
// 		Set("ranking", "$ranking").
// 		Set("product", "$product").
// 		Set("issue_date", "$issue_date").
// 		Set("size", "$size")

// 	pipe := []tk.M{
// 		tk.M{}.Set("$group", tk.M{}.Set("_id", GroupBy))}

// 	result2 := []tk.M{}
// 	csr2, _ := d.Ctx.Connection.NewQuery().
// 		Command("pipe", pipe).
// 		From("bondsmaster").
// 		Cursor(nil)
// 	defer csr2.Close()
// 	_ = csr2.Fetch(&result2, 0, false)

// 	DataAll := make(map[string][]tk.M, 0)
// 	issuer := make(map[string]string, 0)
// 	parent_company_name := make(map[string]string, 0)
// 	continent := make(map[string]string, 0)
// 	region := make(map[string]string, 0)
// 	country := make(map[string]string, 0)
// 	super_industry := make(map[string]string, 0)
// 	industry := make(map[string]string, 0)
// 	ownership := make(map[string]string, 0)
// 	currency := make(map[string]string, 0)
// 	ranking := make(map[string]string, 0)
// 	product := make(map[string]string, 0)
// 	issue_date := make(map[string]string, 0)
// 	size := make(map[string]float64, 0)

// 	for _, i := range result2 {
// 		idx := i["_id"].(tk.M)
// 		key := idx.GetString("isin")

// 		if _, byNameExist := DataAll[key]; !byNameExist {
// 			DataAll[key] = []tk.M{i}
// 			issuer[key] = idx.GetString("issuer")
// 			parent_company_name[key] = idx.GetString("parent_company_name")
// 			continent[key] = idx.GetString("continent")
// 			region[key] = idx.GetString("region")
// 			country[key] = idx.GetString("country")
// 			super_industry[key] = idx.GetString("super_industry")
// 			industry[key] = idx.GetString("industry")
// 			ownership[key] = idx.GetString("ownership")
// 			currency[key] = idx.GetString("currency")
// 			ranking[key] = idx.GetString("ranking")
// 			product[key] = idx.GetString("product")
// 			issue_date[key] = idx.GetString("issue_date")
// 			size[key] = idx.GetFloat64("size")
// 		}
// 	}

// 	ex := d.Ctx.Connection.NewQuery().
// 		From("detailbonds").
// 		SetConfig("multiexec", true).
// 		Save()

// 	o := tk.M{}
// 	for _, o = range result {
// 		isin := o.GetString("isin")

// 		o.Set("issuer", issuer[isin])
// 		o.Set("parent_company_name", parent_company_name[isin])
// 		o.Set("continent", continent[isin])
// 		o.Set("region", region[isin])
// 		o.Set("country", country[isin])
// 		o.Set("super_industry", super_industry[isin])
// 		o.Set("industry", industry[isin])
// 		o.Set("ownership", ownership[isin])
// 		o.Set("currency", currency[isin])
// 		o.Set("ranking", ranking[isin])
// 		o.Set("product", product[isin])
// 		o.Set("issue_date", issue_date[isin])
// 		o.Set("size", size[isin])

// 		err := ex.Exec(tk.M{}.Set("data", o))
// 		if err != nil {
// 			tk.Println(err)
// 		}
// 	}

// 	return "success"
// }
