package controllers

import (
	. "eaciit/dcm/dcmlive/models"
	// db "github.com/eaciit/dbox"
	"github.com/eaciit/knot/knot.v1"
	tk "github.com/eaciit/toolkit"
	"math"
	// "sort"
	// "strings"
)

type TradingComparablesController struct {
	*BaseController
}

func (c *TradingComparablesController) Default(k *knot.WebContext) interface{} {
	access := c.LoadBase(k)
	k.Config.NoLog = true
	// k.Config.IncludeFiles = []string{"dashboard/script_template.html", "dashboard/pricebond.html", "dashboard/pb-instrument.html", "dashboard/pb-currency.html", "dashboard/pb-tenor.html", "dashboard/pb-comp.html", "dashboard/pb-result.html", "dashboard/tb-clienthome.html", "dashboard/tb-creditprofile.html", "dashboard/tb-outstandingbonds.html", "dashboard/tb-tradingcomparables.html", "dashboard/tb-creditcomparables.html", "dashboard/tb-keyinvestors.html"}
	k.Config.OutputType = knot.OutputTemplate
	resdata := c.InitialResultInfo("Access Page", "View Page")
	defer c.LogBase(k, &resdata)

	resdata.IsError = false
	DataAccess := Previlege{}

	for _, o := range access {
		DataAccess.Create = o["Create"].(bool)
		DataAccess.View = o["View"].(bool)
		DataAccess.Delete = o["Delete"].(bool)
		DataAccess.Process = o["Process"].(bool)
		DataAccess.Delete = o["Delete"].(bool)
		DataAccess.Edit = o["Edit"].(bool)
		DataAccess.Menuid = o["Menuid"].(string)
		DataAccess.Menuname = o["Menuname"].(string)
		DataAccess.Approve = o["Approve"].(bool)
		DataAccess.Username = o["Username"].(string)
	}

	return DataAccess
}

func (d *TradingComparablesController) GetDataGrid(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Get Data", "GetDataGrid")
	defer d.LogBase(k, &resdata)

	crsx, ex := d.Ctx.Find(new(TradingComparablesModel), nil)
	if crsx == nil {
		resdata.IsError = true
		resdata.Message = "109. Cursor Not initialized.."
		resdata.Data = nil
	}
	defer crsx.Close()
	result := make([]TradingComparablesModel, 0)
	ex = crsx.Fetch(&result, 0, false)
	if ex != nil {
		resdata.IsError = true
		resdata.Message = "115. " + ex.Error()
		resdata.Data = nil
	}

	resdata.Data = result
	resdata.IsError = false
	resdata.Message = "Get Data Success"
	return resdata
}

func NewChart(d tk.M) GroupedChart {
	e := d["_id"].(tk.M)
	res := GroupedChart{}
	res.Name = e["issuer"].(string)
	res.Category = d.GetFloat64("Yearsmaturity")
	res.Value = d.GetFloat64("Bidzspread")
	res.Color = "#2222"

	return res
}

func (d *TradingComparablesController) ZSpreadVSYTM(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Get Data", "Get Data ZSpreadVSYTM")
	defer d.LogBase(k, &resdata)

	pipe := []tk.M{
		tk.M{}.Set("$group", tk.M{}.Set("_id", tk.M{}.Set("issuer", "$issuer")).
			Set("Yearsmaturity", tk.M{}.Set("$sum", "$years_to_maturity")).
			Set("Bidzspread", tk.M{}.Set("$sum", "$bid_z_spread"))),
		tk.M{}.Set("$sort", tk.M{}.Set("_id", 1))}

	crsx, ex := d.Ctx.Connection.NewQuery().
		Command("pipe", pipe).
		From("bondsmaster").
		Cursor(nil)
	if crsx == nil {
		resdata.IsError = true
		resdata.Message = "109. Cursor Not initialized.."
		resdata.Data = nil
	}
	ds := []tk.M{}
	defer crsx.Close()
	ex = crsx.Fetch(&ds, 0, false)
	if ex != nil {
		resdata.IsError = true
		resdata.Message = "115. " + ex.Error()
		resdata.Data = nil
	}
	max := 0.00
	min := 0.00
	obj := []GroupedChart{}
	for _, _dt := range ds {

		p := NewChart(_dt)
		max = math.Max(max, _dt.GetFloat64("Bidzspread"))
		min = math.Min(min, _dt.GetFloat64("Bidzspread"))

		obj = append(obj, p)
	}

	result := ZspreadYtmModel{
		Max:        max,
		Min:        min,
		Datasource: obj,
	}

	resdata.Total = len(ds)
	resdata.Data = result
	resdata.IsError = false
	resdata.Message = "Get Data Success"
	return resdata
}

func (d *TradingComparablesController) ZSpreadVSYTMHistorical(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Get Data", "Get Data ZSpreadVSYTMHistorical")
	defer d.LogBase(k, &resdata)

	pipe := []tk.M{
		tk.M{}.Set("$group", tk.M{}.Set("_id", tk.M{}.Set("issuer", "$issuer")).
			Set("Yearsmaturity", tk.M{}.Set("$sum", "$years_to_maturity")).
			Set("Bidzspread", tk.M{}.Set("$sum", "$bid_z_spread"))),
		tk.M{}.Set("$sort", tk.M{}.Set("_id", 1))}

	crsx, ex := d.Ctx.Connection.NewQuery().
		Command("pipe", pipe).
		From("bondsmaster").
		Cursor(nil)
	if crsx == nil {
		resdata.IsError = true
		resdata.Message = "109. Cursor Not initialized.."
		resdata.Data = nil
	}
	ds := []tk.M{}
	defer crsx.Close()
	ex = crsx.Fetch(&ds, 0, false)
	if ex != nil {
		resdata.IsError = true
		resdata.Message = "115. " + ex.Error()
		resdata.Data = nil
	}
	max := 0.00
	min := 0.00
	obj := []GroupedChart{}
	for _, _dt := range ds {

		p := NewChart(_dt)
		max = math.Max(max, _dt.GetFloat64("Bidzspread"))
		min = math.Min(min, _dt.GetFloat64("Bidzspread"))

		obj = append(obj, p)
	}

	result := ZspreadYtmModel{
		Max:        max,
		Min:        min,
		Datasource: obj,
	}

	resdata.Total = len(ds)
	resdata.Data = result
	resdata.IsError = false
	resdata.Message = "Get Data Success"
	return resdata
}

func (d *TradingComparablesController) YieldVSYTM(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Get Data", "Get Data YieldVSYTM")
	defer d.LogBase(k, &resdata)

	pipe := []tk.M{
		tk.M{}.Set("$group", tk.M{}.Set("_id", tk.M{}.Set("issuer", "$issuer")).
			Set("Yearsmaturity", tk.M{}.Set("$sum", "$years_to_maturity")).
			Set("Bidzspread", tk.M{}.Set("$sum", "$bid_z_spread"))),
		tk.M{}.Set("$sort", tk.M{}.Set("_id", 1))}

	crsx, ex := d.Ctx.Connection.NewQuery().
		Command("pipe", pipe).
		From("bondsmaster").
		Cursor(nil)
	if crsx == nil {
		resdata.IsError = true
		resdata.Message = "109. Cursor Not initialized.."
		resdata.Data = nil
	}
	ds := []tk.M{}
	defer crsx.Close()
	ex = crsx.Fetch(&ds, 0, false)
	if ex != nil {
		resdata.IsError = true
		resdata.Message = "115. " + ex.Error()
		resdata.Data = nil
	}

	max := 0.00
	min := 0.00
	obj := []GroupedChart{}
	for _, _dt := range ds {

		p := NewChart(_dt)
		max = math.Max(max, _dt.GetFloat64("Bidzspread"))
		min = math.Min(min, _dt.GetFloat64("Bidzspread"))

		obj = append(obj, p)
	}

	result := ZspreadYtmModel{
		Max:        max,
		Min:        min,
		Datasource: obj,
	}

	resdata.Total = len(ds)
	resdata.Data = result
	resdata.IsError = false
	resdata.Message = "Get Data Success"
	return resdata
}

func (d *TradingComparablesController) YieldVSYTMHistorical(k *knot.WebContext) interface{} {
	d.LoadBase(k)
	k.Config.OutputType = knot.OutputJson
	resdata := d.InitialResultInfo("Get Data", "Get Data YieldVSYTMHistorical")
	defer d.LogBase(k, &resdata)

	pipe := []tk.M{
		tk.M{}.Set("$group", tk.M{}.Set("_id", tk.M{}.Set("issuer", "$issuer")).
			Set("Yearsmaturity", tk.M{}.Set("$sum", "$years_to_maturity")).
			Set("Bidzspread", tk.M{}.Set("$sum", "$bid_z_spread"))),
		tk.M{}.Set("$sort", tk.M{}.Set("_id", 1))}

	crsx, ex := d.Ctx.Connection.NewQuery().
		Command("pipe", pipe).
		From("bondsmaster").
		Cursor(nil)
	if crsx == nil {
		resdata.IsError = true
		resdata.Message = "109. Cursor Not initialized.."
		resdata.Data = nil
	}
	ds := []tk.M{}
	defer crsx.Close()
	ex = crsx.Fetch(&ds, 0, false)
	if ex != nil {
		resdata.IsError = true
		resdata.Message = "115. " + ex.Error()
		resdata.Data = nil
	}
	max := 0.00
	min := 0.00
	obj := []GroupedChart{}
	for _, _dt := range ds {

		p := NewChart(_dt)
		max = math.Max(max, _dt.GetFloat64("Bidzspread"))
		min = math.Min(min, _dt.GetFloat64("Bidzspread"))

		obj = append(obj, p)
	}

	result := ZspreadYtmModel{
		Max:        max,
		Min:        min,
		Datasource: obj,
	}

	resdata.Total = len(ds)
	resdata.Data = result
	resdata.IsError = false
	resdata.Message = "Get Data Success"
	return resdata
}
