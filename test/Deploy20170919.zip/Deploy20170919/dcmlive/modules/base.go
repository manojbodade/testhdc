package modules

import (
	"bufio"
	"github.com/eaciit/dbox"
	_ "github.com/eaciit/dbox/dbc/mongo"
	"github.com/eaciit/toolkit"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"
)

func GetConfigPath() string {
	// var wd, _ = os.Getwd()
	// dir, _ := filepath.Abs(filepath.Join(wd, "..", "..", "conf", "app.conf"))
	dir := filepath.Join("D:\\", "go", "src", "eaciit", "dcm", "dcmlive", "conf", "app.conf")
	return dir
}

func GetConfigDatabase() toolkit.M {

	confpath := GetConfigPath()
	ret := toolkit.M{}

	file, err := os.Open(confpath)
	if err == nil {
		defer file.Close()

		reader := bufio.NewReader(file)
		for {
			line, _, e := reader.ReadLine()
			if e != nil {
				break
			}

			sval := strings.Split(string(line), "=")
			ret[sval[0]] = sval[1]
		}
	} else {
		toolkit.Println(err.Error())
	}

	return ret
}

func GetConnectionInfo() (string, *dbox.ConnectionInfo) {

	conf := GetConfigDatabase()
	if len(conf) == 0 {
		return "", nil
	}

	conf.Set("driver", "mongo")

	setting := toolkit.M{}.Set("timeout", 10)
	if conf.Has("setting") {
		for _, val := range conf.Get("setting").(map[string]interface{}) {
			setting, _ = toolkit.ToM(val)
		}
	}

	ci := dbox.ConnectionInfo{
		conf.GetString("host"),
		conf.GetString("database"),
		conf.GetString("username"),
		conf.GetString("password"),
		setting,
	}

	return conf.GetString("driver"), &ci
}

func GetDboxIConnection() (conn dbox.IConnection, err error) {
	driver, ci := GetConnectionInfo()

	conn, err = dbox.NewConnection(driver, ci)

	if err != nil {
		return
	}

	err = conn.Connect()

	return
}

func ToDate(str string) (rt time.Time) {

	F1 := "(^(0[0-9]|[0-9]|(1|2)[0-9]|3[0-1])(\\.|\\/|-)(0[0-9]|[0-9]|1[0-2])(\\.|\\/|-)[\\d]{4}$)"
	F2 := "(^[\\d]{4}(\\.|\\/|-)(0[0-9]|[0-9]|1[0-2])(\\.|\\/|-)(0[0-9]|[0-9]|(1|2)[0-9]|3[0-1])$)"
	if matchF1, _ := regexp.MatchString(F1, str); matchF1 {
		tstr := strings.Replace(str, ".", "/", -1)
		tstr = strings.Replace(str, "-", "/", -1)
		rt = toolkit.String2Date(tstr, "dd/MM/YYYY")
		return
	}

	if matchF2, _ := regexp.MatchString(F2, str); matchF2 {
		tstr := strings.Replace(str, ".", "/", -1)
		tstr = strings.Replace(str, "-", "/", -1)
		rt = toolkit.String2Date(tstr, "YYYY/MM/dd")
		return
	}

	return
}
