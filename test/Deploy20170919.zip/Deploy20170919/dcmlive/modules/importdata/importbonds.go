package main

import (
	"bufio"
	"eaciit/dcm/dcmlive/modules"
	"github.com/eaciit/dbox"
	tk "github.com/eaciit/toolkit"
	"gopkg.in/mgo.v2/bson"
	"os"
	"strconv"
	// "math"
	"github.com/xuri/excelize"
	"strings"
)

var (
	conn dbox.IConnection
	wd   string
)

func setinitialconnection() {
	var err error
	conn, err = modules.GetDboxIConnection()

	if err != nil {
		tk.Println("Initial connection found : ", err)
		os.Exit(1)
	}
}

func main() {
	fpath := "D:/Office/dcm/BondMaster20170821.csv"

	afield := []string{}
	tablename := "bondsmastertest"
	afield = []string{"isin", "isin_corp", "security", "issue_date", "issuer", "country", "region", "corp_fi_ssa", "industry",
		"ownership", "moodys_issuer_rating", "sp_issuer_rating", "fitch_issuer_rating", "moodys_issue_rating",
		"sp_issue_rating", "fitch_issue_rating", "maturity_date", "callable", "call_date", "tenor", "perp", "currency",
		"size", "coupon", "years_to_maturity", "ranking", "coupon_type", "issue_spread", "issue_price", "yield_issue",
		"step_provision", "step_margin", "outstanding", "bid_price", "bid_ytm", "bid_t_spread", "bid_g_spread",
		"bid_z_spread", "pb_rebate", "regs", "144A", "sec_reg", "alternate", "continent", "aliasname", "parent_company_name",
		"guarantor_name", "sub_industry", "super_industry"}

	f, e := os.Open(fpath)
	if e != nil {
		tk.Println("salah path")
	}

	workerconn, _ := modules.GetDboxIConnection()
	defer workerconn.Close()

	crs, ex := workerconn.NewQuery().
		From("masterrating").
		Cursor(nil)
	if crs == nil {
		tk.Println("109. Cursor Not initialized..")
	}
	res := []tk.M{}
	ex = crs.Fetch(&res, 0, false)
	if ex != nil {
		tk.Println(ex.Error())
	}

	xlsx, err := excelize.OpenFile("D:/Office/dcm/widgetdistribution.xlsx")
	if err != nil {
		tk.Println(err)
		os.Exit(1)
	}

	afield2 := []string{}
	afield2 = []string{"isin", "dealsize", "ust_spread", "us", "emea", "asia", "banks", "pb", "fm", "insurance", "others",
		"orderbook"}

	liness := [][]string{}
	for _, v := range xlsx.GetSheetMap() {
		index := xlsx.GetSheetIndex(v)
		rows := xlsx.GetRows("sheet" + strconv.Itoa(index))
		for i, row := range rows {
			if i >= 1 {
				liness = append(liness, row)
			}
		}
	}

	Dealsize := make(map[string]float64, 0)
	UstSpread := make(map[string]string, 0)
	Us := make(map[string]float64, 0)
	Emea := make(map[string]float64, 0)
	Asia := make(map[string]float64, 0)
	Banks := make(map[string]float64, 0)
	Pb := make(map[string]float64, 0)
	Fm := make(map[string]float64, 0)
	Insurance := make(map[string]float64, 0)
	Others := make(map[string]float64, 0)
	Orderbook := make(map[string]float64, 0)
	Subscription := make(map[string]float64, 0)
	Usvalue := make(map[string]float64, 0)
	Emeavalue := make(map[string]float64, 0)
	Asiavalue := make(map[string]float64, 0)
	Banksvalue := make(map[string]float64, 0)
	Pbvalue := make(map[string]float64, 0)
	Fmvalue := make(map[string]float64, 0)
	Insurancevalue := make(map[string]float64, 0)
	Othersvalue := make(map[string]float64, 0)

	for _, line := range liness {
		key := ""
		for _, _str := range afield2 {
			if _str == "isin" {
				key = line[0]
			} else {
				Dealsize[key] = tk.ToFloat64(line[1], 6, tk.RoundingAuto)
				UstSpread[key] = line[2]
				Us[key] = tk.ToFloat64(line[3], 6, tk.RoundingAuto)
				Emea[key] = tk.ToFloat64(line[4], 6, tk.RoundingAuto)
				Asia[key] = tk.ToFloat64(line[5], 6, tk.RoundingAuto)
				Banks[key] = tk.ToFloat64(line[6], 6, tk.RoundingAuto)
				Pb[key] = tk.ToFloat64(line[7], 6, tk.RoundingAuto)
				Fm[key] = tk.ToFloat64(line[8], 6, tk.RoundingAuto)
				Insurance[key] = tk.ToFloat64(line[9], 6, tk.RoundingAuto)
				Others[key] = tk.ToFloat64(line[10], 6, tk.RoundingAuto)
				Orderbook[key] = tk.ToFloat64(line[11], 6, tk.RoundingAuto)
				Subscription[key] = tk.ToFloat64((Orderbook[key] / Dealsize[key]), 6, tk.RoundingAuto)
				Usvalue[key] = tk.ToFloat64((Dealsize[key] * Us[key]), 6, tk.RoundingAuto)
				Emeavalue[key] = tk.ToFloat64((Dealsize[key] * Emea[key]), 6, tk.RoundingAuto)
				Asiavalue[key] = tk.ToFloat64((Dealsize[key] * Asia[key]), 6, tk.RoundingAuto)
				Banksvalue[key] = tk.ToFloat64((Dealsize[key] * Banks[key]), 6, tk.RoundingAuto)
				Pbvalue[key] = tk.ToFloat64((Dealsize[key] * Pb[key]), 6, tk.RoundingAuto)
				Fmvalue[key] = tk.ToFloat64((Dealsize[key] * Fm[key]), 6, tk.RoundingAuto)
				Insurancevalue[key] = tk.ToFloat64((Dealsize[key] * Insurance[key]), 6, tk.RoundingAuto)
				Othersvalue[key] = tk.ToFloat64((Dealsize[key] * Others[key]), 6, tk.RoundingAuto)
			}
		}
	}

	scanner := bufio.NewScanner(f)
	lines := make([]string, 0)

	totalLines := 0
	for scanner.Scan() {
		lines = append(lines, scanner.Text())
		totalLines++
	}

	sresult := make(chan int, len(lines))
	jobs := make(chan tk.M, len(lines))
	for i := 0; i < 10; i++ {
		go workersave(i, jobs, sresult, tablename)
	}

	r := strings.NewReplacer("  ", " ")

	icount := 1
	for i, line := range lines {
		dataSplit := strings.Split(line, "|")
		result := tk.M{}
		if len(dataSplit) > 1 {
			if i != 0 {
				id := bson.NewObjectId()
				result.Set("_id", id)
				pointmoody := 0.00
				pointsp := 0.00
				pointfitch := 0.00
				bucketmoody := "B7"
				bucketsp := "B7"
				bucketfitch := "B7"
				product_sp := ""
				product_moody := ""
				product_fitch := ""
				keyisin := ""
				for ix, _str := range afield {
					if ix < len(dataSplit) {
						if _str == "tenor" || _str == "size" || _str == "years_to_maturity" || _str == "outstanding" ||
							_str == "bid_price" || _str == "bid_ytm" || _str == "bid_t_spread" ||
							_str == "bid_g_spread" || _str == "bid_z_spread" || _str == "issue_price" {
							result.Set(_str, tk.ToFloat64(dataSplit[ix], 6, tk.RoundingAuto))
						} else {
							result.Set(_str, dataSplit[ix])
						}

						if _str == "isin" {
							keyisin = dataSplit[ix]
						}

						if _str == "issue_date" {
							issue := strings.Split(dataSplit[ix], "/")
							date := issue[2] + "/" + issue[0] + "/" + issue[1]
							result.Set("issue_date_str", date)
						}

						if _str == "issuer" {
							trim := strings.Trim(r.Replace(dataSplit[ix]), " ")
							issuer := strings.Title(trim)
							result.Set(_str, issuer)
						}

						for _, idx := range res {
							if _str == "moodys_issuer_rating" {
								if dataSplit[ix] == idx.GetString("moody") {
									product_moody = idx.GetString("product")
									pointmoody = idx.GetFloat64("point")
									bucketmoody = idx.GetString("bucket")
								} else if dataSplit[ix] == "-" {
									product_moody = ""
								}
							}

							if _str == "sp_issuer_rating" {
								if dataSplit[ix] == idx.GetString("sp") {
									product_sp = idx.GetString("product")
									pointsp = idx.GetFloat64("point")
									bucketsp = idx.GetString("bucket")
								} else if dataSplit[ix] == "-" {
									product_sp = ""
								}
							}

							if _str == "fitch_issuer_rating" {
								if dataSplit[ix] == idx.GetString("fitch") {
									product_fitch = idx.GetString("product")
									pointfitch = idx.GetFloat64("point")
									bucketfitch = idx.GetString("bucket")
								} else if dataSplit[ix] == "-" {
									product_fitch = ""
								}
							}

						}

					}
				}

				result.Set("product_moody", product_moody)
				result.Set("product_sp", product_sp)
				result.Set("product_fitch", product_fitch)

				key := product_moody + "&&" + product_sp + "&&" + product_fitch

				if product_moody == "IG" && product_sp == "IG" && product_fitch == "IG" {
					result.Set("product", "IG")
				} else if product_moody == "HY" && product_sp == "HY" && product_fitch == "HY" {
					result.Set("product", "HY")
				} else if product_moody == "" && product_sp == "" && product_fitch == "" {
					result.Set("product", "Unrated")
				} else if strings.Index(key, "IG") > -1 && strings.Index(key, "HY") > -1 {
					result.Set("product", "Crossover")
				} else if strings.Index(key, "IG") > -1 && strings.Index(key, "HY") == -1 {
					result.Set("product", "IG")
				} else if strings.Index(key, "HY") > -1 && strings.Index(key, "IG") == -1 {
					result.Set("product", "HY")
				}

				result.Set("point_moody", pointmoody)
				result.Set("point_sp", pointsp)
				result.Set("point_fitch", pointfitch)

				if pointmoody == 0 && pointsp == 0 && pointfitch == 0 {
					result.Set("bucket", "B7")
				} else if pointmoody != 0 && pointsp != 0 && pointfitch != 0 {
					smallest := pointmoody
					bucket := bucketmoody
					if smallest > pointsp {
						smallest = pointsp
						bucket = bucketsp
					} else if smallest > pointfitch {
						smallest = pointfitch
						bucket = bucketfitch
					}
					result.Set("bucket", bucket)
				} else if pointmoody == 0 && pointsp != 0 && pointfitch != 0 {
					smallest := pointsp
					bucket := bucketsp
					if smallest > pointfitch {
						smallest = pointfitch
						bucket = bucketfitch
					}
					result.Set("bucket", bucket)
				} else if pointmoody != 0 && pointsp == 0 && pointfitch != 0 {
					smallest := pointmoody
					bucket := bucketmoody
					if smallest > pointfitch {
						smallest = pointfitch
						bucket = bucketfitch
					}
					result.Set("bucket", bucket)
				} else if pointmoody != 0 && pointsp != 0 && pointfitch == 0 {
					smallest := pointmoody
					bucket := bucketmoody
					if smallest > pointsp {
						smallest = pointsp
						bucket = bucketsp
					}
					result.Set("bucket", bucket)
				} else if pointmoody == 0 && pointsp == 0 && pointfitch != 0 {
					result.Set("bucket", bucketfitch)
				} else if pointmoody == 0 && pointsp != 0 && pointfitch == 0 {
					result.Set("bucket", bucketsp)
				} else if pointmoody != 0 && pointsp == 0 && pointfitch == 0 {
					result.Set("bucket", bucketmoody)
				}

				result.Set("dealsize", Dealsize[keyisin])
				result.Set("ust_spread", UstSpread[keyisin])
				result.Set("us", Us[keyisin])
				result.Set("emea", Emea[keyisin])
				result.Set("asia", Asia[keyisin])
				result.Set("banks", Banks[keyisin])
				result.Set("pb", Pb[keyisin])
				result.Set("fm", Fm[keyisin])
				result.Set("insurance", Insurance[keyisin])
				result.Set("others", Others[keyisin])
				result.Set("orderbook", Orderbook[keyisin])
				result.Set("subscription", Subscription[keyisin])
				result.Set("us_value", Usvalue[keyisin])
				result.Set("emea_value", Emeavalue[keyisin])
				result.Set("asia_value", Asiavalue[keyisin])
				result.Set("banks_value", Banksvalue[keyisin])
				result.Set("pb_value", Pbvalue[keyisin])
				result.Set("fm_value", Fmvalue[keyisin])
				result.Set("insurance_value", Insurancevalue[keyisin])
				result.Set("others_value", Othersvalue[keyisin])

				icount++
				jobs <- result
			}
		} else {
			tk.Println("error delimiter not match")
		}
	}

	tk.Println(">>> Done Send Data")
	close(jobs)
	step := int(icount / 10)
	if step == 0 {
		step = 1
	}
	for i := 1; i < icount; i++ {
		<-sresult
		if i%step == 0 {
			tk.Println("insertedrows", i)
		}
	}
	close(sresult)

	tk.Println("success")
}

func workersave(wi int, jobs <-chan tk.M, result chan<- int, table string) {
	workerconn, _ := modules.GetDboxIConnection()
	defer workerconn.Close()

	qSave := workerconn.NewQuery().
		From(table).
		SetConfig("multiexec", true).
		Save()

	trx := tk.M{}
	for trx = range jobs {

		err := qSave.Exec(tk.M{}.Set("data", trx))

		if err != nil {
			tk.Println(err)
		}

		result <- 1
	}
}
