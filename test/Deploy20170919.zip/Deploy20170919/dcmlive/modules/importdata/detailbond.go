package main

import (
	"eaciit/dcm/dcmlive/modules"
	"fmt"
	// "github.com/eaciit/dbox"
	tk "github.com/eaciit/toolkit"
	"gopkg.in/mgo.v2/bson"
	"os"
	"strconv"
	// "strings"

	"github.com/xuri/excelize"
)

func main() {
	xlsx, err := excelize.OpenFile("D:/Office/dcm/DetailBondMasterOri.xlsx")
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}

	GroupBy := tk.M{}

	GroupBy.Set("isin", "$isin").
		Set("issuer", "$issuer").
		Set("parent_company_name", "$parent_company_name").
		Set("continent", "$continent").
		Set("region", "$region").
		Set("country", "$country").
		Set("super_industry", "$super_industry").
		Set("industry", "$industry").
		Set("ownership", "$ownership").
		Set("currency", "$currency").
		Set("ranking", "$ranking").
		Set("product", "$product").
		Set("issue_date", "$issue_date").
		Set("size", "$size")

	pipe := []tk.M{
		tk.M{}.Set("$group", tk.M{}.Set("_id", GroupBy))}

	workerconn, _ := modules.GetDboxIConnection()
	defer workerconn.Close()

	res := []tk.M{}
	csr, _ := workerconn.NewQuery().
		Command("pipe", pipe).
		From("bondsmaster").
		Cursor(nil)
	defer csr.Close()
	_ = csr.Fetch(&res, 0, false)

	DataAll := make(map[string][]tk.M, 0)
	issuer := make(map[string]string, 0)
	parent_company_name := make(map[string]string, 0)
	continent := make(map[string]string, 0)
	region := make(map[string]string, 0)
	country_parent := make(map[string]string, 0)
	super_industry := make(map[string]string, 0)
	industry := make(map[string]string, 0)
	ownership := make(map[string]string, 0)
	currency := make(map[string]string, 0)
	ranking := make(map[string]string, 0)
	product := make(map[string]string, 0)
	issue_date := make(map[string]string, 0)
	size := make(map[string]float64, 0)

	for _, i := range res {
		idx := i["_id"].(tk.M)
		key := idx.GetString("isin")

		if _, byNameExist := DataAll[key]; !byNameExist {
			DataAll[key] = []tk.M{i}
			issuer[key] = idx.GetString("issuer")
			parent_company_name[key] = idx.GetString("parent_company_name")
			continent[key] = idx.GetString("continent")
			region[key] = idx.GetString("region")
			country_parent[key] = idx.GetString("country")
			super_industry[key] = idx.GetString("super_industry")
			industry[key] = idx.GetString("industry")
			ownership[key] = idx.GetString("ownership")
			currency[key] = idx.GetString("currency")
			ranking[key] = idx.GetString("ranking")
			product[key] = idx.GetString("product")
			issue_date[key] = idx.GetString("issue_date")
			size[key] = idx.GetFloat64("size")
		}
	}

	ctr := []tk.M{}
	csrx, _ := workerconn.NewQuery().
		From("mastercountry").
		Cursor(nil)
	defer csrx.Close()
	_ = csrx.Fetch(&ctr, 0, false)

	DataCountry := make(map[string][]tk.M, 0)
	country := make(map[string]string, 0)

	for _, j := range ctr {
		key := j.GetString("thirdcode")

		if _, byNameExist := DataCountry[key]; !byNameExist {
			DataCountry[key] = []tk.M{j}
			country[key] = j.GetString("country")
		}
	}

	afield := []string{}
	tablename := "detailbonds"
	afield = []string{"isin", "investor_id", "investor_short_name", "investor_name", "country", "type", "sales_person",
		"firm", "allocated"}

	lines := [][]string{}
	// Get sheet index.
	for _, v := range xlsx.GetSheetMap() {
		index := xlsx.GetSheetIndex(v)
		// Get all the rows in a sheet.
		rows := xlsx.GetRows("sheet" + strconv.Itoa(index))
		tot := len(rows) - 3
		// fmt.Println(tot)
		for i, row := range rows {
			if i >= 3 && i < tot {
				lines = append(lines, row)
			}
		}
	}

	sresult := make(chan int, len(lines))
	jobs := make(chan tk.M, len(lines))
	for i := 0; i < 10; i++ {
		go workersave(i, jobs, sresult, tablename)
	}

	icount := 1
	for _, line := range lines {
		// tk.Println(i, "inserted", line)
		result := tk.M{}
		id := bson.NewObjectId()
		result.Set("_id", id)
		isin := ""
		ctry := ""
		for ix, _str := range afield {
			if ix < len(line) {
				if _str == "firm" || _str == "allocated" {
					result.Set(_str, tk.ToFloat64(line[ix], 6, tk.RoundingAuto))
				} else if _str == "country" {
					ctry = line[ix]
					result.Set("country_code", line[ix])
				} else {
					result.Set(_str, line[ix])
				}

				if _str == "isin" {
					isin = line[ix]
				}
			}
		}

		result.Set("country", country[ctry])
		result.Set("issuer", issuer[isin])
		result.Set("parent_company_name", parent_company_name[isin])
		result.Set("continent", continent[isin])
		result.Set("region", region[isin])
		result.Set("country_parent", country_parent[isin])
		result.Set("super_industry", super_industry[isin])
		result.Set("industry", industry[isin])
		result.Set("ownership", ownership[isin])
		result.Set("currency", currency[isin])
		result.Set("ranking", ranking[isin])
		result.Set("product", product[isin])
		result.Set("issue_date", issue_date[isin])
		result.Set("size", size[isin])

		icount++
		jobs <- result
	}

	tk.Println(">>> Done Send Data")
	close(jobs)
	step := int(icount / 10)
	if step == 0 {
		step = 1
	}
	for i := 1; i < icount; i++ {
		<-sresult
		if i%step == 0 {
			tk.Println("insertedrows", i)
		}
	}
	close(sresult)

	tk.Println("success")

}

func workersave(wi int, jobs <-chan tk.M, result chan<- int, table string) {
	workerconn, _ := modules.GetDboxIConnection()
	defer workerconn.Close()

	qSave := workerconn.NewQuery().
		From(table).
		SetConfig("multiexec", true).
		Save()

	trx := tk.M{}
	for trx = range jobs {

		err := qSave.Exec(tk.M{}.Set("data", trx))

		if err != nil {
			tk.Println(err)
		}

		result <- 1
	}
}
