package models

import (
	"gopkg.in/mgo.v2/bson"
	"github.com/eaciit/orm"
)

type RatingModel struct {
	orm.ModelBase       `bson:"-",json:"-"`
	Id                  bson.ObjectId `bson:"_id" , json:"_id" `
	Moody        		string `bson:"moody" , json:"moody" `
	Sp        			string `bson:"sp" , json:"sp" `
	Fitch        		string `bson:"fitch" , json:"fitch" `
	Product        		string `bson:"product" , json:"product" `
	Point         		float64 `bson:"point" , json:"point" `
}

func NewRatingModel() *RatingModel {
	m := new(RatingModel)
	m.Id = bson.NewObjectId()
	return m
}
func (e *RatingModel) RecordID() interface{} {
	return e.Id
}

func (m *RatingModel) TableName() string {
	return "masterrating"
}
