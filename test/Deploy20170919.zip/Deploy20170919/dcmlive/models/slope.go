package models

import (
	"github.com/eaciit/orm"
	"gopkg.in/mgo.v2/bson"
)

type SlopeModel struct {
	orm.ModelBase `bson:"-",json:"-"`
	Id            			bson.ObjectId `bson:"_id" , json:"_id"`
	Issuer        			string `bson:"issuer", json:"issuer"`
	Ranking      			string `bson:"ranking", json:"ranking"`
	Moodysissuerating       string `bson:"moodys_issuer_rating", json:"moodys_issuer_rating"`
	Spissuerating       	string `bson:"sp_issuer_rating", json:"sp_issuer_rating"`
	Fitchissuerrating       string `bson:"fitch_issuer_rating", json:"fitch_issuer_rating"`
	Yearsmaturity			float64 `bson:"years_to_maturity", json:"years_to_maturity"`
	Bidprice       			float64 `bson:"bid_price", json:"bid_price"`
	Bidytm       			float64 `bson:"bid_ytm", json:"bid_ytm"`
	Bidzspread       		float64 `bson:"bid_z_spread", json:"bid_z_spread"`
	Bidgspread       		float64 `bson:"bid_g_spread", json:"bid_g_spread"`
	Security				string `bson:"security", json:"security"`
	Tenor       			float64 `bson:"tenor", json:"tenor"`
	Product       			string `bson:"product", json:"product"`
}

func NewSlopeModel() *SlopeModel {
	m := new(SlopeModel)
	m.Id = bson.NewObjectId()
	return m
}

func (e *SlopeModel) RecordID() interface{} {
	return e.Id
}

func (m *SlopeModel) TableName() string {
	return "bondsmaster"
}