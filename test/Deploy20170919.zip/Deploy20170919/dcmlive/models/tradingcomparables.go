package models

import (
	"github.com/eaciit/orm"
	"gopkg.in/mgo.v2/bson"
)

type TradingComparablesModel struct {
	orm.ModelBase     `bson:"-",json:"-"`
	Id                bson.ObjectId `bson:"_id" , json:"_id"`
	Security          string        `bson:"security", json:"security"`
	Issuedate         string        `bson:"issue_date", json:"issue_date"`
	Issuer            string        `bson:"issuer", json:"issuer"`
	Moodysissuerating string        `bson:"moodys_issuer_rating", json:"moodys_issuer_rating"`
	Spissuerating     string        `bson:"sp_issuer_rating", json:"sp_issuer_rating"`
	Fitchissuerrating string        `bson:"fitch_issuer_rating", json:"fitch_issuer_rating"`
	Maturitydate      string        `bson:"maturity_date", json:"maturity_date"`
	Calldate          string
	Tenor             float64 `bson:"tenor", json:"tenor"`
	Currency          string  `bson:"currency", json:"currency"`
	Size              float64 `bson:"size", json:"size"`
	Coupon            float64 `bson:"coupon", json:"coupon"`
	Yearsmaturity     float64 `bson:"years_to_maturity", json:"years_to_maturity"`
	Bidprice          float64 `bson:"bid_price", json:"bid_price"`
	Bidytm            float64 `bson:"bid_ytm", json:"bid_ytm"`
	Bidtspread        float64 `bson:"bid_t_spread", json:"bid_t_spread"`
	Bidgspread        float64 `bson:"bid_g_spread", json:"bid_g_spread"`
	Bidzspread        float64 `bson:"bid_z_spread", json:"bid_z_spread"`
}

func NewTradingComparablesModel() *TradingComparablesModel {
	m := new(TradingComparablesModel)
	m.Id = bson.NewObjectId()
	return m
}

func (e *TradingComparablesModel) RecordID() interface{} {
	return e.Id
}

func (m *TradingComparablesModel) TableName() string {
	return "bondsmaster"
}
