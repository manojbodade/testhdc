package models

import (
	"github.com/eaciit/orm"
	"gopkg.in/mgo.v2/bson"
)

type SyndicateModel struct {
	orm.ModelBase      `bson:"-",json:"-"`
	Id                 bson.ObjectId `bson:"_id" , json:"_id"`
	Issuer             string        `bson:"issuer", json:"issuer"`
	Industry           string        `bson:"industry", json:"industry"`
	Country            string        `bson:"country", json:"country"`
	Yearsmaturity      float64       `bson:"years_to_maturity", json:"years_to_maturity"`
	Product       	   string        `bson:"product", json:"product"`
	Value              float64       `bson:"value", json:"value"`
	Bucket 			   string        `bson:"bucket", json:"bucket"`
	Three 			   float64
	Five 			   float64
	Seven 			   float64
	Ten 			   float64
}

func NewSyndicateModel() *SyndicateModel {
	m := new(SyndicateModel)
	m.Id = bson.NewObjectId()
	return m
}

func (e *SyndicateModel) RecordID() interface{} {
	return e.Id
}

func (m *SyndicateModel) TableName() string {
	return "bondsmaster"
}
