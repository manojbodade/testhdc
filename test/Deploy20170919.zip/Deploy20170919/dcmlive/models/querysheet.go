package models

import (
	"github.com/eaciit/orm"
	"gopkg.in/mgo.v2/bson"
)

type QuerysheetModel struct {
	orm.ModelBase      `bson:"-",json:"-"`
	Id                 bson.ObjectId `bson:"_id" , json:"_id"`
	Issuer             string        `bson:"issuer", json:"issuer"`
	Ranking            string        `bson:"ranking", json:"ranking"`
	Moodysissuerating  string        `bson:"moodys_issuer_rating", json:"moodys_issuer_rating"`
	Spissuerating      string        `bson:"sp_issuer_rating", json:"sp_issuer_rating"`
	Fitchissuerrating  string        `bson:"fitch_issuer_rating", json:"fitch_issuer_rating"`
	Industry           string        `bson:"industry", json:"industry"`
	Currency           string        `bson:"currency", json:"currency"`
	Country            string        `bson:"country", json:"country"`
	Region             string        `bson:"region", json:"region"`
	Continent          string        `bson:"continent", json:"continent"`
	Yearsmaturity      float64       `bson:"years_to_maturity", json:"years_to_maturity"`
	Issuedate          string        `bson:"issue_date", json:"issue_date"`
	Size               float64       `bson:"size", json:"size"`
	Bidprice           float64       `bson:"bid_price", json:"bid_price"`
	Bidytm             float64       `bson:"bid_ytm", json:"bid_ytm"`
	Bidtspread         float64       `bson:"bid_t_spread", json:"bid_t_spread"`
	Bidgspread         float64       `bson:"bid_g_spread", json:"bid_g_spread"`
	Bidzspread         float64       `bson:"bid_z_spread", json:"bid_z_spread"`
	Security           string        `bson:"security", json:"security"`
	Ownership          string        `bson:"ownership", json:"ownership"`
	Issuedatestr       string        `bson:"issue_date_str", json:"issue_date_str"`
	Productmoody       string        `bson:"product_moody", json:"product_moody"`
	Productsp          string        `bson:"product_sp", json:"product_sp"`
	Productfitch       string        `bson:"product_fitch", json:"product_fitch"`
	Product       	   string        `bson:"product", json:"product"`
	Superindustry      string        `bson:"super_industry", json:"super_industry"`
	Guarantorname      string        `bson:"guarantor_name", json:"guarantor_name"`
	Parentcompanyname  string        `bson:"parent_company_name", json:"parent_company_name"`
	Maturitydate       string        `bson:"maturity_date", json:"maturity_date"`
	Value              float64       `bson:"value", json:"value"`
	Coupon             string
	Point              float64
	Issuerpoint        float64
	Industrypoint      float64
	Countrypoint       float64
	Regionpoint        float64
	Continentpoint     float64
	Rankingpoint       float64
	Yearsmaturitypoint float64
	Currencypoint      float64
	Ratingpoint        float64
	Ownershippoint     float64
	Issuedatepoint     float64
	Guarantorpoint     float64
	Parentcompanypoint float64
	Isin               string
}

func NewQuerysheetModel() *QuerysheetModel {
	m := new(QuerysheetModel)
	m.Id = bson.NewObjectId()
	return m
}

func (e *QuerysheetModel) RecordID() interface{} {
	return e.Id
}

func (m *QuerysheetModel) TableName() string {
	return "bondsmaster"
}
