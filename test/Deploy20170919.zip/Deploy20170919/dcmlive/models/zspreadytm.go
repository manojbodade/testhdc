package models

import (
	"github.com/eaciit/orm"
	"gopkg.in/mgo.v2/bson"
)

type ZspreadYtmModel struct {
	orm.ModelBase `bson:"-",json:"-"`
	Id            bson.ObjectId `bson:"_id" , json:"_id"`
	Datasource    []GroupedChart
	Max           float64
	Min           float64
}

type GroupedChart struct {
	Name     string
	Category float64
	Value    float64
	Color    string
}

func NewZspreadYtmModel() *ZspreadYtmModel {
	m := new(ZspreadYtmModel)
	m.Id = bson.NewObjectId()
	return m
}

func (e *ZspreadYtmModel) RecordID() interface{} {
	return e.Id
}

func (m *ZspreadYtmModel) TableName() string {
	return "bondsmaster"
}
