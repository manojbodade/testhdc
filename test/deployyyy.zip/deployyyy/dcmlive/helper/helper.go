package helper

import (
	"fmt"
	"io"
	"os"
	"bufio"
	"crypto/md5"
	"encoding/hex"
	"log"
	"strings"
	"github.com/eaciit/dbox"
	_ "github.com/eaciit/dbox/dbc/csv"
	"github.com/eaciit/knot/knot.v1"
	"github.com/eaciit/toolkit"
	// "gopkg.in/gomail.v2"
	//"github.com/sourcegraph/go-ses"
//	"encoding/base64"
	// "io/ioutil"
)

var (
	DebugMode bool
	wd = func() string {
		d, _ := os.Getwd()
		return d + "/"
	}()
)

var config_system = func() string {
	d, _ := os.Getwd()
	d += "/conf/confsystem.json"
	return d
}()

func GetPathConfig() (result map[string]interface{}) {
	result = make(map[string]interface{})

	ci := &dbox.ConnectionInfo{config_system, "", "", "", nil}
	conn, e := dbox.NewConnection("json", ci)
	if e != nil {
		return
	}

	e = conn.Connect()
	defer conn.Close()
	csr, e := conn.NewQuery().Select("*").Cursor(nil)
	if e != nil {
		return
	}
	defer csr.Close()
	data := []toolkit.M{}
	e = csr.Fetch(&data, 0, false)
	if e != nil {
		return
	}
	result["folder-path"] = data[0].GetString("folder-path")
	result["restore-path"] = data[0].GetString("restore-path")
	result["folder-img"] = data[0].GetString("folder-img")
	return
}

func CreateResult(success bool, data interface{}, message string) map[string]interface{} {
	if !success {
		fmt.Println("ERROR! ", message)
		if DebugMode {
			panic(message)
		}
	}

	return map[string]interface{}{
		"data":    data,
		"success": success,
		"message": message,
	}
}

func UploadHandler(r *knot.WebContext, filename, dstpath string) (error, string) {
	file, handler, err := r.Request.FormFile(filename)
	if err != nil {
		return err, ""
	}
	defer file.Close()

	dstSource := dstpath + toolkit.PathSeparator + handler.Filename
	f, err := os.OpenFile(dstSource, os.O_WRONLY|os.O_CREATE, 0666)
	if err != nil {
		return err, ""
	}
	defer f.Close()
	io.Copy(f, file)

	return nil, handler.Filename
}

func GetMD5Hash(text string) string {
	hasher := md5.New()
	hasher.Write([]byte(text))
	return hex.EncodeToString(hasher.Sum(nil))
}

// func OcirSendEmail(_to, _mailmsg string) error {
	/*
	m := gomail.NewMessage()

	m.SetHeader("From", "admin.support@eaciit.com")
	m.SetHeader("To", _to)

	m.SetHeader("Subject", "[no-reply] Self password reset")
	m.SetBody("text/html", _mailmsg)

	d := gomail.NewPlainDialer("smtp.office365.com", 587, "admin.support@eaciit.com", "B920Support")
	err := d.DialAndSend(m)
	*/

	// config := ReadConfig()
	// AccessKeyID := config["accesskeyid"]
	// SecretAccessKey := config["secretaccesskey"]
	// Endpoint := config["endpoint"]
	// AccAmazone := config["accamazone"]
	// textBody := ""

//	_, err := ses.EnvConfig.SendEmailHTML(AccAmazone, _to, "[no-reply] Self password reset", textBody, _mailmsg, AccessKeyID, SecretAccessKey, Endpoint)
	// if err == nil {
	// 	fmt.Printf("email sent")
	// } else {
	// 	fmt.Printf("Error sending email: %s\n", err)
	// }


	// return err
// }

// func OcirSendEmailAttachment(Subject string, Body string, To string, Cc string, Attach string, name string) error {
// 	config 			:= ReadConfig()
// 	AccessKeyID 	:= config["accesskeyid"]
// 	SecretAccessKey := config["secretaccesskey"]
// 	Endpoint 		:= config["endpoint"]
// 	AccAmazone 		:= config["accamazone"]
// 	to 				:= strings.ToLower(To)
// 	bt, _ := ioutil.ReadFile(Attach)
// 	attachment := base64.StdEncoding.EncodeToString(bt)

// /*
// 	readeer := base64.NewDecoder(base64.StdEncoding,
// 		strings.NewReader(Attach))
// 	io.Copy(os.Stdout, readeer)
// 	bt, _ := ioutil.ReadAll(readeer)
// 	attachment := base64.StdEncoding.EncodeToString(bt)
// 	*/

	

// 	raw 			:= `To: %s
// From: %s
// Cc : %s
// Subject: %s
// Content-Type: multipart/mixed; boundary="_003_97DCB304C5294779BEBCFC8357FCC4D2"
// MIME-Version: 1.0

// --_003_97DCB304C5294779BEBCFC8357FCC4D2
// Content-Type: text/html;

// <html>
//   <head>
//     <style type="text/css">
//     body {
//       font-size: 12px;
//       font-family: 'Arial';
//     }
//     .emailgreen{
//       color:#3F9E35;
//     }
//     </style>
//   </head>
//   <body>
//     %s
//   </body>
// </html>

// --_003_97DCB304C5294779BEBCFC8357FCC4D2
// Content-Type: application/pdf; name="%s"
// Content-Description: %s
// Content-Disposition: attachment; filename="%s"; size=%d;
// Content-Transfer-Encoding: base64

// %s

// --_003_97DCB304C5294779BEBCFC8357FCC4D2
// `

// 	_, err := ses.EnvConfig.SendRawEmail([]byte(toolkit.Sprintf(raw, to, AccAmazone, Cc, Subject, Body, name, name, name, len(attachment), attachment)), AccessKeyID, SecretAccessKey, Endpoint)
// 	if err != nil {
// 		fmt.Printf("Error sending email: %s\n", err.Error())
// 	}


// 	return err
// }

//Reference,Time,Description,SessionId,LoginId,RequestAddr,LoadingTimes,_id,Action
func PrepareConnectionLogFile(sfile string) (dbox.IConnection, error) {
	var config = map[string]interface{}{"useheader": true,
		"delimiter": ",",
		"newfile":   true,
		"mapheader": []toolkit.M{toolkit.M{}.Set("SessionId", "string"),
			toolkit.M{}.Set("LoginId", "string"),
			toolkit.M{}.Set("Action", "string"),
			toolkit.M{}.Set("Reference", "string"),
			toolkit.M{}.Set("RequestAddr", "string"),
			toolkit.M{}.Set("Time", "string"),
			toolkit.M{}.Set("LoadingTimes", "string"),
			toolkit.M{}.Set("Description", "string"),
		}}
	ci := &dbox.ConnectionInfo{sfile, "", "", "", config}
	c, e := dbox.NewConnection("csv", ci)
	if e != nil {
		return nil, e
	}

	e = c.Connect()
	if e != nil {
		return nil, e
	}

	return c, nil
}

func ReadConfig() map[string]string {
	ret := make(map[string]string)
	file, err := os.Open(wd + "live/conf/app.conf")
	if err == nil {
		defer file.Close()

		reader := bufio.NewReader(file)
		for {
			line, _, e := reader.ReadLine()
			if e != nil {
				break
			}

			sval := strings.Split(string(line), "=")
			ret[sval[0]] = sval[1]
		}
	} else {
		log.Println(err.Error())
	}

	return ret
}
