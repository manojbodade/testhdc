package webext

import (
	// "bufio"
	. "eaciit/dcm/dcmlive/controllers"

	lacl "github.com/eaciit/acl/v1.0"
	// "github.com/eaciit/dbox"
	"log"
	"os"
	"path/filepath"

	_ "github.com/eaciit/dbox/dbc/mongo"
	"github.com/eaciit/knot/knot.v1"
	"github.com/eaciit/orm"
	"github.com/eaciit/toolkit"
	// "strings"
	"time"
)

var (
	Version string = "dcmlive"
	wd             = func() string {
		d, _ := os.Getwd()
		return d + "/"
	}()
	basePath string = (func(dir string, err error) string { return dir }(os.Getwd()))
)

func init() {
	log.Println("___INIT START_____")
	conn, err := PrepareConnection()
	if err != nil {
		log.Println(err)
	}
	uploadPath := PrepareUploadPath()
	config := ReadConfig()
	ctx := orm.New(conn)
	baseCtrl := new(BaseController)
	baseCtrl.Ctx = ctx
	baseCtrl.UploadPath = uploadPath
	baseCtrl.Path = config["path"]
	baseCtrl.AccessKeyID = config["accesskeyid"]
	baseCtrl.SecretAccessKey = config["secretaccesskey"]
	baseCtrl.Endpoint = config["endpoint"]
	baseCtrl.AccAmazone = config["accamazone"]
	baseCtrl.Attachemail = config["attachemail"]

	//acl db
	lacl.SetExpiredDuration(time.Hour * 2)
	err = lacl.SetDb(conn)
	if err != nil {
		log.Println(err)
	}

	err = PrepareDefaultUser()
	if err != nil {
		log.Println(err)
	}
	//==

	app := knot.NewApp(Version)
	app.ViewsPath = filepath.Join(basePath, Version, "views") + toolkit.PathSeparator

	// app.ViewsPath = config["path"] + "views/"
	app.Register(&AclUserController{baseCtrl})
	app.Register(&AclSysAdminController{baseCtrl})
	app.Register(&DashboardController{baseCtrl})
	app.Register(&PriceBondController{baseCtrl})
	app.Register(&TradingComparablesController{baseCtrl})
	app.Register(&CreditProfileController{baseCtrl})
	app.Register(&GenerateController{baseCtrl})
	app.Register(&WidgetAnalysisController{baseCtrl})

	staticpath := filepath.Join(config["path"], Version, "assets") + toolkit.PathSeparator
	app.Static("static", staticpath)
	app.LayoutTemplate = "_layout.html"
	knot.RegisterApp(app)
	log.Println("___INIT FINISH_____")
}

func PrepareUploadPath() string {
	config := ReadConfig()
	return config["uploadPath"]
}

func PrepareDefaultUser() (err error) {
	username := "eaciit"
	password := "Password.1"

	user := new(lacl.User)
	err = lacl.FindUserByLoginID(user, username)

	if err == nil || user.LoginID == username {
		return
	}

	user.ID = toolkit.RandomString(32)
	user.LoginID = username
	user.FullName = username
	user.Password = password
	user.Enable = true

	err = lacl.Save(user)
	if err != nil {
		return
	}
	err = lacl.ChangePassword(user.ID, password)
	if err != nil {
		return
	}

	toolkit.Printf(`Default user "%s" with standard password has been created%s`, username, "\n")

	return
}
