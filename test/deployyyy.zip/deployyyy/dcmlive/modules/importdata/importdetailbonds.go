package main

import (
	"bufio"
	"eaciit/dcm/dcmlive/modules"
	"github.com/eaciit/dbox"
	tk "github.com/eaciit/toolkit"
	"gopkg.in/mgo.v2/bson"
	"os"
	// "strconv"
	"strings"
)

var (
	conn dbox.IConnection
	wd   string
)

func setinitialconnection() {
	var err error
	conn, err = modules.GetDboxIConnection()

	if err != nil {
		tk.Println("Initial connection found : ", err)
		os.Exit(1)
	}
}

func main() {
	fpath := "D:/Office/dcm/DetailsBond.csv"

	afield := []string{}
	tablename := "detailbonds"
	afield = []string{"isin", "investor_id", "investor_short_name", "investor_name", "country", "type", "sales_person",
		"firm", "allocated"}

	f, e := os.Open(fpath)
	if e != nil {
		tk.Println("salah path")
	}

	scanner := bufio.NewScanner(f)
	lines := make([]string, 0)

	totalLines := 0
	for scanner.Scan() {
		lines = append(lines, scanner.Text())
		totalLines++
	}

	sresult := make(chan int, len(lines))
	jobs := make(chan tk.M, len(lines))
	for i := 0; i < 10; i++ {
		go workersave(i, jobs, sresult, tablename)
	}

	icount := 1
	for i, line := range lines {
		dataSplit := strings.Split(line, "|")
		result := tk.M{}
		if len(dataSplit) > 1 {
			if i != 0 {
				id := bson.NewObjectId()
				result.Set("_id", id)
				for ix, _str := range afield {
					if ix < len(dataSplit) {
						if _str == "firm" || _str == "allocated" {
							result.Set(_str, tk.ToFloat64(dataSplit[ix], 6, tk.RoundingAuto))
						} else {
							result.Set(_str, dataSplit[ix])
						}
					}
				}
				icount++
				jobs <- result
			}
		} else {
			tk.Println("error delimiter not match")
		}
	}

	tk.Println(">>> Done Send Data")
	close(jobs)
	step := int(icount / 10)
	if step == 0 {
		step = 1
	}
	for i := 1; i < icount; i++ {
		<-sresult
		if i%step == 0 {
			tk.Println("insertedrows", i)
		}
	}
	close(sresult)

	tk.Println("success")
}

func workersave(wi int, jobs <-chan tk.M, result chan<- int, table string) {
	workerconn, _ := modules.GetDboxIConnection()
	defer workerconn.Close()

	qSave := workerconn.NewQuery().
		From(table).
		SetConfig("multiexec", true).
		Save()

	trx := tk.M{}
	for trx = range jobs {

		err := qSave.Exec(tk.M{}.Set("data", trx))

		if err != nil {
			tk.Println(err)
		}

		result <- 1
	}
}
