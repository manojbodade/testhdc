package controllers

import (
	// "eaciit/dcm/dcmlive/helper"
	. "eaciit/dcm/dcmlive/models"
	// "errors"
	"fmt"
	"log"
	"math"
	"net/http"
	// "path/filepath"
	"bytes"
	"errors"
	"github.com/eaciit/acl/v1.0"
	"reflect"
	"strconv"
	"strings"
	"time"
	// db "github.com/eaciit/dbox"
	"github.com/eaciit/knot/knot.v1"
	"github.com/eaciit/orm"
	tk "github.com/eaciit/toolkit"
	"gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
)

type IBaseController interface {
}
type BaseController struct {
	base            IBaseController
	Ctx             *orm.DataContext
	UploadPath      string
	Path            string
	AccessKeyID     string
	SecretAccessKey string
	Endpoint        string
	AccAmazone      string
	Attachemail     string
}

type PageInfo struct {
	PageTitle    string
	SelectedMenu string
	Breadcrumbs  map[string]string
}

type ResultInfo struct {
	IsError   bool
	Message   string
	Total     int
	Data      interface{}
	LineData  interface{}
	GridData  interface{}
	StartTime time.Time
	Action    string
}

type Previlege struct {
	View     bool
	Create   bool
	Edit     bool
	Delete   bool
	Approve  bool
	Process  bool
	Menuid   string
	Menuname string
	Username string
}

// func (b *BaseController) LoadBaseUrl(k *knot.WebContext) {

// 	k.Config.NoLog = true
// 	b.IsAuthenticate(k)

// 	return
// }

func (b *BaseController) LoadBaseAjaxServ(k *knot.WebContext) {
	k.Config.NoLog = true

	sessionid := tk.ToString(k.Session("sessionid", ""))
	if !acl.IsSessionIDActive(sessionid) {
		// return errors.New("Session Expired")
	}

	return
}

func (b *BaseController) LoadBase(k *knot.WebContext) []tk.M {
	k.Config.NoLog = true
	b.IsAuthenticate(k)
	return []tk.M{}
}

func (b *BaseController) LogBase(k *knot.WebContext, res *ResultInfo) {

	// tk.Println("============= Check Header: ", k.Request.Header, "=============")
	ilog := new(acl.Log)
	ilog.ID = tk.RandomString(32)
	ilog.SessionId = tk.ToString(k.Session("sessionid", ""))
	ilog.LoginId = tk.ToString(k.Session("username", ""))
	ilog.Action = res.Action
	// ilog.Reference = k.Request.Header.Get("Referer")
	ilog.Reference = k.Request.RequestURI
	ilog.RequestAddr = k.Request.Header.Get("REMOTE_ADDR")
	ilog.Time = res.StartTime
	ilog.LoadingTimes = time.Since(res.StartTime).String()

	payload := tk.M{}
	_ = k.GetPayload(&payload)
	tkm := tk.M{}.Set("iserror", res.IsError).Set("message", res.Message).Set("payload", payload)
	ilog.Description = tk.JsonString(tkm)

	_ = acl.Save(ilog)
	//saving log data in file
	/*
		t1 := time.Now().UTC()
		filelog, _ := filepath.Abs(filepath.Join(b.Path, "log", tk.Sprintf("log-%d%d.csv", t1.Month(), t1.Year())))
		for {
			workerconn, er := helper.PrepareConnectionLogFile(filelog)
			if er == nil {
				_ = workerconn.NewQuery().
					SetConfig("multiexec", true).
					Save().Exec(tk.M{}.Set("data", ilog))
				defer workerconn.Close()
				break
			}
		}
	*/

	return
}

func (b *BaseController) IsAuthenticate(k *knot.WebContext) {
	sessionid := tk.ToString(k.Session("sessionid", ""))
	if !acl.IsSessionIDActive(sessionid) {
		k.SetSession("sessionid", "")
		b.CokRedirect(k, "dcmlive", "acluser", "default")
	}
	return
}

func (b *BaseController) AccessMenu(k *knot.WebContext) []tk.M {
	url := k.Request.URL.String()
	if strings.Index(url, "?") > -1 {
		url = url[:strings.Index(url, "?")]
		//		tk.Println("URL_PARSED,", url)
	}
	sessionRoles := k.Session("roles")
	access := []tk.M{}
	if sessionRoles != nil {
		accesMenu := sessionRoles.([]SysRolesModel)
		if len(accesMenu) > 0 {
			for _, o := range accesMenu[0].Menu {
				if o.Url == url {
					obj := tk.M{}
					obj.Set("View", o.View)
					obj.Set("Create", o.Create)
					obj.Set("Approve", o.Approve)
					obj.Set("Delete", o.Delete)
					obj.Set("Process", o.Process)
					obj.Set("Edit", o.Edit)
					obj.Set("Menuid", o.Menuid)
					obj.Set("Menuname", o.Menuname)
					obj.Set("Username", k.Session("username").(string))
					access = append(access, obj)
					return access
				}

			}
		}
	}
	return access
}

func (b *BaseController) IsLoggedIn(k *knot.WebContext) bool {
	if k.Session("userid") == nil {
		return false
	}
	return true
}
func (b *BaseController) GetCurrentUser(k *knot.WebContext) string {
	if k.Session("userid") == nil {
		return ""
	}
	return k.Session("username").(string)
}
func (b *BaseController) Redirect(k *knot.WebContext, controller string, action string) {
	// log.Println("StandchartORF -->> redirecting to " + controller + "/" + action)
	http.Redirect(k.Writer, k.Request, "/"+controller+"/"+action, http.StatusTemporaryRedirect)
}

func (b *BaseController) CokRedirect(k *knot.WebContext, service string, controller string, action string) {
	// log.Println("StandchartORF -->> redirecting to " + controller + "/" + action)
	http.Redirect(k.Writer, k.Request, "/"+service+"/"+controller+"/"+action, http.StatusTemporaryRedirect)
}

func (b *BaseController) WriteLog(msg interface{}) {
	log.Printf("%#v\n\r", msg)
	return
}

func (b *BaseController) InitialResultInfo(act, msg string) ResultInfo {
	r := ResultInfo{}
	r.IsError = true
	r.Message = msg
	r.Action = act
	r.StartTime = time.Now()
	return r
}

func (b *BaseController) SetResultInfo(isError bool, msg string, data interface{}) ResultInfo {
	r := ResultInfo{}
	r.IsError = isError
	r.Message = msg
	r.Data = data
	return r
}

func (b *BaseController) ErrorResultInfo(msg string, data interface{}) ResultInfo {
	r := ResultInfo{}
	r.IsError = true
	r.Message = msg
	r.Data = data
	return r
}

func (b *BaseController) ErrorMessageOnly(msg string) ResultInfo {
	r := ResultInfo{}
	r.IsError = true
	r.Message = msg
	r.Data = nil
	return r
}

func (b *BaseController) Round(f float64) float64 {
	return math.Floor(f + .5)
}
func (b *BaseController) RoundPlus(f float64, places int) float64 {
	shift := math.Pow(10, float64(places))
	return b.Round(f*shift) / shift
}
func (b *BaseController) FirstMonday(year int, mn int) int {
	month := time.Month(mn)
	t := time.Date(year, month, 1, 0, 0, 0, 0, time.UTC)

	d0 := (8-int(t.Weekday()))%7 + 1
	s := strconv.Itoa(year) + fmt.Sprintf("%02d", mn) + fmt.Sprintf("%02d", d0)
	ret, _ := strconv.Atoi(s)
	return ret
}

func (b *BaseController) FirstWorkDay(ym string) int {
	t, err := time.Parse("2006-01-02", ym+"-01")
	if err != nil {
		fmt.Println(err.Error())
	}
	for t.Weekday() == 0 || t.Weekday() == 6 {
		if t.Weekday() == 0 {
			t = t.AddDate(0, 0, 1)
		} else if t.Weekday() == 6 {
			t = t.AddDate(0, 0, 2)
		}
	}
	ret, _ := strconv.Atoi(t.Format("20060102"))
	return ret
}

// func (b *BaseController) GetNextIdSeq(collName string) (int, error) {
// 	ret := 0
// 	mdl := NewSequenceModel()
// 	crs, err := b.Ctx.Find(NewSequenceModel(), tk.M{}.Set("where", db.Eq("collname", collName)))
// 	if err != nil {
// 		return -9999, err
// 	}
// 	defer crs.Close()
// 	err = crs.Fetch(mdl, 1, false)
// 	if err != nil {
// 		return -9999, err
// 	}
// 	ret = mdl.Lastnumber + 1
// 	mdl.Lastnumber = ret
// 	b.Ctx.Save(mdl)
// 	return ret, nil
// }

func (b *BaseController) ToFixed(num float64, precision int) float64 {
	output := math.Pow(10, float64(precision))
	return float64(b.Rounded(num*output)) / output
}

func (b *BaseController) Rounded(num float64) int {
	return int(num + math.Copysign(0.5, num))
}

func (b *BaseController) DistinctArrayString(xs *[]string) {
	found := make(map[string]bool)
	j := 0
	for i, x := range *xs {
		if !found[x] {
			found[x] = true
			(*xs)[j] = (*xs)[i]
			j++
		}
	}
	*xs = (*xs)[:j]
}

func (b *BaseController) RollingPeriod(periodtype string) int {
	topmonth := 11

	switch periodtype {
	case "Quarterly":
		topmonth = 3
		break
	case "Semesterly":
		topmonth = 1
		break
	case "Fullyear":
		topmonth = 0
		break
	default:
		break
	}

	return topmonth
}

func (b *BaseController) ManyDays(m time.Month, year int, types string) int {
	if types == "year" {
		var ReturnDays int
		// We'll start by getting the current time.
		now := time.Date(
			year+1, 01, 01, 00, 00, 00, 000000000, time.UTC)

		then := time.Date(
			year, 01, 01, 00, 00, 00, 000000000, time.UTC)

		diff := now.Sub(then)
		ReturnDays = int((diff.Hours()) / 24)
		return ReturnDays
	} else {
		return time.Date(year, m+1, 0, 0, 0, 0, 0, time.UTC).Day()
	}

}
func (b *BaseController) ParseMonthYear(monthyear string) string {
	yearstring := monthyear[:4]
	yearstring = yearstring[2:len(yearstring)]
	monthstring := monthyear[4:len(monthyear)]
	if monthstring == "01" {
		monthstring = "Jan"
	} else if monthstring == "02" {
		monthstring = "Feb"
	} else if monthstring == "03" {
		monthstring = "Mar"
	} else if monthstring == "04" {
		monthstring = "Apr"
	} else if monthstring == "05" {
		monthstring = "May"
	} else if monthstring == "06" {
		monthstring = "Jun"
	} else if monthstring == "07" {
		monthstring = "Jul"
	} else if monthstring == "08" {
		monthstring = "Aug"
	} else if monthstring == "09" {
		monthstring = "Sep"
	} else if monthstring == "10" {
		monthstring = "Oct"
	} else if monthstring == "11" {
		monthstring = "Nov"
	} else if monthstring == "12" {
		monthstring = "Dec"
	}
	return monthstring + " " + yearstring
}

func (b *BaseController) ParseMonthYearFull(monthyear string) string {
	yearstring := monthyear[:4]
	// yearstring = yearstring[2:len(yearstring)]
	monthstring := monthyear[4:len(monthyear)]
	if monthstring == "01" {
		monthstring = "January"
	} else if monthstring == "02" {
		monthstring = "Febuary"
	} else if monthstring == "03" {
		monthstring = "March"
	} else if monthstring == "04" {
		monthstring = "April"
	} else if monthstring == "05" {
		monthstring = "May"
	} else if monthstring == "06" {
		monthstring = "June"
	} else if monthstring == "07" {
		monthstring = "July"
	} else if monthstring == "08" {
		monthstring = "August"
	} else if monthstring == "09" {
		monthstring = "September"
	} else if monthstring == "10" {
		monthstring = "October"
	} else if monthstring == "11" {
		monthstring = "November"
	} else if monthstring == "12" {
		monthstring = "December"
	}
	return monthstring + " " + yearstring
}

func (d *BaseController) PercentageVersus(FirstAct float64, SecondAct float64, FirstVersus float64, SecondVersus float64, types string) float64 {
	final := 0.00
	Actual := 0.00
	Versus := 0.00

	if SecondAct != 0.00 {
		Actual = (FirstAct / SecondAct) * 100
	}

	if SecondVersus != 0.00 {
		Versus = (FirstVersus / SecondVersus) * 100
	}
	if types == "comparison" {
		final = Actual - Versus
	} else {
		final = Actual - Versus - 1
	}

	return final
}

func (b *BaseController) GetCurrentQuarter(month int) string {
	quarter := ""

	if month == 1 || month == 2 || month == 3 {
		quarter = "Q1"
	} else if month == 4 || month == 5 || month == 6 {
		quarter = "Q2"
	} else if month == 7 || month == 8 || month == 9 {
		quarter = "Q3"
	} else if month == 10 || month == 11 || month == 12 {
		quarter = "Q4"
	}

	return quarter
}

func (b *BaseController) GetCurrentMonthName(month int) string {
	monthstring := ""
	if month == 1 {
		monthstring = "Jan"
	} else if month == 2 {
		monthstring = "Feb"
	} else if month == 3 {
		monthstring = "Mar"
	} else if month == 4 {
		monthstring = "Apr"
	} else if month == 5 {
		monthstring = "May"
	} else if month == 6 {
		monthstring = "Jun"
	} else if month == 7 {
		monthstring = "Jul"
	} else if month == 8 {
		monthstring = "Aug"
	} else if month == 9 {
		monthstring = "Sep"
	} else if month == 10 {
		monthstring = "Oct"
	} else if month == 11 {
		monthstring = "Nov"
	} else if month == 12 {
		monthstring = "Dec"
	}

	return monthstring
}

func (b *BaseController) daysIn(m time.Month, year int) int {
	// This is equivalent to time.daysIn(m, year).
	return time.Date(year, m+1, 0, 0, 0, 0, 0, time.UTC).Day()
}

func (b *BaseController) daysInYear(year int) int {
	var ReturnDays int
	// We'll start by getting the current time.
	now := time.Date(
		year+1, 01, 01, 00, 00, 00, 000000000, time.UTC)

	then := time.Date(
		year, 01, 01, 00, 00, 00, 000000000, time.UTC)

	diff := now.Sub(then)
	ReturnDays = int((diff.Hours()) / 24)
	return ReturnDays
}

func MgoQuery(tablename string, action string, indexAll []string, newtablename string, indexname string, where tk.M) error {
	config := ReadConfig()
	info := new(mgo.DialInfo)
	info.Username = config["username"]
	info.Password = config["password"]
	info.Source = config["source"]
	info.Addrs = []string{config["host"]}
	info.Database = config["database"]

	session, err := mgo.DialWithInfo(info)
	if err != nil {
		return err
	}
	defer session.Close()

	// Error check on every access
	session.SetSafe(&mgo.Safe{})

	// Get collection
	collection := session.DB(info.Database).C(tablename)

	switch action {
	case "Remove":
		err = collection.Remove(bson.M{})
		break
	case "RemoveAll":
		_, err = collection.RemoveAll(bson.M{})
		break
	case "DropCollection":
		err = collection.DropCollection()
		break
	case "CountCollection":
		total := 0
		total, err = collection.Count()
		strMessage := tk.ToString(total)
		messageError := errors.New(strMessage)
		return messageError
		break
	case "FindUseWhere":
		total := 0
		total, err = collection.Find(where).Count()
		strMessage := tk.ToString(total)
		messageError := errors.New(strMessage)
		return messageError
		break
	case "Pipe":
		wherePipe := where.Get("query").([]tk.M)
		pipe := collection.Pipe(wherePipe)
		iter := pipe.Iter()
		result := []tk.M{}
		err := iter.All(&result)
		if err != nil {
		    tk.Println("ERROR : ",err) 
		}

		// tk.Println(pipe,"+++++++++++++")
		tk.Println(len(result),"=============")
		// tk.Println(len(iter),"=============")
		break
	case "StatusServer":
		result := tk.M{}
		err = session.DB(info.Database).Run("dbstats", &result)
		strMessage := result.GetString("numExtents") + "$$$" + result.GetString("indexes") + "$$$" + result.GetString("collections") + "$$$" +
			result.GetString("objects") + "$$$" + result.GetString("storageSize") + "$$$" + result.GetString("indexSize") + "$$$" +
			result.GetString("db") + "$$$" + result.GetString("ok") + "$$$" + result.GetString("avgObjSize") + "$$$" + result.GetString("dataSize")
		messageError := errors.New(strMessage)
		return messageError
		break
	case "RenameCollection":
		a := []interface{}{}
		sourceCollection := info.Database + "." + tablename
		destinationCollection := info.Database + "." + newtablename
		session.Run(bson.D{{"renameCollection", sourceCollection}, {"to", destinationCollection}}, a)
		break
	case "CreateCollection":
		// info := mgo.CollectionInfo{
		// 	Capped:   true,
		// 	MaxBytes: 1000000,
		// }
		// err = collection.Create(info) //--> Use Create but failed
		// err = collection.Insert(&DefaultCollection{Id: bson.NewObjectId()})  //--> use insert _id success --> will have one row with field _id

		a := []interface{}{}
		session.DB(info.Database).Run(bson.D{{"create", tablename}}, a)
		break
	case "CreateIndex":
		index := mgo.Index{
			Key:        indexAll,
			Unique:     false,
			DropDups:   true,
			Background: true,
			Sparse:     true,
			Name:       indexname,
		}

		err = collection.EnsureIndex(index)
		break
	default:
		break
	}

	if err != nil {
		return err
	}

	return nil
}

func RoundUp(input float64, places int) (newVal float64) {
	var round float64
	pow := math.Pow(10, float64(places))
	digit := pow * input
	round = math.Ceil(digit)
	newVal = round / pow
	return
}

func ByteFormat(inputNum float64, precision int) float64 {

	if precision <= 0 {
		precision = 1
	}

	//var unit string
	var returnVal float64

	if inputNum >= 1000000000000000000000000 {
		returnVal = RoundUp((inputNum / 1208925819614629174706176), precision)
		//unit = " YB" // yottabyte
	} else if inputNum >= 1000000000000000000000 {
		returnVal = RoundUp((inputNum / 1180591620717411303424), precision)
		//unit = " ZB" // zettabyte
	} else if inputNum >= 10000000000000000000 {
		returnVal = RoundUp((inputNum / 1152921504606846976), precision)
		// unit = " EB" // exabyte
	} else if inputNum >= 1000000000000000 {
		returnVal = RoundUp((inputNum / 1125899906842624), precision)
		// unit = " PB" // petabyte
	} else if inputNum >= 1000000000000 {
		returnVal = RoundUp((inputNum / 1099511627776), precision)
		// unit = " TB" // terrabyte
	} else if inputNum >= 1000000000 {
		returnVal = RoundUp((inputNum / 1073741824), precision)
		// unit = " GB" // gigabyte
	} else if inputNum >= 1000000 {
		returnVal = RoundUp((inputNum / 1048576), precision)
		// unit = " MB" // megabyte
	} else if inputNum >= 1000 {
		returnVal = RoundUp((inputNum / 1024), precision)
		// unit = " KB" // kilobyte
	} else {
		returnVal = inputNum
		// unit = " bytes" // byte
	}

	//return strconv.FormatFloat(returnVal, 'f', precision, 64) + unit
	return returnVal
}

func DiffDays(bigDate string, formatBigDate string, littleDate string, formatLittleDate string) float64 {
	max, _ := time.Parse(formatBigDate, bigDate)
	current, _ := time.Parse(formatLittleDate, littleDate)
	diff := max.Sub(current)
	ReturnDays := int((diff.Hours()) / 24)
	return float64(ReturnDays)
}

func SlopeTenorLogic(Slope float64, Intercept float64, TenorUI float64) float64 {
	s := (Slope * TenorUI) + Intercept
	return s
}

func formatNumberString(x string, precision int, thousand string, decimal string) string {
	lastIndex := strings.Index(x, ".") - 1

	if lastIndex < 0 {
		lastIndex = len(x) - 1
	}

	var buffer []byte
	var strBuffer bytes.Buffer

	j := 0
	for i := lastIndex; i >= 0; i-- {
		j++
		buffer = append(buffer, x[i])

		if j == 3 && i > 0 && !(i == 1 && x[0] == '-') {
			buffer = append(buffer, ',')
			j = 0
		}
	}

	for i := len(buffer) - 1; i >= 0; i-- {
		strBuffer.WriteByte(buffer[i])
	}
	result := strBuffer.String()

	if thousand != "," {
		result = strings.Replace(result, ",", thousand, -1)
	}

	extra := x[lastIndex+1:]
	if decimal != "." {
		extra = strings.Replace(extra, ".", decimal, 1)
	}

	return result + extra
}

func FormatNumber(value interface{}, precision int) string {
	thousand := ","
	decimal := "."
	v := reflect.ValueOf(value)
	var x string
	switch v.Kind() {
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		x = fmt.Sprintf("%d", v.Int())
		// if precision > 0 {
		// 	x += "." + strings.Repeat("0", precision)
		// }
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
		x = fmt.Sprintf("%d", v.Uint())
		// if precision > 0 {
		// 	x += "." + strings.Repeat("0", precision)
		// }
	case reflect.Float32, reflect.Float64:
		x = fmt.Sprintf(fmt.Sprintf("%%.%df", precision), v.Float())
	default:
		panic("Unsupported type - " + v.Kind().String())
	}

	return formatNumberString(x, precision, thousand, decimal)
}

func LogicTermSheet(Spread float64, DiffOri float64, DiffLeft float64) float64 {
	res := (Spread / DiffOri) * (DiffLeft)
	return res
}
