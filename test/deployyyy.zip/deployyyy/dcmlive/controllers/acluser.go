package controllers

import (
	"errors"
	"github.com/eaciit/acl/v1.0"
	db "github.com/eaciit/dbox"
	"github.com/eaciit/knot/knot.v1"
	"github.com/eaciit/toolkit"
	// "gopkg.in/gomail.v2"
	"bufio"
	// "eaciit/dcm/dcmlive/helper"
	// . "eaciit/dcm/dcmlive/models"
	// "gopkg.in/mgo.v2/bson"
	"log"
	"os"
	// "reflect"
	"strings"
)

type AclUserController struct {
	*BaseController
}

type Filter struct {
	Filters []FiltersGroup
	Logic   string
}

type FiltersGroup struct {
	Field    string
	Operator string
	Value    string
}

var (
	wd = func() string {
		d, _ := os.Getwd()
		return d + "/"
	}()
)

func (a *AclUserController) Default(k *knot.WebContext) interface{} {
	sessionid := toolkit.ToString(k.Session("sessionid", ""))
	if acl.IsSessionIDActive(sessionid) {
		a.CokRedirect(k, "dcmlive", "dashboard", "default")
	}

	k.Config.NoLog = true
	k.Config.OutputType = knot.OutputTemplate
	k.Config.LayoutTemplate = ""

	resdata := a.InitialResultInfo("Access Page", "View Page Login")
	defer a.LogBase(k, &resdata)

	resdata.IsError = false
	// resdata.Message = "View Page Login"
	// resdata.StartTime = time.Now()
	// resdata.Action = "Access Page"

	return ""
}

func (a *AclUserController) ConfirmReset(k *knot.WebContext) interface{} {
	k.Config.NoLog = true
	k.Config.OutputType = knot.OutputTemplate
	k.Config.LayoutTemplate = ""

	resdata := a.InitialResultInfo("Access Page", "View Page Confirm Reset Password")
	defer a.LogBase(k, &resdata)

	resdata.IsError = false
	// resdata.Message = "View Page Confirm Reset Password"
	// resdata.StartTime = time.Now()
	// resdata.Action = "Access Page"

	return ""
}

func (d *AclUserController) CheckConnection() ResultInfo {
	resdata := d.InitialResultInfo("System Authentication", "System Authentication")
	query := d.Ctx.Connection.NewQuery()
	result := []toolkit.M{}
	csr, _ := query.
		Select("_id").
		From("acl_users").
		Take(1).Cursor(nil)
	_ = csr.Fetch(&result, 0, false)

	if len(result) == 0 {
		resdata.IsError = true
		resdata.Message = "Wrong Database Name"
		resdata.Action = "System Authentication"
		return resdata
	}

	resdata.IsError = false
	resdata.Message = "Connection Success"
	resdata.Action = "Connection Success"
	return resdata
}

func (a *AclUserController) Login(k *knot.WebContext) interface{} {
	k.Config.NoLog = true
	k.Config.OutputType = knot.OutputJson

	resdata := a.InitialResultInfo("Login", "not yet login")

	e := a.CheckConnection()
	if e.IsError == true {
		resdata.IsError = true
		resdata.Message = "Wrong Database Name"
		resdata.Action = "System Authentication"
		return resdata
	}

	defer a.LogBase(k, &resdata)

	payload := toolkit.M{}

	err := k.GetPayload(&payload)
	if err != nil {
		resdata.Message = toolkit.Sprintf("get payload found : %v", err.Error())
		return resdata
	}

	sessionid, err := acl.Login(payload.GetString("username"), payload.GetString("password"))
	if err != nil {
		resdata.Message = toolkit.Sprintf("Wrong Login ID or Password.")
		return resdata
	}

	resdata.Message = "login success"
	resdata.IsError = false
	resdata.Data = sessionid

	k.SetSession("sessionid", sessionid)
	k.SetSession("username", payload.GetString("username"))

	return resdata
}

func (a *AclUserController) Logout(k *knot.WebContext) interface{} {
	k.Config.NoLog = true
	k.Config.OutputType = knot.OutputJson

	resdata := a.InitialResultInfo("Logout", "Logout fail")
	defer a.LogBase(k, &resdata)

	// resdata.IsError = true
	// resdata.StartTime = time.Now()
	// resdata.Action = "Logout"

	sessionid := toolkit.ToString(k.Session("sessionid", ""))
	err := acl.Logout(sessionid)
	if err != nil {
		resdata.Message = toolkit.Sprintf("logout process found : %v", err.Error())
		return resdata
	}

	resdata.Message = "Logout Success"
	resdata.IsError = false

	k.SetSession("sessionid", "")
	a.Redirect(k, "acluser", "default")
	return resdata
}

func (a *AclUserController) SaveNewPassword(k *knot.WebContext) interface{} {
	k.Config.NoLog = true
	k.Config.OutputType = knot.OutputJson

	resdata := a.InitialResultInfo("Change Password", "Change Password fail")
	defer a.LogBase(k, &resdata)

	// resdata.IsError = true
	// resdata.Message = "Change Password Success"
	// resdata.StartTime = time.Now()
	// resdata.Action = "Change Password"

	payload := toolkit.M{}
	if err := k.GetPayload(&payload); err != nil {
		resdata.Message = err.Error()
		return resdata
	}

	sessionid := toolkit.ToString(k.Session("sessionid", ""))
	if !payload.Has("newpassword") || (!payload.Has("tokenid") && sessionid == "") {
		resdata.Message = "Data is not complete"
		return resdata
	}

	var userid string
	var err error
	switch {
	case payload.Has("tokenid"):
		err = acl.ChangePasswordToken(payload.GetString("userid"), payload.GetString("newpassword"), payload.GetString("tokenid"))
		userid = payload.GetString("userid")
	default:
		userid, err = acl.FindUserBySessionID(sessionid)
		if err != nil {
			resdata.Message = err.Error()
			return resdata
		}

		if sessionid == payload.GetString("sessionid") {
			err = acl.ChangePasswordFromOld(userid, payload.GetString("newpassword"), payload.GetString("oldpassword"))
		} else if err == nil {
			err = errors.New("session is not match")
		}
	}

	if err != nil {
		resdata.Message = err.Error()
		return resdata
	}

	tUser := new(acl.User)
	if _err := acl.FindByID(tUser, userid); _err != nil {
		resdata.Message = toolkit.Sprintf("Change Password, Found : %v", _err.Error())
		return resdata
	}

	mailmsg := toolkit.Sprintf("Hi, <br/><br/> Your request for change password has been saved, <br/><br/>")
	mailmsg = toolkit.Sprintf("%vYou can login using your new password <br/><br/>", mailmsg)
	mailmsg = toolkit.Sprintf("%vThanks,</body></html>", mailmsg)

	// if _err := helper.OcirSendEmail(tUser.Email, mailmsg); _err != nil {
	// 	resdata.Message = toolkit.Sprintf("Change Password, Found : %v", _err.Error())
	// 	return resdata
	// }

	resdata.IsError = false
	resdata.Message = "Change Password Success"
	return resdata
}

func (a *AclUserController) ResetPassword(k *knot.WebContext) interface{} {
	// k.Config.NoLog = true
	k.Config.OutputType = knot.OutputJson

	resdata := a.InitialResultInfo("Reset Password", "Request reset password fail")
	defer a.LogBase(k, &resdata)

	// resdata.IsError = true
	// resdata.Message = "Request reset password Success"
	// resdata.StartTime = time.Now()
	// resdata.Action = "Reset Password"

	payload := toolkit.M{}
	if err := k.GetPayload(&payload); err != nil {
		resdata.Message = err.Error()
		return resdata
	}

	if !payload.Has("email") || !payload.Has("baseurl") {
		resdata.Message = "Data is not complete"
		return resdata
	}

	payloadEmail := strings.ToLower(payload.GetString("email"))

	uname, tokenid, err := acl.ResetPassword(payloadEmail)
	if err != nil {
		resdata.Message = err.Error()
		return resdata
	}

	linkstr := toolkit.Sprintf("<a href='%v/acluser/confirmreset?1=%v&2=%v'>Click</a>", payload.GetString("baseurl"), uname, tokenid)

	mailmsg := toolkit.Sprintf("Hi, <br/><br/> We received a request to reset your password, <br/><br/>")
	mailmsg = toolkit.Sprintf("%vFollow the link below to set a new password : <br/><br/> %v <br/><br/>", mailmsg, linkstr)
	mailmsg = toolkit.Sprintf("%vIf you don't want to change your password, you can ignore this email <br/><br/> Thanks,</body></html>", mailmsg)

	// if err := helper.OcirSendEmail(payloadEmail, mailmsg); err != nil {
	// 	resdata.Message = err.Error()
	// 	return resdata
	// }

	resdata.IsError = false
	resdata.Message = "Request reset password Success"
	return resdata
}

func (a *AclUserController) GetListTopMenu(k *knot.WebContext) interface{} {
	a.LoadBase(k)
	k.Config.OutputType = knot.OutputJson

	resdata := a.InitialResultInfo("Get Data", "Get data top menu fail")
	defer a.LogBase(k, &resdata)

	// resdata.IsError = true
	// resdata.Message = "Get data top menu"
	// resdata.StartTime = time.Now()
	// resdata.Action = "Get Data"

	sessionid := toolkit.ToString(k.Session("sessionid", ""))
	arrmenu, err := acl.GetListMenuBySessionId(sessionid)

	if err != nil {
		resdata.Message = err.Error()
		return resdata
	}

	resdata.IsError = false
	resdata.Data = arrmenu
	resdata.Message = "Get data top menu success"
	return resdata
}

// func (a *AclUserController) FindDataUserByID(k *knot.WebContext) interface{} {
// 	k.Config.NoLog = true
// 	k.Config.OutputType = knot.OutputJson
// 	resdata := ResultInfo{}
// 	resdata.IsError = true
// 	resdata.Message = "Find data user"

// 	payload := toolkit.M{}

// 	err := k.GetPayload(&payload)
// 	if err != nil {
// 		resdata.Message = toolkit.Sprintf("get payload found : %v", err.Error())
// 		return resdata
// 	}

// 	tUser := new(acl.User)
// 	if payload.Has("userid") && payload.GetString("userid") != "" {
// 		err = acl.FindByID(tUser, payload.GetString("userid"))
// 		if err != nil {
// 			resdata.Message = toolkit.Sprintf("find user found : %v", err.Error())
// 		} else {
// 			resdata.Total = 1
// 			resdata.Data = toolkit.Sprintf("%v", tUser)
// 			resdata.IsError = false
// 		}
// 	} else {
// 		resdata.Message = toolkit.Sprintf("User ID not found")
// 	}

// 	return resdata
// }

func PrepareConnection() (db.IConnection, error) {
	config := ReadConfig()
	ci := &db.ConnectionInfo{config["host"], config["database"], config["username"], config["password"], toolkit.M{}.Set("timeout", 10)}
	// toolkit.Printfn("Connectcting to: %s\n", toolkit.JsonString(ci))
	c, e := db.NewConnection("mongo", ci)

	if e != nil {
		return nil, e
	}

	e = c.Connect()
	if e != nil {
		return nil, e
	}

	return c, nil
}

func ReadConfig() map[string]string {
	ret := make(map[string]string)
	file, err := os.Open(wd + "dcmlive/conf/app.conf")
	if err == nil {
		defer file.Close()

		reader := bufio.NewReader(file)
		for {
			line, _, e := reader.ReadLine()
			if e != nil {
				break
			}

			sval := strings.Split(string(line), "=")
			ret[sval[0]] = sval[1]
		}
	} else {
		log.Println(err.Error())
	}

	return ret
}
