


var termSheet = {};
termSheet.loading  = ko.observable(true);
termSheet.dataTab1 = {
	issuerName	 		 : ko.observable(""),
	issuerRating 		 : ko.observableArray(["a","b","c"]),
	instrument   		 : ko.observable("instrument"),
	distributionFormat   : ko.observableArray([{text:"Reg S",value:"Reg S"},{text:"144A",value:"144A"}]),
	currency 			 : ko.observableArray(["USD"]),
	size 				 : ko.observableArray([001,002]),
	tenors 				 : ko.observableArray(),
	benchmarkYield		 : ko.observableArray([]),
	benchmarkToSpread	 : ko.observableArray([]),
	yield			     : ko.observableArray([]),
	afterSwap 			 : ko.observableArray([])
};

termSheet.dataTab2   = ko.observableArray([]);
termSheet.columnGrid =  ko.observable("");

termSheet.dataTab3 = {
	tenorsList  : ko.observableArray([]),
	widgets : ko.observableArray([]),
	chartDS : {
		tenors :  [100, 30, 40],
		size   :  300,
		premium : 300,
		ratting : 100
	}
} 
termSheet.dataTab4 = {
	yAxis 		: ko.observable(""),
	yAxisList 	: ko.observableArray([
										{text:'Bid YTM',value:'Bidytm'},
										{text:'Bid Spread G',value:'Bidgspread'},
										{text:'Bid Spread Z',value:'Bidzspread'}
									])
}
termSheet.dataTab4.yAxis.subscribe(function(){
	setTimeout(function() { termSheet.createScaterChartTab4() }, 300);
})
function getWidthPercetage(len){
	return String(100/len) + "%"; 
}

termSheet.RenderTab1 = function(){
	console.log(ds.issuerSelected)
	var gridTemplateFirst = pbGrid.gridTemplateFirst();
	var rowBasis = pbGrid.rowBasis();
	termSheet.dataTab1.issuerRating([
										ds.issuerSelected.moodys_issuer_rating,
										ds.issuerSelected.sp_issuer_rating,
										ds.issuerSelected.fitch_issuer_rating
									]);
	termSheet.dataTab1.instrument(pbGrid.gridTemplateFirst().payload.Ranking);
	termSheet.dataTab1.tenors(pbGrid.gridTemplateFirst().payload.Tenor);
	


	// _.each(gridTemplateFirst.payload.Tenor, function(o,idx){
	// 	benchmarkYields.push("CT5 at 1.52%");
	// 	benchmarkToSpreads.push("+340-355");
	// 	yields.push("4.92-5.07%");
	// 	afterSwaps.push("+329-344");
	// });



	termSheet.dataTab1.size([parseInt(pbGrid.filterTermSheet.issuenze.issueSize())]);
	termSheet.dataTab1.issuerName(ds.issuerSelected.issuer)
} 
termSheet.RenderTab2 = function(){
	termSheet.dataTab2(pbGrid.GridTemplate()[0].resData());
	if(ds.issuerSelected.product.toLowerCase() == 'ig' || ds.issuerSelected.product.toLowerCase() == 'crossover')
		termSheet.columnGrid("Bid Spread Z");
	else
		termSheet.columnGrid("Bid YTM");
}
termSheet.createChart =  function(obj){
	setTimeout(function(){
		var basis 		= pbGrid.filterTermSheet.tenor.basis()[0].value();
		var dsBasis     = [0, parseFloat(basis)];

		var tenor 		= termSheet.dataTab3.chartDS.tenors[obj.tenor()];
		var dsTenor     = [parseFloat(basis), parseFloat(basis) + parseFloat(tenor)];
		
		if(parseFloat(termSheet.dataTab3.chartDS.size) == 0){
			var dsSize      = [0,0];
		}else{
			var dsSize      = [parseFloat(basis) + parseFloat(tenor),
							   parseFloat(basis) + parseFloat(tenor) + parseFloat(termSheet.dataTab3.chartDS.size)];	
		}


		if(termSheet.dataTab3.chartDS.premium == 0){
			var dsPremium   = [0,0];
		}else{
			var dsPremium   = [
								parseFloat(basis) + parseFloat(tenor) + parseFloat(termSheet.dataTab3.chartDS.size) , 
							   (parseFloat(basis) + parseFloat(tenor) + parseFloat(termSheet.dataTab3.chartDS.size) ) + parseFloat(termSheet.dataTab3.chartDS.premium)];	
		}

		if(pbGrid.tenordiff()){
			console.log(termSheet.dataTab3.chartDS.ratting)
			if(termSheet.dataTab3.chartDS.ratting == 0){
				var dsRatting   =[0,0];
			}else{
				var dsRatting   = [
									parseFloat(basis) + parseFloat(tenor) + parseFloat(termSheet.dataTab3.chartDS.size) + parseFloat(termSheet.dataTab3.chartDS.premium),  
								   (parseFloat(basis) + parseFloat(tenor) + parseFloat(termSheet.dataTab3.chartDS.size) + parseFloat(termSheet.dataTab3.chartDS.premium)) + parseFloat(termSheet.dataTab3.chartDS.ratting)
								  ];
			}
		}else{
			var dsRatting   =[0,0];
		}
		var datas= _.union(dsBasis, dsTenor, dsSize, dsPremium, dsRatting);
		var maxtotal = _.max(datas)
		var dsTotal = [0, (parseFloat(basis) + parseFloat(tenor) + parseFloat(termSheet.dataTab3.chartDS.size) + parseFloat(termSheet.dataTab3.chartDS.premium)) + parseFloat(termSheet.dataTab3.chartDS.ratting)];
		 
		var allData = [dsBasis, dsTenor, dsSize, dsPremium, dsRatting, dsTotal];
		var listCategories  = ["Bench", "TD", "LP", "NIP", "RD", "Total"];
		var listCategories2  = ["Bench", "TD", "LP", "NIC", "RD", "Total"];
		var categories 		= [];
		var data 	= []
		_.each(allData, function(o,i){
			if(o[0] != 0 || o[1] != 0){

				if(ds.issuerSelected.product.toLowerCase() == 'ig' || ds.issuerSelected.product.toLowerCase() == 'crossover'){
					listCategories[0] = 'Bench Z'
					listCategories2[0] = 'Bench Z'
				}else{
					listCategories[0] = 'Bench YTM'
					listCategories2[0] = 'Bench YTM'
				}

				if(dsPremium[1]-dsPremium[0] < 0){
					categories.push(listCategories2[i]);
				}else{
					categories.push(listCategories[i]);
				}
				data.push([o[0],o[1]])
			}
		})
		var maxAxis = _.max([
		 					 0,
		 					 parseFloat(dsTenor[1]),
		 					 parseFloat(dsSize[1]),
		 					 parseFloat(dsPremium[1]),
		 					 parseFloat(dsRatting[1]),
		 					]);
	 	var minAxis = _.min([
	 					0,
	 					 parseFloat(dsTenor[1]),
	 					 parseFloat(dsSize[1]),
	 					 parseFloat(dsPremium[1]),
						 parseFloat(dsRatting[1]),
 					]);
	 	console.log(obj.id,data)
		$("#"+obj.id).find(".contentWidget").html()
		$("#"+obj.id).find(".contentWidget").kendoChart({
		    series: [{ 
		    	gap : 1.6,
		        type: "rangeColumn",
		        colorField :'color',
		        field:'value',
		        data: data,
			    color: function(e){
			      if (e.category == "TD" || e.category == "Bench Z" || e.category == "Bench YTM"){
			      	return "#1E88E5"
			      }else if(e.category == "LP"){
			      	return "#57ACF3"
			      }else if(e.category == "NIP" || e.category == "NIC" || e.category == "RD"){
			      	return "#65B7F5"
			      }else{
			      	return "#60D5A8"
			      }
			    }, 
		    }],
		    // seriesColors: ["#1E88E5", "#57ACF3", "#65B7F5","#60D5A8"],
		    seriesDefaults: {
		    	overlay: {
					gradient: "none"
				},
		        labels: {
		            visible: false, 
		        }
		    },
		    categoryAxis: {
		        categories: categories,
		        labels: {
		            rotation: "auto",
		            font: ds.font('9px'),
		        },
		        majorGridLines: {
					visible: false
				},
				line:{
					visible: true
				}
		    },
		    valueAxis: {
		    	max   : maxAxis * 1.1,
		    	min   : minAxis,
				labels: {
					color: "#4c5356",
					font: ds.font('9px'),
					visible: true,
				},
				line: {
					visible: false
				},
				majorGridLines: {
					visible: false
		        },
	        },
		   
		        
	        tooltip: {
                visible: true,
                template : function(e){
	                	// console.log(e);
	                return kendo.toString((e.dataItem[1] - e.dataItem[0]),'n0');
                }

            }
		    
		    // pannable 	: true,
      //   	zoomable 	: true
		});
	},100)
};
termSheet.createDataTenor3 = function(){
	var tenors = []
	_.each(pbGrid.tenors() , function(o,i){
		switch(o.value()){
			case"syndicate":
				tenors.push(pbGrid.filterTermSheet.tenor.syndicateTabel()[i].value())
			break;
			case"trending":
				tenors.push(pbGrid.filterTermSheet.tenor.trendingCurve()[i].value());
			break;
			default:
				tenors.push(pbGrid.filterTermSheet.tenor.manualInput()[i].value());
		}
	})
	termSheet.dataTab3.chartDS.tenors 	 = tenors;
 	termSheet.dataTab3.chartDS.size  	 = (pbGrid.filterTermSheet.issuenze.issueSize() > 300) ? 0 : pbGrid.filterTermSheet.issuenze.liquityPerm(); 
 	termSheet.dataTab3.chartDS.premium   = (pbGrid.filterTermSheet.premium.checked()) ? pbGrid.filterTermSheet.premium.value() : 0; 
 	termSheet.dataTab3.chartDS.ratting   = (pbGrid.filterTermSheet.ratting.checked()) ? pbGrid.filterTermSheet.ratting.sugested():pbGrid.filterTermSheet.ratting.manualInput(); 
};
termSheet.RenderTab3 = function(){
	termSheet.dataTab3.widgets([])
	var obj      =  pbGrid.GridTemplate()[0];
	var tenors  = obj.payload.Tenor;

	termSheet.createDataTenor3();

	var widgets  = [];
	var tenorsList = [];
	// if(tenors.length == 1){
	// 	tenorsList.push({text:tenors[0],value:0});
	// 	widgets.push({
	// 						tenor: ko.observable(0),
	// 						id   : 'termSheet-chart0'
	// 			     },{
	// 						tenor: ko.observable(0),
	// 						id   : 'termSheet-chart1'
	// 			     });
	// }else{
	_.each(tenors, function(obj,idx){
		tenorsList.push({text:obj,value:idx});
		if(idx > 1)
		 return	
		widgets.push({
						tenor: ko.observable(),
						id   : 'termSheet-chart'+idx
					  });
			
	});
	// }


	termSheet.dataTab3.widgets(widgets);
	termSheet.dataTab3.tenorsList(tenorsList);

	_.each(termSheet.dataTab3.widgets(), function(o,i){
		if(tenors.length == 1){
			i = 0;
		}
 
		o.tenor(i);
		termSheet.createChart(o)
		o.tenor.subscribe(function(n){
			termSheet.createChart(o)
		})
	});



};
termSheet.createScaterChartTab4 = function(){
	var obj      	=  pbGrid.GridTemplate()[0];

	var circelData  = [{x:0,y:1},{x:1,y:2},{x:2,y:3}]
 
	var grid 		= _.first( _.reject(pbGrid.dataGridTemplateFirst(), function(o){ return pbGrid.gridTemplateFirst().invisibleIsin().indexOf(o.Isin) != -1; })  ,10);
	var circelData 	= [];
	if(termSheet.dataTab4.yAxis() == ""){
		_.each(grid,function(o){
			circelData.push({x:o.Yearsmaturity ,y:o.Value,	desc: o.Security + ' / ' + o.Moodysissuerating + " "+ o.Spissuerating + " " + o.Fitchissuerrating})
		});
	}else{
		_.each(grid,function(o){
			circelData.push({x:o.Yearsmaturity ,y:o[termSheet.dataTab4.yAxis()], desc: o.Security + ' / ' + o.Moodysissuerating + " "+ o.Spissuerating + " " + o.Fitchissuerrating})
		});
	}
	var minY 		= _.min(_.clone(circelData), function(data){
							if(!_.has(data,'y'))
								return 0;
						 	return data.y;
						}).y; 
	var minX 		= _.min(_.clone(circelData), function(data){
						if(!_.has(data,'x'))
							return 0;
					 	return data.x;
					  }).x ; 
	var series  	= [{
		type: "scatter",
		xField: "x",
		yField: "y",
		data: circelData,
		color : function(e){
			 return  "#7BBFF6";
		}, 
		markers: {
			size: function(e){
				return 10 
			}, 
			background : function(e){
				return  "#7BBFF6";
			}
		},
		labels:{
			font: ds.font('9px'),
			visible:true,
		    template:function(e){
		    	return  e.dataItem.desc;
		    }
		},

	}];	
 
	console.log( parseInt( parseInt(minY.toFixed(0)) - 50 ));
	$("#scatterChartTab4").find(".contentWidget").html("")
	$("#scatterChartTab4").find(".contentWidget").kendoChart({
		series: series,
		legend:{
			visible:false
		},
		
		xAxis: {
			min : ( ( parseInt(minX.toFixed(0)) - 1 ) < 0 ) ? 0 : parseInt(minX.toFixed(0)) - 1,
			labels: { 
			   	font: ds.font('9px'),
			    template:function(e){
			    	return e.value.toFixed(0);
			    }
   			},
          	majorGridLines:{
            	visible:false
            }, 

        },
        yAxis:{
    		min  : ( ( parseInt(minY.toFixed(0)) - 50 ) < 0 ) ? 0 :  parseInt(minY.toFixed(0)) - 50,
    		labels: { 
			   	font: ds.font('9px'),
			    template:function(e){
			    	return e.value.toFixed(0); 
			    }
   			},
        	 
        },
        tooltip 	: {
        	background:"#353D47",
            border: {
                width: 1,
                color: "#DDD"
	        },
        	visible  : false,
        	template : function(e){
        		return e.dataItem.desc;
        	}
        },
		pannable 	: true,
        zoomable 	: false,
 
	});
	// if(termSheet.dataTab4.yAxis() == "")


	// else	


}
termSheet.RenderTab4 = function(){
	if(ds.issuerSelected.product.toLowerCase() == 'ig' || ds.issuerSelected.product.toLowerCase() == 'crossover'){
		termSheet.dataTab4.yAxis('Bidzspread')
	}else{
		termSheet.dataTab4.yAxis('Bidytm')
	}
	// setTimeout(function(){ termSheet.createScaterChartTab4() }, 300);  
};
termSheet.GetBenchmark =  function(){
	var total = []
	_.each(pbGrid.tenors() , function(o,i){
		var tenor = 0;
		switch(o.value()){
			
			case"syndicate":
				tenor = pbGrid.filterTermSheet.tenor.syndicateTabel()[i].value();
			break;
			case"trending":
				tenor = pbGrid.filterTermSheet.tenor.trendingCurve()[i].value();
			break;
			default:
				tenor = pbGrid.filterTermSheet.tenor.manualInput()[i].value();
			
		}
		basis  	  =  pbGrid.filterTermSheet.tenor.basis()[0].value();
		size  	  = (pbGrid.filterTermSheet.issuenze.issueSize() > 300) ? 0 : pbGrid.filterTermSheet.issuenze.liquityPerm(); 
 		premium   = (pbGrid.filterTermSheet.premium.checked()) ? pbGrid.filterTermSheet.premium.value() : 0; 
 	    ratting   = (pbGrid.filterTermSheet.ratting.checked()) ? pbGrid.filterTermSheet.ratting.sugested():pbGrid.filterTermSheet.ratting.manualInput(); 
		total.push(parseFloat(tenor) + parseFloat(basis)  + parseFloat(size) +  parseFloat(premium) + parseFloat(ratting));
	})
	var payload = {
		Tenor : pbGrid.gridTemplateFirst().payload.Tenor,
		Product : ds.issuerSelected.product,
		Total : total,
		Flag : pbGrid.filterTermSheet.finish.value(),
		Range : pbGrid.filterTermSheet.finish.rangeValue()
	}
	ajaxPost("/dashboard/benchmark", payload, function (res){
	 	 if(res.IsError)
	 	 	return;

		var benchmarkYields = [];
		var benchmarkToSpreads = [];
		var yields = [];
		var afterSwaps = [];
		
		_.each(res.Data, function(o){
			console.log(o);

			benchmarkYields.push(o.benchmarkyield);
			
			benchmarkToSpreads.push(o.spreadbenchmark);
			
			yields.push(o.yield);
			
			afterSwaps.push(o.afterswamp);
		});

	 	termSheet.dataTab1.benchmarkYield(benchmarkYields);
		termSheet.dataTab1.benchmarkToSpread(benchmarkToSpreads);
		termSheet.dataTab1.yield(yields);	
		termSheet.dataTab1.afterSwap(afterSwaps);
		termSheet.loading(false);
	})
}
termSheet.init = function(){
	termSheet.GetBenchmark();
	return $(".termSheet-tab").find("li a#termSheetTab1").click();
	
	// termSheet.RenderTab1();
}