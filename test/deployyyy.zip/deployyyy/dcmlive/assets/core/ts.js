var termSheet = {
	ts:{
		render 				 : ko.observable(false),
		loading 			 : ko.observable(false),
		issuerName 		 	 : ko.observableArray([]),
		issuerRating 		 : ko.observableArray([]),
		instrument   		 : ko.observable(""),
		distributionFormat   : ko.observableArray([]),
		currency 			 : ko.observableArray([]),
		size 				 : ko.observableArray([]),
		tenors 				 : ko.observableArray(),
		benchmarkYield		 : ko.observableArray([]),
		benchmarkToSpread	 : ko.observableArray([]),
		yield			     : ko.observableArray([]),
		afterSwap 			 : ko.observableArray([])
	},
	bondIssuenceSpreads:{
		render 		: ko.observable(false),
		yAxis 		: ko.observable(""),
		yAxisList 	: ko.observableArray([
											{ text:'Bid YTM',value:'Bidytm' },
											{ text:'Bid Spread G',value:'Bidgspread' },
											{ text:'Bid Spread Z',value:'Bidzspread' }
										])
	},
	table:{
		dataSource: ko.observableArray([]),
		render:ko.observable(false)
	},
	relativeValueCharts:{
		render 	: ko.observable(false),
		widgets : ko.observableArray([]),
		tenorList : ko.observableArray([]),
		ds : {
			basis 	: 0,
			tenors 	: [],
			size  	: 0,
			premium : 0,
			ratting : 0,
			totals   : []
		}
	}
};
// termSheet.ts = {	
// 	render 				 : ko.observable(false),
// 	loading 			 : ko.observable(false),
// 	issuerName 		 	 : ko.observableArray([]),
// 	issuerRating 		 : ko.observableArray([]),
// 	instrument   		 : ko.observable(""),
// 	distributionFormat   : ko.observableArray([]),
// 	currency 			 : ko.observableArray([]),
// 	size 				 : ko.observableArray([]),
// 	tenors 				 : ko.observableArray(),
// 	benchmarkYield		 : ko.observableArray([]),
// 	benchmarkToSpread	 : ko.observableArray([]),
// 	yield			     : ko.observableArray([]),
// 	afterSwap 			 : ko.observableArray([])
// };
// termSheet.bondIssuenceSpreads = {	
// 	render 		: ko.observable(false),
// 	yAxis 		: ko.observable(""),
// 	yAxisList 	: ko.observableArray([
// 										{ text:'Bid YTM',value:'Bidytm' },
// 										{ text:'Bid Spread G',value:'Bidgspread' },
// 										{ text:'Bid Spread Z',value:'Bidzspread' }
// 									])
// };
termSheet.bondIssuenceSpreads.yAxis.subscribe(function(){
	termSheet.createChartScatter();
});
// termSheet.table = {	
// 	dataSource: ko.observableArray([]),
// 	render:ko.observable(false),
// };
// termSheet.relativeValueCharts = {	
// 	render 	: ko.observable(false),
// 	widgets : ko.observableArray([]),
// 	tenorList : ko.observableArray([]),
// 	ds : {
// 		basis 	: 0,
// 		tenors 	: [],
// 		size  	: 0,
// 		premium : 0,
// 		ratting : 0,
// 		totals   : []
// 	}
// };
termSheet.GetBenchmark = function(){
	var total = [];


	var payload = {
		Tenor 	: pbGrid.gridTemplateFirst().payload.Tenor,
		Product : ds.issuerSelected.product,
		Total   : termSheet.relativeValueCharts.ds.totals,
		Flag 	: createTermSheet.finish.value(),
		Range 	: createTermSheet.finish.rangeValue(),
		Typevalue : createTermSheet.bidType()
	};

	ajaxPost("/dashboard/benchmark", payload, function (res){
	 	 if(res.IsError)
	 	 	return;

		var benchmarkYields 	= [];
		var benchmarkToSpreads 	= [];
		var yields 				= [];
		var afterSwaps 			= [];
		
		_.each(res.Data, function(o){
			benchmarkYields.push(o.benchmarkyield);
			benchmarkToSpreads.push(o.spreadbenchmark);			
			yields.push(o.yield);
			afterSwaps.push(o.afterswamp);
		});

	 	termSheet.ts.benchmarkYield(benchmarkYields);
		termSheet.ts.benchmarkToSpread(benchmarkToSpreads);
		termSheet.ts.yield(yields);	
		termSheet.ts.afterSwap(afterSwaps);
		termSheet.ts.loading(false);
		termSheet.ts.render(true);
	});
};
function getWidthPercetage(len){
	return String(100/len) + "%"; 
};
termSheet.renderTs = function(){
	var config  = termSheet.ts;
	if(config.render())
		return;

	config.loading(true);
	var rowBasis = pbGrid.rowBasis();
	config.issuerRating([ds.issuerSelected.moodys_issuer_rating, ds.issuerSelected.sp_issuer_rating, ds.issuerSelected.fitch_issuer_rating]);
	config.instrument(rowBasis.Ranking);
	config.distributionFormat([{text:"Reg S",value:"Reg S"},{text:"144A",value:"144A"}]);
	config.currency(["USD"]);
	config.tenors(pbGrid.gridTemplateFirst().tenors());
	config.size([parseInt(createTermSheet.issuenze.issueSize())]);
	config.issuerName(ds.issuerSelected.issuer);
	termSheet.GetBenchmark();
};
termSheet.createChartScatter = function(){
	var dataSource 	= _.first( 
							_.reject(pbGrid.dataGridTemplateFirst(), function(o){ 
								return pbGrid.gridTemplateFirst().deleteIsin().indexOf(o.Isin) != -1; 
							})  
						,10);
	var circelData 	= [];
	_.each(dataSource,function(o){
		circelData.push({x: o.Yearsmaturity, y: o[termSheet.bondIssuenceSpreads.yAxis()], desc: o.Security + ' / ' + o.Moodysissuerating + " "+ o.Spissuerating + " " + o.Fitchissuerrating });
	});

	var minY 		= _.min(_.clone(circelData), function(data){
							if(!_.has(data,'y'))
								return 0;
						 	return data.y;
						}).y; 
	var minX 		= _.min(_.clone(circelData), function(data){
						if(!_.has(data,'x'))
							return 0;
					 	return data.x;
					 }).x;

	$("#scatterChartTab4").find(".contentWidget").html("")
	$("#scatterChartTab4").find(".contentWidget").kendoChart({
		series: [
			{
				type: "scatter",
				xField: "x",
				yField: "y",
				data: circelData,
				color : function(e){
					 return  "#7BBFF6";
				}, 
				markers: {
					size: function(e){
						return 10 
					}, 
					background : function(e){
						return  "#7BBFF6";
					}
				},
				labels:{
					font: ds.font('9px'),
					visible:true,
				    template:function(e){
				    	return  e.dataItem.desc;
				    }
				},
			}
		],
		legend:{
			visible:false
		},
		xAxis: {
			min : ( ( parseInt(minX.toFixed(0)) - 1 ) < 0 ) ? 0 : parseInt(minX.toFixed(0)) - 1,
			labels: { 
			   	font: ds.font('9px'),
			    template:function(e){
			    	return e.value.toFixed(0);
			    }
   			},
          	majorGridLines:{
            	visible:false
            }, 
        },
        yAxis:{
    		min  : ( ( parseInt(minY.toFixed(0)) - 50 ) < 0 ) ? 0 :  parseInt(minY.toFixed(0)) - 50,
    		labels: { 
			   	font: ds.font('9px'),
			    template:function(e){
			    	return e.value.toFixed(0); 
			    }
   			},
        },
        tooltip 	: {
        	background:"#353D47",
            border: {
                width: 1,
                color: "#DDD"
	        },
        	visible  : false,
        	template : function(e){
        		return e.dataItem.desc;
        	}
        },
		pannable 	: true,
        zoomable 	: false,
	});
};
termSheet.crateeChartRange =  function(obj){
 
	var allDs =  termSheet.relativeValueCharts.ds;
	// var bench = "Bench YTM";

	// if(ds.issuerSelected.product.toLowerCase() == 'ig' || ds.issuerSelected.product.toLowerCase() == 'crossover')
	// 	bench = "Bench Z";
	var bench = "Bench ";
	switch(createTermSheet.bidType()){
		case"bid_ytm":
			bench += "YTM";
		break;
		case"bid_z_spread":
			bench += "Z";
		break;
		case"bid_g_spread":
			bench += "G";
		break;
		 
	}
 	var listCategory = [bench, "TD", "LP", "NIC", "RD"];
	var datas  = [allDs.basis, 
				 allDs.tenors[obj.tenor()], 
				 allDs.size, 
				 allDs.premium, 
				 allDs.ratting];

	var seriesDs     = [];
	var categories = [];
	var counter    = 0;
 	_.each(datas, function(o , i){
 		if(parseFloat(o) == 0)
 			return; 
 		seriesDs.push([parseFloat(counter), parseFloat(counter) + parseFloat(o)]);
 		categories.push(listCategory[i]);
 		counter += parseFloat(o);
	});

	seriesDs.push( [ 0, parseFloat(allDs.totals[obj.tenor() ]) ] );
	categories.push('Total');

	var maxAxis = _.max( _.flatten(seriesDs) );
	var minAxis = _.min( _.flatten(seriesDs) );

	$("#"+obj.id).find(".contentWidget").html()
	$("#"+obj.id).find(".contentWidget").kendoChart({
	    series: [{ 
	    	gap : 1.6,
	        type: "rangeColumn",
	        colorField :'color',
	        field:'value',
	        data: seriesDs,
		    color: function(e){
		    	console.log(e.category);
		    	switch(e.category){
		    		case"TD":
		    		case"Bench Z":
		    		case"Bench G":
		    		case"Bench YTM":
		    			return "#1E88E5";
		    		break;
		    		case"LP":
						return "#57ACF3";
		    		break;
		    		case"NIP":
		    		case"NIC":
		    		case"RD":
		    			return "#65B7F5";
		    		break;
		    		default:
		    			return "#60D5A8";
		    	}
		    }, 
	    }],
	    seriesDefaults: {
	    	overlay: {
				gradient: "none"
			},
	        labels: {
	            visible: false, 
	        }
	    },
	    categoryAxis: {
	        categories: categories,
	        labels: {
	            rotation: "auto",
	            font: ds.font('9px'),
	        },
	        majorGridLines: {
				visible: false
			},
			line:{
				visible: true
			}
	    },
	    valueAxis: {
	    	max   : maxAxis * 1.1,
	    	min   : minAxis,
			labels: {
				color: "#4c5356",
				font: ds.font('9px'),
				visible: true,
			},
			line: {
				visible: false
			},
			majorGridLines: {
				visible: false
	        },
        },
	   
	        
        tooltip: {
            visible: true,
            template : function(e){
                return kendo.toString((e.dataItem[1] - e.dataItem[0]),'n0');
            }

        }
	    
	});
};
termSheet.renderBondIssuenceSpreads = function(){	
	var config = termSheet.bondIssuenceSpreads;
	if(config.render())
		return;

	$("#scatterChartTab4").find(".contentWidget").html("");
	config.yAxis(createTermSheet.bidProp().key);
	setTimeout(function(){
		termSheet.createChartScatter();
		config.render(true)
	},300);

};
termSheet.renderTable = function(){	
	var config  = termSheet.table;
	if(config.render())
		return;
	config.dataSource(pbGrid.dataGridTemplateFirst());
	config.render(true);
};
termSheet.createDsRelativeValueCharts = function(){
 
	var ds = termSheet.relativeValueCharts.ds;
	ds.basis 	 = pbGrid.rowBasis()[createTermSheet.bidProp().key];
 	ds.size  	 = ( createTermSheet.issuenze.issueSize() > 300) ? 0 : createTermSheet.issuenze.liquityPerm(); 
 	ds.premium   = ( createTermSheet.premium.checked() ) ? createTermSheet.premium.value() : 0; 
 	ds.ratting   = ( createTermSheet.sameIssuer() ) ? 0 : (createTermSheet.ratting.checked()) ? createTermSheet.ratting.sugested() : createTermSheet.ratting.manualInput(); 
	
	var tenors 	 = [];
	var totals 	 = [];
	_.each(createTermSheet.tenor.checkeds(), function(o,i){
		switch(o()){
			case"syndicate":
				tenors.push(createTermSheet.tenor.syndicateTabel()[i].value())
			break;
			case"trending":
				tenors.push(createTermSheet.tenor.trendingCurve()[i].value());
			break;
			default:
				tenors.push(createTermSheet.tenor.manualInput()[i].value());
		};
		totals.push( parseFloat(
							parseFloat(ds.basis) +
							parseFloat(tenors[i]) + 
							parseFloat(ds.size) + 
							parseFloat(ds.premium) + 
							parseFloat(ds.ratting)
					) );
	});
	ds.tenors 	 = tenors;
	ds.totals 	 = totals;
};
termSheet.renderRelativeValueCharts = function(){
	var config  = termSheet.relativeValueCharts;
	if(config.render())
		return;

	termSheet.createDsRelativeValueCharts();
	var tenorsList 	= [];
	var widgets 	= [];
	_.each(pbGrid.gridTemplateFirst().tenors(), function(obj,idx){
		tenorsList.push({text:obj,value:idx});
		if(idx > 1)
		 return	
		widgets.push({
						tenor: ko.observable(),
						id   : 'termSheet-chart'+idx
					});
			
	});
	config.widgets(widgets);
	config.tenorList(tenorsList);
	_.each(config.widgets(), function(o,i){
		o.tenor(i);
		setTimeout(function(){ termSheet.crateeChartRange(o) },300);
		o.tenor.subscribe(function(n){
			termSheet.crateeChartRange(o)
		})
	});

	config.render(true);
};
termSheet.orderedDataGrid = function(){
	// var obj 	= pbGrid.gridTemplateFirst();
	// var data  	= [];

	// _.each(obj.orderIsin(), function(o){ 
	// 	var d = _.where(obj.resData(),  {Isin: o})[0];
	//  		data.push(d);
	// });
	// obj.resData(data);
};
termSheet.init = function(){
	termSheet.ts.render(false);
	termSheet.bondIssuenceSpreads.render(false);
	termSheet.table.render(false);
	termSheet.relativeValueCharts.render(false);
	termSheet.orderedDataGrid();
	termSheet.createDsRelativeValueCharts();
	
	return $(".termSheet-tab").find("li a#termSheetTab1").click();
};

