var wa_reviseQryChart = {
	leftFilter:
	[{
		id:"Ratingtype",
		title:"Ratingtype", 
	},{
		id: "Ratingaction",
		title: "Ratingaction", 
	
	},{
		id:"Ratingvalue",
		title:"Ratingvalue", 
	},
	{
		id:"Ownership",
		title:"Ownership"
	},{
		id:"Ranking",
		title:"Ranking"
	}],
};
wa_reviseQryChart.RenderGrid = function(payload, $selector){
	var $selector = $selector.find(".wa_reviseQryChart #grid");
	payload.Flag = 'point_sp';
	var url = "/widgetanalysis/widgetsyndicate";
	payload.Ratingvalue = payload.Ratingvalue == "" ? 99.0 : payload.Ratingvalue; 

	$selector.html("");
	$selector.kendoGrid({
		dataSource: {
			transport: {
				read:function(option){
					payload.skip = option.data.skip;
					payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : '';
					payload.take = option.data.take;
                    ajaxPost(url, payload, function(res){
                        option.success({ Records: res.Data, Count: res.Total });
                    })
                },
			},
			schema: {
				data: function(data) {
                    return data.Records;
				},
				total: "Count",
			},
			pageSize: 17,
			serverPaging: true,
			serverSorting: true,
		},
		sortable: true,
		pageable: {
              numeric: true,
              previousNext: true,
              messages: {
                  display: "Showing {2} data items"
              }
        },
		columns: [
			{
				title: "Product",
				field: "Product",
			 	attributes: {
	                "class": "align-left"
                },
                headerAttributes: {
					"class": "align-left"
                },
			},
			{
				title: "Industry",
				field: "Industry",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Country",
				field: "Country",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Bucket",
				field: "Bucket",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Years To Maturity",
				field: "Yearsmaturity",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
				template: "#= kendo.toString(Yearsmaturity,'N2') #"
			},
			{
				title: "Value",
				field: "Value",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
				template: "#= kendo.toString(Value,'N2') #"
			},
			{
				title: "3",
				field: "Three",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
				template: "#= kendo.toString(Three,'N2') #"
			},
			{
				title: "5",
				field: "Five",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
				template: "#= kendo.toString(Five,'N2') #"
			},
			{
				title: "7",
				field: "Seven",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
				template: "#= kendo.toString(Seven,'N2') #"
			},
			{
				title: "10",
				field: "Ten",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
				template: "#= kendo.toString(Ten,'N2') #"
			}
		]
	});
};
wa_reviseQryChart.reloadFilter = function(){
	var template = wa.getActivePage();
	template.mainPage.mode('preview');
  	template.mainPage.type('wa_reviseQryChart');
	_.each(wa_reviseQryChart.leftFilter, function(v){ 
		 
		if(v == 'Ratingaction'){
			return 
		}
		var payload = wa.getPayload();
		payload['Flag'] = v.id;
		getFilter("/widgetanalysis/getfilterwidget",payload , template.filter[v.id].data);
	});
	// template.valueHasMutated();
};
wa_reviseQryChart.init = function(){
	wa_reviseQryChart.reloadFilter();
	var $selector = wa.$getSelectorPage();
	var payload = wa.getPayload();
	wa_reviseQryChart.RenderGrid(payload, $selector);
};