var creditprofilev2 	= {};
creditprofilev2.loading = ko.observable(false)
creditprofilev2.maturityList = ko.observableArray([
											{value:"",text:"Maturity Profile for all Debt"},
											{value:"LOANBOND",text:"Maturity by Loans and Bonds"},
										])
creditprofilev2.maturity = ko.observable('');
creditprofilev2.title = ko.observable('');
creditprofilev2.lastPanel = ko.observable(true);

creditprofilev2.grid = function(){
}
creditprofilev2.currencyChart = function(){
	$("#chart1").kendoChart({
        chartArea: {
            height:280,
            width:310
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Currency",
            data: [6977, 4154, 2439, 384]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "CNY", "USD", "HKD"],
            majorGridLines: {
                visible: false
            },
            line:{
                visible:false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
}
creditprofilev2.fixedFloatingChart = function(){
	$("#chart2").kendoChart({
        chartArea: {
			height:280,
			width:310
		},
		legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.8,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Fixed Vs Floating",
            data: [6976, 4346, 2630]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "Floating", "Fixed"],
            majorGridLines: {
                visible: false
            },
			labels: {
				font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        	},
            line:{
                visible:false
            }
        },
        tooltip: {
            visible: true,
          	font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
}
creditprofilev2.loadBondsChart = function(){
	$("#chart3").kendoChart({
        chartArea: {
			height:280,
			width:310
		},
		legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.8,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Loan Vs Bonds",
            data: [6976, 4413, 2563]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "Loan", "Bonds"],
            majorGridLines: {
                visible: false
            },
			labels: {
				font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        	},
            line:{
                visible:false
            }
        },
        tooltip: {
            visible: true,
          	font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
}
creditprofilev2.maturityChart = function(val){
	if (val == '' || val == undefined) {
		$("#chart4").kendoChart({
	        chartArea: {
				height:280,
				width:470
			},
			legend: {
	            visible: false
	        },
	        seriesDefaults: {
	            type: "bar",
	            overlay: {
	              gradient: "none"
	            },
                gap: 0.5,
	            labels: {
	                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
	                color: "#002951",
	                visible: true,
	                position:"outsideEnd",
	            },
	            color: "#005C84",
	        },
	        series: [{
	            name: "Maturity",
	            data: [2929, 1844, 1519, 684]
	        }],
	        valueAxis: {
	            majorGridLines: {
	                visible: false
	            },
	            minorGridLines: {
	                visible: false
	            },
	            labels:{
                    visible:false,
                },
                line:{
                    visible:false
                }
	        },
	        categoryAxis: {
	            categories: [">2Y, <5Y", "<1Y", ">1Y, <2Y", ">5Y"],
	            majorGridLines: {
	                visible: false
	            },
				labels: {
					font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
	        	},
                line:{
                    visible:false
                }
	        },
	        tooltip: {
            visible: true,
          	font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
	        }
	    });
	}else{
		$("#chart4").kendoChart({
	        chartArea: {
				height:280,
				width:470
			},
			legend: {
	            visible: true,
                position: 'bottom',
	        },
	        seriesDefaults: {
                type: "bar",
                stack: true,
                overlay: {
                    gradient: "none"
                },
                gap: 0.5,
                labels: {
                    font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                    color: "#fff",
                    visible: true,
                    position:"center",
                    background: "transparent",
                },
            },
	        series: [{
                    name: "Loans",
                    data: [1908, 952, 869, 684],
                    color: "#005C84"
                }, {
                    name: "Bonds",
                    data: [1021, 892, 650, 0],
                    color: "#50d0ff"
                }],
	        valueAxis: {
	            majorGridLines: {
	                visible: false
	            },
	            minorGridLines: {
	                visible: false
	            },
	            labels:{
                    visible:false,
                },
                line:{
                    visible:false
                }
	        },
	        categoryAxis: {
	            categories: [">2Y, <5Y", "<1Y", ">1Y, <2Y", ">5Y"],
	            majorGridLines: {
	                visible: false
	            },
				labels: {
					font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
	        	},
                line:{
                    visible:false
                }
	        },
	        tooltip: {
	            visible: true,
	          	font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
	            template: "#= series.name #: #= value #"
	        }
	    });
	};
}
creditprofilev2.revenueEbitdaChart = function(){
	$("#chart5").kendoChart({
        chartArea: {
			height:280,
			width:470
		},
		legend: {
            visible: false
        },
        seriesDefaults: {
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
        },
        series: [{
            type: "column",
            data: [2606, 1517, 958],
            stack: true,
            name: "Revenue",
            color: "#005C84",
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                background: "transparent",
                visible: true,
            },
        }, {
            type: "line",
            data: [27.55, 24.46, 15.24],
            name: "EBITDA Margin",
            color: "#002951",
            axis: "ebitda"
        }],
        valueAxes: [{
          	name: "revenue",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                step: 2,
                color: "#000"
            },
          	majorGridLines: {
				visible: false
			},
        }, {
            name: "ebitda",
            color: "#f1f1f1",
          	visible: true,
          	labels: {
        		font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                position:"insideEnd",
             	step: 2,
                color: "#000"
    		},
          	majorGridLines: {
				visible: false
			},
        }],
        categoryAxis: {
            color: "#f1f1f1",
           	categories: ["FY2016A", "FY2014A", "FY2015A"],
          	labels: {
        		font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#000"
    		},                  
          	majorGridLines: {
				visible: false
			},
            axisCrossingValue: [0, 3]
        },
        tooltip: {
            visible: true,
          	font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
}

creditprofilev2.expandedWidget = function(title){
    if (title == 'currency'){
        creditprofilev2.title('Currency')
        creditprofilev2.modalCurrencyChart()
        creditprofilev2.lastPanel(true)
    }else if (title == 'fixedfloating'){
        creditprofilev2.title('Fixed & Floating')
        creditprofilev2.modalFixedFloatingChart()
        creditprofilev2.lastPanel(false)
    }else if (title == 'loandbonds'){
        creditprofilev2.title('Loan & Bonds')
        creditprofilev2.modalLoadBondsChart()
        creditprofilev2.lastPanel(true)
    }else if (title == 'maturity'){
        console.log(creditprofilev2.maturity())
        if(creditprofilev2.maturity() == 'LOANBOND'){
            creditprofilev2.title('Maturity by Loans and Bonds')
            creditprofilev2.modalMaturityChart()
        creditprofilev2.lastPanel(true)
        }else{
            creditprofilev2.title('Maturity Profile for all Debt')
            creditprofilev2.modalMaturityChart()
        creditprofilev2.lastPanel(true)
        }
    }else if (title == 'revenueebitda'){
        creditprofilev2.title('Revenue & EBITDA')
        creditprofilev2.modalRevenueEbitdaChart()
        creditprofilev2.lastPanel(true)
    }else{
    }
    $('#expandmodal').modal('show')
}

creditprofilev2.modalCurrencyChart = function(){
    $("#chart6-1").kendoChart({
        chartArea: {
            height:220,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Currency",
            data: [2287, 1235, 961, 91]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "USD", "CNY", "HKD"],
            majorGridLines: {
                visible: false
            },
            line:{
                visible:false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-2").kendoChart({
        chartArea: {
            height:220,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Currency",
            data: [5425, 5223, 134, 69]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "CNY", "USD", "HKD"],
            majorGridLines: {
                visible: false
            },
            line:{
                visible:false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-3").kendoChart({
        chartArea: {
            height:220,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Currency",
            data: [20163, 13711, 5444, 605, 504]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "CNY", "USD", "HKD", "Other"],
            majorGridLines: {
                visible: false
            },
            line:{
                visible:false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-4").kendoChart({
        chartArea: {
            height:220,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Currency",
            data: [4351, 2437, 1500, 415]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "CNY", "USD", "HKD"],
            majorGridLines: {
                visible: false
            },
            line:{
                visible:false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-5").kendoChart({
        chartArea: {
            height:220,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Currency",
            data: [6977, 4154, 2439, 384]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "CNY", "USD", "HKD"],
            majorGridLines: {
                visible: false
            },
            line:{
                visible:false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    }); //secured unsecured
    $("#chart6-6").kendoChart({
        chartArea: {
            height:220,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Currency",
            data: [6513, 3624, 1731, 1070, 88]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "CNY", "USD", "HKD", "MYR"],
            majorGridLines: {
                visible: false
            },
            line:{
                visible:false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
}
creditprofilev2.modalFixedFloatingChart = function(){
    $("#chart6-1").kendoChart({
        chartArea: {
            height:220,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.8,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Fixed Vs Floating",
            data: [2287, 1346, 941]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "Fixed", "Floating"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-2").kendoChart({
        chartArea: {
            height:220,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.8,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Fixed Vs Floating",
            data: [5425, 2728, 2697]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "Fixed", "Floating"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-3").kendoChart({
        chartArea: {
            height:220,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.8,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Fixed Vs Floating",
            data: [20163, 10248, 9915]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "Floating", "Fixed"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-4").kendoChart({
        chartArea: {
            height:220,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.8,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Fixed Vs Floating",
            data: [4351, 2621, 1730]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "Fixed", "Floating"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-5").kendoChart({
        chartArea: {
            height:220,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.8,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Fixed Vs Floating",
            data: [4004, 3257, 747]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "Floating", "Fixed"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    //no fixed floating for chart6-6
}
creditprofilev2.modalLoadBondsChart = function(){
    $("#chart6-1").kendoChart({
        chartArea: {
            height:220,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.8,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Loan Vs Bonds",
            data: [2287, 1158, 1129]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "Bonds", "Loan"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-2").kendoChart({
        chartArea: {
            height:220,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.8,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Loan Vs Bonds",
            data: [5425, 2801, 2624]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "Bonds", "Loan"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-3").kendoChart({
        chartArea: {
            height:220,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.8,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Loan Vs Bonds",
            data: [20163, 10248, 9915]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "Loan", "Bonds"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-4").kendoChart({
        chartArea: {
            height:220,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.8,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Loan Vs Bonds",
            data: [4351, 2343, 2008]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "Bonds", "Loan"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-5").kendoChart({
        chartArea: {
            height:220,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.8,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Loan Vs Bonds",
            data: [4004, 3257, 747]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "Loan", "Bonds"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-6").kendoChart({
        chartArea: {
            height:220,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.8,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Loan Vs Bonds",
            data: [6513, 3436, 3077]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "Bonds", "Loan"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
}
creditprofilev2.modalMaturityChart = function(){
    $("#chart6-1").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Maturity",
            data: [2287, 1272, 775, 204, 36]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", ">2Y, <5Y", "<1Y", ">1Y, <2Y", ">5Y"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
        visible: true,
        font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        template: "#= value #"
        }
    });
    $("#chart6-2").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Maturity",
            data: [5425, 2497, 1202, 884, 842]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", ">2Y, <5Y", "<1Y", ">5Y", ">1Y, <2Y"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
        visible: true,
        font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        template: "#= value #"
        }
    });
    $("#chart6-3").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Maturity",
            data: [20163, 8950, 5732, 5108, 372]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", ">2Y, <5Y", "<1Y", ">1Y, <2Y", ">5Y"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
        visible: true,
        font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        template: "#= value #"
        }
    });
    $("#chart6-4").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Maturity",
            data: [4351, 2927, 660, 634, 131]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", ">2Y, <5Y", "<1Y", ">1Y, <2Y", ">5Y"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
        visible: true,
        font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        template: "#= value #"
        }
    });
    $("#chart6-5").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Maturity",
            data: [4004, 3257, 946, 454, 0]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", ">5Y", "<1Y", ">2Y, <5Y", ">1Y, <2Y"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
        visible: true,
        font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        template: "#= value #"
        }
    });
    $("#chart6-6").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Maturity",
            data: [6513, 2312, 1897, 1609, 695]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", ">2Y, <5Y", "<1Y", ">1Y, <2Y", ">5Y"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
        visible: true,
        font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        template: "#= value #"
        }
    });
}
creditprofilev2.modalRevenueEbitdaChart = function(){
    $("#chart6-1").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
        },
        series: [{
            type: "column",
            data: [2606, 2170],
            stack: true,
            name: "Revenue",
            color: "#005C84",
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                background: "transparent",
                visible: true,
            },
        }, {
            type: "line",
            data: [27.6, 21.5],
            name: "EBITDA Margin",
            color: "#002951",
            axis: "ebitda"
        }],
        valueAxes: [{
            name: "revenue",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }, {
            name: "ebitda",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                position:"insideEnd",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }],
        categoryAxis: {
            color: "#f1f1f1",
            categories: ["Dec-16", "Dec-16"],
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#000"
            },                  
            majorGridLines: {
                visible: false
            },
            axisCrossingValue: [0, 3]
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-2").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
        },
        series: [{
            type: "column",
            data: [2606, 4331],
            stack: true,
            name: "Revenue",
            color: "#005C84",
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                background: "transparent",
                visible: true,
            },
        }, {
            type: "line",
            data: [27.6, 33.5],
            name: "EBITDA Margin",
            color: "#002951",
            axis: "ebitda"
        }],
        valueAxes: [{
            name: "revenue",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }, {
            name: "ebitda",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                position:"insideEnd",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }],
        categoryAxis: {
            color: "#f1f1f1",
            categories: ["Dec-16", "Mar-17"],
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#000"
            },                  
            majorGridLines: {
                visible: false
            },
            axisCrossingValue: [0, 3]
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-3").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
        },
        series: [{
            type: "column",
            data: [2606, 3347],
            stack: true,
            name: "Revenue",
            color: "#005C84",
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                background: "transparent",
                visible: true,
            },
        }, {
            type: "line",
            data: [27.6, 20.1],
            name: "EBITDA Margin",
            color: "#002951",
            axis: "ebitda"
        }],
        valueAxes: [{
            name: "revenue",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }, {
            name: "ebitda",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                position:"insideEnd",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }],
        categoryAxis: {
            color: "#f1f1f1",
            categories: ["Dec-16", "Dec-16"],
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#000"
            },                  
            majorGridLines: {
                visible: false
            },
            axisCrossingValue: [0, 3]
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-4").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
        },
        series: [{
            type: "column",
            data: [2606, 23053],
            stack: true,
            name: "Revenue",
            color: "#005C84",
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                background: "transparent",
                visible: true,
            },
        }, {
            type: "line",
            data: [27.6, 15.0],
            name: "EBITDA Margin",
            color: "#002951",
            axis: "ebitda"
        }],
        valueAxes: [{
            name: "revenue",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }, {
            name: "ebitda",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                position:"insideEnd",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }],
        categoryAxis: {
            color: "#f1f1f1",
            categories: ["Dec-16", "Dec-16"],
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#000"
            },                  
            majorGridLines: {
                visible: false
            },
            axisCrossingValue: [0, 3]
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-5").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
        },
        series: [{
            type: "column",
            data: [2606, 7385],
            stack: true,
            name: "Revenue",
            color: "#005C84",
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                background: "transparent",
                visible: true,
            },
        }, {
            type: "line",
            data: [27.6, 18.00],
            name: "EBITDA Margin",
            color: "#002951",
            axis: "ebitda"
        }],
        valueAxes: [{
            name: "revenue",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }, {
            name: "ebitda",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                position:"insideEnd",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }],
        categoryAxis: {
            color: "#f1f1f1",
            categories: ["Dec-16", "Mar-17"],
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#000"
            },                  
            majorGridLines: {
                visible: false
            },
            axisCrossingValue: [0, 3]
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-6").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
        },
        series: [{
            type: "column",
            data: [2606, 7029],
            stack: true,
            name: "Revenue",
            color: "#005C84",
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                background: "transparent",
                visible: true,
            },
        }, {
            type: "line",
            data: [27.55, 19.3],
            name: "EBITDA Margin",
            color: "#002951",
            axis: "ebitda"
        }],
        valueAxes: [{
            name: "revenue",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }, {
            name: "ebitda",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                position:"insideEnd",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }],
        categoryAxis: {
            color: "#f1f1f1",
            categories: ["Dec-16", "Dec-16"],
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#000"
            },                  
            majorGridLines: {
                visible: false
            },
            axisCrossingValue: [0, 3]
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
}

creditprofilev2.maturity.subscribe(function(newValue){
	creditprofilev2.maturityChart(newValue)
})

creditprofilev2.init =  function(){
	creditprofilev2.grid()
	creditprofilev2.currencyChart()
	creditprofilev2.fixedFloatingChart()
	creditprofilev2.loadBondsChart()
	creditprofilev2.maturityChart()
	creditprofilev2.revenueEbitdaChart()
};