var wa_DSChart = {
  f:{
    defaultTypes: ['Contains', 'Equals'],
    data:ko.observableArray([]),
    val: {
      type:ko.observable("Contains"),
      searchText:ko.observable(""),
      searchMulti:ko.observableArray([]),
    }
  }
};

wa_DSChart.config = {
  loading: ko.observable(true),
}

wa_DSChart.createDonut = function($selector, title, dataSource) {

  var series = _.map(dataSource, function(o, i) {

    return {
      category: i.substr(0,i.indexOf("_")).toUpperCase(),
      value: o,
      color: ecisColors[i]
    }
  })
  $selector.kendoChart({
    legend: {
      visible: true,
      position: "bottom",
    },
    seriesDefaults: {
        type: "donut",
    },
    series: [{
      overlay: { gradient: "none"},
      name: title,
      data: series
    }],
    tooltip: {
      visible: true,
      template: "#= category # : #= value #%",
    }
  })
}

wa_DSChart.createGrid = function($selector, url, payload) {
  $selector.kendoGrid({
    dataSource: {
      transport: {
        read: function(option) {
          payload.skip = option.data.skip;
          payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : '';
          payload.take = option.data.take
          ajaxPost(url, payload, function(res) {
            option.success({ Records: res.Data, Count: res.Total });
          })
        }
      },
      schema: {
        data: function(d) {
          return d.Records
        },
				total: "Count"
      },
      serverPaging: true,
      serverFiltering: true,
      serverSorting: true,
      pageSize: 10,
    },
    scrollable: true,
    sortable: true,
    filterable: {
      extra:false,
      operators: {
        string: {
          contains: "Contains",
          startswith: "Starts with",
          eq: "Is equal to",
          neq: "Is not equal to",
          doesnotcontain: "Does not contain",
          endswith: "Ends with"
        },
      }
    },
    pageable: {
      number: true,
      previousNext: true,
      messages: {
          display: "Showing {2} data items"
      }
    },
    columns: [
      {field: "country", title: "Country"},
      {field: "currency", title: "Currency"},
      {field: "industry", title: "Industry"},
      {field: "issue_date", title: "Issue Date"},
      {field: "issuer", title: "Issuer"},
      {field: "ownership", title: "Ownership"},
      {field: "ranking", title: "Ranking"},
      {field: "rating_type", title: "Rating Type"},
      {field: "size", title: "Size"},
    ]
  });
}

wa_DSChart.generateDonutDataViz = function($selector, payload) {
  payload["Flag"] = "Geography";
  ajaxPost("/widgetanalysis/getdonutdistributionstatistic", payload, function(res) {
    wa_DSChart.config.loading(false);
    wa_DSChart.createDonut($selector.find("#wa-ds-donut-1"), "Industry", res.Data[0]);
  })
  payload["Flag"] = "InvestorType";
  ajaxPost("/widgetanalysis/getdonutdistributionstatistic", payload, function(res) {
    wa_DSChart.config.loading(false);
    wa_DSChart.createDonut($selector.find("#wa-ds-donut-2"), "Ranking", res.Data[0]);
  })
  wa_DSChart.createGrid($selector.find("#wa-ds-grid"), "/widgetanalysis/getgridinvestor", payload);
}

wa_DSChart.generateDataViz = function() {
  var template = wa.getActivePage();
  template.mainPage.mode('preview');
  template.mainPage.type('wa_DSChart');

  var payload = wa.getPayload();

  wa.config.caption("Page of Investors");
  var $selector = wa.$getSelectorPage();
  wa_DSChart.generateDonutDataViz($selector, payload);
}

wa_DSChart.init =  function(){
  wa_DSChart.generateDataViz();
};
