function getFilter(url, payload, observerData) {
  ajaxPost(url, payload, function(res) {
    var resData = _.map(res, function(d) {
      return d._id
    });
    observerData(resData);

  })
}

var wa = {};
var defaultCaption = 'Charts add your own summary charts by selecting the bellow "+" sign and selecting the chart type.';
// ['preview', 'export']
wa.mode           = ko.observable("preview");
wa.config         = {
                      dataViz: ["wa_IChart"],
                      caption: ko.observable(defaultCaption),
                      modal: {
                        state: ko.observable(""),
                        investor: {
                          defaultTypes: ['Contains', 'Equals'],
                          type: ko.observable("Contains"),
                          searchText: ko.observable(""),
                          searchMulti: ko.observableArray([]),
                          data: ko.observableArray([]),
                        },
                        distributions: {
                          defaultTypes: ['Contains', 'Equals'],
                          investorsList: ko.observableArray([]),
                          investorsVal: ko.observableArray([]),
                          investedType: ko.observable("Equals"),
                          investedList: ko.observableArray([]),
                          investedMulti: ko.observableArray([]),
                          investedText: ko.observable(""),
                        },
                        commonuninvestor: {
                          commonInvestorsList: ko.observableArray([]),
                          commonInvestorsVal: ko.observableArray([]),
                          commonInvestedList: ko.observableArray([]),
                          commonInvestedVal: ko.observableArray([]),
                        },
                        commonInvestor: {
                          investorsList: ko.observableArray([]),
                          investorsVal: ko.observable(""),
                        }
                      },
                      template: {
                        data: ko.observableArray([]),
                        value: ko.observable(""),
                        inputVal: ko.observable(""),
                      },
                      realoadProcess : ko.observable(true)
                    }
wa.template       = ko.observableArray([]);
wa.page           = {
                      active: ko.observable(0),
                      total: ko.observable(0),
                      data: ko.observableArray([])
                    };
wa.filterDefault  = [
                      {id: 'Issuer', title: 'Issuer Name'},
                      {id: 'Parentcompanyname', title: 'Parent Company Name'},
                      {id: 'Continent', title: 'Continent'},
                      {id: 'Region', title: 'Region'},
                      {id: 'Country', title: 'Country'},
                      {id: 'Superindustry', title: 'Industry'},
                      {id: 'Ownership', title: 'Ownership'},
                      {id: 'Currency', title: 'Currency'},
                      {id: 'Ranking', title: 'Ranking'},
                      {id: 'Product', title: 'Product'}
                    ];

wa.config.template.value.subscribe(function(newValue) {
  console.log("from subscribe :"+newValue);
  if(newValue == '') {
    wa.formatTemplate();
  } else {
    wa.loadTemplate(newValue);
  }
})

wa.getSelectorPage = function(page) {
  if(page) {
    return "#page-"+(page+1)
  } else {
    return "#page-"+wa.page.active()
  }
};

wa.$getSelectorPage = function(page) {
  if(page) {
    return $("#page-"+(page+1));
  } else {
    return $("#page-"+wa.page.active());
  }
}

wa.getActivePage = function() {
  return wa.template()[wa.page.active() - 1];
}

wa.getPage = function(page) {
  return wa.template()[page];
}
wa.getFilterTemplate = function() {
  return {
    "Issuer": {
      id    : 'issuer',
      data  : ko.observableArray([{_id: 'Issuer'}]),
      value : ko.observableArray([]),
      loading : false,
      visible : true
    },
    "Parentcompanyname": {
      id      : 'parent_company_name',
      data    : ko.observableArray(['Parent Company Name']),
      value   : ko.observableArray([]),
      loading : false,
      visible : true,
    },
    "Continent": {
      id      : 'continent',
      data    : ko.observableArray(['Continent']),
      value   : ko.observableArray([]),
      loading : false,
      visible : true
    },
    "Region": {
      id      : 'region',
      data    : ko.observableArray(['Region']),
      value   : ko.observableArray([]),
      loading : false,
      visible : true,
    },
    "Country": {
      id      : 'country',
      data    : ko.observableArray(['Country']),
      value   : ko.observableArray([]),
      loading : false,
      visible : true,
    },
    "Superindustry": {
      id      : 'super_industry',
      data    : ko.observableArray(['Super Industry']),
      value   : ko.observableArray([]),
      loading : false,
      visible : true,
    },
    "Industry": {
      id      : 'industry',
      data    : ko.observableArray(['Industry']),
      value   : ko.observableArray([]),
      loading : false,
      visible : true,
    },
    "Ownership": {
      id      : 'ownership',
      data    : ko.observableArray(['Ownership']),
      value   : ko.observableArray([]),
      loading : false,
      visible : true,
    },
    "Currency": {
      id      : 'currency',
      data    : ko.observableArray(['Currency' ]),
      value   : ko.observableArray([]),
      loading : false,
      visible : true,
    },
    "Ranking": {
      id      : 'ranking',
      data    : ko.observableArray(['Ranking' ]),
      value   : ko.observableArray([]),
      loading : false,
      visible : true,
    },
    "Product": {
      id      : 'product',
      data    : ko.observableArray(['Product' ]),
      value   : ko.observableArray([]),
      loading : false,
      visible : true,
    },
    "Ratingtype": {
      id      : 'Ratingtype',
      data    : ko.observableArray([]),
      value   : ko.observable(""),
      loading : false,
      visible : true,
    },
    "Ratingaction": {
      id      : 'Ratingaction',
     
      data    : ko.observableArray([{text:"==",value:"$qe"},{text:">",value:"$gte"},{text:"<",value:"$lt"},{text:"<=",value:"$lte"}]),
      value   : ko.observable(''), 
      loading : false,
      visible : true,
    },
    "Ratingvalue": {
      id      : 'Ratingvaluezz',
     
     
      data    : ko.observableArray(['ranking' ]),
      value   : ko.observable(''),  
      loading : false,
      visible : true,
    },
  }
}
wa.closeChart = function(){
  
}
wa.getPayload =  function(){
  var template = wa.getActivePage();
  var filter = template.filter;
  return  wa.GeneratePayload(filter);
}

wa.GetTemplate = function() {
  ajaxPost("/widgetanalysis/getwidgetanalysis", {}, function(res) {
    var data = _.map(res.Data, function(o) {
      return o._id;
    });
    wa.config.template.data(data);
  });
}

wa.SetupTemplate = function(data) {
  var template = data.details;
  var newTemplate = [];
  var newPageData = [];
  _.each(template, function(d, i) {
    newPageData.push(i+1);
    var newFilter = wa.getFilterTemplate();
    var filterKeys = Object.keys(newFilter);
    _.each(d.filter, function(obj) {
      if(newFilter[obj.id]) {
        newFilter[obj.id].value(obj.value);
      } else {
        newFilter[obj.id] = {
          value: obj.value
        }
      }

    })
    // _.each(filterKeys, function(key,idx) {
    //   if(d.filter[idx].value.length > 0) {
    //     newFilter[key].value(d.filter[idx].value);
    //     newFilter[key].data(d.filter[idx].value);
    //   }
    // })
    var mainPage = {
      type: ko.observable(d.mainPage.type),
      mode: ko.observable(d.mainPage.mode),
    }
    newTemplate.push({
      filter: newFilter,
      mainPage: mainPage
    });
  });
  wa.template(newTemplate);
  wa.page.active(1);
  wa.page.total(template.length);
  wa.page.data(newPageData);
  var _template = wa.template();
  _.each(_template, function(d, i) {
    wa.reloadPage(d.filter, i);
  })
}

wa.loadTemplate = function(val) {
  ajaxPost('/widgetanalysis/getdetailswidgetanalysis',{
    id: val,
  }, function(res) {
    wa.SetupTemplate(res.Data);
  })
}

wa.formatTemplate = function() {
  wa.page.active(0);
  wa.page.total(0);
  wa.page.data([]);
  wa.template([]);
  wa.createPage();
}

wa.saveTemplate = function() {
  var input = wa.config.template.inputVal();
  if(input == "") {
    return swal("", "Please insert a template name", "warning");
  }
  var newTemplate = [];
  var template = wa.template();

  _.each(template, function(o) {
    var filter = _.map(o.filter, function(filter, i) {
      return {
        id: i,
        value: filter.value()
      }
    });
    var ownFilter = window[o.mainPage.type()].f;
    if(typeof ownFilter != 'undefined') {
      _.each(ownFilter.val, function(o, x) {
        filter.push({
          id: x,
          value: typeof o == "function" ? o() : o,
        })
      })
    }
    console.log(filter);
    newTemplate.push({
      filter: filter,
      mainPage: {
        type: o.mainPage.type(),
        mode: o.mainPage.mode(),
      }
    })
  })

  var payload = {TemplateName: input, details: newTemplate};
  ajaxPost("/widgetanalysis/savewidgetanalysis", payload, function(res) {
    console.log(res);
    var currentData = wa.config.template.data();
    currentData.push(input)
    wa.config.template.data(currentData);
    swal("Saved!", "", "success");
    wa.config.template.inputVal("");
  })
}

wa.GeneratePayload = function(filter) {
  var payload = {}
  _.each(filter, function(d,i) {
    payload[i] = d.value()
  })
  console.log(payload);
  return payload;
}

wa.GetDataFilter = function(filter, exceptId) {
  // console.log(filter);
  var payload = wa.GeneratePayload(filter);
  var filterKeys = Object.keys(filter);
  _.each(filterKeys, function(key) {
    if(exceptId && exceptId == key) {
      return ;
    }
    payload["Flag"] = filter[key].id;
    // if(wa.getActivePage().mainPage.type() == 'wa_reviseQryChart')
    //   getFilter("/widgetanalysis/getfilterrating", payload, filter[key].data);
    // else
    getFilter("/widgetanalysis/getfilterwidget", payload, filter[key].data);
  });
}

wa.GetDataInvestor = function(filter) {
  var payload = wa.GeneratePayload(filter);
  getFilter("/widgetanalysis/getinvestorname", payload, wa.config.modal.investor.data)
}

wa.GetDataDistributions = function(filter) {
  var payload = wa.GeneratePayload(filter);
  payload["Flag"] = "country";
  getFilter("/widgetanalysis/getcountrydetail", payload, wa.config.modal.distributions.investorsList);
  payload["Flag"] = "issuer";
  getFilter("/widgetanalysis/getcountrydetail", payload, wa.config.modal.distributions.investedList);
}

wa.GetDatacommonUnInv = function(filter) {
  var payload = wa.GeneratePayload(filter);
  payload["Flag"] = "issuer";
  getFilter("/widgetanalysis/getcountrydetail", payload, wa.config.modal.commonuninvestor.commonInvestorsList);
  payload["Flag"] = "issuer";
  getFilter("/widgetanalysis/getcountrydetail", payload, wa.config.modal.commonuninvestor.commonInvestedList);
}

wa.GetDataCommonInvestor = function(filter) {
  var payload = wa.GeneratePayload(filter);
  payload["Flag"] = "issuer";
  getFilter("/widgetanalysis/getcountrydetail", payload, wa.config.modal.commonInvestor.investorsList);
}

wa.ChangeFilter = function(e, id) {
  var filter = wa.getActivePage().filter;
  filter[id].value(e._old);
  wa.GetDataFilter(filter, id);
  wa.reloadPage(filter);
}

wa.reloadPage = function(filter, page) {
  var _page = page ? wa.getPage(page) : wa.getActivePage();
  var payload = wa.GeneratePayload(filter);
  var mainPageType = _page.mainPage.type();
  switch (mainPageType) {
    case 'default':
      wa_DefChart.init(payload, $(wa.getSelectorPage(page)).find('.default'));
      break;
    case 'distributions':
      payload['Countrydetail'] = wa.config.modal.distributions.investorsVal();
      payload['Actions'] = wa.config.modal.distributions.investedType();
      payload['Text'] = wa.config.modal.distributions.investedText();
      payload['Textmulti'] = wa.config.modal.distributions.investedMulti();
      wa_DisChart.init(payload, $(wa.getSelectorPage(page)).find('.distributions'));
      break;
    case 'wa_IChart':
      wa_IChart.generateDataViz();
      break;
    case 'allocation':
      wa_AlcChart.init(payload, wa.getSelectorPage(page));
      break;
    case 'commonInvestor' :
      payload['Flag'] = 'investor_name';
      payload['Issuerdetail'] = wa.config.modal.commonInvestor.investorsVal();
      wa_DefChart.init("/widgetanalysis/getgridcommon", payload, $(wa.getSelectorPage(page)).find('.commonInvestor'));
      break;
    case 'commonUnInvestor' :
      payload['Flag'] = 'Uninvestor';
      payload['Issuerdetail'] = wa.config.modal.commonuninvestor.commonInvestorsVal();
      payload['Issuerdetail2'] = wa.config.modal.commonuninvestor.commonInvestedVal();
      wa_DefChart.init("/widgetanalysis/getgridcommon", payload,$(wa.getSelectorPage(page)).find('.commonUnInvestor'));
      break;
    case 'salesPersons' :
      payload['Flag'] = 'sales_person';
      wa_DefChart.init("/widgetanalysis/getgridtransaction", payload, $(wa.getSelectorPage(page)).find('.salesPersons'));
      break;

    case 'wa_reviseQryChart' :
      wa_reviseQryChart.init();
      break;
  }
}

wa.createPage = function() {
  var page = wa.page.total() + 1;
  var filter = wa.getFilterTemplate();

  wa.GetDataFilter(filter);

  wa.template.push({
    filter: filter,
    mainPage: {
      // available ["default","investor"]
      type: ko.observable(""),
      // available 2 options: chooseData and preview
      mode: ko.observable('chooseData'),
    }
  })

  wa.page.data().push(page);
  wa.page.data.valueHasMutated();
  wa.page.total(page);
  wa.page.active(page);
};

wa.goToPage = function(page) {
  wa.page.active(page);
}

wa.showInvestorModal = function() {
  wa.GetDataInvestor(wa.getActivePage().filter);
  $("#investorModal").modal("show");
}

wa.handleClickAddWidget = function() {
  $("#popupOptionBar").modal("show");
};

wa.closeBtnHandler = function() {
  var template = wa.getActivePage();
  template.mainPage.mode("chooseData");
  wa.config.caption(defaultCaption)
  template.mainPage.type("");
}
wa.GenerateChart =  function(type){
  $("#popupOptionBar").modal("hide");
  switch(type){
    case"default":
      wa_DefChart.init();
      break;
    case"investor":
      wa_IChart.init();
      break;
    case"distributions":
      wa_DisChart.init();
      break;
    case"allocation":
      wa_AlcChart.init();
      break;
    case"commonuninvestor":
      wa_CommonUnInvChart.init();
      break;
    case"commoninvestor":
      wa_CommonInvChart.init();
      break;
    case"salesPersons":
      wa_SlsPersonChart.init();
      break;
    case"reviseQuery":
      wa_reviseQryChart.init()
      break;
    case "wa_DSChart":
      wa_DSChart.init();
      break;
  }
}
wa.GenerateInvestorViz = function() {
  var template = wa.getActivePage();
  var filter = template.filter;
  var payload = wa.GeneratePayload(filter);
  wa.config.caption("Page of Investors");
  payload["Action"] = wa.config.modal.investor.type();
  payload["Text"] = wa.config.modal.investor.searchText();
  payload["Textmulti"] = wa.config.modal.investor.searchMulti();
  wa_IChart.init(payload, wa.getSelectorPage());
  template.mainPage.mode('preview');
  template.mainPage.type('wa_IChart');
  $("#investorModal").modal("hide");
};

wa.GenerateDistributionsViz = function() {
  var template = wa.getActivePage();
  var filter = template.filter;
  var payload = wa.GeneratePayload(filter);
  wa.config.caption("Page of Distributions");
  payload['Countrydetail'] = wa.config.modal.distributions.investorsVal();
  payload['Actions'] = wa.config.modal.distributions.investedType();
  payload['Text'] = wa.config.modal.distributions.investedText();
  payload['Textmulti'] = wa.config.modal.distributions.investedMulti();
  wa_DisChart.init(payload, $(wa.getSelectorPage()).find('.distributions'));
  template.mainPage.mode('preview');
  template.mainPage.type('distributions');
  $("#distributionsModal").modal('hide');
}

wa.GenerateDefaultViz = function() {
  var template = wa.getActivePage();
  var filter = template.filter;
  var payload = wa.GeneratePayload(filter);
  wa.config.caption("Page of Default");
  wa_DefChart.init("/widgetanalysis/getgridtransaction", payload,$(wa.getSelectorPage()).find('.default'));
  template.mainPage.mode('preview');
  template.mainPage.type('default');
  $("#popupOptionBar").modal("hide");
}

wa.GenerateSalesPersons = function() {
  var template = wa.getActivePage();
  var filter = template.filter;
  var payload = wa.GeneratePayload(filter);
  wa.config.caption("Page of Sales Persons");
  payload['Flag'] = 'sales_person';
  wa_DefChart.init("/widgetanalysis/getgridtransaction", payload, $(wa.getSelectorPage()).find('.salesPersons'));
  template.mainPage.mode('preview');
  template.mainPage.type('salesPersons');
  $("#popupOptionBar").modal("hide");
}

wa.GenerateCommonInvViz = function() {
  var template = wa.getActivePage();
  var filter = template.filter;
  var payload = wa.GeneratePayload(filter);
  wa.config.caption("Page of Common Investors");
  payload['Flag'] = 'investor_name';
  payload['Issuerdetail'] = wa.config.modal.commonInvestor.investorsVal();
  wa_DefChart.init("/widgetanalysis/getgridcommon", payload, $(wa.getSelectorPage()).find('.commonInvestor'));
  template.mainPage.mode('preview');
  template.mainPage.type('commonInvestor');
  $("#commonInvestorModal").modal("hide");
}

wa.GenerateCommonUnInvViz = function() {
  var template = wa.getActivePage();
  var filter = template.filter;
  var payload = wa.GeneratePayload(filter);
  wa.config.caption("Page of Common Un Investors");
  payload['Flag'] = 'Uninvestor';
  payload['Issuerdetail'] = wa.config.modal.commonuninvestor.commonInvestorsVal();
  payload['Issuerdetail2'] = wa.config.modal.commonuninvestor.commonInvestedVal();
  wa_DefChart.init("/widgetanalysis/getgridcommon", payload,$(wa.getSelectorPage()).find('.commonUnInvestor'));
  template.mainPage.mode('preview');
  template.mainPage.type('commonUnInvestor');
  $("#commonUnInvestorModal").modal("hide");
}

wa.init = function() {
  wa.createPage();
  wa.GetTemplate();
};


wa.showAllocationModal = function() {
  // wa.GenerateAllocated();
  $("#allocationModal").modal("show");
}

wa.showDistributionsModal = function() {
  $("#popupOptionBar").modal("hide");
  wa.GetDataDistributions(wa.getActivePage().filter);
  $("#distributionsModal").modal("show");
}

wa.showCommonUnInvModal = function() {
  // wa.GenerateAllocated();
  wa.GetDatacommonUnInv(wa.getActivePage().filter);
  $("#commonUnInvestorModal").modal("show");
}

wa.showCommonInvestorModal = function() {
  $("#popupOptionBar").modal("hide");
  wa.GetDataCommonInvestor(wa.getActivePage().filter);
  $("#commonInvestorModal").modal("show");
}

wa.exportPDF = function() {
  wa.mode('export');

  kendo.drawing.drawDOM($(".wa-content"),{
    forcePageBreak  : ".page-break",
    paperSize   : "a3",
    landscape   : true,
    margin    : {top:"5mm",left:"-2cm",right:"-2cm",bottom:"0cm"},
  })
  .then(function (group) {
    return kendo.drawing.exportPDF(group);
  })
  .done(function (data) {

    kendo.saveAs({
      dataURI   : data,
      fileName  : "DCM_Focus_Report.pdf",
        callback: (function() { wa.mode("preview")})()
    });
  });
}


wa.GenerateAllocation = function() {
  $("#popupOptionBar").modal("hide");
  var template = wa.getActivePage();
  var payload = wa.GeneratePayload(template.filter);
  wa_AlcChart.init(payload, wa.getSelectorPage());
  wa.config.caption("Page of Allocation");
  template.mainPage.mode('preview');
  template.mainPage.type('allocation');
  $("#allocationModal").modal("hide");
};

$(function() {
  wa.init();
})
