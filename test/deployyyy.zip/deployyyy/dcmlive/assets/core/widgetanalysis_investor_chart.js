var wa_IChart = {
  f:{
    defaultTypes: ['Contains', 'Equals'],
    data:ko.observableArray([]),
    val: {
      type:ko.observable("Contains"),
      searchText:ko.observable(""),
      searchMulti:ko.observableArray([]),
    }
  }
};

wa_IChart.config = {
  loading: ko.observable(true),
}

wa_IChart.createDonut = function($selector, title, dataSource) {

  var series = _.map(dataSource, function(o, i) {
    return {
      category: o._id,
      value: o.value,
      color: ecisColors[i]
    }
  })
  $selector.kendoChart({
    legend: {
      visible: true,
      position: "bottom",
    },
    seriesDefaults: {
        type: "donut",
        // startAngle: 150,
        // labels: {
        //  ''   template: title+" #= category # - #= value #%",
        //     position: "outsideEnd",
        //     visible: true,
        //     background: "transparent"
        // }
    },
    series: [{
      overlay: { gradient: "none"},
      name: title,
      data: series
    }],
    tooltip: {
      visible: true,
      template: "#= category # : #= value #%",
    }
  })
}

wa_IChart.createGrid = function($selector, url, payload) {
  $selector.kendoGrid({
    dataSource: {
      transport: {
        read: function(option) {
          payload.skip = option.data.skip;
          payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : '';
          payload.take = option.data.take
          ajaxPost(url, payload, function(res) {
            option.success({ Records: res.Data, Count: res.Total });
          })
        }
      },
      schema: {
        data: function(d) {
          return d.Records
        },
				total: "Count"
      },
      serverPaging: true,
      serverFiltering: true,
      serverSorting: true,
      pageSize: 10,
    },
    scrollable: true,
    sortable: true,
    filterable: {
      extra:false,
      operators: {
        string: {
          contains: "Contains",
          startswith: "Starts with",
          eq: "Is equal to",
          neq: "Is not equal to",
          doesnotcontain: "Does not contain",
          endswith: "Ends with"
        },
      }
    },
    pageable: {
      number: true,
      previousNext: true,
      messages: {
          display: "Showing {2} data items"
      }
    },
    columns: [
      {field: "country", title: "Country"},
      {field: "currency", title: "Currency"},
      {field: "industry", title: "Industry"},
      {field: "issue_date", title: "Issue Date"},
      {field: "issuer", title: "Issuer"},
      {field: "ownership", title: "Ownership"},
      {field: "ranking", title: "Ranking"},
      {field: "rating_type", title: "Rating Type"},
      {field: "size", title: "Size"},
    ]
  });
}

wa_IChart.generateDonutDataViz = function($selector, payload) {
  ajaxPost("/widgetanalysis/getdonutinvestorone", payload, function(res) {
    wa_IChart.config.loading(false);
    wa_IChart.createDonut($selector.find("#wa-ic-donut-1"), "Industry", res.Data);
  })
  ajaxPost("/widgetanalysis/getdonutinvestortwo", payload, function(res) {
    wa_IChart.config.loading(false);
    wa_IChart.createDonut($selector.find("#wa-ic-donut-2"), "Ranking", res.Data);
  })
  ajaxPost("/widgetanalysis/getdonutinvestorthird", payload, function(res) {
    wa_IChart.config.loading(false);
    wa_IChart.createDonut($selector.find("#wa-ic-donut-3"), "Ranking", res.Data);
  })
  wa_IChart.createGrid($selector.find("#wa-ic-grid"), "/widgetanalysis/getgridinvestor", payload);
}

wa_IChart.generateDataViz = function() {
  var template = wa.getActivePage();
  template.mainPage.mode('preview');
  template.mainPage.type('wa_IChart');

  var payload = wa.getPayload();

  wa.config.caption("Page of Investors");
  payload["Countrydetail"] = wa.config.modal.investor.type();
  payload["Actions"] = wa.config.modal.investor.searchText();
  payload["Text"] = wa.config.modal.investor.searchMulti();
  payload["Textmulti"] = wa.config.modal.investor.searchMulti();

  var $selector = wa.$getSelectorPage();
  wa_IChart.generateDonutDataViz($selector, payload);
}

wa_IChart.GetDataInvestor = function( ) {
  getFilter( "/widgetanalysis/getinvestorname", wa.getPayload(), wa_IChart.f.data );
}
wa_IChart.init =  function(){
  wa_IChart.GetDataInvestor();
  $("#wa_IChartModal").modal("show");
};
