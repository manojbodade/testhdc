package functions

import (
	"bufio"
	. "eaciit/scb-cdc/webapp/helper"
	. "eaciit/scb-cdc/webapp/models"
	//"encoding/csv"
	db "github.com/eaciit/dbox"
	_ "github.com/eaciit/dbox/dbc/mongo"
	tk "github.com/eaciit/toolkit"
	"io/ioutil"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"time"
)

var mongo db.IConnection
var wg sync.WaitGroup
var errorFlag bool
var errorMessage string
var mandatoryFiles = []string{"access_server", "datastorestatus", "statusinfo",
	"activity", "busytables", "eventlog", "performancestats", "tablemappings"}

func RunConsole(isAutomated bool) (bool, string) {
	if isAutomated {
		tk.Println("starting data digestion .... ")
		runconsole := true
		for runconsole {
			cfg := ReadConfig()
			startProcess(cfg)
			time.Sleep(time.Duration(tk.ToInt(cfg["timer"], "ROUNDINGAUTO")) * time.Hour)
		}
		tk.Println("application is closing")
	} else {
		tk.Println("starting data digestion .... ")
		cfg := ReadConfig()
		startProcess(cfg)
		tk.Println("done .... ")
	}

	return errorFlag, errorMessage
}

func PurgeData(days int, arrtable []string) (bool, string) {
	cfg := ReadConfig()
	conn := connectMongo(cfg)

	isError := false
	var e error

	periodToDelete := time.Now().AddDate(0, 0, days).UTC()
	periodToDelete = time.Date(periodToDelete.Year(), periodToDelete.Month(), periodToDelete.Day(), 0, 0, 0, 0, time.UTC)

	if len(arrtable) > 0 {
		for _, table := range arrtable {
			qddldelete := conn.NewQuery().From(table).Where(db.Lt("Period.Dates", periodToDelete.UTC())).SetConfig("multiexec", true).Delete()
			e = qddldelete.Exec(nil)
			_ = ErrorHandling(e, false)
			qddldelete.Close()

			if e != nil {
				isError = true
				break
			}
		}
	}

	return isError, e.Error()
}

func startProcess(cfg map[string]string) {
	start := time.Now().UTC()
	tk.Println("start batch process at " + start.Format("2006-01-02 15:04:05"))
	errorFlag = false
	errorMessage = ""
	getData(cfg)
	tk.Println("Error Flag : " + tk.ToString(errorFlag))
	if !errorFlag {
		tk.Println("commit data...")
		_ = commitData(cfg)
		_ = rollbackData(cfg)
	} else {
		_ = rollbackData(cfg)
		//raise alert email
		sendAlert(true)
	}
	tk.Println("sending alert")
	sendAlert(false)

	tk.Println("batch process complete : start " + start.Format("2006-01-02 15:04:05") + " finish : " + time.Now().UTC().Format("2006-01-02 15:04:05"))
}

func connectMongo(cfg map[string]string) db.IConnection {
	mongoci := db.ConnectionInfo{cfg["host"], cfg["database"], cfg["username"], cfg["password"], nil}
	mongo, e := db.NewConnection("mongo", &mongoci)
	ErrorHandling(e, true)
	mongo.Connect()
	ErrorHandling(e, true)
	return mongo
}

func getData(cfg map[string]string) {
	runtime.GOMAXPROCS(2)
	conn := connectMongo(cfg)
	defer conn.Close()

	filePath := cfg["sourcefilepath"]

	if filePath != "" {
		tk.Println(filePath)

		var FileNames []string
		var TempFileNames []string
		var UnloadedFiles []string

		e := filepath.Walk(filePath, func(path string, f os.FileInfo, err error) error {
			if strings.Contains(path, ".csv") || strings.Contains(path, ".CSV") || (strings.Contains(strings.ToLower(path), ".txt") && strings.Contains(strings.ToLower(path), "appfile")) {
				TempFileNames = append(TempFileNames, path)
			}
			return nil
		})

		//check loaded file
		if len(TempFileNames) > 0 {
			for _, tempfile := range TempFileNames {
				if strings.Contains(tempfile, ".csv") {
					if _, err := os.Stat(strings.Replace(tempfile, ".csv", cfg["markdone"], -1)); os.IsNotExist(err) {
						UnloadedFiles = append(UnloadedFiles, tempfile)
					}
				} else if strings.Contains(tempfile, ".CSV") {
					if _, err := os.Stat(strings.Replace(tempfile, ".CSV", cfg["markdone"], -1)); os.IsNotExist(err) {
						UnloadedFiles = append(UnloadedFiles, tempfile)
					}
				} else if strings.Contains(strings.ToLower(tempfile), ".txt") && strings.Contains(strings.ToLower(tempfile), "appfile") {
					if _, err := os.Stat(strings.Replace(strings.ToLower(tempfile), ".txt", cfg["markdone"], -1)); os.IsNotExist(err) {
						UnloadedFiles = append(UnloadedFiles, tempfile)
					}
				}
			}
		}

		//check mandatory files completeness
		if len(UnloadedFiles) > 0 && !errorFlag {
			isComplete := false
			for _, mandatFile := range mandatoryFiles {
				isComplete = false
				for _, filename := range UnloadedFiles {
					if strings.Contains(filename, mandatFile) {
						isComplete = true
						break
					}
				}
				if !isComplete {
					errorFlag = true
					errorMessage = "mandatory file missing " + mandatFile
					tk.Println("mandatory file missing " + mandatFile)
					break
				}
			}

			if isComplete && !errorFlag {
				for _, filename := range UnloadedFiles {
					// if strings.Contains(filename, "appfile") {
					// 	FileNames = append(FileNames, filename)
					// }
					FileNames = append(FileNames, filename)
				}
			}
		}

		if len(FileNames) > 0 && !errorFlag {
			counter := 0
			tk.Println("Import Data")
			var cdcsummary *CDCSummary
			var ddlchanges *DDLChanges
			var serverhealth *ServerHealth
			var serverdisk *ServerDisk
			var appfile *AppFile

			qinsertSumm := conn.NewQuery().
				From(cdcsummary.Temp_TableName()).
				SetConfig("multiexec", true).
				Insert()
			defer qinsertSumm.Close()

			qinsertddl := conn.NewQuery().
				From(ddlchanges.Temp_TableName()).
				SetConfig("multiexec", true).
				Insert()
			defer qinsertddl.Close()

			qinsertserverhealth := conn.NewQuery().
				From(serverhealth.Temp_TableName()).
				SetConfig("multiexec", true).
				Insert()
			defer qinsertserverhealth.Close()

			qinsertserverdisk := conn.NewQuery().
				From(serverdisk.Temp_TableName()).
				SetConfig("multiexec", true).
				Insert()
			defer qinsertserverdisk.Close()

			qinsertappfile := conn.NewQuery().
				From(appfile.Temp_TableName()).
				SetConfig("multiexec", true).
				Insert()
			defer qinsertappfile.Close()

			for _, file := range FileNames {
				wg.Add(1)

				go func(file string) {
					tk.Println("processing " + file)

					lineData := readFile(file)

					if !errorFlag {
						filepathFragments := strings.Split(file, "/")
						hostname := strings.Split(filepathFragments[len(filepathFragments)-2], "_")[0]
						if cfg["environment"] != "dev" {
							hostname = strings.Split(filepathFragments[len(filepathFragments)-2], "_")[len(strings.Split(filepathFragments[len(filepathFragments)-2], "_"))-1]
						}
						saveData(conn, file, lineData, qinsertSumm, cdcsummary, hostname, ddlchanges, qinsertddl, serverhealth, qinsertserverhealth, serverdisk, qinsertserverdisk, appfile, qinsertappfile)
						//moveFile(cfg, file)
						e = createLoadedFile(cfg, file)
						errorFlag = ErrorHandling(e, false)
						if e != nil {
							errorMessage = "Error while creating processed flag file : " + e.Error()
						}

						wg.Done()
						return
					} else {
						wg.Done()
						return
					}
					counter++
					if counter == len(FileNames)-1 {
						wg.Done()
						return
					}
				}(file)

				wg.Wait()
			}
		} else if errorFlag {
			return
		}

	}
	return
}

func removeQuote(val string) string {
	return RemoveQuestionMark(strings.Replace(val, "\"", "", -1))
}

func readFile(filePath string) []string {
	file, e := os.Open(filePath)
	errorFlag = ErrorHandling(e, false)
	defer file.Close()
	reader := bufio.NewReader(file)
	var retval []string
	for {
		line, _, e := reader.ReadLine()
		if e != nil {
			break
		}

		retval = append(retval, string(line))
	}
	return retval
}

func saveData(conn db.IConnection, file string, lineData []string, qinsertSumm db.IQuery, cdcsummary *CDCSummary, hostname string, ddlchanges *DDLChanges, qinsertDDL db.IQuery, serverhealth *ServerHealth, qinsertserverhealth db.IQuery, serverdisk *ServerDisk, qinsertserverdisk db.IQuery, appfile *AppFile, qinsertappfile db.IQuery) {
	var e error
	var obj *SubsCountry

	if strings.Contains(strings.ToLower(file), "access_server") {

		for _, line := range lineData {
			data := strings.Split(line, ",")
			if removeQuote(data[0]) != "START TIME" && len(data) > 1 {
				cdcsummary = NewCDCSummary()
				cdcsummary.Start_Time = tk.ToString(removeQuote(data[0]))
				cdcsummary.Current_Timestamp = GetDate(removeQuote(tk.ToString(data[1])))
				cdcsummary.Host = hostname
				cdcsummary.Host_IP = tk.ToString(removeQuote(data[2]))
				cdcsummary.Port = tk.ToString(removeQuote(data[3]))
				cdcsummary.User = tk.ToString(removeQuote(data[4]))
				cdcsummary.Data_Source = "Access Server"
				cdcsummary.Access_Server_Status = tk.ToString(removeQuote(data[5]))
				_, tempWeek := time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), cdcsummary.Current_Timestamp.Day(), 0, 0, 0, 0, time.UTC).ISOWeek()
				Week_Start, Week_End := GetStartAndEndDateOfTheWeek(cdcsummary.Current_Timestamp)
				cdcsummary.Period = Period{
					Actual_Period: cdcsummary.Current_Timestamp,
					Period:        time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), 1, 0, 0, 0, 0, time.UTC),
					Dates:         time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), cdcsummary.Current_Timestamp.Day(), 0, 0, 0, 0, time.UTC),
					Year:          cdcsummary.Current_Timestamp.Year(),
					Year_Month:    tk.ToInt(cdcsummary.Current_Timestamp.Format("200601"), "ROUNDINGAUTO"),
					Week:          tempWeek,
					Week_Start:    Week_Start,
					Week_End:      Week_End,
				}

				dataSumm := map[string]interface{}{"data": cdcsummary}
				e = qinsertSumm.Exec(dataSumm)
				errorFlag = ErrorHandling(e, false)
				if e != nil {
					errorMessage = "Error while saving data : " + e.Error()
				}
			}

		}
	} else if strings.Contains(strings.ToLower(file), "datastorestatus") {

		for _, line := range lineData {
			data := strings.Split(line, ",")
			if removeQuote(data[0]) != "START TIME" && len(data) > 1 {
				cdcsummary = NewCDCSummary()
				cdcsummary.Start_Time = tk.ToString(removeQuote(data[0]))
				cdcsummary.Current_Timestamp = GetDate(removeQuote(tk.ToString(data[1])))
				cdcsummary.Host = hostname
				cdcsummary.Host_IP = tk.ToString(removeQuote(data[2]))
				cdcsummary.Port = tk.ToString(removeQuote(data[3]))
				cdcsummary.Data_Source = "Data Store Status"
				cdcsummary.Data_Store_Name = tk.ToString(removeQuote(data[4]))
				cdcsummary.Data_Store_Type = tk.ToString(removeQuote(data[5]))
				cdcsummary.Data_Store_Status = tk.ToString(removeQuote(data[6]))
				_, tempWeek := time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), cdcsummary.Current_Timestamp.Day(), 0, 0, 0, 0, time.UTC).ISOWeek()
				Week_Start, Week_End := GetStartAndEndDateOfTheWeek(cdcsummary.Current_Timestamp)
				cdcsummary.Period = Period{
					Actual_Period: cdcsummary.Current_Timestamp,
					Period:        time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), 1, 0, 0, 0, 0, time.UTC),
					Dates:         time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), cdcsummary.Current_Timestamp.Day(), 0, 0, 0, 0, time.UTC),
					Year:          cdcsummary.Current_Timestamp.Year(),
					Year_Month:    tk.ToInt(cdcsummary.Current_Timestamp.Format("200601"), "ROUNDINGAUTO"),
					Week:          tempWeek,
					Week_Start:    Week_Start,
					Week_End:      Week_End,
				}

				dataSumm := map[string]interface{}{"data": cdcsummary}
				e = qinsertSumm.Exec(dataSumm)
				errorFlag = ErrorHandling(e, false)
				if e != nil {
					errorMessage = "Error while saving data : " + e.Error()
				}
			}

		}
	} else if strings.Contains(strings.ToLower(file), "subscripionstatusinfo") {

		for _, line := range lineData {
			data := strings.Split(line, ",")
			if removeQuote(data[0]) != "START TIME" && len(data) > 1 {
				cdcsummary = NewCDCSummary()
				cdcsummary.Start_Time = tk.ToString(removeQuote(data[0]))
				cdcsummary.Current_Timestamp = GetDate(tk.ToString(removeQuote(data[1])))
				cdcsummary.Host = hostname
				cdcsummary.Host_IP = tk.ToString(removeQuote(data[3]))
				cdcsummary.Port = tk.ToString(removeQuote(data[4]))
				cdcsummary.Data_Source = "Subscription Status Info"
				cdcsummary.Subscription = tk.ToString(removeQuote(data[2]))
				cdcsummary.Subscription_Status_Info_State = tk.ToString(removeQuote(data[5]))
				cdcsummary.Subscription_Status_Info_Scheduled_End = tk.ToString(removeQuote(data[6]))
				cdcsummary.Subscription_Status_Info_Latency_Threshold = tk.ToInt(removeQuote(data[7]), "ROUNDINGAUTO")
				cdcsummary.Subscription_Status_Info_Latency = tk.ToInt(removeQuote(data[8]), "ROUNDINGAUTO")
				cdcsummary.Subscription_Status_Info_Source_Datastore = tk.ToString(removeQuote(data[9]))
				cdcsummary.Subscription_Status_Info_Target_Datastore = tk.ToString(removeQuote(data[10]))
				cdcsummary.Subscription_Status_Info_Application_Name = tk.ToString(removeQuote(data[11]))

				if cdcsummary.Subscription_Status_Info_Latency > tk.ToInt(cdcsummary.Subscription_Status_Info_Latency_Threshold, "ROUNDINGAUTO") {
					cdcsummary.LatencyExceedThreshold = true
				} else {
					cdcsummary.LatencyExceedThreshold = false
				}

				subscountries := []tk.M{}
				csr2, err := conn.NewQuery().From(obj.TableName()).Where(
					db.Eq("Host", cdcsummary.Host),
					db.Eq("Source_Datastore", cdcsummary.Subscription_Status_Info_Source_Datastore),
					db.Eq("Target_Datastore", cdcsummary.Subscription_Status_Info_Target_Datastore),
					db.Eq("Subscription", cdcsummary.Subscription),
				).Cursor(nil)
				defer csr2.Close()
				err = csr2.Fetch(&subscountries, 0, false)

				if len(subscountries) <= 0 {
					qinsertcountry := conn.NewQuery().
						From(obj.TableName()).
						SetConfig("multiexec", true).
						Insert()
					defer qinsertcountry.Close()

					obj = NewSubsCountry()
					obj.Host = cdcsummary.Host
					obj.Source_Datastore = cdcsummary.Subscription_Status_Info_Source_Datastore
					obj.Target_Datastore = cdcsummary.Subscription_Status_Info_Target_Datastore
					obj.Subscription = cdcsummary.Subscription

					dat := tk.M{"data": obj}
					err = qinsertcountry.Exec(dat)
					ErrorHandling(err, false)
				}
				_, tempWeek := time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), cdcsummary.Current_Timestamp.Day(), 0, 0, 0, 0, time.UTC).ISOWeek()
				Week_Start, Week_End := GetStartAndEndDateOfTheWeek(cdcsummary.Current_Timestamp)
				cdcsummary.Period = Period{
					Actual_Period: cdcsummary.Current_Timestamp,
					Period:        time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), 1, 0, 0, 0, 0, time.UTC),
					Dates:         time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), cdcsummary.Current_Timestamp.Day(), 0, 0, 0, 0, time.UTC),
					Year:          cdcsummary.Current_Timestamp.Year(),
					Year_Month:    tk.ToInt(cdcsummary.Current_Timestamp.Format("200601"), "ROUNDINGAUTO"),
					Week:          tempWeek,
					Week_Start:    Week_Start,
					Week_End:      Week_End,
				}

				dataSumm := map[string]interface{}{"data": cdcsummary}
				e = qinsertSumm.Exec(dataSumm)
				errorFlag = ErrorHandling(e, false)
				if e != nil {
					errorMessage = "Error while saving data : " + e.Error()
				}
			}
		}
	} else if strings.Contains(strings.ToLower(file), "subscriptionactivity") {

		group := ""
		subgroup := ""

		for _, line := range lineData {
			data := strings.Split(line, ",")
			if len(data) > 1 && removeQuote(data[0]) != "START TIME" {
				if tk.ToString(removeQuote(data[5]))[:4] != "    " && tk.ToString(removeQuote(data[5]))[:2] != "  " {
					group = tk.ToString(removeQuote(data[5]))
				} else if tk.ToString(removeQuote(data[5]))[:4] != "    " && tk.ToString(removeQuote(data[5]))[:2] == "  " {
					subgroup = tk.ToString(removeQuote(data[5]))[2:]
				} else if group != "" && subgroup != "" {
					if removeQuote(data[0]) != "START TIME" {
						cdcsummary = NewCDCSummary()
						cdcsummary.Start_Time = tk.ToString(removeQuote(data[0]))
						cdcsummary.Current_Timestamp = GetDate(tk.ToString(removeQuote(data[1])))
						cdcsummary.Host = hostname
						cdcsummary.Host_IP = tk.ToString(removeQuote(data[3]))
						cdcsummary.Port = tk.ToString(removeQuote(data[4]))
						cdcsummary.Data_Source = "Subscription Activity"
						cdcsummary.Subscription = tk.ToString(removeQuote(data[2]))
						cdcsummary.Subscription_Activity_Metric = tk.ToString(removeQuote(data[5]))[4:]
						cdcsummary.Subscription_Activity_Group_Metric = group
						cdcsummary.Subscription_Activity_Total = tk.ToFloat64(removeQuote(data[6]), 0, "ROUNDINGAUTO")
						cdcsummary.Subscription_Activity_Sub_Group_Metric = subgroup
						_, tempWeek := time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), cdcsummary.Current_Timestamp.Day(), 0, 0, 0, 0, time.UTC).ISOWeek()
						Week_Start, Week_End := GetStartAndEndDateOfTheWeek(cdcsummary.Current_Timestamp)
						cdcsummary.Period = Period{
							Actual_Period: cdcsummary.Current_Timestamp,
							Period:        time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), 1, 0, 0, 0, 0, time.UTC),
							Dates:         time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), cdcsummary.Current_Timestamp.Day(), 0, 0, 0, 0, time.UTC),
							Year:          cdcsummary.Current_Timestamp.Year(),
							Year_Month:    tk.ToInt(cdcsummary.Current_Timestamp.Format("200601"), "ROUNDINGAUTO"),
							Week:          tempWeek,
							Week_Start:    Week_Start,
							Week_End:      Week_End,
						}

						dataSumm := map[string]interface{}{"data": cdcsummary}
						e = qinsertSumm.Exec(dataSumm)
						errorFlag = ErrorHandling(e, false)
						if e != nil {
							errorMessage = "Error while saving data : " + e.Error()
						}
					}

				}
			}
		}
	} else if strings.Contains(strings.ToLower(file), "subscriptionbusytables") {

		for _, line := range lineData {
			data := strings.Split(line, ",")
			if removeQuote(data[0]) != "START TIME" && len(data) > 1 {
				cdcsummary = NewCDCSummary()
				cdcsummary.Start_Time = tk.ToString(removeQuote(data[0]))
				cdcsummary.Current_Timestamp = GetDate(tk.ToString(removeQuote(data[1])))
				cdcsummary.Host = hostname
				cdcsummary.Host_IP = tk.ToString(removeQuote(data[3]))
				cdcsummary.Port = tk.ToString(removeQuote(data[4]))
				cdcsummary.Data_Source = "Subscription Busy Tables"
				cdcsummary.Subscription = tk.ToString(removeQuote(data[2]))
				cdcsummary.Subscription_Busy_Tables_Prct_Busy = tk.ToFloat64(strings.Replace(removeQuote(data[7]), "%", "", -1), 2, "ROUNDINGAUTO")
				cdcsummary.Subscription_Busy_Tables_Source_Table = tk.ToString(removeQuote(data[5]))
				cdcsummary.Subscription_Busy_Tables_Total_Bytes = tk.ToFloat64(removeQuote(data[6]), 2, "ROUNDINGAUTO")
				_, tempWeek := time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), cdcsummary.Current_Timestamp.Day(), 0, 0, 0, 0, time.UTC).ISOWeek()
				Week_Start, Week_End := GetStartAndEndDateOfTheWeek(cdcsummary.Current_Timestamp)
				cdcsummary.Period = Period{
					Actual_Period: cdcsummary.Current_Timestamp,
					Period:        time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), 1, 0, 0, 0, 0, time.UTC),
					Dates:         time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), cdcsummary.Current_Timestamp.Day(), 0, 0, 0, 0, time.UTC),
					Year:          cdcsummary.Current_Timestamp.Year(),
					Year_Month:    tk.ToInt(cdcsummary.Current_Timestamp.Format("200601"), "ROUNDINGAUTO"),
					Week:          tempWeek,
					Week_Start:    Week_Start,
					Week_End:      Week_End,
				}

				dataSumm := map[string]interface{}{"data": cdcsummary}
				e = qinsertSumm.Exec(dataSumm)
				errorFlag = ErrorHandling(e, false)
				if e != nil {
					errorMessage = "Error while saving data : " + e.Error()
				}
			}

		}
	} else if strings.Contains(strings.ToLower(file), "subscriptioneventlog_source") || strings.Contains(strings.ToLower(file), "subscriptioneventlog_target") {

		for _, line := range lineData {
			data := strings.Split(line, ",")
			if removeQuote(data[0]) != "START TIME" && len(data) > 1 {
				cdcsummary = NewCDCSummary()
				cdcsummary.Start_Time = tk.ToString(removeQuote(data[0]))
				cdcsummary.Current_Timestamp = GetDate(tk.ToString(removeQuote(data[1])))
				cdcsummary.Host = hostname
				cdcsummary.Host_IP = tk.ToString(removeQuote(data[3]))
				cdcsummary.Port = tk.ToString(removeQuote(data[4]))

				if strings.Contains(strings.ToLower(file), "subscriptioneventlog_source") {
					cdcsummary.Data_Source = "Subscription Event Log - Source"
				} else {
					cdcsummary.Data_Source = "Subscription Event Log - Target"
				}

				cdcsummary.Subscription = tk.ToString(removeQuote(data[2]))
				cdcsummary.Subscription_Event_Log_Row = tk.ToInt(removeQuote(data[5]), "ROUNDINGAUTO")
				cdcsummary.Subscription_Event_Log_Event_ID = tk.ToInt(removeQuote(data[6]), "ROUNDINGAUTO")
				cdcsummary.Subscription_Event_Log_Type = tk.ToString(removeQuote(data[7]))
				cdcsummary.Subscription_Event_Log_Time = GetDate(tk.ToString(removeQuote(data[8]) + "," + removeQuote(data[9])))
				cdcsummary.Subscription_Event_Log_Object = tk.ToString(removeQuote(data[10]))
				cdcsummary.Subscription_Event_Log_Message = tk.ToString(removeQuote(data[11]))
				_, tempWeek := time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), cdcsummary.Current_Timestamp.Day(), 0, 0, 0, 0, time.UTC).ISOWeek()
				Week_Start, Week_End := GetStartAndEndDateOfTheWeek(cdcsummary.Current_Timestamp)
				cdcsummary.Period = Period{
					Actual_Period: cdcsummary.Current_Timestamp,
					Period:        time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), 1, 0, 0, 0, 0, time.UTC),
					Dates:         time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), cdcsummary.Current_Timestamp.Day(), 0, 0, 0, 0, time.UTC),
					Year:          cdcsummary.Current_Timestamp.Year(),
					Year_Month:    tk.ToInt(cdcsummary.Current_Timestamp.Format("200601"), "ROUNDINGAUTO"),
					Week:          tempWeek,
					Week_Start:    Week_Start,
					Week_End:      Week_End,
				}

				dataSumm := map[string]interface{}{"data": cdcsummary}
				e = qinsertSumm.Exec(dataSumm)
				errorFlag = ErrorHandling(e, false)
				if e != nil {
					errorMessage = "Error while saving data : " + e.Error()
				}
			}

		}
	} else if strings.Contains(strings.ToLower(file), "subscriptionperformancestats") {

		for _, line := range lineData {
			data := strings.Split(line, ",")
			if removeQuote(data[0]) != "START TIME" && len(data) > 1 {
				cdcsummary = NewCDCSummary()
				cdcsummary.Start_Time = tk.ToString(removeQuote(data[0]))
				cdcsummary.Current_Timestamp = GetDate(tk.ToString(removeQuote(data[1])))
				cdcsummary.Host = hostname
				cdcsummary.Host_IP = tk.ToString(removeQuote(data[3]))
				cdcsummary.Port = tk.ToString(removeQuote(data[4]))
				cdcsummary.Data_Source = "Subscription Performance Stats"
				cdcsummary.Subscription = tk.ToString(removeQuote(data[2]))
				cdcsummary.Subscription_Performance_Stats_Metric_Context = tk.ToString(removeQuote(data[5]))
				cdcsummary.Subscription_Performance_Stats_Metric = strings.TrimSpace(tk.ToString(removeQuote(data[6])))
				cdcsummary.Subscription_Performance_Stats_Value = tk.ToFloat64(removeQuote(data[7]), 2, "ROUNDINGAUTO")
				_, tempWeek := time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), cdcsummary.Current_Timestamp.Day(), 0, 0, 0, 0, time.UTC).ISOWeek()
				Week_Start, Week_End := GetStartAndEndDateOfTheWeek(cdcsummary.Current_Timestamp)
				cdcsummary.Period = Period{
					Actual_Period: cdcsummary.Current_Timestamp,
					Period:        time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), 1, 0, 0, 0, 0, time.UTC),
					Dates:         time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), cdcsummary.Current_Timestamp.Day(), 0, 0, 0, 0, time.UTC),
					Year:          cdcsummary.Current_Timestamp.Year(),
					Year_Month:    tk.ToInt(cdcsummary.Current_Timestamp.Format("200601"), "ROUNDINGAUTO"),
					Week:          tempWeek,
					Week_Start:    Week_Start,
					Week_End:      Week_End,
				}

				dataSumm := map[string]interface{}{"data": cdcsummary}
				e = qinsertSumm.Exec(dataSumm)
				errorFlag = ErrorHandling(e, false)
				if e != nil {
					errorMessage = "Error while saving data : " + e.Error()
				}
			}

		}
	} else if strings.Contains(strings.ToLower(file), "subscriptiontablemappings") {

		for _, line := range lineData {
			data := strings.Split(line, ",")
			if removeQuote(data[0]) != "START TIME" && len(data) > 1 {
				cdcsummary = NewCDCSummary()
				cdcsummary.Start_Time = tk.ToString(removeQuote(data[0]))
				cdcsummary.Current_Timestamp = GetDate(tk.ToString(removeQuote(data[1])))
				cdcsummary.Host = hostname
				cdcsummary.Host_IP = tk.ToString(removeQuote(data[3]))
				cdcsummary.Port = tk.ToString(removeQuote(data[4]))
				cdcsummary.Data_Source = "Subscription Table Mappings"
				cdcsummary.Subscription = tk.ToString(removeQuote(data[2]))
				cdcsummary.Subscription_Table_Mapping_Source_Table = tk.ToString(removeQuote(data[5]))
				cdcsummary.Subscription_Table_Mapping_Target_Table = tk.ToString(removeQuote(data[6]))
				cdcsummary.Subscription_Table_Mapping_Mapping_Type = tk.ToString(removeQuote(data[7]))
				cdcsummary.Subscription_Table_Mapping_Method = tk.ToString(removeQuote(data[8]))
				cdcsummary.Subscription_Table_Mapping_Status = tk.ToString(removeQuote(data[9]))
				cdcsummary.Subscription_Table_Mapping_Prevent = tk.ToString(removeQuote(data[10]))
				cdcsummary.Subscription_Table_Mapping_Context = tk.ToString(removeQuote(data[11]))
				_, tempWeek := time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), cdcsummary.Current_Timestamp.Day(), 0, 0, 0, 0, time.UTC).ISOWeek()
				Week_Start, Week_End := GetStartAndEndDateOfTheWeek(cdcsummary.Current_Timestamp)
				cdcsummary.Period = Period{
					Actual_Period: cdcsummary.Current_Timestamp,
					Period:        time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), 1, 0, 0, 0, 0, time.UTC),
					Dates:         time.Date(cdcsummary.Current_Timestamp.Year(), cdcsummary.Current_Timestamp.Month(), cdcsummary.Current_Timestamp.Day(), 0, 0, 0, 0, time.UTC),
					Year:          cdcsummary.Current_Timestamp.Year(),
					Year_Month:    tk.ToInt(cdcsummary.Current_Timestamp.Format("200601"), "ROUNDINGAUTO"),
					Week:          tempWeek,
					Week_Start:    Week_Start,
					Week_End:      Week_End,
				}

				dataSumm := map[string]interface{}{"data": cdcsummary}
				e = qinsertSumm.Exec(dataSumm)
				errorFlag = ErrorHandling(e, false)
				if e != nil {
					errorMessage = "Error while saving data : " + e.Error()
				}
			}

		}
	} else if strings.Contains(strings.ToLower(file), "ddl_changes") {

		filename := strings.Split(file, "/")[len(strings.Split(file, "/"))-1]
		filefulldate := strings.Split(filename, "_")[len(strings.Split(filename, "_"))-2]
		fileyear := tk.ToInt(filefulldate[:4], "ROUNDINGAUTO")
		filemonth := tk.ToInt(filefulldate[4:6], "ROUNDINGAUTO")
		filedate := tk.ToInt(filefulldate[6:8], "ROUNDINGAUTO")
		filehour := tk.ToInt(filefulldate[8:10], "ROUNDINGAUTO")
		fileminute := tk.ToInt(filefulldate[10:12], "ROUNDINGAUTO")
		filesecond := tk.ToInt(filefulldate[12:14], "ROUNDINGAUTO")

		datadate := time.Date(fileyear, time.Month(filemonth), filedate, filehour, fileminute, filesecond, 0, time.UTC).UTC()

		for _, line := range lineData {
			data := strings.Split(line, ",")
			if removeQuote(data[0]) != "HOSTNAME" && len(data) > 1 {
				ddlchanges = NewDDLChanges()
				ddlchanges.Host_Name = tk.ToString(removeQuote(data[0]))
				ddlchanges.Host_IP = tk.ToString(removeQuote(data[1]))
				ddlchanges.Source_Instance = tk.ToString(removeQuote(data[2]))
				ddlchanges.Target_Instance = tk.ToString(removeQuote(data[3]))
				ddlchanges.Subscription = tk.ToString(removeQuote(data[4]))
				ddlchanges.Schema_Name = tk.ToString(removeQuote(data[5]))
				ddlchanges.Table_Name = tk.ToString(removeQuote(data[6]))
				ddlchanges.Activity = tk.ToString(removeQuote(data[7]))
				ddlchanges.Column_List = tk.ToString(removeQuote(data[8]))
				ddlchanges.Method = tk.ToString(removeQuote(data[9]))
				ddlchanges.Status = tk.ToString(removeQuote(data[10]))
				_, tempWeek := time.Date(datadate.Year(), datadate.Month(), datadate.Day(), 0, 0, 0, 0, time.UTC).ISOWeek()
				Week_Start, Week_End := GetStartAndEndDateOfTheWeek(datadate)
				ddlchanges.Period = Period{
					Actual_Period: datadate,
					Period:        time.Date(datadate.Year(), datadate.Month(), 1, 0, 0, 0, 0, time.UTC),
					Dates:         time.Date(datadate.Year(), datadate.Month(), datadate.Day(), 0, 0, 0, 0, time.UTC),
					Year:          datadate.Year(),
					Year_Month:    tk.ToInt(datadate.Format("200601"), "ROUNDINGAUTO"),
					Week:          tempWeek,
					Week_Start:    Week_Start,
					Week_End:      Week_End,
				}

				dataSumm := map[string]interface{}{"data": ddlchanges}
				e = qinsertDDL.Exec(dataSumm)
				errorFlag = ErrorHandling(e, false)
				if e != nil {
					errorMessage = "Error while saving data : " + e.Error()
				}
			}

		}
	} else if strings.Contains(strings.ToLower(file), "server_health") {

		filename := strings.Split(file, "/")[len(strings.Split(file, "/"))-1]
		filefulldate := strings.Split(filename, "_")[len(strings.Split(filename, "_"))-1]
		fileyear := tk.ToInt(filefulldate[:4], "ROUNDINGAUTO")
		filemonth := tk.ToInt(filefulldate[4:6], "ROUNDINGAUTO")
		filedate := tk.ToInt(filefulldate[6:8], "ROUNDINGAUTO")
		filehour := tk.ToInt(filefulldate[8:10], "ROUNDINGAUTO")
		fileminute := tk.ToInt(filefulldate[10:12], "ROUNDINGAUTO")
		filesecond := tk.ToInt(filefulldate[12:14], "ROUNDINGAUTO")

		datadate := time.Date(fileyear, time.Month(filemonth), filedate, filehour, fileminute, filesecond, 0, time.UTC).UTC()

		for _, line := range lineData {
			data := strings.Split(line, ",")
			if removeQuote(data[0]) != "HOSTNAME" && len(data) > 1 {
				serverhealth = NewServerHealth()
				serverhealth.Host_Name = tk.ToString(removeQuote(data[0]))
				serverhealth.Host_IP = tk.ToString(removeQuote(data[1]))
				serverhealth.Kernel_Version = tk.ToString(removeQuote(data[2]))
				serverhealth.Uptime = tk.ToString(removeQuote(data[3]))
				serverhealth.Uptime_Days = tk.ToInt(strings.TrimSpace(strings.Replace(serverhealth.Uptime, "days", "", -1)), "ROUNDINGAUTO")
				serverhealth.Last_Reboot = GetDate(tk.ToString(removeQuote(data[4])))
				serverhealth.CPU_Utilization_User_Level_Prct = tk.ToFloat64(tk.ToString(removeQuote(data[5])), 2, "ROUNDINGAUTO")
				serverhealth.CPU_Utilization_User_Nice_Level_Prct = tk.ToFloat64(tk.ToString(removeQuote(data[6])), 2, "ROUNDINGAUTO")
				serverhealth.CPU_Utilization_System_Level = tk.ToFloat64(tk.ToString(removeQuote(data[7])), 2, "ROUNDINGAUTO")
				serverhealth.CPU_Idle_Prct = SetPercentage(tk.ToString(removeQuote(data[8])))
				serverhealth.CPU_Load_Average = tk.ToFloat64(tk.ToString(removeQuote(data[9])), 2, "ROUNDINGAUTO")
				serverhealth.CPU_Health_Status = tk.ToString(removeQuote(data[10]))
				serverhealth.Physical_Memory_Total_MB = SetSizeNumberToMB(tk.ToString(removeQuote(data[11])))
				serverhealth.Physical_Memory_Used_MB = SetSizeNumberToMB(tk.ToString(removeQuote(data[12])))
				serverhealth.Physical_Memory_Free_MB = SetSizeNumberToMB(tk.ToString(removeQuote(data[13])))
				serverhealth.Physical_Memory_Free_Prct = SetPercentage(tk.ToString(removeQuote(data[14])))
				serverhealth.Swap_Memory_Total_MB = SetSizeNumberToMB(tk.ToString(removeQuote(data[15])))
				serverhealth.Swap_Memory_Used_MB = SetSizeNumberToMB(tk.ToString(removeQuote(data[16])))
				serverhealth.Swap_Memory_Free_MB = SetSizeNumberToMB(tk.ToString(removeQuote(data[17])))
				serverhealth.Swap_Memory_Free_Prct = SetPercentage(tk.ToString(removeQuote(data[18])))

				_, tempWeek := time.Date(datadate.Year(), datadate.Month(), datadate.Day(), 0, 0, 0, 0, time.UTC).ISOWeek()
				Week_Start, Week_End := GetStartAndEndDateOfTheWeek(datadate)
				serverhealth.Period = Period{
					Actual_Period: datadate,
					Period:        time.Date(datadate.Year(), datadate.Month(), 1, 0, 0, 0, 0, time.UTC),
					Dates:         time.Date(datadate.Year(), datadate.Month(), datadate.Day(), 0, 0, 0, 0, time.UTC),
					Year:          datadate.Year(),
					Year_Month:    tk.ToInt(datadate.Format("200601"), "ROUNDINGAUTO"),
					Week:          tempWeek,
					Week_Start:    Week_Start,
					Week_End:      Week_End,
				}

				dataSumm := map[string]interface{}{"data": serverhealth}
				e = qinsertserverhealth.Exec(dataSumm)
				errorFlag = ErrorHandling(e, false)
				if e != nil {
					errorMessage = "Error while saving data : " + e.Error()
				}
			}

		}
	} else if strings.Contains(strings.ToLower(file), "server_disk") {

		filename := strings.Split(file, "/")[len(strings.Split(file, "/"))-1]
		filefulldate := strings.Split(filename, "_")[len(strings.Split(filename, "_"))-1]
		fileyear := tk.ToInt(filefulldate[:4], "ROUNDINGAUTO")
		filemonth := tk.ToInt(filefulldate[4:6], "ROUNDINGAUTO")
		filedate := tk.ToInt(filefulldate[6:8], "ROUNDINGAUTO")
		filehour := tk.ToInt(filefulldate[8:10], "ROUNDINGAUTO")
		fileminute := tk.ToInt(filefulldate[10:12], "ROUNDINGAUTO")
		filesecond := tk.ToInt(filefulldate[12:14], "ROUNDINGAUTO")

		datadate := time.Date(fileyear, time.Month(filemonth), filedate, filehour, fileminute, filesecond, 0, time.UTC).UTC()

		for _, line := range lineData {
			data := strings.Split(line, ",")
			if removeQuote(data[0]) != "HOSTNAME" && len(data) > 1 {
				serverdisk = NewServerDisk()
				serverdisk.Host_Name = tk.ToString(removeQuote(data[0]))
				serverdisk.Host_IP = tk.ToString(removeQuote(data[1]))
				serverdisk.File_System = tk.ToString(removeQuote(data[2]))
				serverdisk.Total_Size_MB = SetSizeNumberToMB(tk.ToString(removeQuote(data[3])))
				serverdisk.Size_Used_MB = SetSizeNumberToMB(tk.ToString(removeQuote(data[4])))
				serverdisk.Size_Available_MB = SetSizeNumberToMB(tk.ToString(removeQuote(data[5])))
				serverdisk.Size_Free_MB = SetSizeNumberToMB(tk.ToString(removeQuote(data[6])))
				serverdisk.Size_Prct = SetPercentage(tk.ToString(removeQuote(data[7])))
				serverdisk.Mounted_Filestream = tk.ToString(removeQuote(data[8]))
				serverdisk.Health = tk.ToString(removeQuote(data[9]))

				_, tempWeek := time.Date(datadate.Year(), datadate.Month(), datadate.Day(), 0, 0, 0, 0, time.UTC).ISOWeek()
				Week_Start, Week_End := GetStartAndEndDateOfTheWeek(datadate)
				serverdisk.Period = Period{
					Actual_Period: datadate,
					Period:        time.Date(datadate.Year(), datadate.Month(), 1, 0, 0, 0, 0, time.UTC),
					Dates:         time.Date(datadate.Year(), datadate.Month(), datadate.Day(), 0, 0, 0, 0, time.UTC),
					Year:          datadate.Year(),
					Year_Month:    tk.ToInt(datadate.Format("200601"), "ROUNDINGAUTO"),
					Week:          tempWeek,
					Week_Start:    Week_Start,
					Week_End:      Week_End,
				}

				dataSumm := map[string]interface{}{"data": serverdisk}
				e = qinsertserverdisk.Exec(dataSumm)
				errorFlag = ErrorHandling(e, false)
				if e != nil {
					errorMessage = "Error while saving data : " + e.Error()
				}
			}

		}
	} else if strings.Contains(strings.ToLower(file), "appfile") {

		filename := strings.Split(file, "/")[len(strings.Split(file, "/"))-1]
		host := strings.Replace(strings.Replace(strings.Split(filename, "_")[1], ".txt", "", -1), ".TXT", "", -1)

		datadate := time.Now().UTC()

		for _, line := range lineData {
			data := strings.Split(line, ",")
			if removeQuote(data[0]) != "" && len(data) > 1 {
				appfile = NewAppFile()
				appfile.Host_IP = tk.ToString(removeQuote(data[0]))
				appfile.Host_Name = host
				appfile.Host_Port = tk.ToString(removeQuote(data[1]))
				appfile.App_Name = tk.ToString(removeQuote(data[2]))
				appfile.Source_Datastore = tk.ToString(removeQuote(data[3]))
				appfile.Source_Connection = tk.ToString(removeQuote(data[4]))
				appfile.Target_Datastore = tk.ToString(removeQuote(data[5]))
				appfile.Target_Connection = tk.ToString(removeQuote(data[6]))

				_, tempWeek := time.Date(datadate.Year(), datadate.Month(), datadate.Day(), 0, 0, 0, 0, time.UTC).ISOWeek()
				Week_Start, Week_End := GetStartAndEndDateOfTheWeek(datadate)
				appfile.Period = Period{
					Actual_Period: datadate,
					Period:        time.Date(datadate.Year(), datadate.Month(), 1, 0, 0, 0, 0, time.UTC),
					Dates:         time.Date(datadate.Year(), datadate.Month(), datadate.Day(), 0, 0, 0, 0, time.UTC),
					Year:          datadate.Year(),
					Year_Month:    tk.ToInt(datadate.Format("200601"), "ROUNDINGAUTO"),
					Week:          tempWeek,
					Week_Start:    Week_Start,
					Week_End:      Week_End,
				}

				dataSumm := map[string]interface{}{"data": appfile}
				e = qinsertappfile.Exec(dataSumm)
				errorFlag = ErrorHandling(e, false)
				if e != nil {
					errorMessage = "Error while saving data : " + e.Error()
				}
			}

		}
	}
}

func moveFile(cfg map[string]string, filename string) {
	//move extracted file to "Done" Folder
	//err := os.Rename(filename, strings.Replace(filename, cfg["sourcefilepath"], cfg["dumpfilepath"], -1))
	err := os.Rename(filename, cfg["dumpfilepath"]+filepath.Base(filename))
	ErrorHandling(err, false)
}

func createLoadedFile(cfg map[string]string, filename string) (e error) {
	e = nil
	if strings.Contains(filename, ".csv") {
		e = ioutil.WriteFile(strings.Replace(filename, ".csv", cfg["markdone"], -1), []byte(""), 755)
	} else if strings.Contains(filename, ".CSV") {
		e = ioutil.WriteFile(strings.Replace(filename, ".CSV", cfg["markdone"], -1), []byte(""), 755)
	} else if strings.Contains(filename, ".txt") {
		e = ioutil.WriteFile(strings.Replace(filename, ".txt", cfg["markdone"], -1), []byte(""), 755)
	}

	return
}

func commitData(cfg map[string]string) (e error) {
	conn := connectMongo(cfg)
	defer conn.Close()

	//CDCSummary
	var obj *CDCSummary
	tempDatas := []tk.M{}

	group := tk.M{}
	e = Deserialize(`
		{
			"$group":{"_id":"", "num":{"$sum":1}}
		}
		`, &group)

	pipes := []tk.M{}
	pipes = append(pipes, group)

	csr, e := conn.NewQuery().From(obj.Temp_TableName()).Command("pipe", pipes).Cursor(nil)
	e = csr.Fetch(&tempDatas, 0, true)
	defer csr.Close()
	ErrorHandling(e, false)

	if len(tempDatas) > 0 {
		maxRow := tempDatas[0].GetInt("num")

		limitdata := tk.ToInt(cfg["limitdata"], "ROUNDINGAUTO")
		counter := 0

		for counter < maxRow {
			tempDatas2 := []tk.M{}

			csr, e := conn.NewQuery().From(obj.Temp_TableName()).Skip(counter).Take(limitdata).Cursor(nil)
			e = csr.Fetch(&tempDatas2, 0, true)
			ErrorHandling(e, false)

			qinsert := conn.NewQuery().From(obj.TableName()).SetConfig("multiexec", true).Insert()

			if len(tempDatas2) > 0 {
				for _, data := range tempDatas2 {
					e = qinsert.Exec(map[string]interface{}{"data": data})
					_ = ErrorHandling(e, false)
				}

			}
			counter += limitdata
			qinsert.Close()
		}
	}

	//DDLChanges
	var ddl *DDLChanges
	tempDatas = []tk.M{}

	group = tk.M{}
	e = Deserialize(`
		{
			"$group":{"_id":"", "num":{"$sum":1}}
		}
		`, &group)

	pipes = []tk.M{}
	pipes = append(pipes, group)

	csr, e = conn.NewQuery().From(ddl.Temp_TableName()).Command("pipe", pipes).Cursor(nil)
	e = csr.Fetch(&tempDatas, 0, true)
	ErrorHandling(e, false)

	if len(tempDatas) > 0 {
		maxRow := tempDatas[0].GetInt("num")

		limitdata := tk.ToInt(cfg["limitdata"], "ROUNDINGAUTO")
		counter := 0

		for counter < maxRow {
			tempDatas2 := []tk.M{}

			csr, e := conn.NewQuery().From(ddl.Temp_TableName()).Skip(counter).Take(limitdata).Cursor(nil)
			e = csr.Fetch(&tempDatas2, 0, true)
			ErrorHandling(e, false)

			qinsert := conn.NewQuery().From(ddl.TableName()).SetConfig("multiexec", true).Insert()

			if len(tempDatas2) > 0 {
				for _, data := range tempDatas2 {
					e = qinsert.Exec(map[string]interface{}{"data": data})
					_ = ErrorHandling(e, false)
				}

			}
			counter += limitdata
			qinsert.Close()
		}
	}

	//ServerHealth
	var serverhealth *ServerHealth
	tempDatas = []tk.M{}

	group = tk.M{}
	e = Deserialize(`
		{
			"$group":{"_id":"", "num":{"$sum":1}}
		}
		`, &group)

	pipes = []tk.M{}
	pipes = append(pipes, group)

	csr, e = conn.NewQuery().From(serverhealth.Temp_TableName()).Command("pipe", pipes).Cursor(nil)
	e = csr.Fetch(&tempDatas, 0, true)
	ErrorHandling(e, false)

	if len(tempDatas) > 0 {
		maxRow := tempDatas[0].GetInt("num")

		limitdata := tk.ToInt(cfg["limitdata"], "ROUNDINGAUTO")
		counter := 0

		for counter < maxRow {
			tempDatas2 := []tk.M{}

			csr, e := conn.NewQuery().From(serverhealth.Temp_TableName()).Skip(counter).Take(limitdata).Cursor(nil)
			e = csr.Fetch(&tempDatas2, 0, true)
			ErrorHandling(e, false)

			qinsert := conn.NewQuery().From(serverhealth.TableName()).SetConfig("multiexec", true).Insert()

			if len(tempDatas2) > 0 {
				for _, data := range tempDatas2 {
					e = qinsert.Exec(map[string]interface{}{"data": data})
					_ = ErrorHandling(e, false)
				}

			}
			counter += limitdata
			qinsert.Close()
		}
	}

	//ServerDisk
	var serverdisk *ServerDisk
	tempDatas = []tk.M{}

	group = tk.M{}
	e = Deserialize(`
		{
			"$group":{"_id":"", "num":{"$sum":1}}
		}
		`, &group)

	pipes = []tk.M{}
	pipes = append(pipes, group)

	csr, e = conn.NewQuery().From(serverdisk.Temp_TableName()).Command("pipe", pipes).Cursor(nil)
	e = csr.Fetch(&tempDatas, 0, true)
	ErrorHandling(e, false)

	if len(tempDatas) > 0 {
		maxRow := tempDatas[0].GetInt("num")

		limitdata := tk.ToInt(cfg["limitdata"], "ROUNDINGAUTO")
		counter := 0

		for counter < maxRow {
			tempDatas2 := []tk.M{}

			csr, e := conn.NewQuery().From(serverdisk.Temp_TableName()).Skip(counter).Take(limitdata).Cursor(nil)
			e = csr.Fetch(&tempDatas2, 0, true)
			ErrorHandling(e, false)

			qinsert := conn.NewQuery().From(serverdisk.TableName()).SetConfig("multiexec", true).Insert()

			if len(tempDatas2) > 0 {
				for _, data := range tempDatas2 {
					e = qinsert.Exec(map[string]interface{}{"data": data})
					_ = ErrorHandling(e, false)
				}

			}
			counter += limitdata
			qinsert.Close()
		}
	}

	//AppFile
	var appfile *AppFile
	tempDatas = []tk.M{}

	group = tk.M{}
	e = Deserialize(`
		{
			"$group":{"_id":"", "num":{"$sum":1}}
		}
		`, &group)

	pipes = []tk.M{}
	pipes = append(pipes, group)

	csr, e = conn.NewQuery().From(appfile.Temp_TableName()).Command("pipe", pipes).Cursor(nil)
	e = csr.Fetch(&tempDatas, 0, true)
	ErrorHandling(e, false)

	if len(tempDatas) > 0 {
		maxRow := tempDatas[0].GetInt("num")

		limitdata := tk.ToInt(cfg["limitdata"], "ROUNDINGAUTO")
		counter := 0

		for counter < maxRow {
			tempDatas2 := []tk.M{}

			csr, e := conn.NewQuery().From(appfile.Temp_TableName()).Skip(counter).Take(limitdata).Cursor(nil)
			e = csr.Fetch(&tempDatas2, 0, true)
			ErrorHandling(e, false)

			qinsert := conn.NewQuery().From(appfile.TableName()).SetConfig("multiexec", true).Insert()

			if len(tempDatas2) > 0 {
				for _, data := range tempDatas2 {
					e = qinsert.Exec(map[string]interface{}{"data": data})
					_ = ErrorHandling(e, false)
				}

			}
			counter += limitdata
			qinsert.Close()
		}
	}
	return
}

func rollbackData(cfg map[string]string) (e error) {
	conn := connectMongo(cfg)
	defer conn.Close()

	var obj *CDCSummary

	qdelete := conn.NewQuery().From(obj.Temp_TableName()).SetConfig("multiexec", true).Delete()
	e = qdelete.Exec(nil)
	_ = ErrorHandling(e, false)
	qdelete.Close()

	var ddl *DDLChanges

	qddldelete := conn.NewQuery().From(ddl.Temp_TableName()).SetConfig("multiexec", true).Delete()
	e = qddldelete.Exec(nil)
	_ = ErrorHandling(e, false)
	qddldelete.Close()

	var serverhealth *ServerHealth

	qserverhealth := conn.NewQuery().From(serverhealth.Temp_TableName()).SetConfig("multiexec", true).Delete()
	e = qserverhealth.Exec(nil)
	_ = ErrorHandling(e, false)
	qserverhealth.Close()

	var serverdisk *ServerDisk

	qserverdisk := conn.NewQuery().From(serverdisk.Temp_TableName()).SetConfig("multiexec", true).Delete()
	e = qserverdisk.Exec(nil)
	_ = ErrorHandling(e, false)
	qserverdisk.Close()

	var appfile *AppFile

	qappfile := conn.NewQuery().From(appfile.Temp_TableName()).SetConfig("multiexec", true).Delete()
	e = qappfile.Exec(nil)
	_ = ErrorHandling(e, false)
	qappfile.Close()

	return
}

func sendAlert(errorOccured bool) {
	wdpath, _ := os.Getwd()
	path := strings.Replace(wdpath+"/conf/app.conf", "consoleapps", "webapp", -1)
	cfg := ReadConfigWithPath(path)

	if errorOccured {
		//error alert
		SendEmail("", "", "Error Alert", errorMessage)
	}

	endofdayhour := tk.ToInt(cfg["emailtime"], "ROUNDINGAUTO")

	if time.Now().Hour() == endofdayhour {
		dataSubs := GetSummaryEODEmail(cfg)
		dataDDL := GetSummaryDDLEmail(cfg)
		//SendEmail("", "", "End Of Day Report", CreateEODHTMLTemplate(dataSubs, dataDDL))
		SendEmailMailx(cfg["emailrecipient"], cfg["emailsender"], "CDC - End Of Day Report", CreateEODHTMLTemplate(dataSubs, dataDDL))
	}

	dataServerStatus := GetAlertServerStatus(cfg)
	dataDSFailure := GetAlertDatastoreFailure(cfg)
	dataSubsFailure := GetAlertSubscriptonFailure(cfg)
	// SendEmail("", "", "Server Status and Failures Alert", CreateHAHTMLTemplate(dataServerStatus, dataDSFailure, dataSubsFailure))
	SendEmailMailx(cfg["emailrecipient"], cfg["emailsender"], "CDC - Server Status and Failures Alert", CreateHAHTMLTemplate(dataServerStatus, dataDSFailure, dataSubsFailure))

	dataSubsLatency := GetAlertSubscriptonLatency(cfg)
	// SendEmail("", "", "Latency Alert (above "+cfg["latencythreshold"]+" mins)", CreateLHAHTMLTemplate(dataSubsLatency))
	SendEmailMailx(cfg["emailrecipient"], cfg["emailsender"], "Latency Alert (above "+cfg["latencythreshold"]+" mins)", CreateLHAHTMLTemplate(dataSubsLatency))
}

func GetSummaryEODEmail(cfg map[string]string) []tk.M {
	conn := connectMongo(cfg)
	defer conn.Close()

	pipes := []tk.M{}
	grouping := tk.M{}
	sorting := tk.M{}
	whereClause := []tk.M{}

	var obj *CDCSummary

	type retVal struct {
		host              string
		application       string
		country           string
		num_subs          int
		num_subs_failed   int
		num_subs_inactive int
		num_subs_unknown  int
		num_subs_latency  int
		now_failed        int
		now_latency       int
	}

	today := time.Date(time.Now().Year(), time.Now().Month(), time.Now().Day(), 0, 0, 0, 0, time.UTC).UTC()
	tomorrow := today.AddDate(0, 0, 1).UTC()

	// today := time.Date(2017, time.Month(9), 13, 0, 0, 0, 0, time.UTC).UTC()
	// tomorrow := today.AddDate(0, 0, 1).UTC()

	// tk.Println(today)
	// tk.Println(tomorrow)

	whereClause = append(whereClause, tk.M{"Current_Timestamp": tk.M{"$gte": today.UTC()}})   //remarked
	whereClause = append(whereClause, tk.M{"Current_Timestamp": tk.M{"$lt": tomorrow.UTC()}}) //remarked
	whereClause = append(whereClause, tk.M{"Data_Source": "Subscription Status Info"})

	pipes = append(pipes, tk.M{"$match": tk.M{"$and": whereClause}})

	err := Deserialize(`
		{
			"$group":
			{
				"_id":{
					"server":"$Access_Server_Host",
					"apps":"$Subscription_Status_Info_Application_Name"
				},
				"num_subs":{"$addToSet":"$Subscription"}
			}
		}
		`, &grouping)

	pipes = append(pipes, grouping)

	err = Deserialize(`
		{
			"$sort":
			{
				"_id.server":1
			}
		}
		`, &sorting)

	pipes = append(pipes, sorting)

	apps := []tk.M{}
	csr, err := conn.NewQuery().Command("pipe", pipes).
		From(obj.TableName()).
		Cursor(nil)
	err = csr.Fetch(&apps, 0, false)
	defer csr.Close()
	if err != nil {
		ErrorHandling(err, false)
	}

	var arrRetVal []tk.M

	if len(apps) > 0 {
		for idx := range apps {
			id, _ := tk.ToM(apps[idx]["_id"])

			ret := retVal{}
			ret.host = id.GetString("server")
			ret.application = id.GetString("apps")
			ret.num_subs = len(apps[idx].Get("num_subs").([]interface{}))

			if ret.num_subs > 0 {
				var subscriptions []string
				for _, sub := range apps[idx].Get("num_subs").([]interface{}) {
					subscriptions = append(subscriptions, tk.ToString(sub))
				}

				//get countries
				countrypipes := []tk.M{}
				countryWhereClause := []tk.M{}
				countryWhereClause = append(countryWhereClause, tk.M{"Host": ret.host})
				countryWhereClause = append(countryWhereClause, tk.M{"Subscription": tk.M{"$in": subscriptions}})
				countrypipes = append(countrypipes, tk.M{"$match": tk.M{"$and": countryWhereClause}})
				err := Deserialize(`
					{
						"$group":
						{
							"_id":"",
							"countries":{"$addToSet":"$Country"}
						}
					}
					`, &grouping)

				countrypipes = append(countrypipes, grouping)

				countries := []tk.M{}
				csr, err := conn.NewQuery().Command("pipe", countrypipes).
					From("SubsCountry").
					Cursor(nil)
				err = csr.Fetch(&countries, 0, false)
				defer csr.Close()
				if err != nil {
					ErrorHandling(err, false)
				}

				if len(countries) > 0 {
					var allcountry []string
					for _, country := range countries[0].Get("countries").([]interface{}) {
						allcountry = append(allcountry, tk.ToString(country))
					}

					ret.country = strings.Join(allcountry, ", ")
				}

				//get failed etc
				detailedWhereClause := []tk.M{}
				detailedPipes := []tk.M{}
				detailedWhereClause = append(detailedWhereClause, tk.M{"Access_Server_Host": ret.host})
				detailedWhereClause = append(detailedWhereClause, tk.M{"Subscription_Status_Info_Application_Name": ret.application})

				for i := range whereClause {
					detailedWhereClause = append(detailedWhereClause, whereClause[i])
				}

				detailedWhereClause = append(detailedWhereClause, tk.M{"Subscription_Status_Info_State": tk.M{"$in": []string{"Failed", "Inactive", "Unknown"}}})
				detailedPipes = append(detailedPipes, tk.M{"$match": tk.M{"$and": detailedWhereClause}})

				err = Deserialize(`
					{
						"$group":
						{
							"_id":{
								"state":"$Subscription_Status_Info_State"
							},
							"num_subs":{"$addToSet":"$Subscription"}
						}
					}
					`, &grouping)

				detailedPipes = append(detailedPipes, grouping)

				statuses := []tk.M{}
				csr, err = conn.NewQuery().Command("pipe", detailedPipes).
					From(obj.TableName()).
					Cursor(nil)
				err = csr.Fetch(&statuses, 0, false)
				defer csr.Close()
				if err != nil {
					ErrorHandling(err, false)
				}

				if len(statuses) > 0 {
					for status := range statuses {
						statusid, _ := tk.ToM(statuses[status]["_id"])
						if statusid.GetString("state") == "Failed" {
							ret.num_subs_failed = len(statuses[0].Get("num_subs").([]interface{}))
						} else if statusid.GetString("state") == "Inactive" {
							ret.num_subs_inactive = len(statuses[0].Get("num_subs").([]interface{}))
						} else if statusid.GetString("state") == "Unknown" {
							ret.num_subs_unknown = len(statuses[0].Get("num_subs").([]interface{}))
						}
					}
				}

				for _, cond := range detailedWhereClause {
					if cond.Has("Subscription_Status_Info_State") {
						cond.Set("Subscription_Status_Info_State", []string{"Mirror Continuous"})
					}
				}

				detailedWhereClause = append(detailedWhereClause, tk.M{"Subscription_Status_Info_Latency": tk.M{"$gt": tk.ToInt(cfg["latencythreshold"], "ROUNDINGAUTO") * 60}})
				detailedPipes = []tk.M{}
				detailedPipes = append(detailedPipes, tk.M{"$match": tk.M{"$and": detailedWhereClause}})

				err = Deserialize(`
					{
						"$group":
						{
							"_id":{
								"state":"$Subscription_Status_Info_State"
							},
							"num_subs":{"$addToSet":"$Subscription"}
						}
					}
					`, &grouping)

				detailedPipes = append(detailedPipes, grouping)

				statuses = []tk.M{}
				csr, err = conn.NewQuery().Command("pipe", detailedPipes).
					From(obj.TableName()).
					Cursor(nil)
				err = csr.Fetch(&statuses, 0, false)
				defer csr.Close()
				if err != nil {
					ErrorHandling(err, false)
				}

				if len(statuses) > 0 {
					for status := range statuses {
						statusid, _ := tk.ToM(statuses[status]["_id"])
						if statusid.GetString("state") == "Mirror Continuous" {
							ret.num_subs_latency = len(statuses[0].Get("num_subs").([]interface{}))
						}
					}
				}

				nowClause := []tk.M{}
				nowClause = append(nowClause, tk.M{"Access_Server_Host": ret.host})
				nowClause = append(nowClause, tk.M{"Data_Source": "Subscription Status Info"})

				nowpipes := []tk.M{}
				nowpipes = append(nowpipes, tk.M{"$match": tk.M{"$and": nowClause}})

				nowgroup := tk.M{}
				err = Deserialize(`
					{
						"$group":
						{
							"_id":"",
							"maxdate":{"$max":"$Current_Timestamp"}
						}
					}
					`, &nowgroup)
				nowpipes = append(nowpipes, nowgroup)

				latestdates := []tk.M{}
				csr, err = conn.NewQuery().Command("pipe", detailedPipes).
					From(obj.TableName()).
					Cursor(nil)
				err = csr.Fetch(&latestdates, 0, false)
				defer csr.Close()
				if err != nil {
					ErrorHandling(err, false)
				}

				var latdates time.Time
				if len(latestdates) > 0 {
					latdates = latestdates[0].Get("maxdate").(time.Time)
				}

				nowClause = append(nowClause, tk.M{"Current_Timestamp": latdates})
				nowClause = append(nowClause, tk.M{"Subscription_Status_Info_State": tk.M{"$in": []string{"Failed", "Mirror Continuous"}}})
				nowpipes = []tk.M{}
				nowpipes = append(nowpipes, tk.M{"$match": tk.M{"$and": nowClause}})

				nowgroup = tk.M{}
				err = Deserialize(`
					{
						"$group":
						{
							"_id":{
								"status":"Subscription_Status_Info_State",
								"subs":"$Subscription",
								"latency":"$Subscription_Status_Info_Latency"
							}
						}
					}
					`, &nowgroup)
				nowpipes = append(nowpipes, nowgroup)

				asofnow := []tk.M{}
				csr, err = conn.NewQuery().Command("pipe", detailedPipes).
					From(obj.TableName()).
					Cursor(nil)
				err = csr.Fetch(&asofnow, 0, false)
				defer csr.Close()
				if err != nil {
					ErrorHandling(err, false)
				}

				if len(asofnow) > 0 {
					asof_failed := 0
					asof_latency := 0
					for asofidx := range asofnow {
						asofid, _ := tk.ToM(asofnow[asofidx]["_id"])

						if asofid.GetString("status") == "Failed" {
							asof_failed += 1
						} else if asofid.GetString("status") == "Mirror Countinuous" {
							if asofid.GetInt("latency") > tk.ToInt(cfg["latencythreshold"], "ROUNDINGAUTO") {
								asof_latency += 1
							}
						}
					}

					ret.now_failed = asof_failed
					ret.now_latency = asof_latency

				}

			}
			val := tk.M{
				"host":              ret.host,
				"application":       ret.application,
				"country":           ret.country,
				"num_subs":          ret.num_subs,
				"num_subs_failed":   ret.num_subs_failed,
				"num_subs_inactive": ret.num_subs_inactive,
				"num_subs_unknown":  ret.num_subs_unknown,
				"num_subs_latency":  ret.num_subs_latency,
				"now_failed":        ret.now_failed,
				"now_latency":       ret.now_latency,
			}
			arrRetVal = append(arrRetVal, val)
		}
	}

	return arrRetVal
}

func GetSummaryDDLEmail(cfg map[string]string) []tk.M {
	conn := connectMongo(cfg)
	defer conn.Close()

	pipes := []tk.M{}
	grouping := tk.M{}
	grouping2 := tk.M{}
	sorting := tk.M{}
	whereClause := []tk.M{}

	var obj *DDLChanges
	var cdc *CDCSummary

	type retVal struct {
		host        string
		application string
		country     string
		num_add     int
		num_mod     int
		num_drop    int
		tables      string
	}

	var datas []tk.M

	today := time.Date(time.Now().Year(), time.Now().Month(), time.Now().Day(), 0, 0, 0, 0, time.UTC).UTC()
	tomorrow := today.AddDate(0, 0, 1).UTC()

	// today := time.Date(2017, time.Month(9), 13, 0, 0, 0, 0, time.UTC).UTC()
	// tomorrow := today.AddDate(0, 0, 1).UTC()

	// tk.Println(today)
	// tk.Println(tomorrow)

	whereClause = append(whereClause, tk.M{"Period.Actual_Period": tk.M{"$gte": today.UTC()}})   //remarked
	whereClause = append(whereClause, tk.M{"Period.Actual_Period": tk.M{"$lt": tomorrow.UTC()}}) //remarked

	pipes = append(pipes, tk.M{"$match": tk.M{"$and": whereClause}})

	err := Deserialize(`
		{
			"$group":
			{
				"_id":{
					"server":"$Host_Name",
					"subscription":"$Subscription"
				}
			}
		}
		`, &grouping)

	pipes = append(pipes, grouping)

	err = Deserialize(`
		{
			"$sort":
			{
				"_id.server":1
			}
		}
		`, &sorting)

	pipes = append(pipes, sorting)

	subs := []tk.M{}
	csr, err := conn.NewQuery().Command("pipe", pipes).
		From(obj.TableName()).
		Cursor(nil)
	err = csr.Fetch(&subs, 0, false)
	defer csr.Close()
	if err != nil {
		ErrorHandling(err, false)
	}

	if len(subs) > 0 {
		pipes = []tk.M{}
		grouping = tk.M{}
		sorting = tk.M{}
		var sublist []string
		var hostlist []string
		for idsub := range subs {
			sub, _ := tk.ToM(subs[idsub]["_id"])
			sublist = append(sublist, sub.GetString("subscription"))
			hostlist = append(hostlist, sub.GetString("server"))
		}

		whereClause = append(whereClause, tk.M{"Subscription": tk.M{"$in": sublist}})        //remarked
		whereClause = append(whereClause, tk.M{"Access_Server_Host": tk.M{"$in": hostlist}}) //remarked
		whereClause = append(whereClause, tk.M{"Data_Source": "Subscription Status Info"})

		pipes = append(pipes, tk.M{"$match": tk.M{"$and": whereClause}})

		err = Deserialize(`
		{
			"$group":
			{
				"_id":{
					"host":"$Access_Server_Host",
					"apps":"$Subscription_Status_Info_Application_Name",
					"subs":"$Subscription"
				}
			}
		}
		`, &grouping)

		pipes = append(pipes, grouping)

		err = Deserialize(`
		{
			"$group":
			{
				"_id":{
					"apps":"$_id.apps",
					"host":"$_id.host"
				},
				"subs": {"$addToSet":"$_id.subs"}
			}
		}
		`, &grouping2)

		pipes = append(pipes, grouping2)

		err = Deserialize(`
		{
			"$sort":
			{
				"_id.host":1
			}
		}
		`, &sorting)

		pipes = append(pipes, sorting)

		apps := []tk.M{}
		csr, err := conn.NewQuery().Command("pipe", pipes).
			From(cdc.TableName()).
			Cursor(nil)
		err = csr.Fetch(&apps, 0, false)
		defer csr.Close()
		if err != nil {
			ErrorHandling(err, false)
		}

		if len(apps) > 0 {
			for appidx := range apps {
				id, _ := tk.ToM(apps[appidx]["_id"])

				var stringsubs []string
				for _, subsint := range apps[appidx].Get("subs").([]interface{}) {
					stringsubs = append(stringsubs, subsint.(string))
				}

				var val retVal
				val.host = id.GetString("host")
				val.application = id.GetString("apps")

				//get countries
				countrypipes := []tk.M{}
				countryWhereClause := []tk.M{}
				countryWhereClause = append(countryWhereClause, tk.M{"Host": val.host})
				countryWhereClause = append(countryWhereClause, tk.M{"Subscription": tk.M{"$in": stringsubs}})
				countrypipes = append(countrypipes, tk.M{"$match": tk.M{"$and": countryWhereClause}})
				err := Deserialize(`
					{
						"$group":
						{
							"_id":"",
							"countries":{"$addToSet":"$Country"}
						}
					}
					`, &grouping)

				countrypipes = append(countrypipes, grouping)

				countries := []tk.M{}
				csr, err := conn.NewQuery().Command("pipe", countrypipes).
					From("SubsCountry").
					Cursor(nil)
				err = csr.Fetch(&countries, 0, false)
				defer csr.Close()
				if err != nil {
					ErrorHandling(err, false)
				}

				if len(countries) > 0 {
					var allcountry []string
					for _, country := range countries[0].Get("countries").([]interface{}) {
						allcountry = append(allcountry, tk.ToString(country))
					}

					val.country = strings.Join(allcountry, ", ")
				}

				pipes = []tk.M{}
				whereClause = []tk.M{}
				grouping = tk.M{}
				grouping2 = tk.M{}

				whereClause = append(whereClause, tk.M{"Period.Actual_Period": tk.M{"$gte": today.UTC()}})
				whereClause = append(whereClause, tk.M{"Period.Actual_Period": tk.M{"$lt": tomorrow.UTC()}})
				whereClause = append(whereClause, tk.M{"Subscription": tk.M{"$in": stringsubs}})
				whereClause = append(whereClause, tk.M{"Host_Name": tk.M{"$eq": val.host}})

				pipes = append(pipes, tk.M{"$match": tk.M{"$and": whereClause}})

				err = Deserialize(`
					{
						"$group":
						{
							"_id":{
								"activity":"$Activity",
								"tables":"$Table_Name"
							},
							"ddl":{"$sum":1}
						}
					}
					`, &grouping)

				pipes = append(pipes, grouping)

				err = Deserialize(`
					{
						"$group":
						{
							"_id":{
								"activity":"$_id.activity"
							},
							"ddl":{"$sum":"$ddl"},
							"tables":{"$addToSet":"$_id.tables"}
						}
					}
					`, &grouping2)

				pipes = append(pipes, grouping2)

				results := []tk.M{}
				csr, err = conn.NewQuery().Command("pipe", pipes).
					From(obj.TableName()).
					Cursor(nil)
				err = csr.Fetch(&results, 0, false)
				defer csr.Close()
				if err != nil {
					ErrorHandling(err, false)
				}

				if len(results) > 0 {
					coladd := 0
					colmod := 0
					coldrop := 0
					tables := []string{}
					for resid := range results {
						resultid, _ := tk.ToM(results[resid]["_id"])

						switch resultid.GetString("activity") {
						case "COL ADD":
							coladd++
						case "COL MOD":
							colmod++
						case "COL DEL":
							coldrop++
						}

						tabs := results[resid].Get("tables").([]string)
						if len(tabs) > 0 {
							for _, tab := range tabs {
								tables = append(tables, tab)
							}
						}
					}

					val.num_add = coladd
					val.num_mod = colmod
					val.num_drop = coldrop
					val.tables = strings.Join(tables, ",")
				}

				returndata := tk.M{
					"server":      val.host,
					"application": val.application,
					"country":     val.country,
					"num_add":     val.num_add,
					"num_mod":     val.num_mod,
					"num_drop":    val.num_drop,
					"tables":      val.tables,
				}

				datas = append(datas, returndata)
			}
		}
	}
	return datas
}

func GetAlertServerStatus(cfg map[string]string) []tk.M {
	conn := connectMongo(cfg)
	defer conn.Close()

	var obj *CDCSummary

	pipes := []tk.M{}
	grouping := tk.M{}
	grouping2 := tk.M{}
	sorting := tk.M{}
	whereClause := []tk.M{}

	type serverstatus struct {
		server string
		status string
	}

	retVal := []tk.M{}

	//GetServerStatus
	whereClause = append(whereClause, tk.M{"Data_Source": "Access Server"})

	pipes = append(pipes, tk.M{"$match": tk.M{"$and": whereClause}})

	err := Deserialize(`
		{
			"$group":
			{
				"_id":{
					"server":"$Access_Server_Host",
					"connection_status":"$Access_Server_Status",
					"timestamp":"$Current_Timestamp"
				}
			}
		}
		`, &grouping)

	pipes = append(pipes, grouping)

	err = Deserialize(`
		{
	  		"$group":
	  		{
	    		"_id":{
	    			"server":"$_id.server"
	    		},
	    	"conn":{"$max":"$_id.connection_status"}
	  		}
		}
		`, &grouping2)

	pipes = append(pipes, grouping2)

	err = Deserialize(`
		{
			"$sort":
			{
				"_id.server":1
			}
		}
		`, &sorting)

	pipes = append(pipes, sorting)

	servers := []tk.M{}
	csr, err := conn.NewQuery().Command("pipe", pipes).
		From(obj.TableName()).
		Cursor(nil)
	defer csr.Close()
	err = csr.Fetch(&servers, 0, false)
	ErrorHandling(err, false)

	if len(servers) > 0 {
		for _, server := range servers {
			var serv serverstatus
			id, _ := tk.ToM(server["_id"])
			serv.server = id.GetString("server")
			serv.status = server.GetString("conn")

			retVal = append(retVal, tk.M{
				"server": serv.server,
				"status": serv.status,
			})
		}
	}

	return retVal
}

func GetAlertDatastoreFailure(cfg map[string]string) []tk.M {
	conn := connectMongo(cfg)
	defer conn.Close()

	var obj *CDCSummary
	var objCountry *SubsCountry
	var objApps *AppFile

	pipes := []tk.M{}
	grouping := tk.M{}
	sorting := tk.M{}
	whereClause := []tk.M{}

	type datastorefailure struct {
		host          string
		port          string
		application   string
		country       string
		datastorename string
		datastoretype string
		status        string
	}

	retVal := []tk.M{}

	whereClause = append(whereClause, tk.M{"Data_Source": "Data Store Status"})
	whereClause = append(whereClause, tk.M{"Data_Store_Status": tk.M{"$ne": "Connected"}})
	pipes = append(pipes, tk.M{"$match": tk.M{"$and": whereClause}})

	err := Deserialize(`
		{
			"$group":
			{
				"_id":"",
				"period":{"$max":"$Current_Timestamp"}
			}
		}
		`, &grouping)

	pipes = append(pipes, grouping)

	period := []tk.M{}
	var latestperiod time.Time
	csr, err := conn.NewQuery().Command("pipe", pipes).
		From(obj.TableName()).
		Cursor(nil)
	defer csr.Close()
	err = csr.Fetch(&period, 0, false)
	ErrorHandling(err, false)

	if len(period) > 0 {
		latestperiod = period[0].Get("period").(time.Time).UTC()
		latestperiod = latestperiod.Add(time.Minute * (-10)).UTC()
		//latestperiod = time.Date(latestperiod.Year(), latestperiod.Month(), latestperiod.Day(), latestperiod.Hour(), 0, 0, 0, time.UTC)
	}

	pipes = []tk.M{}
	grouping = tk.M{}

	whereClause = append(whereClause, tk.M{"Current_Timestamp": tk.M{"$gte": latestperiod.UTC()}})
	pipes = append(pipes, tk.M{"$match": tk.M{"$and": whereClause}})

	err = Deserialize(`
		{
			"$group":
			{
				"_id":{
					"port":"$Access_Server_Port",
					"server":"$Access_Server_Host",
					"dsname":"$Data_Store_Name",
					"dstype":"$Data_Store_Type"
				},
				"status":{"$max":"$Data_Store_Status"}
			}
		}
		`, &grouping)

	pipes = append(pipes, grouping)

	err = Deserialize(`
		{
			"$sort":
			{
				"_id.server":1
			}
		}
		`, &sorting)

	pipes = append(pipes, sorting)

	datas := []tk.M{}
	csr, err = conn.NewQuery().Command("pipe", pipes).
		From(obj.TableName()).
		Cursor(nil)
	defer csr.Close()
	err = csr.Fetch(&datas, 0, false)
	ErrorHandling(err, false)

	//get country list
	countries := []tk.M{}
	csr, err = conn.NewQuery().From(objCountry.TableName()).Cursor(nil)
	err = csr.Fetch(&countries, 0, false)
	defer csr.Close()
	ErrorHandling(err, false)

	//get app list
	apps := []tk.M{}
	csr, err = conn.NewQuery().From(objApps.TableName()).Cursor(nil)
	err = csr.Fetch(&apps, 0, false)
	defer csr.Close()
	ErrorHandling(err, false)

	if len(datas) > 0 {
		for idx := range datas {
			selected_country := ""
			selected_apps := ""
			id, _ := tk.ToM(datas[idx]["_id"])

			var datastore datastorefailure
			datastore.datastoretype = id.GetString("dstype")
			datastore.host = id.GetString("server")
			datastore.port = id.GetString("port")
			datastore.datastorename = id.GetString("dsname")
			datastore.status = datas[idx].GetString("status")

			if strings.ToLower("datastorefailure.datastoretype") == "source" || strings.ToLower("datastorefailure.datastoretype") == "dual" {
				if len(apps) > 0 {
					for _, app := range apps {
						if app.GetString("Host_Name") == datastore.host && app.GetString("Host_Port") == datastore.port && app.GetString("Source_Datastore") == datastore.datastorename {
							selected_apps = app.GetString("App_Name")
						}
					}
				}
			} else if strings.ToLower("datastorefailure.datastoretype") == "target" || strings.ToLower("datastorefailure.datastoretype") == "dual" {
				if len(apps) > 0 {
					for _, app := range apps {
						if app.GetString("Host_Name") == datastore.host && app.GetString("Host_Port") == datastore.port && app.GetString("Target_Datastore") == datastore.datastorename {
							selected_apps = app.GetString("App_Name")
						}
					}
				}
			}

			if len(countries) > 0 {
				for _, country := range countries {
					if strings.ToLower("datastorefailure.datastoretype") == "source" || strings.ToLower("datastorefailure.datastoretype") == "dual" {
						if country.GetString("Host") == datastore.host && country.GetString("Source_Datastore") == datastore.datastorename {
							selected_country = country.GetString("Country")
						}
					} else if strings.ToLower("datastorefailure.datastoretype") == "target" || strings.ToLower("datastorefailure.datastoretype") == "dual" {
						if country.GetString("Host") == datastore.host && country.GetString("Target_Datastore") == datastore.datastorename {
							selected_country = country.GetString("Country")
						}
					}
				}
			}
			datastore.application = selected_apps
			datastore.country = selected_country

			retVal = append(retVal, tk.M{
				"host":          datastore.host,
				"apps":          datastore.application,
				"status":        datastore.status,
				"country":       datastore.country,
				"port":          datastore.port,
				"datastorename": datastore.datastorename,
				"datastoretype": datastore.datastoretype,
			})
		}
	}

	return retVal
}

func GetAlertSubscriptonFailure(cfg map[string]string) []tk.M {
	conn := connectMongo(cfg)
	defer conn.Close()

	var obj *CDCSummary
	var objCountry *SubsCountry

	pipes := []tk.M{}
	grouping := tk.M{}
	sorting := tk.M{}
	whereClause := []tk.M{}

	type subsfailure struct {
		host         string
		application  string
		country      string
		source       string
		target       string
		subscription string
		status       string
	}

	retVal := []tk.M{}

	whereClause = append(whereClause, tk.M{"Data_Source": "Subscription Status Info"})
	whereClause = append(whereClause, tk.M{"Subscription_Status_Info_State": tk.M{"$ne": "Mirror Continuous"}}) //remarked
	pipes = append(pipes, tk.M{"$match": tk.M{"$and": whereClause}})

	err := Deserialize(`
		{
			"$group":
			{
				"_id":"",
				"period":{"$max":"$Current_Timestamp"}
			}
		}
		`, &grouping)

	pipes = append(pipes, grouping)

	period := []tk.M{}
	var latestperiod time.Time
	csr, err := conn.NewQuery().Command("pipe", pipes).
		From(obj.TableName()).
		Cursor(nil)
	defer csr.Close()
	err = csr.Fetch(&period, 0, false)
	ErrorHandling(err, false)

	if len(period) > 0 {
		latestperiod = period[0].Get("period").(time.Time).UTC()
		latestperiod = latestperiod.Add(time.Minute * (-10)).UTC()
		//latestperiod = time.Date(latestperiod.Year(), latestperiod.Month(), latestperiod.Day(), latestperiod.Hour(), 0, 0, 0, time.UTC)
	}

	pipes = []tk.M{}
	grouping = tk.M{}

	whereClause = append(whereClause, tk.M{"Current_Timestamp": tk.M{"$gte": latestperiod.UTC()}})
	pipes = append(pipes, tk.M{"$match": tk.M{"$and": whereClause}})

	err = Deserialize(`
		{
			"$group":
			{
				"_id":{
					"server":"$Access_Server_Host",
					"apps":"$Subscription_Status_Info_Application_Name",
					"subscription":"$Subscription"
				},
				"source_datasource":{"$max":"$Subscription_Status_Info_Source_Datastore"},
				"target_datasource":{"$max":"$Subscription_Status_Info_Target_Datastore"},
				"status":{"$max":"$Subscription_Status_Info_State"}
			}
		}
		`, &grouping)

	pipes = append(pipes, grouping)

	err = Deserialize(`
		{
			"$sort":
			{
				"_id.server":1
			}
		}
		`, &sorting)

	pipes = append(pipes, sorting)

	datas := []tk.M{}
	csr, err = conn.NewQuery().Command("pipe", pipes).
		From(obj.TableName()).
		Cursor(nil)
	defer csr.Close()
	err = csr.Fetch(&datas, 0, false)
	ErrorHandling(err, false)

	//get country list
	countries := []tk.M{}
	csr, err = conn.NewQuery().From(objCountry.TableName()).Cursor(nil)
	err = csr.Fetch(&countries, 0, false)
	defer csr.Close()
	ErrorHandling(err, false)

	if len(datas) > 0 {
		for idx := range datas {
			selected_country := ""
			id, _ := tk.ToM(datas[idx]["_id"])

			var subs subsfailure
			subs.host = id.GetString("server")
			subs.application = id.GetString("apps")
			subs.subscription = id.GetString("subscription")
			subs.source = datas[idx].GetString("source_datasource")
			subs.target = datas[idx].GetString("Subscription_Status_Info_Target_Datastore")
			subs.status = datas[idx].GetString("status")

			if len(countries) > 0 {
				for _, country := range countries {
					if country.GetString("Host") == subs.host && country.GetString("Subscription") == subs.subscription && country.GetString("Source_Datastore") == subs.source && country.GetString("Target_Datastore") == subs.target {
						selected_country = country.GetString("Country")
					}
				}
			}

			subs.country = selected_country

			retVal = append(retVal, tk.M{
				"host":    subs.host,
				"apps":    subs.application,
				"subs":    subs.subscription,
				"status":  subs.status,
				"source":  subs.source,
				"target":  subs.target,
				"country": subs.country,
			})
		}
	}

	return retVal
}

func GetAlertSubscriptonLatency(cfg map[string]string) []tk.M {
	conn := connectMongo(cfg)
	defer conn.Close()

	var obj *CDCSummary
	var objCountry *SubsCountry

	pipes := []tk.M{}
	grouping := tk.M{}
	sorting := tk.M{}
	whereClause := []tk.M{}

	type subslatency struct {
		host         string
		application  string
		country      string
		source       string
		target       string
		subscription string
		status       string
		latency      int
	}

	retVal := []tk.M{}
	latencythreshold := tk.ToInt(cfg["latencythreshold"], "ROUNDINGAUTO") * 60

	whereClause = append(whereClause, tk.M{"Data_Source": "Subscription Status Info"})
	whereClause = append(whereClause, tk.M{"Subscription_Status_Info_State": tk.M{"$eq": "Mirror Continuous"}})
	whereClause = append(whereClause, tk.M{"Subscription_Status_Info_Latency": tk.M{"$gt": latencythreshold}}) //remarked
	pipes = append(pipes, tk.M{"$match": tk.M{"$and": whereClause}})

	err := Deserialize(`
		{
			"$group":
			{
				"_id":"",
				"period":{"$max":"$Current_Timestamp"}
			}
		}
		`, &grouping)

	pipes = append(pipes, grouping)

	period := []tk.M{}
	var latestperiod time.Time
	csr, err := conn.NewQuery().Command("pipe", pipes).
		From(obj.TableName()).
		Cursor(nil)
	defer csr.Close()
	err = csr.Fetch(&period, 0, false)
	ErrorHandling(err, false)

	if len(period) > 0 {
		latestperiod = period[0].Get("period").(time.Time).UTC()
		latestperiod = latestperiod.Add(time.Minute * (-10)).UTC()
		//latestperiod = time.Date(latestperiod.Year(), latestperiod.Month(), latestperiod.Day(), latestperiod.Hour(), 0, 0, 0, time.UTC)
	}

	pipes = []tk.M{}
	grouping = tk.M{}

	whereClause = append(whereClause, tk.M{"Current_Timestamp": tk.M{"$gte": latestperiod.UTC()}})
	pipes = append(pipes, tk.M{"$match": tk.M{"$and": whereClause}})

	err = Deserialize(`
		{
			"$group":
			{
				"_id":{
					"server":"$Access_Server_Host",
					"apps":"$Subscription_Status_Info_Application_Name",
					"subscription":"$Subscription"
				},
				"source_datasource":{"$max":"$Subscription_Status_Info_Source_Datastore"},
				"target_datasource":{"$max":"$Subscription_Status_Info_Target_Datastore"},
				"status":{"$max":"$Subscription_Status_Info_State"},
				"latency":{"$max":"$Subscription_Status_Info_Latency"}
			}
		}
		`, &grouping)

	pipes = append(pipes, grouping)

	err = Deserialize(`
		{
			"$sort":
			{
				"_id.server":1
			}
		}
		`, &sorting)

	pipes = append(pipes, sorting)

	datas := []tk.M{}
	csr, err = conn.NewQuery().Command("pipe", pipes).
		From(obj.TableName()).
		Cursor(nil)
	defer csr.Close()
	err = csr.Fetch(&datas, 0, false)
	ErrorHandling(err, false)

	//get country list
	countries := []tk.M{}
	csr, err = conn.NewQuery().From(objCountry.TableName()).Cursor(nil)
	err = csr.Fetch(&countries, 0, false)
	defer csr.Close()
	ErrorHandling(err, false)

	if len(datas) > 0 {
		for idx := range datas {
			selected_country := ""
			id, _ := tk.ToM(datas[idx]["_id"])

			var subs subslatency
			subs.host = id.GetString("server")
			subs.application = id.GetString("apps")
			subs.subscription = id.GetString("subscription")
			subs.source = datas[idx].GetString("source_datasource")
			subs.target = datas[idx].GetString("target_datasource")
			subs.status = datas[idx].GetString("status")
			subs.latency = datas[idx].GetInt("latency")

			hour := GetTwoNumber(subs.latency / 3600)
			mins := GetTwoNumber((subs.latency % 3600) / 60)

			threshour := GetTwoNumber(latencythreshold / 3600)
			thresmins := GetTwoNumber((latencythreshold % 3600) / 60)

			if len(countries) > 0 {
				for _, country := range countries {
					if country.GetString("Host") == subs.host && country.GetString("Subscription") == subs.subscription && country.GetString("Source_Datastore") == subs.source && country.GetString("Target_Datastore") == subs.target {
						selected_country = country.GetString("Country")
					}
				}
			}

			subs.country = selected_country

			retVal = append(retVal, tk.M{
				"host":    subs.host,
				"apps":    subs.application,
				"subs":    subs.subscription,
				"status":  subs.status,
				"source":  subs.source,
				"target":  subs.target,
				"country": subs.country,
				//"latency":   subs.latency,
				"latency": hour + ":" + mins,
				// "threshold": latencythreshold,
				"threshold": threshour + ":" + thresmins,
			})
		}
	}

	return retVal
}
