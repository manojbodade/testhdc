package main

import (
	. "eaciit/scb-cdc/consoleapps/functions"
	// . "eaciit/scb-cdc/webapp/helper"
	// "os"
	// "strings"
)

func main() {
	_, _ = RunConsole(true)

	// wdpath, _ := os.Getwd()
	// path := strings.Replace(wdpath+"/conf/app.conf", "consoleapps", "webapp", -1)
	// cfg := ReadConfigWithPath(path)
	// dataSubs := GetSummaryEODEmail(cfg)
	// dataDDL := GetSummaryDDLEmail(cfg)
	// SendEmailMailx(cfg["emailrecipient"], cfg["emailsender"], "CDC End Of Day Report", CreateEODHTMLTemplate(dataSubs, dataDDL))
}
